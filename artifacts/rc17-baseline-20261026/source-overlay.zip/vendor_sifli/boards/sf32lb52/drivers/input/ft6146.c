/****************************************************************************
 * vendor/sifli/boards/sf32lb52/drivers/input/ft6146.c
 *
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.  The
 * ASF licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <assert.h>
#include <debug.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>

#include <nuttx/clock.h>
#include <nuttx/input/touchscreen.h>
#include <nuttx/i2c/i2c_master.h>
#include <nuttx/kmalloc.h>
#include <nuttx/mutex.h>
#include <nuttx/wqueue.h>

#include "sifli_gpio.h"
#include "drv_io.h"

#include "ft6146.h"

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

#define FT6146_NAME_TOUCH     "input0"
#define FT6146_I2C_DEF_FREQ   400000
#define FT6146_DEV_ADDR        0x38

#define FT6146_REG_TD_STATUS   0x02
#define FT6146_REG_P1_XH       0x03
#define FT6146_REG_ID_H        0xa3
#define FT6146_REG_ID_L        0x9f

#define FT6146_EVENT_DOWN       0
#define FT6146_EVENT_UP         1
#define FT6146_EVENT_CONTACT    2
#define FT6146_EVENT_RESERVED   3
#define FT6146_POLL_INTERVAL_MS 8

/****************************************************************************
 * Private Types
 ****************************************************************************/

struct ft6146_touch_lowerhalf_s
{
  struct touch_lowerhalf_s lower;
  struct i2c_master_s *i2c;
  struct work_s work;
  mutex_t devlock;
  sem_t waitsem;
  uint32_t pin_irq;
  uint16_t last_x;
  uint16_t last_y;
  uint8_t last_id;
  bool contact_active;
};

/****************************************************************************
 * Private Function Prototypes
 ****************************************************************************/

static ssize_t ft6146_touch_notify(FAR void *input_lower,
                                   FAR const char *buffer,
                                   size_t buflen);
static ssize_t ft6146_touch_write(FAR struct touch_lowerhalf_s *input_lower,
                                  FAR const char *buffer,
                                  size_t buflen);
static void ft6146_irq_handler(void *arg);

static int ft6146_irq_enable(struct ft6146_touch_lowerhalf_s *ft6146,
                             bool enable)
{
  if (!enable)
    {
      return sifli_gpio_set_event(ft6146->pin_irq, false, false, NULL, NULL);
    }

  return sifli_gpio_set_event(ft6146->pin_irq, false, true,
                              ft6146_irq_handler, ft6146);
}

/****************************************************************************
 * Private Functions
 ****************************************************************************/

static int ft6146_i2c_read(struct i2c_master_s *i2c,
                           uint8_t reg, uint8_t *buf, uint8_t len)
{
  struct i2c_msg_s msgs[2];
  int ret;

  msgs[0].addr      = FT6146_DEV_ADDR;
  msgs[0].frequency = FT6146_I2C_DEF_FREQ;
  msgs[0].flags     = I2C_M_NOSTOP;
  msgs[0].buffer    = &reg;
  msgs[0].length    = 1;

  msgs[1].addr      = FT6146_DEV_ADDR;
  msgs[1].frequency = FT6146_I2C_DEF_FREQ;
  msgs[1].flags     = I2C_M_READ | I2C_M_NOSTART;
  msgs[1].buffer    = buf;
  msgs[1].length    = len;

  ret = I2C_TRANSFER(i2c, msgs, 2);
  return ret < 0 ? ret : OK;
}

static void ft6146_data_worker(void *param)
{
  struct ft6146_touch_lowerhalf_s *ft6146 =
    (struct ft6146_touch_lowerhalf_s *)param;
  struct touch_sample_s sample;
  uint8_t buf[5] = {0};
  uint8_t event;
  uint8_t touch_num;
  uint16_t x;
  uint16_t y;
  bool report = false;
  int ret;

  ret = ft6146_i2c_read(ft6146->i2c, FT6146_REG_TD_STATUS, buf, sizeof(buf));
  if (ret < 0)
    {
      ierr("ft6146: read touch data failed: %d\n", ret);
      goto out;
    }

  touch_num = buf[0] & 0x0f;

  memset(&sample, 0, sizeof(sample));
  sample.npoints = 1;
  if (touch_num > 0)
    {
      /* FT6146 point layout: XH(event[7:6]), XL, YH(id[7:4]), YL. */
      event = buf[1] >> 6;
      if (event == FT6146_EVENT_RESERVED)
        {
          goto out;
        }

      x = ((uint16_t)(buf[1] & 0x0f) << 8) | buf[2];
      y = ((uint16_t)(buf[3] & 0x0f) << 8) | buf[4];
      ft6146->last_id = buf[3] >> 4;

      if (event == FT6146_EVENT_UP)
        {
          sample.point[0].flags = TOUCH_UP;
          report = ft6146->contact_active;
          ft6146->contact_active = false;
        }
      else if (!ft6146->contact_active)
        {
          sample.point[0].flags = TOUCH_DOWN;
          report = true;
          ft6146->contact_active = true;
        }
      else
        {
          sample.point[0].flags = TOUCH_MOVE;
          report = x != ft6146->last_x || y != ft6146->last_y;
        }

      ft6146->last_x = x;
      ft6146->last_y = y;
      sample.point[0].flags |= TOUCH_ID_VALID | TOUCH_POS_VALID;
    }
  else
    {
      sample.point[0].flags = TOUCH_UP | TOUCH_ID_VALID | TOUCH_POS_VALID;
      report = ft6146->contact_active;
      ft6146->contact_active = false;
    }

  sample.point[0].id = ft6146->last_id;
  sample.point[0].x = ft6146->last_x;
  sample.point[0].y = ft6146->last_y;
  sample.point[0].timestamp = touch_get_time();

  if (report)
    {
      touch_event(ft6146->lower.priv, &sample);
    }

out:
  ret = work_queue(HPWORK, &ft6146->work, ft6146_data_worker, ft6146,
                   MSEC2TICK(FT6146_POLL_INTERVAL_MS));
  if (ret < 0)
    {
      ierr("ft6146: requeue polling worker failed: %d\n", ret);
    }
}

static void ft6146_irq_handler(void *arg)
{
  struct ft6146_touch_lowerhalf_s *ft6146 =
    (struct ft6146_touch_lowerhalf_s *)arg;
  int ret;

  /* Match the official SiFli driver: serialize IRQ and I2C handling.  A
   * second work_queue() on the same work_s can replace pending work and lose
   * an intermediate sample.
   */

  ft6146_irq_enable(ft6146, false);
  ret = work_queue(HPWORK, &ft6146->work, ft6146_data_worker, ft6146, 0);
  if (ret < 0)
    {
      ierr("ft6146: queue touch worker failed: %d\n", ret);
      ft6146_irq_enable(ft6146, true);
    }
}

static int ft6146_hw_init(struct ft6146_touch_lowerhalf_s *ft6146)
{
  uint8_t id_h = 0;
  uint8_t id_l = 0;
  int ret;

  BSP_TP_PowerUp();
  BSP_TP_Reset(0);
  usleep(5000);
  BSP_TP_Reset(1);
  usleep(80000);

  ret = sifli_gpio_config(ft6146->pin_irq, GPIO_INPUT);
  if (ret < 0)
    {
      ierr("ft6146: irq pin config failed: %d\n", ret);
      return ret;
    }

  ret = ft6146_i2c_read(ft6146->i2c, FT6146_REG_ID_H, &id_h, 1);
  if (ret < 0)
    {
      ierr("ft6146: read id_h failed: %d\n", ret);
      return ret;
    }

  ret = ft6146_i2c_read(ft6146->i2c, FT6146_REG_ID_L, &id_l, 1);
  if (ret < 0)
    {
      ierr("ft6146: read id_l failed: %d\n", ret);
      return ret;
    }

  iinfo("ft6146 id_h=0x%02x id_l=0x%02x\n", id_h, id_l);
  ret = work_queue(HPWORK, &ft6146->work, ft6146_data_worker, ft6146,
                   MSEC2TICK(FT6146_POLL_INTERVAL_MS));
  if (ret < 0)
    {
      ierr("ft6146: polling worker setup failed: %d\n", ret);
      return ret;
    }

  return OK;
}

static ssize_t ft6146_touch_notify(FAR void *input_lower,
                                   FAR const char *buffer,
                                   size_t buflen)
{
  FAR struct ft6146_touch_lowerhalf_s *ft6146 =
    (FAR struct ft6146_touch_lowerhalf_s *)input_lower;
  FAR const struct touch_sample_s *sample =
    (FAR const struct touch_sample_s *)buffer;

  touch_event(ft6146->lower.priv, sample);
  return buflen;
}

static ssize_t ft6146_touch_write(FAR struct touch_lowerhalf_s *input_lower,
                                  FAR const char *buffer,
                                  size_t buflen)
{
  FAR struct ft6146_touch_lowerhalf_s *ft6146 =
    (FAR struct ft6146_touch_lowerhalf_s *)input_lower;

  return ft6146_touch_notify(ft6146, buffer, buflen);
}

/****************************************************************************
 * Public Functions
 ****************************************************************************/

int ft6146_touch_initialize(struct i2c_master_s *i2c, uint32_t irq_pin)
{
  FAR struct ft6146_touch_lowerhalf_s *ft6146;
  int ret;

  DEBUGASSERT(i2c != NULL);

  ft6146 = kmm_zalloc(sizeof(struct ft6146_touch_lowerhalf_s));
  if (ft6146 == NULL)
    {
      return -ENOMEM;
    }

  ft6146->lower.write = ft6146_touch_write;
  ft6146->lower.maxpoint = 1;
  ft6146->i2c = i2c;
  ft6146->pin_irq = irq_pin;

  nxmutex_init(&ft6146->devlock);
  nxsem_init(&ft6146->waitsem, 0, 0);

  ret = touch_register(&ft6146->lower, "/dev/" FT6146_NAME_TOUCH, 16);
  if (ret < 0)
    {
      nxmutex_destroy(&ft6146->devlock);
      nxsem_destroy(&ft6146->waitsem);
      kmm_free(ft6146);
      return ret;
    }

  ret = ft6146_hw_init(ft6146);
  if (ret < 0)
    {
      touch_unregister(&ft6146->lower, "/dev/" FT6146_NAME_TOUCH);
      nxmutex_destroy(&ft6146->devlock);
      nxsem_destroy(&ft6146->waitsem);
      kmm_free(ft6146);
      return ret;
    }

  return OK;
}
