/*
 * SPDX-FileCopyrightText: 2019-2022 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <nuttx/config.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <syslog.h>
#include <unistd.h>
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <nuttx/cache.h>
#include <nuttx/lcd/lcd.h>
#include <nuttx/lcd/lcd_dev.h>
#include <nuttx/semaphore.h>
#include <nuttx/video/fb.h>

#include "lvgl.h"
#include "board.h"
#include "drv_lcd_fb.h"
#include <lvgl/src/drivers/nuttx/lv_nuttx_entry.h>
#include <lvgl/src/draw/sifli/epic/lv_sifli_epic_cfg.h>

#include <lvgl/src/display/lv_display_private.h>
#include <lvgl/src/core/lv_refr.h>

#if (16 != LV_COLOR_DEPTH) && (24 != LV_COLOR_DEPTH) && (32 != LV_COLOR_DEPTH)
    #error "Unsupported color depth"
#endif

#ifndef LV_HOR_RES_MAX
#  define LV_HOR_RES_MAX CONFIG_LCD_HOR_RES_MAX
#endif

#ifndef LV_VER_RES_MAX
#  define LV_VER_RES_MAX CONFIG_LCD_VER_RES_MAX
#endif

#ifndef LCD_HOR_RES_MAX
#  define LCD_HOR_RES_MAX CONFIG_LCD_HOR_RES_MAX
#endif

#ifndef LCD_VER_RES_MAX
#  define LCD_VER_RES_MAX CONFIG_LCD_VER_RES_MAX
#endif

#ifdef CONFIG_BSP_USING_LCD_FRAMEBUFFER
#  define BSP_USING_LCD_FRAMEBUFFER
#endif

#ifdef CONFIG_LCD_FB_USING_NONE
#  define LCD_FB_USING_NONE
#endif
#ifdef CONFIG_LCD_FB_USING_ONE_UNCOMPRESSED
#  define LCD_FB_USING_ONE_UNCOMPRESSED
#endif
#ifdef CONFIG_LCD_FB_USING_TWO_UNCOMPRESSED
#  define LCD_FB_USING_TWO_UNCOMPRESSED
#endif
#ifdef CONFIG_LCD_FB_USING_ONE_COMPRESSED
#  define LCD_FB_USING_ONE_COMPRESSED
#endif
#ifdef CONFIG_LCD_FB_USING_TWO_COMPRESSED
#  define LCD_FB_USING_TWO_COMPRESSED
#endif
#ifdef CONFIG_LV_FB_ONE_SCREEN_SIZE
#  define LV_FB_ONE_SCREEN_SIZE
#endif
#ifdef CONFIG_LV_FB_TWO_SCREEN_SIZE
#  define LV_FB_TWO_SCREEN_SIZE
#endif
#ifdef CONFIG_LV_FB_ONE_NOT_SCREEN_SIZE
#  define LV_FB_ONE_NOT_SCREEN_SIZE
#endif
#ifdef CONFIG_LV_FB_TWO_NOT_SCREEN_SIZE
#  define LV_FB_TWO_NOT_SCREEN_SIZE
#endif

#ifndef LV_FB_LINE_NUM
#  ifdef CONFIG_LV_FB_LINE_NUM
#    define LV_FB_LINE_NUM CONFIG_LV_FB_LINE_NUM
#  else
#    define LV_FB_LINE_NUM LV_VER_RES_MAX
#  endif
#endif

#ifndef FB_ALIGN_BYTE
#  define FB_ALIGN_BYTE LV_DRAW_BUF_ALIGN
#endif

#ifndef FB_ALIGNED_HOR_RES
#  define FB_ALIGNED_HOR_RES LV_HOR_RES_MAX
#endif

#ifndef ALIGN
#  define ALIGN(n) __attribute__((aligned(n)))
#endif

#ifndef L1_NON_RET_BSS_SECT_BEGIN
#  define L1_NON_RET_BSS_SECT_BEGIN(name)
#  define L1_NON_RET_BSS_SECT_END
#  define L1_NON_RET_BSS_SECT(name, var) \
    var __attribute__((section(".bss.l1_non_ret_bss_" #name)))
#endif

#ifndef L2_NON_RET_BSS_SECT_BEGIN
#  define L2_NON_RET_BSS_SECT_BEGIN(name)
#  define L2_NON_RET_BSS_SECT_END
#  ifdef CONFIG_BSP_USING_PSRAM
#    define L2_NON_RET_BSS_SECT(name, var) \
      __attribute__((section(".psram_bss_" #name))) var
#  else
#    define L2_NON_RET_BSS_SECT(name, var) \
      __attribute__((section(".bss.l2_non_ret_bss_" #name))) var
#  endif
#endif

#ifndef RT_ALIGN
#  define RT_ALIGN(v, a) (((v) + (a) - 1) & ~((a) - 1))
#endif

#ifndef RT_ALIGN_DOWN
#  define RT_ALIGN_DOWN(v, a) ((v) & ~((a) - 1))
#endif

#define LOG_I(...) syslog(LOG_INFO, __VA_ARGS__)
#define LOG_W(...) syslog(LOG_WARNING, __VA_ARGS__)
#define LOG_E(...) syslog(LOG_ERR, __VA_ARGS__)

/*LCD resolution can't small than LVGL's*/
#ifdef BSP_USING_LCD
    #if (LV_HOR_RES_MAX>LCD_HOR_RES_MAX)
        #error "LV_HOR_RES_MAX>LCD_HOR_RES_MAX, Select right LCD please!"
    #endif

    #if (LV_VER_RES_MAX>LCD_VER_RES_MAX)
        #error "LV_VER_RES_MAX>LCD_VER_RES_MAX, Select right LCD please!"
    #endif
#endif /* BSP_USING_LCD */

#if defined(LV_FB_TWO_SCREEN_SIZE) || defined(LV_FB_ONE_SCREEN_SIZE)
    #define LV_FB_LINE_NUM LV_VER_RES_MAX
#endif /* LV_FB_TWO_SCREEN_SIZE || LV_FB_ONE_SCREEN_SIZE*/
#if defined(LV_FB_ONE_SCREEN_SIZE) && defined(LCD_FB_USING_NONE)
    #error "Not supported on v9 now!"
#endif


#define LCD_FLUSH_EXP_MS   (5000)//Include LCD reset time

#ifdef FRAME_BUFFER_IN_PSRAM
    #define FRAME_BUFFER_BSS_SECT_BEGIN(frambuf) L2_NON_RET_BSS_SECT_BEGIN(frambuf)
    #define FRAME_BUFFER_BSS_SECT_END L2_NON_RET_BSS_SECT_END
    #define FRAME_BUFFER_BSS_SECT(frambuf, var) L2_NON_RET_BSS_SECT(frambuf, var)
#else
    #define FRAME_BUFFER_BSS_SECT_BEGIN(frambuf) L1_NON_RET_BSS_SECT_BEGIN(frambuf)
    #define FRAME_BUFFER_BSS_SECT_END L1_NON_RET_BSS_SECT_END
    #define FRAME_BUFFER_BSS_SECT(frambuf, var) L1_NON_RET_BSS_SECT(frambuf, var)
#endif

#define debug_lcd_flush_start(x1, y1, x2, y2)
#define debug_lcd_flush_end()

struct lv_lcd_info_s
{
    uint16_t width;
    uint16_t height;
    uint16_t bits_per_pixel;
    uint16_t draw_align;
};

static int device = -1;
static struct lv_lcd_info_s info;
static sem_t lcd_sema;

static lv_display_t *lcd_flushing_disp_drv = NULL;
static lv_display_t *disp;

#if (LV_COLOR_DEPTH == 24)
    typedef lv_color_t lv_fb_color_t;
#elif (LV_COLOR_DEPTH == 16)
    typedef lv_color16_t lv_fb_color_t;
#endif /* LV_COLOR_DEPTH == 24*/

/**************************************************
   1. Defination of LVGL buffer(s) on SRAM
****************************************************/
/* One spare row after each draw buffer.  LVGL never sees it; a write that
 * runs past the end lands here instead of in the display state below, and
 * the flush path reports it once.
 */

#define DRAW_BUF_PX     (FB_ALIGNED_HOR_RES * LV_FB_LINE_NUM)
#define DRAW_GUARD_PX   FB_ALIGNED_HOR_RES
#define DRAW_GUARD_FILL 0xa5

FRAME_BUFFER_BSS_SECT_BEGIN(frambuf)
FRAME_BUFFER_BSS_SECT(frambuf, ALIGN(FB_ALIGN_BYTE) static lv_fb_color_t  buf1_1[DRAW_BUF_PX + DRAW_GUARD_PX]);
#if defined(LV_FB_TWO_NOT_SCREEN_SIZE) || defined(LV_FB_TWO_SCREEN_SIZE)
    FRAME_BUFFER_BSS_SECT(frambuf, ALIGN(FB_ALIGN_BYTE) static lv_fb_color_t  buf1_2[DRAW_BUF_PX + DRAW_GUARD_PX]);
#endif /* LV_FB_TWO_NOT_SCREEN_SIZE || LV_FB_TWO_SCREEN_SIZE */
FRAME_BUFFER_BSS_SECT_END

static void draw_guard_fill(lv_fb_color_t *buf)
{
    memset(&buf[DRAW_BUF_PX], DRAW_GUARD_FILL,
           DRAW_GUARD_PX * sizeof(lv_fb_color_t));
}

static void draw_guard_check(lv_fb_color_t *buf, const char *name,
                             const lv_area_t *area)
{
    static uint32_t reports;
    const uint8_t *guard = (const uint8_t *)&buf[DRAW_BUF_PX];
    size_t len = DRAW_GUARD_PX * sizeof(lv_fb_color_t);
    size_t first;
    size_t last = 0;
    bool hit = false;

    for (first = 0; first < len; first++)
    {
        if (guard[first] != DRAW_GUARD_FILL)
        {
            hit = true;
            break;
        }
    }

    if (!hit)
    {
        return;
    }

    for (last = len; last > first && guard[last - 1] == DRAW_GUARD_FILL;
         last--)
    {
    }

    if (reports++ < 8)
    {
        syslog(LOG_ERR, "LV_LCD_GUARD: %s overrun bytes=%u..%u area=%d,%d-%d,%d\n",
               name, (unsigned)first, (unsigned)last,
               (int)area->x1, (int)area->y1, (int)area->x2, (int)area->y2);
    }

    draw_guard_fill(buf);
}

/**************************************************
   2. Defination of LCD buffer(s) on PSRAM
****************************************************/


#ifdef LCD_FB_USING_NONE
    #if defined(LV_FB_ONE_SCREEN_SIZE)
        #define FB_LINE_SIZE FB_ALIGNED_HOR_RES
        #define FB_TYPE      lv_fb_color_t

        #undef get_draw_buf
        #define get_draw_buf()  (&buf1_1[0])
    #endif
#else
    #if defined(LCD_FB_USING_ONE_UNCOMPRESSED) || defined(LCD_FB_USING_TWO_UNCOMPRESSED)
        #define FB_LINE_SIZE FB_ALIGNED_HOR_RES
        #define FB_TYPE      lv_fb_color_t

    #elif defined(LCD_FB_USING_ONE_COMPRESSED) || defined(LCD_FB_USING_TWO_COMPRESSED)
        #define FB_TYPE      CMPR_DATA_TYPE
        #if (LV_COLOR_DEPTH == 24)
            #define FB_CMPR_RATE 3
            #define FB_LINE_SIZE CMPR_3_RGB888_COMPRESSED_BYTES(LV_HOR_RES_MAX)
        #elif (LV_COLOR_DEPTH == 16)
            #define FB_CMPR_RATE 1
            #define FB_LINE_SIZE CMPR_1_RGB565_COMPRESSED_BYTES(LV_HOR_RES_MAX)
        #endif /* LV_COLOR_DEPTH == 24*/
    #endif /* LCD_FB_USING_ONE_UNCOMPRESSED */

    /* screen sized buffer on low speed RAM
    64 algined buffer is more efficient for EPIC
    */
    L2_NON_RET_BSS_SECT_BEGIN(frambuf)
    static FB_TYPE buf2_1[FB_LINE_SIZE * LV_VER_RES_MAX]
      __attribute__((section(".psram_bss"), aligned(64)));
    L2_NON_RET_BSS_SECT_END

    #if defined(LCD_FB_USING_TWO_UNCOMPRESSED)||defined(LCD_FB_USING_TWO_COMPRESSED)
        L2_NON_RET_BSS_SECT_BEGIN(frambuf)
        static FB_TYPE buf2_2[FB_LINE_SIZE * LV_VER_RES_MAX]
          __attribute__((section(".psram_bss"), aligned(64)));
        L2_NON_RET_BSS_SECT_END

        static FB_TYPE *using_buf; /*ramless LCD using fb*/
        #undef get_draw_buf
        #define get_draw_buf()  ((using_buf == &buf2_1[0]) ? &buf2_2[0] : &buf2_1[0])
        #define switch_draw_buf()  (using_buf = get_draw_buf())
    #else
        #undef get_draw_buf
        #define get_draw_buf()  (&buf2_1[0])
    #endif
#endif /* LCD_FB_USING_NONE */

static void dummy_func2(void)
{
};

static void dummy_func3(void)
{
}

#ifdef BSP_USING_LCD_FRAMEBUFFER
static void update_fb(void)
{
    lcd_fb_desc_t fb_dsc;
    uint16_t cf;

    if (16 == LV_COLOR_DEPTH)
        cf = RTGRAPHIC_PIXEL_FORMAT_RGB565;
    else if (24 == LV_COLOR_DEPTH)
        cf = RTGRAPHIC_PIXEL_FORMAT_RGB888;
    else if (32 == LV_COLOR_DEPTH)
        cf = RTGRAPHIC_PIXEL_FORMAT_ARGB888;
    else
    {
        //Fix me
        DEBUGASSERT(0);
    }

    fb_dsc.area.x0 = disp->offset_x;
    fb_dsc.area.y0 = disp->offset_y;
    fb_dsc.area.x1 = disp->offset_x + disp->hor_res - 1;
    fb_dsc.area.y1 = disp->offset_y + disp->ver_res - 1;
    fb_dsc.p_data = (uint8_t *)get_draw_buf();
#ifdef FB_CMPR_RATE
    fb_dsc.cmpr_rate = FB_CMPR_RATE;
#else
    fb_dsc.cmpr_rate = 0;
#endif /* FB_CMPR_RATE */
    fb_dsc.line_bytes = FB_LINE_SIZE * sizeof(FB_TYPE);
    fb_dsc.format = cf;
    drv_lcd_fb_set(&fb_dsc);
}
#endif /* BSP_USING_LCD_FRAMEBUFFER */

/*
    Some LCD (ie. Rydium DSI LCD):
    The SC and EC-SC+1 must can be divisible by 2, (SC - Start Column, EC - End Column), and row too.

    SPD LCD need align to 4
*/
static void rounder_cb(lv_event_t *e)
{
    lv_area_t *area = lv_event_get_param(e);
    uint32_t align_size = (info.draw_align != 0) ? info.draw_align : 1;

    area->x1 = RT_ALIGN_DOWN(area->x1, align_size);
    area->x2 = RT_ALIGN(area->x2 + 1, align_size) - 1;

    area->y1 = RT_ALIGN_DOWN(area->y1, align_size);
    area->y2 = RT_ALIGN(area->y2 + 1, align_size) - 1;

#ifdef FB_CMPR_RATE
    /*Extend to whole line if FB compression is enabled.*/
    area->x1 = 0;
    area->x2 = LV_HOR_RES_MAX - 1;
#endif /* FB_CMPR_RATE */

}

#if defined(LCD_FB_USING_TWO_COMPRESSED)||defined(LCD_FB_USING_TWO_UNCOMPRESSED)
/* The framebuffer being drawn still holds the frame before last, so a frame
 * must also redraw what the previous frame changed (this avoids a
 * PSRAM->PSRAM copy).  The official code redraws the whole screen on
 * REFR_START instead; areas invalidated after it (layout updates, the
 * VelaRide transition applied on REFR_START) were then drawn into one
 * buffer only and left stale stripes on the other during horizontal
 * swipes.  RENDER_START comes after every invalidation of the frame.
 * Set LV_FB_FULL in the environment to redraw the whole screen instead.
 */

extern volatile uint8_t drv_lcd_fb_full_window;
static lv_area_t prev_areas[LV_INV_BUF_SIZE];
static uint16_t prev_count;
static bool full_redraw_env;
static bool full_redraw;
static bool fb_check;
static lv_area_t last_redraw[LV_INV_BUF_SIZE];
static uint16_t last_redraw_count;
static uint32_t frame_seq;
#if LV_USE_SIFLI_EPIC
extern int8_t lv_sifli_epic_off;
static bool epic_off_env;
#endif

/* `echo 1 > /data/lv_prof`: average timing of rendering frames over 32 of
 * them, from the DWT cycle counter.  A frame is split at REFR_START,
 * RENDER_START, the hand-over of its last block and REFR_READY:
 *   pre    REFR_START -> RENDER_START (layout, invalidation)
 *   render RENDER_START -> last block handed to drv_lcd_fb
 *   post   -> REFR_READY
 *   gap    previous REFR_READY -> REFR_START (other timers, idle)
 * blk is the part of render spent blocked in lcd_flush (copywait: the
 * previous block copy, linewait: the LCD still sending those rows), waitcb
 * LVGL waiting for a draw buffer, send the LCD transfer itself.
 */

extern volatile uint32_t drv_lcd_fb_prof_send_cyc;
extern volatile uint32_t drv_lcd_fb_prof_send_cnt;
extern volatile uint32_t drv_lcd_fb_prof_send_rows;
extern volatile uint32_t drv_lcd_fb_prof_copywait_cyc;
extern volatile uint32_t drv_lcd_fb_prof_linewait_cyc;

static bool prof_on;
static bool prof_rendered;
static uint32_t prof_refr_t;
static uint32_t prof_render_t;
static uint32_t prof_flush_t;
static uint32_t prof_ready_t;

static struct
{
    uint32_t frames;
    uint32_t chunks;
    uint64_t px;
    uint64_t period;
    uint64_t pre;
    uint64_t render;
    uint64_t post;
    uint64_t gap;
    uint64_t blk;
    uint64_t waitcb;
} prof;

static void prof_reset(void)
{
    memset(&prof, 0, sizeof(prof));
    drv_lcd_fb_prof_send_cyc = 0;
    drv_lcd_fb_prof_send_cnt = 0;
    drv_lcd_fb_prof_send_rows = 0;
    drv_lcd_fb_prof_copywait_cyc = 0;
    drv_lcd_fb_prof_linewait_cyc = 0;
}

static void prof_refr_start_cb(lv_event_t *e)
{
    LV_UNUSED(e);
    prof_refr_t = DWT->CYCCNT;
    prof_rendered = false;
}

static void prof_refr_ready_cb(lv_event_t *e)
{
    uint32_t now = DWT->CYCCNT;
    uint32_t mhz;
    uint32_t n;
    uint32_t sends;

    LV_UNUSED(e);
    if (!prof_on || !prof_rendered)
    {
        prof_ready_t = 0;
        return;
    }

    mhz = HAL_RCC_GetHCLKFreq(CORE_ID_HCPU) / 1000000;
    if (now - prof_refr_t > 30 * mhz * 1000)
    {
        syslog(LOG_ERR, "LV_SLOW: frame=%u pre=%u render=%u post=%u"
               " gap=%u" "\n",
               (unsigned)((now - prof_refr_t) / mhz),
               (unsigned)((prof_render_t - prof_refr_t) / mhz),
               (unsigned)((prof_flush_t - prof_render_t) / mhz),
               (unsigned)((now - prof_flush_t) / mhz),
               (unsigned)(prof_ready_t ? (prof_refr_t - prof_ready_t) / mhz
                                       : 0));
    }

    if (prof_ready_t != 0)
    {
        prof.period += now - prof_ready_t;
        prof.gap += prof_refr_t - prof_ready_t;
        prof.pre += prof_render_t - prof_refr_t;
        prof.render += prof_flush_t - prof_render_t;
        prof.post += now - prof_flush_t;
        prof.frames++;
    }

    prof_ready_t = now;
    if (prof.frames < 32)
    {
        return;
    }

    n = prof.frames;
    sends = drv_lcd_fb_prof_send_cnt ? drv_lcd_fb_prof_send_cnt : 1;
    syslog(LOG_ERR, "LV_PROF: hz=%u period=%u pre=%u render=%u post=%u"
           " gap=%u blk=%u copywait=%u linewait=%u waitcb=%u send=%u"
           " rows=%u chunks=%u kpx=%u" "\n",
           (unsigned)((uint64_t)n * mhz * 1000000 / prof.period),
           (unsigned)(prof.period / mhz / n),
           (unsigned)(prof.pre / mhz / n),
           (unsigned)(prof.render / mhz / n),
           (unsigned)(prof.post / mhz / n),
           (unsigned)(prof.gap / mhz / n),
           (unsigned)(prof.blk / mhz / n),
           (unsigned)(drv_lcd_fb_prof_copywait_cyc / mhz / n),
           (unsigned)(drv_lcd_fb_prof_linewait_cyc / mhz / n),
           (unsigned)(prof.waitcb / mhz / n),
           (unsigned)(drv_lcd_fb_prof_send_cyc / mhz / sends),
           (unsigned)(drv_lcd_fb_prof_send_rows / sends),
           (unsigned)(prof.chunks / n),
           (unsigned)(prof.px / n / 1000));
    prof_reset();
}

/* Diagnostics without reflashing: from NSH, `echo 1 > /data/lv_fb_full`
 * forces whole-screen redraws and `echo 1 > /data/lv_epic_off` keeps all
 * drawing on the CPU; `rm` the file to undo.  Polled twice a second.
 */

static void poll_debug_switches(void)
{
    static uint32_t last;
    static bool first = true;
    bool on;

    if (!first && lv_tick_elaps(last) < 500)
    {
        return;
    }

    first = false;
    last = lv_tick_get();
    on = full_redraw_env || access("/data/lv_fb_full", F_OK) == 0;
    if (on != full_redraw)
    {
        syslog(LOG_INFO, "LV_LCD: full redraw %s\n", on ? "on" : "off");
        full_redraw = on;
    }

    on = access("/data/lv_fb_fullwin", F_OK) == 0;
    if (on != drv_lcd_fb_full_window)
    {
        syslog(LOG_INFO, "LV_LCD: full window %s\n", on ? "on" : "off");
        drv_lcd_fb_full_window = on;
    }

    on = access("/data/lv_fb_check", F_OK) == 0;
    if (on != fb_check)
    {
        syslog(LOG_INFO, "LV_LCD: fb check %s\n", on ? "on" : "off");
        fb_check = on;
        last_redraw_count = 0;
    }

    on = access("/data/lv_prof", F_OK) == 0;
    if (on != prof_on)
    {
        syslog(LOG_INFO, "LV_LCD: prof %s\n", on ? "on" : "off");
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
        prof_on = on;
        prof_ready_t = 0;
        prof_reset();
    }

#if LV_USE_SIFLI_EPIC
    on = epic_off_env || access("/data/lv_epic_off", F_OK) == 0;
    if (on != (lv_sifli_epic_off > 0))
    {
        syslog(LOG_INFO, "LV_LCD: EPIC %s\n", on ? "off" : "on");
        lv_sifli_epic_off = on;
    }
#endif
}

/* `echo 1 > /data/lv_fb_check`: when the previous frame is complete, compare
 * the two framebuffers outside the areas that frame redrew.  The buffer just
 * written holds frame N and the other frame N-1; they may only differ where
 * frame N changed, which is inside its redraw set, so any difference there
 * means one of them is stale.  Costs a full read of both buffers per frame.
 */


static void fb_check_frame(void)
{
    static uint32_t reports;
    static uint32_t last_report;
    static uint8_t skip[LV_HOR_RES_MAX];
    const lv_fb_color_t *a = (const lv_fb_color_t *)using_buf;
    const lv_fb_color_t *b = (const lv_fb_color_t *)get_draw_buf();
    lv_area_t bad = { LV_HOR_RES_MAX, LV_VER_RES_MAX, -1, -1 };
    uint32_t count = 0;
    int32_t x;
    int32_t y;
    uint16_t i;
    int err;

    if (a == NULL || last_redraw_count == 0)
    {
        return;
    }

    /* The last block of the previous frame may still be on its way. */

    err = nxsem_tickwait_uninterruptible(&lcd_sema, MSEC2TICK(LCD_FLUSH_EXP_MS));
    DEBUGASSERT(err == 0);
    nxsem_post(&lcd_sema);
    a = (const lv_fb_color_t *)using_buf;
    b = (const lv_fb_color_t *)get_draw_buf();

    up_invalidate_dcache((uintptr_t)buf2_1, (uintptr_t)buf2_1 + sizeof(buf2_1));
    up_invalidate_dcache((uintptr_t)buf2_2, (uintptr_t)buf2_2 + sizeof(buf2_2));

    for (y = 0; y < LV_VER_RES_MAX; y++)
    {
        memset(skip, 0, sizeof(skip));
        for (i = 0; i < last_redraw_count; i++)
        {
            const lv_area_t *r = &last_redraw[i];

            if (y >= r->y1 && y <= r->y2)
            {
                memset(&skip[LV_MAX(r->x1, 0)], 1,
                       LV_MIN(r->x2, LV_HOR_RES_MAX - 1) - LV_MAX(r->x1, 0) + 1);
            }
        }

        const lv_fb_color_t *ra = &a[y * FB_LINE_SIZE];
        const lv_fb_color_t *rb = &b[y * FB_LINE_SIZE];

        for (x = 0; x < LV_HOR_RES_MAX; x++)
        {
            if (!skip[x] && memcmp(&ra[x], &rb[x], sizeof(ra[x])) != 0)
            {
                count++;
                bad.x1 = LV_MIN(bad.x1, x);
                bad.x2 = LV_MAX(bad.x2, x);
                bad.y1 = LV_MIN(bad.y1, y);
                bad.y2 = LV_MAX(bad.y2, y);
            }
        }
    }

    if (count == 0 || (reports >= 3 && lv_tick_elaps(last_report) < 300))
    {
        return;
    }

    reports++;
    last_report = lv_tick_get();
    syslog(LOG_ERR, "LV_FB_CHECK: frame=%u diff=%u bbox=%d,%d-%d,%d redraw=%u:"
           " %d,%d-%d,%d" "\n",
           (unsigned)frame_seq, (unsigned)count,
           (int)bad.x1, (int)bad.y1, (int)bad.x2, (int)bad.y2,
           (unsigned)last_redraw_count,
           (int)last_redraw[0].x1, (int)last_redraw[0].y1,
           (int)last_redraw[0].x2, (int)last_redraw[0].y2);
    for (i = 1; i < last_redraw_count && i < 6; i++)
    {
        syslog(LOG_ERR, "LV_FB_CHECK:   %d,%d-%d,%d" "\n",
               (int)last_redraw[i].x1, (int)last_redraw[i].y1,
               (int)last_redraw[i].x2, (int)last_redraw[i].y2);
    }
}

static void render_start(lv_event_t *e)
{
    LV_UNUSED(e);
    poll_debug_switches();
    prof_render_t = DWT->CYCCNT;
    prof_rendered = true;
    if (fb_check)
    {
        fb_check_frame();
    }

    const lv_area_t scr_area = { 0, 0, LV_HOR_RES_MAX - 1, LV_VER_RES_MAX - 1};
    lv_area_t cur[LV_INV_BUF_SIZE];
    uint16_t cur_count = 0;
    uint16_t n;
    uint16_t i;
    uint16_t j;

    for (i = 0; i < disp->inv_p; i++)
    {
        if (disp->inv_area_joined[i] == 0)
        {
            cur[cur_count++] = disp->inv_areas[i];
        }
    }

    if (full_redraw)
    {
        n = 0;
        goto full;
    }

    n = cur_count;
    for (i = 0; i < cur_count; i++)
    {
        disp->inv_areas[i] = cur[i];
    }

    for (i = 0; i < prev_count; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (_lv_area_is_in(&prev_areas[i], &disp->inv_areas[j], 0))
            {
                break;
            }
        }

        if (j < n)
        {
            continue;
        }

        if (n >= LV_INV_BUF_SIZE)
        {
            goto full;
        }

        disp->inv_areas[n++] = prev_areas[i];
    }

    memset(disp->inv_area_joined, 0, sizeof(disp->inv_area_joined));

    /* Same rule as lv_refr_join_area(), which is private to lv_refr.c. */

    for (i = 0; i < n; i++)
    {
        if (disp->inv_area_joined[i] != 0)
        {
            continue;
        }

        for (j = 0; j < n; j++)
        {
            lv_area_t joined;

            if (i == j || disp->inv_area_joined[j] != 0 ||
                !_lv_area_is_on(&disp->inv_areas[i], &disp->inv_areas[j]))
            {
                continue;
            }

            _lv_area_join(&joined, &disp->inv_areas[i], &disp->inv_areas[j]);
            if (lv_area_get_size(&joined) <
                lv_area_get_size(&disp->inv_areas[i]) +
                lv_area_get_size(&disp->inv_areas[j]))
            {
                disp->inv_areas[i] = joined;
                disp->inv_area_joined[j] = 1;
            }
        }
    }

    disp->inv_p = n;
    goto save;

full:
    memset(disp->inv_area_joined, 0, sizeof(disp->inv_area_joined));
    disp->inv_areas[0] = scr_area;
    disp->inv_p = 1;

save:
    memcpy(prev_areas, cur, cur_count * sizeof(cur[0]));
    prev_count = cur_count;

    last_redraw_count = 0;
    for (i = 0; i < disp->inv_p; i++)
    {
        if (disp->inv_area_joined[i] == 0)
        {
            last_redraw[last_redraw_count++] = disp->inv_areas[i];
        }
    }

    frame_seq++;
}
#else
static void render_start(lv_event_t *e)
{
    LV_UNUSED(e);
}
#endif

static void wait_flush_done(lv_display_t *disp_drv)
{
#if 0//def BSP_USING_LCD_FRAMEBUFFER
    drv_lcd_fb_wait_write_done(LCD_FLUSH_EXP_MS);
#endif /* BSP_USING_LCD_FRAMEBUFFER */
    int err;
    uint32_t prof_t = DWT->CYCCNT;
    err = nxsem_tickwait_uninterruptible(&lcd_sema,
                                         MSEC2TICK(LCD_FLUSH_EXP_MS));
    DEBUGASSERT(err == 0);
    err = nxsem_post(&lcd_sema);
    DEBUGASSERT(err == 0);
    prof.waitcb += DWT->CYCCNT - prof_t;
}

#ifdef BSP_USING_LCD_FRAMEBUFFER
#if defined(LCD_FB_USING_TWO_COMPRESSED)||defined(LCD_FB_USING_TWO_UNCOMPRESSED)
static volatile uint8_t pending_switch_draw_buf;
#endif
static void lcd_flush_done(lcd_fb_desc_t *fb_desc)
{
    LV_UNUSED(fb_desc);
    lv_display_t *p_disp = lcd_flushing_disp_drv;
    lcd_flushing_disp_drv = NULL;
    int err;

#if defined(LCD_FB_USING_TWO_COMPRESSED)||defined(LCD_FB_USING_TWO_UNCOMPRESSED)
    if (pending_switch_draw_buf)
    {
        pending_switch_draw_buf = 0;
        switch_draw_buf();
        update_fb();
    }
#endif

    err = nxsem_post(&lcd_sema);
    DEBUGASSERT(err == 0);
    if (p_disp != NULL)
    {
        lv_display_flush_ready(p_disp);
    }
}
#else
static int lcd_flush_done(int dev, void *buffer)
{
    LV_UNUSED(dev);
    LV_UNUSED(buffer);
    lv_display_t *p_disp = lcd_flushing_disp_drv;
    lcd_flushing_disp_drv = NULL;
    debug_lcd_flush_end();

    int err = nxsem_post(&lcd_sema);
    DEBUGASSERT(err == 0);
    if (p_disp != NULL)
    {
        lv_display_flush_ready(p_disp);
    }

    return 0;
}

#endif /* BSP_USING_LCD_FRAMEBUFFER */

uint8_t drv_gpu_is_cached_ram(uint32_t start, uint32_t len)
{
#ifndef LCD_FB_USING_NONE
    uint32_t uncached_start, uncached_end;

    uncached_start = (uint32_t)&buf2_1[0];
    uncached_end = uncached_start + sizeof(buf2_1);
    if ((start >= uncached_start) && (start + len <= uncached_end))
    {
        return 0;
    }

#if defined(switch_draw_buf)
    uncached_start = (uint32_t)&buf2_2[0];
    uncached_end = uncached_start + sizeof(buf2_2);
    if ((start >= uncached_start) && (start + len <= uncached_end))
    {
        return 0;
    }
#endif
#endif /* LCD_FB_USING_NONE */

    return 1;
}

static void lcd_flush(lv_display_t *disp_drv, const lv_area_t *refresh_area, uint8_t *color_p)
{
    // Regular LCD refresh mode
    const lv_area_t *p_buf_area = &disp_drv->layer_head->buf_area;

    LCD_AreaDef clip_area =   //Buf clip area
    {
        .x0 = refresh_area->x1 + disp_drv->offset_x,
        .y0 = refresh_area->y1 + disp_drv->offset_y,
        .x1 = refresh_area->x2 + disp_drv->offset_x,
        .y1 = refresh_area->y2 + disp_drv->offset_y
    };

    LCD_AreaDef src_area =
    {
        .x0 = p_buf_area->x1,
        .y0 = p_buf_area->y1,
        .x1 = p_buf_area->x2,
        .y1 = p_buf_area->y2
    };

    //BUG 1944: Invalid coordinates if framebuffer larger than LCD and refresh area out of screen
    if ((clip_area.x0 > clip_area.x1) || (clip_area.y0 > clip_area.y1))
    {
        /* Inform the graphics library that you are ready with the flushing*/
        lv_display_flush_ready(disp_drv);
        return;
    }

    uint32_t prof_t = DWT->CYCCNT;

    draw_guard_check(buf1_1, "buf1_1", refresh_area);
#if defined(LV_FB_TWO_NOT_SCREEN_SIZE) || defined(LV_FB_TWO_SCREEN_SIZE)
    draw_guard_check(buf1_2, "buf1_2", refresh_area);
#endif

    int err;
    err = nxsem_tickwait_uninterruptible(&lcd_sema,
                                         MSEC2TICK(LCD_FLUSH_EXP_MS));
    DEBUGASSERT(err == 0);

    lcd_flushing_disp_drv = disp_drv;

#ifdef BSP_USING_LCD_FRAMEBUFFER
#if defined(LCD_FB_USING_TWO_COMPRESSED)||defined(LCD_FB_USING_TWO_UNCOMPRESSED)
    if (disp_drv->flushing_last)
    {
        pending_switch_draw_buf = 1;
    }
#endif
    drv_lcd_fb_write_send(&clip_area, &src_area, (uint8_t *)color_p, lcd_flush_done,
                          disp_drv->flushing_last);
    if (prof_on)
    {
        uint32_t now = DWT->CYCCNT;

        prof.blk += now - prof_t;
        prof.chunks++;
        prof.px += lv_area_get_size(refresh_area);
        if (disp_drv->flushing_last)
        {
            prof_flush_t = now;
        }
    }
#else
    debug_lcd_flush_start(clip_area.x0, clip_area.y0, clip_area.x1, clip_area.y1);
    struct lcddev_area_s area =
    {
        .row_start = clip_area.y0,
        .row_end = clip_area.y1,
        .col_start = clip_area.x0,
        .col_end = clip_area.x1,
        .stride = lv_area_get_width(p_buf_area) * (LV_COLOR_DEPTH / 8),
        .data = color_p,
    };
    err = ioctl(device, LCDDEVIO_PUTAREA,
                (unsigned long)(uintptr_t)&area);
    lcd_flush_done(device, NULL);
#endif /* BSP_USING_LCD_FRAMEBUFFER */

}
void *get_disp_buf(uint32_t size)
{
    lv_display_t *disp = lv_display_get_default();
    if (!disp)
    {
        LOG_E("Display not initialized");
        return NULL;
    }

    lv_draw_buf_t *draw_buf = lv_display_get_buf_active(disp);
    if (!draw_buf || !draw_buf->data)
    {
        LOG_E("Active draw buffer is NULL or invalid");
        return NULL;
    }

    uint32_t buf_size = draw_buf->header.stride * draw_buf->header.h * lv_color_format_get_size(draw_buf->header.cf);
    if (buf_size >= size)
    {
        return (void *)draw_buf->data;
    }

#if defined(LV_FB_TWO_NOT_SCREEN_SIZE) || defined(LV_FB_TWO_SCREEN_SIZE)
    if (disp->buf_1 && disp->buf_2 &&
            draw_buf == disp->buf_1 &&
            (uint32_t)((uintptr_t)disp->buf_2->data - (uintptr_t)disp->buf_1->data) == buf_size &&
            2 * buf_size >= size)
    {
        return (void *)disp->buf_1->data;
    }
#endif

#ifndef LCD_FB_USING_NONE
    if (size <= sizeof(buf2_1))
    {
        return (void *)get_draw_buf();
    }
#endif

    LOG_W("No suitable display buffer found for size: %u", size);
    return NULL;
}

void lv_lcd_init(const char *name)
{
    struct fb_videoinfo_s vinfo;
    struct lcd_planeinfo_s pinfo;
    struct lcddev_area_align_s align;
    int ret;

    DEBUGASSERT(name != NULL);
    device = open(name, O_RDWR | O_CLOEXEC);
    DEBUGASSERT(device >= 0);
    if (device < 0)
    {
        return;
    }

    memset(&vinfo, 0, sizeof(vinfo));
    memset(&pinfo, 0, sizeof(pinfo));
    memset(&align, 0, sizeof(align));
    ret = ioctl(device, LCDDEVIO_GETVIDEOINFO,
                (unsigned long)(uintptr_t)&vinfo);
    DEBUGASSERT(ret >= 0);
    if (ret < 0)
    {
        close(device);
        device = -1;
        return;
    }

    ret = ioctl(device, LCDDEVIO_GETPLANEINFO,
                (unsigned long)(uintptr_t)&pinfo);
    DEBUGASSERT(ret >= 0);
    if (ret < 0)
    {
        close(device);
        device = -1;
        return;
    }

    (void)ioctl(device, LCDDEVIO_GETAREAALIGN,
                (unsigned long)(uintptr_t)&align);

    info.width = vinfo.xres;
    info.height = vinfo.yres;
    info.bits_per_pixel = pinfo.bpp;
    info.draw_align = align.width_align != 0 ? align.width_align : 1;

    if (info.bits_per_pixel != LV_COLOR_DEPTH)
    {
        LOG_W("framebuffer color depth(%u) mismatch (LV_COLOR_DEPTH=%u)",
              info.bits_per_pixel, LV_COLOR_DEPTH);
    }

    disp = lv_display_create(LV_HOR_RES_MAX, LV_VER_RES_MAX);
    if (disp == NULL)
    {
        DEBUGASSERT(0);
    }

    static lv_draw_buf_t draw_buf;

    lv_draw_buf_init(&draw_buf, LV_HOR_RES_MAX, LV_FB_LINE_NUM,
                     LV_COLOR_FORMAT_NATIVE,
                     LV_HOR_RES_MAX * (LV_COLOR_DEPTH >> 3),
                     &buf1_1, DRAW_BUF_PX * sizeof(lv_fb_color_t));
    draw_guard_fill(buf1_1);

#if defined(LCD_FB_USING_TWO_COMPRESSED)||defined(LCD_FB_USING_TWO_UNCOMPRESSED)
    full_redraw_env = getenv("LV_FB_FULL") != NULL;
#if LV_USE_SIFLI_EPIC
    epic_off_env = getenv("LV_EPIC_OFF") != NULL;
#endif
    prev_count = 0;
#endif

    ret = nxsem_init(&lcd_sema, 0, 1);
    DEBUGASSERT(ret == 0);
    if (ret < 0)
    {
        return;
    }

#if defined(LV_FB_TWO_NOT_SCREEN_SIZE)||defined(LV_FB_TWO_SCREEN_SIZE)
    static lv_draw_buf_t draw_buf2;

    lv_draw_buf_init(&draw_buf2, LV_HOR_RES_MAX, LV_FB_LINE_NUM,
                     LV_COLOR_FORMAT_NATIVE,
                     LV_HOR_RES_MAX * (LV_COLOR_DEPTH >> 3),
                     &buf1_2, DRAW_BUF_PX * sizeof(lv_fb_color_t));
    draw_guard_fill(buf1_2);
    lv_display_set_draw_buffers(disp, &draw_buf, &draw_buf2);
#else
    lv_display_set_draw_buffers(disp, &draw_buf, NULL);
#endif /* LV_FB_TWO_NOT_SCREEN_SIZE ||  LV_FB_TWO_SCREEN_SIZE*/

#if defined(LV_FB_ONE_SCREEN_SIZE)||defined(LV_FB_TWO_SCREEN_SIZE)
    lv_display_set_render_mode(disp, LV_DISPLAY_RENDER_MODE_DIRECT);
#else
    lv_display_set_render_mode(disp, LV_DISPLAY_RENDER_MODE_PARTIAL);
#endif /* LV_FB_ONE_SCREEN_SIZE ||  LV_FB_TWO_SCREEN_SIZE*/


    uint32_t align_size = (info.draw_align != 0) ? info.draw_align : 1;
    int32_t offset_x = 0;
    int32_t offset_y = 0;

    /*Align disp to center of physical screen*/
    if (LV_HOR_RES_MAX < info.width)
    {
        offset_x = RT_ALIGN_DOWN((info.width - LV_HOR_RES_MAX) / 2, align_size);
    }

    if (LV_VER_RES_MAX < info.height)
    {
        offset_y = RT_ALIGN_DOWN((info.height - LV_VER_RES_MAX) / 2, align_size);
    }
    lv_display_set_offset(disp, offset_x, offset_y);
    lv_display_set_flush_cb(disp, lcd_flush);
    lv_display_set_flush_wait_cb(disp, wait_flush_done);
    lv_display_add_event_cb(disp, rounder_cb, LV_EVENT_INVALIDATE_AREA, &info);
    lv_display_add_event_cb(disp, render_start, LV_EVENT_RENDER_START, NULL);
    lv_display_add_event_cb(disp, prof_refr_start_cb, LV_EVENT_REFR_START,
                            NULL);
    lv_display_add_event_cb(disp, prof_refr_ready_cb, LV_EVENT_REFR_READY,
                            NULL);

    lv_display_set_driver_data(disp, (void *)(intptr_t)device);

#ifdef BSP_USING_LCD_FRAMEBUFFER
    drv_lcd_fb_init(name);
    memset(buf2_1, 0, sizeof(buf2_1));
    up_clean_dcache((uintptr_t)buf2_1,
                    (uintptr_t)buf2_1 + sizeof(buf2_1));
#if defined(LCD_FB_USING_TWO_COMPRESSED)||defined(LCD_FB_USING_TWO_UNCOMPRESSED)
    memset(buf2_2, 0, sizeof(buf2_2));
    up_clean_dcache((uintptr_t)buf2_2,
                    (uintptr_t)buf2_2 + sizeof(buf2_2));
#endif
    update_fb();
#endif /* BSP_USING_LCD_FRAMEBUFFER */

}

/*
    * @brief Check if the refreshing is done(Including LCD flushing, GPU rendering, etc.)
    * @return true if done, false if not done
*/
bool lv_refreshing_done(void)
{
    if (drv_lcd_fb_is_busy())
    {
        return false;
    }

#if LV_USE_SIFLI_EPIC
    if (lv_epic_is_busy())
    {
        return false;
    }
#endif

    return true;
}

#if LV_USE_NUTTX_CUSTOM_INIT
void lv_nuttx_init_custom(const lv_nuttx_dsc_t *dsc,
                          lv_nuttx_result_t *result)
{
    if (dsc == NULL || result == NULL)
    {
        return;
    }

    lv_lcd_init(dsc->fb_path != NULL ? dsc->fb_path : "/dev/lcd0");
    result->disp = disp;
#if LV_USE_NUTTX_TOUCHSCREEN
    if (dsc->input_path != NULL)
    {
        result->indev = lv_nuttx_touchscreen_create(dsc->input_path);
    }
#endif
}

void lv_nuttx_deinit_custom(lv_nuttx_result_t *result)
{
    if (result != NULL && result->disp != NULL)
    {
        drv_lcd_fb_deinit();
        lv_display_delete(result->disp);
        result->disp = NULL;
    }

    if (device >= 0)
    {
        close(device);
        device = -1;
    }
}
#endif
