/*
 * SPDX-FileCopyrightText: 2019-2022 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "drv_lcd_nuttx.h"
#include "stdlib.h"
#include "drv_lcd.h"
#include "drv_io.h"
#include "drv_lcd_private.h"
#include "drv_ext_dma.h"
#include "string.h"
#include "sifli_gpio.h"
#include <errno.h>
#include <syslog.h>
#include <nuttx/clock.h>
#include <nuttx/signal.h>
#include <nuttx/lcd/lcd_dev.h>

#ifdef CONFIG_LCD_USING_CO5300
extern const lcd_drv_desc_t __lcddriver_co5300;
const void *drv_lcd_co5300_ref __attribute__((used)) = &__lcddriver_co5300;
#endif
#ifdef BSP_USING_EPIC
    #include "drv_epic.h"
#endif /* BSP_USING_EPIC */
#ifdef BSP_USING_LCD_FRAMEBUFFER
    #include "drv_lcd_fb.h"
#endif /* BSP_USING_LCD_FRAMEBUFFER */

#define  DBG_LEVEL            DBG_INFO  //DBG_LOG //

#define LOG_TAG                "drv.lcd"

#if defined(SOC_BF0_HCPU)&&!defined(BSP_USE_LCDC2_ON_HPSYS)
    #define DRV_LCD_USE_LCDC1
#endif

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

#if defined(PKG_USING_LITTLEVGL2RTT) && defined(LV_FRAME_BUF_SCHEME_0)
    /*
    LVGL defined compress buffer macros
    */

    #include "lvgl.h"

    #define COPY2COMPRESS_FB_AND_SEND

    #if LV_COLOR_DEPTH == 16
        #define COMPRESSED_FRAME_BUF_FMT  EXTDMA_CMPRCR_SRCFMT_RGB565
    #elif LV_COLOR_DEPTH == 24
        #define COMPRESSED_FRAME_BUF_FMT  EXTDMA_CMPRCR_SRCFMT_RGB888
    #else
        #define COMPRESSED_FRAME_BUF_FMT  EXTDMA_CMPRCR_SRCFMT_ARGB8888
    #endif

    #define SRC_FRAME_BUF_BPP LV_COLOR_DEPTH
    #define MAX_SRC_FRAMEBUFFER_BYTES (FB_ALIGNED_HOR_RES * LV_VER_RES_MAX * LV_COLOR_DEPTH / 8)
    #define MAX_LINEBUFFER_BYTES (FB_ALIGNED_HOR_RES * LV_COLOR_DEPTH / 8)
    #define MAX_LINE_NUM LV_VER_RES_MAX

#else

    /*
    Default compressed buffer configuration
    */
    //#define COPY2COMPRESS_FB_AND_SEND

    #define COMPRESSED_FRAME_BUF_FMT    EXTDMA_CMPRCR_SRCFMT_RGB888
    #define SRC_FRAME_BUF_BPP           24
    #define MAX_SRC_FRAMEBUFFER_BYTES   (454*454*SRC_FRAME_BUF_BPP/8)
    #define MAX_LINEBUFFER_BYTES        (454*SRC_FRAME_BUF_BPP/8)
    #define MAX_LINE_NUM                (454)

#endif /*PKG_USING_LITTLEVGL2RTT && LV_FRAME_BUF_SCHEME_0*/

#ifdef COPY2COMPRESS_FB_AND_SEND
#define COMPRESS_BUFF_MAGIC_FLAG 0x9527BEEF
#define COMPRESSED_FRAME_BUF_NUM  (2)
#if defined(BSP_USING_BOARD_FPGA_A0) || defined(BSP_USING_BOARD_SF32LB58X_FPGA) || defined(BSP_USING_BOARD_BUTTERFLITE_FPGA)
    #define FRAME_BUF_CMPR_RATE   (0)
#elif defined(BSP_USE_LCDC2_ON_HPSYS)|| !defined(LCDC_SUPPORTED_COMPRESSED_LAYER)
    #define FRAME_BUF_CMPR_RATE   (0) //Ext dma if not avaiable
#else
    #define FRAME_BUF_CMPR_RATE   (1)
#endif

#if (FRAME_BUF_CMPR_RATE == 0)
    #define COMPRESS_BUF_SIZE_IN_WORDS   RT_ALIGN(MAX_SRC_FRAMEBUFFER_BYTES, 4)/4
#elif (FRAME_BUF_CMPR_RATE == 1)
    #if SRC_FRAME_BUF_BPP == 16
        #define COMPRESS_BUF_SIZE_IN_WORDS     (RT_ALIGN((MAX_LINEBUFFER_BYTES * 3), 16) / 16 * MAX_LINE_NUM)
    #elif SRC_FRAME_BUF_BPP == 24
        #define COMPRESS_BUF_SIZE_IN_WORDS     (RT_ALIGN(MAX_LINEBUFFER_BYTES, 8) / 8 * MAX_LINE_NUM)
    #else
        #error "Fix me"
    #endif
#else
    #error "wrong compression rate"
#endif

typedef enum
{
    FRAME_BUF_EMPTY,
    FRAME_BUF_HALF_FULL,
    FRAME_BUF_FULL
} frame_buf_status_t;

typedef struct
{
    uint32_t *addr;
    uint8_t cmpr_rate;

    LCD_AreaDef window;
    LCD_AreaDef fb_rect;
    uint32_t start_tick;  //Start DMA copy (buffer allocated)
    uint32_t cp_done_tick; //DMA copy done
    uint32_t end_tick;     //Flushed to LCD (buffer free)
    uint32_t writetimes;  //Been overwrite if large than 1
    struct rt_semaphore sema; //The buf is writting or flushing
} frame_buf_t;

typedef struct
{
    frame_buf_t frame_buf[COMPRESSED_FRAME_BUF_NUM];
    struct rt_semaphore dma_sema;
    LCD_AreaDef tmp_window; //Record last 'set_window' area
    frame_buf_t *dma_copy_buf; //Current DMA copy buf   /
    const char *dma_copy_src_buf;  //Current DMA copy buf source
} frame_buf_ctx_t;

static frame_buf_ctx_t compress_fb_ctx;
static uint8_t cmpr_rate = FRAME_BUF_CMPR_RATE;

L2_NON_RET_BSS_SECT_BEGIN(comp_frambuf)
L2_NON_RET_BSS_SECT(comp_frambuf, ALIGN(4) static uint32_t compress_buf1[COMPRESS_BUF_SIZE_IN_WORDS + 1 /*Overflow flag*/]);
#if COMPRESSED_FRAME_BUF_NUM > 1
    L2_NON_RET_BSS_SECT(comp_frambuf, ALIGN(4) static uint32_t compress_buf2[COMPRESS_BUF_SIZE_IN_WORDS  + 1/*Overflow flag*/]);
#endif
L2_NON_RET_BSS_SECT_END

#define EventStartA(v)
#define EventStopA(v)

static void copy2compress_fb_init(void);
static void copy2compress_fb_deinit(void);

static frame_buf_t *alloc_frame_buf(void);
static void free_frame_buf(frame_buf_t *buf);
static frame_buf_t *get_pending_frame_buf(void);
static rt_err_t flush_pending_buf(void);
static void api_compress_fb_set_window(int x0, int y0, int x1, int y1);
static frame_buf_t *copy2compress_fb_async(const char *pixels, int32_t x0, int32_t y0, int32_t x1, int32_t y1);
static void api_copy2compress_fb_and_send_sync(const char *pixels, int32_t x0, int32_t y0, int32_t x1, int32_t y1);
static void api_copy2compress_fb_and_send_async(const char *pixels, int32_t x0, int32_t y0, int32_t x1, int32_t y1);
static rt_err_t try_flush_pending_buf(void);

#endif /* COPY2COMPRESS_FB_AND_SEND */

L1_NON_RET_BSS_SECT_BEGIN(drv_lcd_stack)
ALIGN(RT_ALIGN_SIZE)
L1_NON_RET_BSS_SECT(drv_lcd_stack, static uint8_t drv_lcd_stack[2048]);
L1_NON_RET_BSS_SECT_END

static LCD_DrvTypeDef drv_lcd;
static void (*drv_lcd_tx_complete)(rt_device_t dev, void *buffer);

int drv_lcd_set_tx_complete(void (*cb)(rt_device_t dev, void *buffer))
{
    drv_lcd_tx_complete = cb;
    return 0;
}

#ifdef BSP_USING_RAMLESS_LCD
    #ifdef BSP_PM_FREQ_SCALING
        #error "Not supported on ramless LCD"
    #endif
    static uint32_t *ramless_code = NULL;
#endif /* BSP_USING_RAMLESS_LCD */

#if defined(BSP_USING_RAMLESS_LCD) && defined(BSP_LCDC_USING_DPI)
    #if defined(LCDC_SUPPORT_EXTERNAL_LINEBUF)
        //Fixed ARGB8888 format
        #define SRAM_BUF_1LINE (LCD_HOR_RES_MAX * 4)
    #else
        //We don't know upper color format, just define the maximum RGB888 format
        #define SRAM_BUF_1LINE (LCD_HOR_RES_MAX * 3)
    #endif

    #define SRAM_BUF_1LINE_WORDS (HAL_ALIGN(SRAM_BUF_1LINE, 4) / 4)
    #define SRAM_BUF_MAGIC_NUM (0xabcdefaa)
    #define SRAM_BUF_TOTAL_WORDS  (SRAM_BUF_1LINE_WORDS + 1) /*overwrite examination*/

    static uint32_t *sram_data0 = NULL;
    static uint32_t *sram_data1 = NULL;
    #ifdef LCDC_SUPPORT_EXTERNAL_LINEBUF
        static uint32_t *unaligned_sram_data0 = NULL;
        static uint32_t *unaligned_sram_data1 = NULL;
    #endif /* LCDC_SUPPORT_EXTERNAL_LINEBUF */
#endif

RETM_BSS_SECT_BEGIN(lcd_idle_status)
static uint8_t lcd_idle_status;
RETM_BSS_SECT_END

static void lcd_display_on(void);
static void lcd_display_off(void);
static rt_err_t lcd_set_brightness(uint8_t bright);
static void lcd_driver_print_error_info(void);
static void lcd_driver_error_handle(void);
//static void async_send_timeout_handler(void *parameter);
static void aysnc_send_cmplt_cbk(LCD_DrvTypeDef *p_drvlcd, const uint8_t *buffer);
static void lcd_idlemode_on(void);
static void lcd_idlemode_off(void);
static void lcd_rotate(uint16_t degree);
static void lcd_task(void *param);
static int lcd_task_entry(int argc, FAR char *argv[]);
#ifdef LCD_USING_PWM_AS_BACKLIGHT
static int lcd_backlight_init(void);
#endif

#ifdef BSP_USING_BOARD_MPW_EVB

    #define  LCD_BACKLIGHT_POWER_PIN    1

#endif

#define WAIT_SEMA_TIMEOUT()  do {                 \
    lcd_driver_print_error_info();                \
    lcd_driver_error_handle();                    \
    LOG_E("lcd_timeout_error %s, %d",             \
          __FUNCTION__, __LINE__);                \
    RT_ASSERT(0);                                 \
} while (0)


#define IS_DRV_LCD_ERROR() ((LCD_STATUS_DISPLAY_TIMEOUT == drv_lcd.status) || (NULL == drv_lcd.p_drv_ops))

/* VelaRide panel wake and health control.  The requests travel as
 * synchronous LCD_MSG_CONTROL messages, so they run on the LCD task after
 * any queued transfer and never touch the bus in the middle of a frame.
 */

struct velaride_lcd_req_s
{
    unsigned long arg;
    int ret;
};

#ifdef CONFIG_LCD_USING_CO5300
int co5300_check_state(LCDC_HandleTypeDef *hlcdc);
void co5300_dump_state(LCDC_HandleTypeDef *hlcdc);
#endif

static bool velaride_panel_on = true;
static uint32_t velaride_recovery_count;

#define IS_LCDC_OFF()  (LCD_STATUS_DISPLAY_OFF == drv_lcd.status)

static const char *lcd_s_name(uint32_t s)
{
    switch (s)
    {
    case LCD_STATUS_NONE:
        return "NONE";
    case LCD_STATUS_OPENING:
        return "OPENING";
    case LCD_STATUS_NOT_FIND_LCD:
        return "NOT_FIND";
    case LCD_STATUS_INITIALIZED:
        return "INITIALIZED";
    case LCD_STATUS_DISPLAY_ON:
        return "ON";
    case LCD_STATUS_DISPLAY_OFF_PENDING:
        return "OFF_PENDING";
    case LCD_STATUS_DISPLAY_OFF:
        return "OFF";
    case LCD_STATUS_DISPLAY_TIMEOUT:
        return "TIMEOUT";
    case LCD_STATUS_IDLE_MODE:
        return "IDLEMODE";
    default:
        return "Unknow";
    }
}

static void set_drv_lcd_state(uint32_t new_state)
{
    uint32_t old_state;
    rt_base_t mask = (rt_base_t)enter_critical_section();
    if (new_state != drv_lcd.status)
    {
        //Keep timeout error not changed
        RT_ASSERT(drv_lcd.status != LCD_STATUS_DISPLAY_TIMEOUT);

        old_state = drv_lcd.status;
        drv_lcd.status = new_state;
    }
    else
    {
        old_state = new_state;
    }
    leave_critical_section((irqstate_t)mask);

    if (old_state != new_state)
    {
        LOG_I("[%s] -> [%s]", lcd_s_name(old_state), lcd_s_name(new_state));
    }
}

static char *lcd_msg_to_name(LCD_MsgIdDef msg)
{
#define EVENT_TO_NAME_CASE(msg) case msg: return #msg
    switch (msg)
    {
        EVENT_TO_NAME_CASE(LCD_MSG_OPEN);
        EVENT_TO_NAME_CASE(LCD_MSG_CLOSE);
        EVENT_TO_NAME_CASE(LCD_MSG_SET_MODE);
        EVENT_TO_NAME_CASE(LCD_MSG_CTRL_SET_LCD_PRESENT);
        EVENT_TO_NAME_CASE(LCD_MSG_CTRL_ASSERT_IF_DRAWTIMEOUT);
        EVENT_TO_NAME_CASE(LCD_MSG_POWER_ON);
        EVENT_TO_NAME_CASE(LCD_MSG_POWER_OFF);
        EVENT_TO_NAME_CASE(LCD_MSG_DRAW_RECT_ASYNC);
        EVENT_TO_NAME_CASE(LCD_MSG_DRAW_COMP_RECT_ASYNC);
        EVENT_TO_NAME_CASE(LCD_MSG_SET_BRIGHTNESS);

        EVENT_TO_NAME_CASE(LCD_MSG_DRAW_RECT);
        EVENT_TO_NAME_CASE(LCD_MSG_SET_WINDOW);
        EVENT_TO_NAME_CASE(LCD_MSG_SET_PIXEL);
        EVENT_TO_NAME_CASE(LCD_MSG_GET_PIXEL);

    default:
        return "UNKNOW";
    }
}

#ifdef QAD_SPI_USE_GPIO_CS

void gpio_cs_init(void)
{
    sifli_gpio_config(QAD_SPI_USE_GPIO_CS, GPIO_OUTPUT);
    sifli_gpio_write(QAD_SPI_USE_GPIO_CS, true);
}

void gpio_cs_enable(void)
{
    sifli_gpio_write(QAD_SPI_USE_GPIO_CS, false);
}

void gpio_cs_disable(void)
{
    sifli_gpio_write(QAD_SPI_USE_GPIO_CS, true);
}
#endif /* QAD_SPI_USE_GPIO_CS */

LCDC_HandleTypeDef *get_drv_lcd_handler(void)
{
    return &drv_lcd.hlcdc;
}

static rt_err_t api_lock(LCD_DrvTypeDef *p_drvlcd)
{
    rt_err_t err;
#define MAX_LCD_API_TIME  (10*1000)  /*10 seconds should be enough for LCD initialization.*/
    err = nxsem_tickwait_uninterruptible(&p_drvlcd->sem.sem,
                                         MSEC2TICK(MAX_LCD_API_TIME));
    if (err == 0) p_drvlcd->sem.value = 0;

    return err;
}

static void api_unlock(LCD_DrvTypeDef *p_drvlcd)
{
    rt_err_t err;

    RT_ASSERT(p_drvlcd);
    RT_ASSERT(0 == p_drvlcd->sem.value);
    err = nxsem_post(&p_drvlcd->sem.sem);
    if (err == 0) p_drvlcd->sem.value = 1;
    RT_ASSERT(RT_EOK == err);
}

static void print_all_msgs(rt_mq_t mq)
{
    for (uint32_t i = 0; i < mq->entry; i++)
    {
        uint32_t index = (mq->head + i) % mq->depth;
        LCD_MsgTypeDef *msg = (LCD_MsgTypeDef *)(mq->buffer + index * mq->msg_size);
        LOG_E("[%lu] id:%d,tick:%lu,drv:%p", (unsigned long)i, msg->id,
              (unsigned long)msg->tick, msg->driver);
    }
}

static rt_err_t send_msg_to_lcd_task(LCD_MsgTypeDef *msg)
{
    rt_err_t err;
    static uint32_t tick_cnt = 0;

    LCD_DrvTypeDef *p_drvlcd = msg->driver;
    msg->tick = tick_cnt++;
    LOG_D("send msg%x [%s] to lcd.", msg->tick, lcd_msg_to_name(msg->id));
    if (p_drvlcd->mq == NULL || sizeof(*msg) > p_drvlcd->mq->msg_size)
    {
        err = -EINVAL;
    }
    else
    {
        err = nxsem_trywait(&p_drvlcd->mq->slots);
        if (err < 0)
        {
            err = -RT_ETIMEOUT;
        }
        else
        {
            nxsem_wait_uninterruptible(&p_drvlcd->mq->lock);
            memcpy(p_drvlcd->mq->buffer +
                   p_drvlcd->mq->tail * p_drvlcd->mq->msg_size,
                   msg, p_drvlcd->mq->msg_size);
            p_drvlcd->mq->tail =
                (p_drvlcd->mq->tail + 1) % p_drvlcd->mq->depth;
            p_drvlcd->mq->entry++;
            nxsem_post(&p_drvlcd->mq->lock);
            nxsem_post(&p_drvlcd->mq->items);
            err = RT_EOK;
        }
    }

    if (err != RT_EOK)
    {
        LOG_E("send msg[%d] to lcd err:%d, %d msgs.", msg->id, err, p_drvlcd->mq->entry);
        print_all_msgs(p_drvlcd->mq);
        RT_ASSERT(0);
    }
    else
    {
        if (IS_SYNC_MSG_ID(msg->id))
        {
            //Wait msg been execution for synchronize msg
            err = nxsem_wait_uninterruptible(&p_drvlcd->sync_msg_sem.sem);
            if (err == 0) p_drvlcd->sync_msg_sem.value = 0;
            RT_ASSERT(RT_EOK == err);
            LOG_D("msg%x taken sync_msg_sem.", msg->tick);
        }
        else
        {
            ;
        }
    }

    return err;
}

static void enable_low_power(LCD_DrvTypeDef *p_drvlcd)
{
    HAL_StatusTypeDef err;

    LOG_D("LCDC Enter lowpower mode");

    if (p_drvlcd->auto_lowpower)
    {
        err = HAL_LCDC_Enter_LP(&p_drvlcd->hlcdc);
        if (HAL_OK != err)
        {
            LOG_E("Enter lowpower mode err %d", err);
        }
    }
    LOG_D("LCDC Enter lowpower mode done.");
}

static void disable_low_power(LCD_DrvTypeDef *p_drvlcd)
{
    HAL_StatusTypeDef err;

    LOG_D("LCDC Exit lowpower mode");
    err = HAL_LCDC_Exit_LP(&p_drvlcd->hlcdc);
    if (HAL_OK != err)
    {
        LOG_E("Exit lowpower mode err %d", err);
    }
}

#ifdef BSP_USING_LCDC
static void SendLayerDataCpltCbk(LCDC_HandleTypeDef *lcdc)
{
    LCD_DrvTypeDef *p_drvlcd = container_of(lcdc, LCD_DrvTypeDef, hlcdc);
    p_drvlcd->debug_cnt2++;

    if (lcdc->XferCpltCallback != NULL)
    {
        rt_err_t err;
        lcdc->XferCpltCallback = NULL;

        err = nxsem_post(&p_drvlcd->draw_sem.sem);
        if (err == 0) p_drvlcd->draw_sem.value = 1;
        RT_ASSERT(RT_EOK == err);
    }

}

#ifdef LCDC_SUPPORT_LINE_DONE_IRQ
static void SendLineDoneCpltCbk(LCDC_HandleTypeDef *lcdc, uint32_t lines)
{
#if 0
    uint32_t roi_top = GET_REG_VAL(lcdc->Instance->CANVAS_TL_POS,  LCD_IF_CANVAS_TL_POS_Y0_Msk, LCD_IF_CANVAS_TL_POS_Y0_Pos);
    uint32_t roi_bottom = GET_REG_VAL(lcdc->Instance->CANVAS_BR_POS,  LCD_IF_CANVAS_BR_POS_Y1_Msk, LCD_IF_CANVAS_BR_POS_Y1_Pos);

#ifndef SF32LB55X
    uint32_t v = GET_REG_VAL(lcdc->Instance->SETTING, LCD_IF_SETTING_LINE_DONE_NUM_Msk, LCD_IF_SETTING_LINE_DONE_NUM_Pos);
    uint32_t cur_rio_line = GET_REG_VAL(lcdc->Instance->CANVAS_STAT0, LCD_IF_CANVAS_STAT0_Y_COR_Msk, LCD_IF_CANVAS_STAT0_Y_COR_Pos);
#else
    uint32_t v = roi_top + lines;
    uint32_t cur_rio_line = hwp_ptc1->MEM4;
#endif /* SF32LB55X */

    LOG_D("rio[%d~%d], irq_line=%d, cur_rio_line=%d", roi_top, roi_bottom, v, cur_rio_line);

#endif
}
#endif /* LCDC_SUPPORT_LINE_DONE_IRQ */

static void SendLayerDataErrCbk(LCDC_HandleTypeDef *lcdc)
{
    LOG_E("SendLayerData Error");
    lcd_driver_print_error_info();
}

#endif

static lcd_drv_desc_t *find_right_driver(void)
{

    lcd_drv_desc_t *table_begin = NULL;
    lcd_drv_desc_t *table_end = NULL;
    lcd_drv_desc_t *p_drv_desc = NULL;

#if defined(__CC_ARM) || (defined (__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050))                                 /* ARM C Compiler */
    extern const int LcdDriverDescTab$$Base;
    extern const int LcdDriverDescTab$$Limit;
    table_begin = (lcd_drv_desc_t *) &LcdDriverDescTab$$Base;
    table_end = (lcd_drv_desc_t *)   &LcdDriverDescTab$$Limit;
#elif defined (__ICCARM__) || defined(__ICCRX__)      /* for IAR Compiler */
#error "tobe contribute"
#elif defined (__GNUC__)                              /* for GCC Compiler */
    extern const int LcdDriverDescTab_start;
    extern const int LcdDriverDescTab_end;
    table_begin = (lcd_drv_desc_t *)&LcdDriverDescTab_start;
    table_end = (lcd_drv_desc_t *) &LcdDriverDescTab_end;
#endif /* defined(__CC_ARM) */

    if ((NULL == table_begin) || (NULL == table_end) || (table_begin == table_end))
    {
        LOG_W("No LCD driver registered!");
        return NULL;
    }

    LOG_I("Try registered LCD driver...");
    if (drv_lcd.force_lcd_missing)
    {
        LOG_I("Froce LCD missing!");
    }
    else
    {

#ifndef LCD_MISSING
        for (p_drv_desc = table_begin; p_drv_desc < table_end; p_drv_desc++)
        {
            if ((p_drv_desc->p_ops != NULL) && (p_drv_desc->p_init_cfg != NULL))
            {
                if (p_drv_desc->p_ops->ReadID != NULL)
                {
                    uint32_t id;

                    if (p_drv_desc->p_ops->Init != NULL)
                        p_drv_desc->p_ops->Init(&drv_lcd.hlcdc);

                    id = p_drv_desc->p_ops->ReadID(&drv_lcd.hlcdc);

                    if (p_drv_desc->id == id)
                    {
                        LOG_I("Found lcd %s id:%xh", p_drv_desc->name, id);
                        return p_drv_desc;
                    }
                    else
                    {
                        LOG_I("Try lcd %s, read id:%xh, expect:%xh", p_drv_desc->name, id, p_drv_desc->id);
                    }
                }
            }
        }
#endif
    }
    LOG_W("unknow lcd!");
    return NULL;
}

void _lcd_low_level_init(void)
{
}

static rt_err_t api_lcd_init(rt_device_t dev)
{
    drv_lcd.brightness = MAX_BRIGHTNESS_LEVEL / 2;
    nxsem_init(&drv_lcd.sem.sem, 0, 1);
    drv_lcd.sem.value = 1;

    drv_lcd.mq = calloc(1, sizeof(*drv_lcd.mq));
    if (drv_lcd.mq != NULL)
    {
        drv_lcd.mq->buffer = calloc(4, sizeof(LCD_MsgTypeDef));
        if (drv_lcd.mq->buffer != NULL)
        {
            drv_lcd.mq->msg_size = sizeof(LCD_MsgTypeDef);
            drv_lcd.mq->depth = 4;
            nxsem_init(&drv_lcd.mq->slots, 0, drv_lcd.mq->depth);
            nxsem_init(&drv_lcd.mq->items, 0, 0);
            nxsem_init(&drv_lcd.mq->lock, 0, 1);
        }
        else
        {
            free(drv_lcd.mq);
            drv_lcd.mq = NULL;
        }
    }
    RT_ASSERT(drv_lcd.mq);

    uint16_t priority = RT_THREAD_PRIORITY_HIGH;
#ifdef SOLUTION
    priority = 6;
#endif
    drv_lcd.task.name = "lcd_task";
    drv_lcd.task.entry = lcd_task;
    drv_lcd.task.parameter = drv_lcd.mq;
    drv_lcd.task.priority = priority;
    drv_lcd.task.stack_size = sizeof(drv_lcd_stack);
    drv_lcd.task.pid = kthread_create(drv_lcd.task.name, priority,
                                      sizeof(drv_lcd_stack),
                                      lcd_task_entry, NULL);
    RT_ASSERT(drv_lcd.task.pid >= 0);
    nxsem_init(&drv_lcd.draw_sem.sem, 0, 0);
    drv_lcd.draw_sem.value = 0;
    nxsem_init(&drv_lcd.sync_msg_sem.sem, 0, 0);
    drv_lcd.sync_msg_sem.value = 0;
#ifdef COPY2COMPRESS_FB_AND_SEND
    copy2compress_fb_init();
#endif /* COPY2COMPRESS_FB_AND_SEND */

    return RT_EOK;
}

rt_thread_t lcd_get_task(void)
{
    return drv_lcd.task.name != NULL ? &drv_lcd.task : NULL;
}

#ifdef LCD_USE_GPIO_TE
static void te_pin_irq_handler(void *arg)
{
    HAL_LCDC_TE_IRQHandler((LCDC_HandleTypeDef *) arg);
}
#endif /* LCD_USE_GPIO_TE */

#ifdef BSP_USE_LCDC2_ON_HPSYS
static void copy2buf(uint8_t *dst_buf, const uint8_t *src_buf, uint16_t format, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    uint32_t bytes_per_pixel;

    //Copy to LSPYS ram use memcpy

    switch (format)
    {
    case RTGRAPHIC_PIXEL_FORMAT_RGB565:
        bytes_per_pixel  = 2;
        break;
    case RTGRAPHIC_PIXEL_FORMAT_RGB888:
        bytes_per_pixel = 3;
        break;

    default:
        RT_ASSERT(0);
        break;
    }

    memcpy(dst_buf, src_buf,
           bytes_per_pixel * (x1 - x0 + 1) * (y1 - y0 + 1));

}
#endif /* BSP_USE_LCDC2_ON_HPSYS */

#ifdef SRAM_BUF_1LINE
static void init_line_buffer(void)
{
#ifdef LCDC_SUPPORT_EXTERNAL_LINEBUF
    //Allocate memory with 64 bytes aligned address
    if (!unaligned_sram_data0) unaligned_sram_data0 = (uint32_t *) malloc_dma_friendly_sram(sizeof(uint32_t) * SRAM_BUF_TOTAL_WORDS + 63);
    RT_ASSERT(unaligned_sram_data0 != NULL);
    if (!unaligned_sram_data1) unaligned_sram_data1 = (uint32_t *) malloc_dma_friendly_sram(sizeof(uint32_t) * SRAM_BUF_TOTAL_WORDS + 63);
    RT_ASSERT(unaligned_sram_data1 != NULL);

    sram_data0 = (uint32_t *)RT_ALIGN((uint32_t)unaligned_sram_data0, 64);
    sram_data1 = (uint32_t *)RT_ALIGN((uint32_t)unaligned_sram_data1, 64);

#else /* LCDC_SUPPORT_EXTERNAL_LINEBUF */
    if (!sram_data0) sram_data0 = (uint32_t *) malloc_dma_friendly_sram(sizeof(uint32_t) * SRAM_BUF_TOTAL_WORDS);
    RT_ASSERT(sram_data0 != NULL);
    if (!sram_data1) sram_data1 = (uint32_t *) malloc_dma_friendly_sram(sizeof(uint32_t) * SRAM_BUF_TOTAL_WORDS);
    RT_ASSERT(sram_data1 != NULL);
#endif /* LCDC_SUPPORT_EXTERNAL_LINEBUF */



    sram_data0[SRAM_BUF_1LINE_WORDS] = SRAM_BUF_MAGIC_NUM;
    sram_data1[SRAM_BUF_1LINE_WORDS] = SRAM_BUF_MAGIC_NUM;
}
static bool check_line_bufer_overwrite(void)
{
    if ((sram_data0[SRAM_BUF_1LINE_WORDS] != SRAM_BUF_MAGIC_NUM)
            || (sram_data1[SRAM_BUF_1LINE_WORDS] != SRAM_BUF_MAGIC_NUM))
        return true; //overwritten
    else
        return false;
}
static void deinit_line_buffer(void)
{
#ifdef LCDC_SUPPORT_EXTERNAL_LINEBUF
    if (unaligned_sram_data0)
    {
        free_dma_friendly_sram(unaligned_sram_data0);
        unaligned_sram_data0 = NULL;
        sram_data0 = NULL;
    }
    if (unaligned_sram_data1)
    {
        free_dma_friendly_sram(unaligned_sram_data1);
        unaligned_sram_data1 = NULL;
        sram_data1 = NULL;
    }
#else /* LCDC_SUPPORT_EXTERNAL_LINEBUF */
    if (sram_data0)
    {
        free_dma_friendly_sram(sram_data0);
        sram_data0 = NULL;
    }
    if (sram_data1)
    {
        free_dma_friendly_sram(sram_data1);
        sram_data1 = NULL;
    }
#endif /* LCDC_SUPPORT_EXTERNAL_LINEBUF */
}
#endif /*SRAM_BUF_1LINE*/

extern void list_mem(void);

static rt_err_t lcd_hw_open(void)
{
    LOG_I("HW open");
    BSP_LCD_PowerUp();

#ifdef QAD_SPI_USE_GPIO_CS
    gpio_cs_init();
#endif /* QAD_SPI_USE_GPIO_CS */

#ifdef CONFIG_PM
    pm_stay(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */

    if (NULL == drv_lcd.p_drv_ops)
    {
        drv_lcd.p_drv_ops = find_right_driver();
    }
    else
    {
        LOG_I("Init LCD %s", drv_lcd.p_drv_ops->name);

        if (drv_lcd.p_drv_ops->p_ops->Init != NULL)
            drv_lcd.p_drv_ops->p_ops->Init(&drv_lcd.hlcdc);
    }

    if (drv_lcd.p_drv_ops)
    {
        enable_low_power(&drv_lcd);

#ifdef DRV_LCD_USE_LCDC1
        HAL_NVIC_SetPriority(LCDC1_IRQn, 6, 0);
        HAL_NVIC_EnableIRQ(LCDC1_IRQn);
#else
        HAL_NVIC_SetPriority(LCDC2_IRQn, 6, 0);
        HAL_NVIC_EnableIRQ(LCDC2_IRQn);
#endif

#ifdef LCD_USE_GPIO_TE
        sifli_gpio_config(LCD_USE_GPIO_TE, GPIO_INPUT);
        sifli_gpio_set_event(LCD_USE_GPIO_TE, true, false,
                             te_pin_irq_handler, &drv_lcd.hlcdc);
#endif /* LCD_USE_GPIO_TE */
#ifdef BSP_LCDC1_USE_LCDC2_TE
        HAL_LCDC_UseLCDC2TE(&drv_lcd.hlcdc);
#endif /* BSP_LCDC1_USE_LCDC2_TE */

    }

#ifdef HAL_DSI_MODULE_ENABLED
    if (drv_lcd.p_drv_ops && HAL_LCDC_IS_DSI_IF(drv_lcd.hlcdc.Init.lcd_itf))
    {
        HAL_NVIC_SetPriority(DSIHOST_IRQn, 3, 0);
        HAL_NVIC_EnableIRQ(DSIHOST_IRQn);
    }
#endif /* HAL_DSI_MODULE_ENABLED */

#ifdef HAL_V2D_GPU_MODULE_ENABLED
    HAL_NVIC_SetPriority(V2D_GPU_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(V2D_GPU_IRQn);
#endif

#ifdef CONFIG_PM
    pm_relax(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */

#ifdef SRAM_BUF_1LINE
    init_line_buffer();
#ifdef LCDC_SUPPORT_EXTERNAL_LINEBUF
    drv_lcd.hlcdc.sram_line_buf0 = sram_data0;
    drv_lcd.hlcdc.sram_line_buf1 = sram_data1;
#endif /*LCDC_SUPPORT_EXTERNAL_LINEBUF*/
#endif /* SRAM_BUF_1LINE */

#ifdef BSP_USING_RAMLESS_LCD
    if ((drv_lcd.p_drv_ops) && (HAL_LCDC_IS_PTC_AUX_IF(drv_lcd.hlcdc.Init.lcd_itf)))
    {
        if (!ramless_code) ramless_code = (uint32_t *) malloc_dma_friendly_sram(sizeof(uint32_t) * RAMLESS_AUTO_REFR_CODE_SIZE_IN_WORD);
        RT_ASSERT(ramless_code != NULL);
#ifdef BSP_LCDC_USING_DPI
        HAL_LCDC_RAMLESS_Init_Ext(&drv_lcd.hlcdc, ramless_code,
                                  (uint8_t *)&sram_data0[0], (uint8_t *)&sram_data1[0], SRAM_BUF_1LINE_WORDS * 4);
#else
        HAL_LCDC_RAMLESS_Init(&drv_lcd.hlcdc, ramless_code);
#endif /* BSP_LCDC_USING_DPI */
    }
#endif /* BSP_USING_RAMLESS_LCD */

    LOG_I("HW open done.");

    return RT_EOK;

}

static rt_err_t lcd_hw_close(void)
{
    LOG_I("HW close");

#ifdef LCD_USE_GPIO_TE
    sifli_gpio_set_event(LCD_USE_GPIO_TE, false, false, NULL, NULL);
#endif /* LCD_USE_GPIO_TE */

    HAL_LCDC_DeInit(&drv_lcd.hlcdc);

    BSP_LCD_PowerDown();
#ifdef LCDC_SUPPORT_EXTERNAL_LINEBUF
    drv_lcd.hlcdc.sram_line_buf0 = NULL;
    drv_lcd.hlcdc.sram_line_buf1 = NULL;
#else
#ifdef BSP_USING_RAMLESS_LCD
    if (ramless_code)
    {
        free_dma_friendly_sram(ramless_code);
        ramless_code = NULL;
    }
#endif /* BSP_USING_RAMLESS_LCD */
#endif /*LCDC_SUPPORT_EXTERNAL_LINEBUF*/

#ifdef SRAM_BUF_1LINE
    deinit_line_buffer();
#endif /* SRAM_BUF_1LINE */
    LOG_I("HW close done.");

    return RT_EOK;
}

static rt_err_t api_lcd_open(rt_device_t dev, rt_uint16_t oflag)
{
    LCD_MsgTypeDef msg;

    set_drv_lcd_state(LCD_STATUS_OPENING);

    msg.id = LCD_MSG_OPEN;
    msg.driver = &drv_lcd;

    send_msg_to_lcd_task(&msg);
    return RT_EOK;
}

static rt_err_t api_lcd_close(rt_device_t dev)
{
    LCD_MsgTypeDef msg;

    set_drv_lcd_state(LCD_STATUS_DISPLAY_OFF_PENDING);

    msg.id = LCD_MSG_CLOSE;
    msg.driver = &drv_lcd;

    send_msg_to_lcd_task(&msg);
    return RT_EOK;
}

static void print_u32_data(const char *name, uint32_t *p, uint32_t col_num, uint32_t total)
{
    uint32_t new_line = 0;
    printf("\r\n%s(%08x):\r\n", name, p);

    while (total-- > 0)
    {
        printf("%08x ", *p++);
        if (++new_line == col_num)
        {
            printf("\r\n");
            new_line = 0;
        }
    }
}
static void lcd_driver_print_error_info(void)
{
    LOG_E("Error, Clear p_drv_ops %x, sem_v=%d", drv_lcd.p_drv_ops, drv_lcd.sem.value);

    /*Check possible error reasons*/
    if (drv_lcd.hlcdc.Instance)
    {

        rt_base_t mask;
        mask = (rt_base_t)enter_critical_section();
        leave_critical_section((irqstate_t)mask);

        LOG_E("irq_en=%x", mask);
#ifdef DRV_LCD_USE_LCDC1
        LOG_E("LCDC1_irq_en=%x, active=%x, pending=%x", HAL_NVIC_GetEnableIRQ(LCDC1_IRQn), HAL_NVIC_GetActive(LCDC1_IRQn), NVIC_GetPendingIRQ(LCDC1_IRQn));
#else
        LOG_E("LCDC2_irq_en=%x, active=%x, pending=%x", HAL_NVIC_GetEnableIRQ(LCDC2_IRQn), HAL_NVIC_GetActive(LCDC2_IRQn), NVIC_GetPendingIRQ(LCDC2_IRQn));
#endif /* DRV_LCD_USE_LCDC1 */

        LOG_E("hlcdc errcode=%x, lock=%x, state=%x", drv_lcd.hlcdc.ErrorCode, drv_lcd.hlcdc.Lock, drv_lcd.hlcdc.State);
        LOG_E("LCDC STATUS=%x,TE=%x",    drv_lcd.hlcdc.Instance->STATUS, drv_lcd.hlcdc.Instance->TE_CONF);
        LOG_E("HAL dbg cnt %x, %x, %x", drv_lcd.hlcdc.debug_cnt0, drv_lcd.hlcdc.debug_cnt1, drv_lcd.hlcdc.debug_cnt2);
        LOG_E("DRV dbg cnt %x, %x, %x", drv_lcd.debug_cnt1, drv_lcd.debug_cnt2, drv_lcd.debug_cnt3);

#ifndef SOC_BF_Z0
        LOG_E("LCDC CANVAS TL=%x,BR=%x,SETTING=%x,IRQ=%x",
              drv_lcd.hlcdc.Instance->CANVAS_TL_POS,
              drv_lcd.hlcdc.Instance->CANVAS_BR_POS,
              drv_lcd.hlcdc.Instance->SETTING,
              drv_lcd.hlcdc.Instance->IRQ
             );

        LOG_E("LCDC LAYER0 CFG=%x,TL=%x,BR=%x,SRC=%x",
              drv_lcd.hlcdc.Instance->LAYER0_CONFIG,
              drv_lcd.hlcdc.Instance->LAYER0_TL_POS,
              drv_lcd.hlcdc.Instance->LAYER0_BR_POS,
              drv_lcd.hlcdc.Instance->LAYER0_SRC
             );

#ifdef LCD_IF_LAYER0_DECOMP_ENABLE
        LOG_E("LAYER0_DECOMP=%x", drv_lcd.hlcdc.Instance->LAYER0_DECOMP);
#else
        LOG_E("COENG_CFG=%x", drv_lcd.hlcdc.Instance->COENG_CFG);
#endif
        LOG_E("LCDC LAYER1 CFG=%x,TL=%x,BR=%x,SRC=%x",
              drv_lcd.hlcdc.Instance->LAYER1_CONFIG,
              drv_lcd.hlcdc.Instance->LAYER1_TL_POS,
              drv_lcd.hlcdc.Instance->LAYER1_BR_POS,
              drv_lcd.hlcdc.Instance->LAYER1_SRC
             );

#endif
#ifdef HAL_DSI_MODULE_ENABLED
        if (HAL_LCDC_IS_DSI_IF(drv_lcd.hlcdc.Init.lcd_itf))
        {
            LOG_E("DSI write_finish=%d, D0_STOP=%d, is_master=%d, COM_INTF=%x, PHY_CTRL=%x",
                  __HAL_DSI_IS_WRITE_FINISH(&drv_lcd.hlcdc.hdsi),
                  __HAL_DSI_IS_DLANE0_STOP(&drv_lcd.hlcdc.hdsi),
                  __HAL_DSI_IS_MASTER_STATE(&drv_lcd.hlcdc.hdsi),
                  drv_lcd.hlcdc.hdsi.Instance->COM_INTF,
                  drv_lcd.hlcdc.hdsi.Instance->PHY_CTRL
                 );

            LOG_E("DSI INT_STAT1=%x,INT_STAT2=%x",
                  drv_lcd.hlcdc.hdsi.Instance->INT_STAT1,
                  drv_lcd.hlcdc.hdsi.Instance->INT_STAT2
                 );
        }
#endif /* HAL_DSI_MODULE_ENABLED */
#if defined(BSP_USING_RAMLESS_LCD)
        if (HAL_LCDC_IS_PTC_AUX_IF(drv_lcd.hlcdc.Init.lcd_itf))
        {
            HAL_Delay(5);
            LOG_E("LCDC CANVAS TL=%x,BR=%x",
                  drv_lcd.hlcdc.Instance->CANVAS_TL_POS,
                  drv_lcd.hlcdc.Instance->CANVAS_BR_POS);
#ifdef DMA_SUPPORT_DYN_CHANNEL_ALLOC
            LOG_E("PTC DMA instance=0x%x, ch=%d",
                  drv_lcd.hlcdc.hdma_handle.Instance,
                  (drv_lcd.hlcdc.hdma_handle.ChannelIndex >> 2) + 1);
#endif

#ifdef SOC_BF0_HCPU
#if defined(hwp_ptc1)
#ifdef SF32LB55X
            const uint32_t ptc_tab_size = 24;
            const uint32_t ptc_ch_words = 3;
            const uint32_t ptc_ch_cmp_len = 12;
#else
            const uint32_t ptc_tab_size = 32;
            const uint32_t ptc_ch_words = 4;
            const uint32_t ptc_ch_cmp_len = 12;
#endif /* SF32LB55X */

            LOG_E(" PTC_MEM4=%x, DMA_TC8=%x", hwp_ptc1->MEM4, hwp_dmac1->CM0AR8);

            LOG_E("BTIM1 CR=%x, PSC=%x,ARR=%x, EGR=%x", hwp_btim1->CR1, hwp_btim1->PSC, hwp_btim1->ARR, hwp_btim1->EGR);
            LOG_E("BTIM2 CR=%x, PSC=%x,ARR=%x, EGR=%x", hwp_btim2->CR1, hwp_btim2->PSC, hwp_btim2->ARR, hwp_btim2->EGR);

            if (drv_lcd.hlcdc.ptc_code[0] != drv_lcd.hlcdc.ptc_code[24])
            {
                LOG_E("ERR: ptc_code[0,24]=%08x, %08x", drv_lcd.hlcdc.ptc_code[0],
                      drv_lcd.hlcdc.ptc_code[24]);
            }

#ifdef hwp_busmon1
            if ((hwp_busmon1->MIN7 != (uint32_t)(&hwp_ptc1->MEM4)) || (hwp_busmon1->MAX7 != hwp_busmon1->MIN7 + 4))
            {
                LOG_E("ERR: BUS_MON7=[%x, %x]", hwp_busmon1->MIN7, hwp_busmon1->MAX7);
            }
#endif /* hwp_busmon1 */

            uint32_t dma_1_ch_regs = &hwp_dmac1->CCR2 - &hwp_dmac1->CCR1;
            print_u32_data("AllDMA", (uint32_t *) & (hwp_dmac1->CCR1), dma_1_ch_regs, dma_1_ch_regs * 8);

            {
                print_u32_data("regs", (uint32_t *) & (hwp_ptc1->TCR1), ptc_ch_words, ptc_tab_size);
                uint8_t phase_idx = 0;
                for (uint32_t *p = drv_lcd.hlcdc.ptc_code; p < drv_lcd.hlcdc.ptc_code +
                        RAMLESS_AUTO_REFR_CODE_SIZE_IN_WORD; p += ptc_tab_size)
                {
                    uint32_t *ptc_ch_code = p;
                    uint32_t *ptc_ch_reg = (uint32_t *) & (hwp_ptc1->TCR1);

                    for (uint32_t ch = 1; ch <= 8; ch++)
                    {
                        if (memcmp(ptc_ch_code, ptc_ch_reg, ptc_ch_cmp_len))
                        {
                            break;
                        }
                        else if (8 == ch)
                        {
                            LOG_E("code phase %d", phase_idx);
                            print_u32_data("code", p, ptc_ch_words, ptc_tab_size);
                        }
                        else
                        {
                            ptc_ch_reg  += ptc_ch_words;
                            ptc_ch_code += ptc_ch_words;
                        }
                    }

                    phase_idx++;
                }

            }

#elif defined(hwp_ptm1)
            uint32_t pc = hwp_ptm1->PC0;
            uint32_t val = (pc < 0x800) ? (PTM1_CORE0_TCM)[pc] : *((uint32_t *)pc);
            LOG_E("PTM ENTRY=0x%08x, PC=0x%08x, val=0x%08x", drv_lcd.hlcdc.ptc_code, pc, val);
            if (0 == (val & 0xE0000000)) //Wait cmd
            {
                uint8_t src = (val >> 16) & 0xff;
                uint16_t delay = val & 0xffff;
                uint8_t pol = (val >> 24) & 0x1;

                LOG_E("Wait src=%d, delay=0x%x, pol=%d", src, delay, pol);
            }
#endif /*hwp_ptc1*/


#endif /* SOC_BF0_HCPU */

        }
#endif /* BSP_USING_RAMLESS_LCD */
    }
}

static void lcd_driver_error_handle(void)
{
#ifdef DRV_LCD_USE_LCDC1
    HAL_NVIC_DisableIRQ(LCDC1_IRQn);
#else
    HAL_NVIC_DisableIRQ(LCDC2_IRQn);
#endif

#ifdef HAL_DSI_MODULE_ENABLED
    if (drv_lcd.p_drv_ops && HAL_LCDC_IS_DSI_IF(drv_lcd.hlcdc.Init.lcd_itf))
    {
        HAL_NVIC_DisableIRQ(DSIHOST_IRQn);
    }
#endif /* HAL_DSI_MODULE_ENABLED */

    drv_lcd.p_drv_ops = NULL;
    set_drv_lcd_state(LCD_STATUS_DISPLAY_TIMEOUT);
}

static void aysnc_send_cmplt_cbk(LCD_DrvTypeDef *p_drvlcd, const uint8_t *buffer)
{
    RT_ASSERT(p_drvlcd);

    rt_device_t p_lcd_device = &p_drvlcd->parent;

    p_drvlcd->debug_cnt3++;

    if (drv_lcd_tx_complete)
    {
        drv_lcd_tx_complete(p_lcd_device, (void *)buffer);
    }

}

typedef struct _lcd_mode_desc_s
{
    uint32_t buffer_color_format;
    uint32_t buffer_compression_rate;
    uint32_t lcd_dev_color_format;
} lcd_mode_desc_t;

/**
 * @brief Set backlight brightness
 * @param bright - [0~100]  0-close backlight， 100-all backlight on
 * @return
 */
static rt_err_t lcd_set_brightness(uint8_t bright)
{

    if (IS_DRV_LCD_ERROR()) return RT_ERROR;

    LOG_I("set brightness %d", bright);

    //In case of async_send_timeout_handler called before semaphore timeout
    if (drv_lcd.p_drv_ops && drv_lcd.p_drv_ops->p_ops->SetBrightness)
    {
        disable_low_power(&drv_lcd);
        drv_lcd.p_drv_ops->p_ops->SetBrightness(&drv_lcd.hlcdc, bright);
        enable_low_power(&drv_lcd);
    }
    drv_lcd.brightness = bright;

    return RT_EOK;
}

static rt_err_t api_lcd_control(rt_device_t dev, int cmd, void *args)
{
    if (LCD_STATUS_NONE == drv_lcd.status) //LCD not been opened.
    {
        return RT_EOK;
    }

    if (RTGRAPHIC_CTRL_GET_BUSY == cmd)
    {
        if (args)
        {
            rt_err_t result;

            /* try to take condition semaphore */
            result = nxsem_trywait(&drv_lcd.sem.sem);
            if (result == 0) drv_lcd.sem.value = 0;
            if (result == -EAGAIN) result = -RT_ETIMEOUT;
            if (result == -RT_ETIMEOUT)
            {
                /* it's timeout, busy state */
                *(bool *)args = true;
            }
            else if (result == RT_EOK)
            {
                /* has taken this semaphore, release it */
                result = nxsem_post(&drv_lcd.sem.sem);
                if (result == 0) drv_lcd.sem.value = 1;

                /*Check async DMA copy*/
#if defined(COPY2COMPRESS_FB_AND_SEND) && !defined(BSP_USE_LCDC2_ON_HPSYS)
                result = nxsem_trywait(&compress_fb_ctx.dma_sema.sem);
                if (result == 0) compress_fb_ctx.dma_sema.value = 0;
                if (result == -EAGAIN) result = -RT_ETIMEOUT;
                if (result == -RT_ETIMEOUT)
                {
                    *(bool *)args = true;
                    return RT_EOK;
                }
                else if (result == RT_EOK)
                {
                    result = nxsem_post(&compress_fb_ctx.dma_sema.sem);
                    if (result == 0) compress_fb_ctx.dma_sema.value = 1;
                }
                else
                {
                    RT_ASSERT(0);
                }
#endif /* COPY2COMPRESS_FB_AND_SEND && !BSP_USE_LCDC2_ON_HPSYS*/

#ifdef BSP_USING_LCD_FRAMEBUFFER
                if (drv_lcd_fb_is_busy())
                {
                    *(bool *)args = true;
                    return RT_EOK;
                }
#endif /* BSP_USING_LCD_FRAMEBUFFER */

                *(bool *)args = (drv_lcd.mq->entry != 0) ? true : false;
            }
            else
            {
                RT_ASSERT(0);
            }

        }
        return RT_EOK;
    }

    if (SF_GRAPHIC_CTRL_GET_DRAW_ERR == cmd)
    {
        uint8_t *p_err = (uint8_t *)args;

        *p_err = drv_lcd.draw_error;

        if (*p_err)
        {
            LOG_I("Get error %d", *p_err);
            drv_lcd.draw_error = 0;
        }

        return RT_EOK;
    }

    if (RT_DEVICE_CTRL_RESUME == cmd)
    {
        if (NULL != drv_lcd.p_drv_ops)
        {
            HAL_StatusTypeDef err;
            //Re-initialize LCDC
            err = HAL_LCDC_Resume(&drv_lcd.hlcdc);
            RT_ASSERT(HAL_OK == err);
        }
#ifdef BSP_USING_EPIC
        drv_gpu_open();
#endif /* BSP_USING_EPIC */

        return RT_EOK;
    }

    if (RT_DEVICE_CTRL_SUSPEND == cmd)
    {
#ifdef BSP_USING_EPIC
        drv_gpu_close();
#endif /* BSP_USING_EPIC */
        RT_ASSERT(HAL_LCDC_STATE_BUSY != drv_lcd.hlcdc.State);
        /*LCDC lost power supply*/

        return RT_EOK;
    }

    LCD_MsgTypeDef msg;
    switch (cmd)
    {
    case RTGRAPHIC_CTRL_POWERON:
        msg.id = LCD_MSG_POWER_ON;
        break;

    case RTGRAPHIC_CTRL_POWEROFF:
        msg.id = LCD_MSG_POWER_OFF;
        break;

    case RTGRAPHIC_CTRL_SET_BRIGHTNESS:
        msg.id = LCD_MSG_SET_BRIGHTNESS;
        msg.content.brightness = *((uint8_t *)args);
        break;

    case RTGRAPHIC_CTRL_GET_BRIGHTNESS_ASYNC:
        msg.id = LCD_MSG_GET_BRIGHTNESS_ASYNC;
        msg.content.p_brightness_ret = (uint8_t *)args;
        break;

    case RTGRAPHIC_CTRL_SET_NEXT_TE:
        msg.id = LCD_MSG_SET_NEXT_TE;
        msg.content.TE_on = *((uint8_t *)args);
        break;

    case SF_GRAPHIC_CTRL_LCDC_FLUSH:
        drv_lcd.debug_cnt1++;
        msg.id = LCD_MSG_FLUSH_RECT_ASYNC;
        memcpy(&msg.content.flush, args, sizeof(msg.content.flush));
        break;

    case RTGRAPHIC_CTRL_SET_MODE:
        msg.id = LCD_MSG_SET_MODE;
        msg.content.idle_mode_on = *((uint8_t *)args);
        break;

    case SF_GRAPHIC_CTRL_ASSERT_IF_DRAWTIMEOUT:
        msg.id = LCD_MSG_CTRL_ASSERT_IF_DRAWTIMEOUT;
        msg.content.assert_timeout = (uint8_t)(uint32_t)args;
        break;

    case SF_GRAPHIC_CTRL_LCD_PRESENT:
        msg.id = LCD_MSG_CTRL_SET_LCD_PRESENT;
        msg.content.is_lcd_present = (uint8_t)(uint32_t)args;
        break;

    default:
        msg.id = LCD_MSG_CONTROL;
        msg.content.ctrl_ctx.dev = dev;
        msg.content.ctrl_ctx.cmd = cmd;
        msg.content.ctrl_ctx.args = args;
        break;
    }

    msg.driver = &drv_lcd;
    send_msg_to_lcd_task(&msg);
    return RT_EOK;
}

static int velaride_lcd_control(int cmd, struct velaride_lcd_req_s *req)
{
    const LCD_DrvOpsDef *ops;
    int ret = 0;

    if (drv_lcd.p_drv_ops == NULL)
    {
        return -ENODEV;
    }

    ops = drv_lcd.p_drv_ops->p_ops;
    switch (cmd)
    {
    case LCDDEVIO_SETPOWER:
        /* Wake and sleep only switch the panel output.  A full power cycle
         * would re-run the 270 ms init sequence on every wrist raise.
         */

        disable_low_power(&drv_lcd);
        if (req->arg > 0 && ops->DisplayOn)
        {
            ops->DisplayOn(&drv_lcd.hlcdc);
        }
        else if (req->arg == 0 && ops->DisplayOff)
        {
            ops->DisplayOff(&drv_lcd.hlcdc);
        }
        enable_low_power(&drv_lcd);
        velaride_panel_on = req->arg > 0;
        return 0;

    case LCDDEVIO_CHECKSTATE:
#ifdef CONFIG_LCD_USING_CO5300
        if (!velaride_panel_on || drv_lcd.status != LCD_STATUS_DISPLAY_ON)
        {
            return 0;
        }

        disable_low_power(&drv_lcd);
        ret = co5300_check_state(&drv_lcd.hlcdc);
        enable_low_power(&drv_lcd);
        return ret;
#else
        return -ENOTTY;
#endif

    case LCDDEVIO_REINITIALIZE:
        if (ops->Init == NULL)
        {
            return -ENODEV;
        }

        disable_low_power(&drv_lcd);
        BSP_LCD_PowerDown();
        nxsig_usleep(100000);
        BSP_LCD_PowerUp();
        ops->Init(&drv_lcd.hlcdc);
        HAL_LCDC_SetBgColor(&drv_lcd.hlcdc, 0, 0, 0);
        HAL_LCDC_LayerReset(&drv_lcd.hlcdc, HAL_LCDC_LAYER_DEFAULT);
        HAL_LCDC_LayerSetFormat(&drv_lcd.hlcdc, drv_lcd.select_layer,
                                drv_lcd.buf_format);
        if (velaride_panel_on && ops->DisplayOn)
        {
            ops->DisplayOn(&drv_lcd.hlcdc);
        }

        if (ops->SetBrightness && drv_lcd.brightness > 0)
        {
            ops->SetBrightness(&drv_lcd.hlcdc, drv_lcd.brightness);
        }

        enable_low_power(&drv_lcd);
        drv_lcd.timeout_retry_cnt = MAX_TIMEOUT_RETRY;
        set_drv_lcd_state(LCD_STATUS_DISPLAY_ON);
        velaride_recovery_count++;
#ifdef CONFIG_LCD_USING_CO5300
        disable_low_power(&drv_lcd);
        ret = co5300_check_state(&drv_lcd.hlcdc);
        enable_low_power(&drv_lcd);
        if (ret != 0)
        {
            ret = ret < 0 ? ret : -EIO;
        }
#endif

        /* Report the state after recovery, as the old driver did. */

        /* FALLTHROUGH */

    case LCDDEVIO_DUMPSTATE:
#ifdef CONFIG_LCD_USING_CO5300
        disable_low_power(&drv_lcd);
        co5300_dump_state(&drv_lcd.hlcdc);
        enable_low_power(&drv_lcd);
#endif
        syslog(LOG_INFO, "VELARIDE_LCD: state=%d error=%lu sent=%lu done=%lu"
               " recoveries=%lu\n",
               drv_lcd.hlcdc.State, (unsigned long)drv_lcd.hlcdc.ErrorCode,
               (unsigned long)drv_lcd.hlcdc.debug_cnt0,
               (unsigned long)drv_lcd.hlcdc.debug_cnt1,
               (unsigned long)velaride_recovery_count);
        return ret;

    default:
        return -ENOTTY;
    }
}

static rt_err_t exe_lcd_control_cmds(rt_device_t dev, int cmd, void *args)
{
    switch (cmd)
    {
    case LCDDEVIO_SETPOWER:
    case LCDDEVIO_CHECKSTATE:
    case LCDDEVIO_REINITIALIZE:
    case LCDDEVIO_DUMPSTATE:
    {
        struct velaride_lcd_req_s *req = (struct velaride_lcd_req_s *)args;

        req->ret = velaride_lcd_control(cmd, req);
    }
    break;

    case RTGRAPHIC_CTRL_GET_INFO:
    {
        struct rt_device_graphic_info *info;
        const LCDC_InitTypeDef *lcd_cfg;

        info = (struct rt_device_graphic_info *) args;
        RT_ASSERT(info != RT_NULL);
        memset(info, 0, sizeof(struct rt_device_graphic_info));

        if (NULL != drv_lcd.p_drv_ops)
        {
            lcd_cfg = drv_lcd.p_drv_ops->p_init_cfg;
            if (LCDC_PIXEL_FORMAT_RGB332 == lcd_cfg->color_mode)
            {
                info->bits_per_pixel = 8;
                info->pixel_format = RTGRAPHIC_PIXEL_FORMAT_RGB332;
            }
            else if (LCDC_PIXEL_FORMAT_RGB565 == lcd_cfg->color_mode)
            {
                info->bits_per_pixel = 16;
                info->pixel_format = RTGRAPHIC_PIXEL_FORMAT_RGB565;
            }
            else if (LCDC_PIXEL_FORMAT_RGB666 == lcd_cfg->color_mode)
            {
                info->bits_per_pixel = 18;
                info->pixel_format = RTGRAPHIC_PIXEL_FORMAT_RGB666;
            }
            else if (LCDC_PIXEL_FORMAT_RGB888 == lcd_cfg->color_mode)
            {
                info->bits_per_pixel = 24;
                info->pixel_format = RTGRAPHIC_PIXEL_FORMAT_RGB888;
            }
            else
            {
                info->bits_per_pixel = 0;
                info->pixel_format = 0;
            }
            info->framebuffer = NULL;
            info->width = drv_lcd.p_drv_ops->lcd_horizonal_res;
            info->height = drv_lcd.p_drv_ops->lcd_vertical_res;
            info->draw_align = drv_lcd.p_drv_ops->pixel_align;
#ifdef BSP_USING_ROUND_TYPE_LCD
#ifdef BSP_USING_RECT_TYPE_LCD
#error "Can't define both 'ROUND_TYPE_LCD' and 'RECT_TYPE_LCD'"
#endif /* BSP_USING_RECT_TYPE_LCD */
            info->is_round   = 1;
#else
            info->is_round   = 0;
#endif /* BSP_USING_ROUND_TYPE_LCD */
            RT_ASSERT(info->draw_align > 0);

            switch (lcd_cfg->lcd_itf)
            {
            case LCDC_INTF_DBI_8BIT_A:
            case LCDC_INTF_DBI_8BIT_B:
            {
                info->bandwidth = lcd_cfg->freq << 3;
                break;
            }

            case LCDC_INTF_SPI_NODCX_1DATA:
            case LCDC_INTF_SPI_DCX_1DATA:
            {
                info->bandwidth = lcd_cfg->freq;
                break;
            }
            case LCDC_INTF_SPI_NODCX_2DATA:
            case LCDC_INTF_SPI_DCX_2DATA:
            {
                info->bandwidth = lcd_cfg->freq << 1;
                break;
            }
            case LCDC_INTF_SPI_NODCX_4DATA:
            case LCDC_INTF_SPI_DCX_4DATA:
            {
                info->bandwidth = lcd_cfg->freq << 2;
                break;
            }
            case LCDC_INTF_SPI_DCX_DDR_4DATA:
            {
                info->bandwidth = lcd_cfg->freq << 3;
                break;
            }
#ifdef HAL_DSI_MODULE_ENABLED
            case LCDC_INTF_DSI:
            case LCDC_INTF_DSI_VIDEO:
            {
                if (lcd_cfg->cfg.dsi.Init.NumberOfLanes == DSI_TWO_DATA_LANES)
                    info->bandwidth = lcd_cfg->freq << 1;
                else
                    info->bandwidth = lcd_cfg->freq;

                break;
            }
#endif /* HAL_DSI_MODULE_ENABLED */
            case LCDC_INTF_JDI_PARALLEL:
            {
                info->bandwidth = lcd_cfg->freq;
                break;
            }

            default:
            {
                info->bandwidth = 0;
                break;
            }
            }
        }
        else
        {
            info->bits_per_pixel = 16;          // To avoid assert.

            rt_uint8_t max_align_v = 1; //Get maximum align value according to LCD_HOR_RES_MAX
            rt_uint16_t v = LCD_HOR_RES_MAX;
            while (v)
            {
                if (v & 1) break;
                max_align_v = max_align_v << 1;
                v = v >> 1;
            }
            info->draw_align = max_align_v;
            info->width = LCD_HOR_RES_MAX;
            info->height = LCD_VER_RES_MAX;
        }

    }
    break;

    case RTGRAPHIC_CTRL_RECT_UPDATE:
        /* nothong to be done */
        break;

    case RTGRAPHIC_CTRL_GET_STATE:
    {
        RT_ASSERT(args != NULL);
        *((LCD_DrvStatusTypeDef *)args) = drv_lcd.status;
        break;
    }

    case RTGRAPHIC_CTRL_ROTATE_180:
    {
        if (LCD_ROTATE_0_DEGREE == drv_lcd.rotate)
            lcd_rotate(LCD_ROTATE_180_DEGREE);
        else
            lcd_rotate(LCD_ROTATE_0_DEGREE);
    }
    break;

    case RTGRAPHIC_CTRL_IRQ_INTERVAL_LINE:
    {
#ifdef LCDC_SUPPORT_LINE_DONE_IRQ
        drv_lcd.hlcdc.irq_lines = *((uint16_t *)args);
        LOG_D("Set irq interval line %d", drv_lcd.hlcdc.irq_lines);
#endif /* LCDC_SUPPORT_LINE_DONE_IRQ */
    }
    break;

    case RTGRAPHIC_CTRL_GET_BRIGHTNESS:
    {
        if (args)
        {
            *(uint8_t *)args = drv_lcd.brightness;
        }
    }
    break;

        /**********************************************/
        /******************Test only  START**********/
        /**********************************************/

#if 1

#ifdef COPY2COMPRESS_FB_AND_SEND
    case SF_GRAPHIC_CTRL_LCDC_CP2COMPRESS_FB_AND_SEND_CMPRATE_GET:
        if (args)
        {
            *((uint8_t *)args) = cmpr_rate;
        }
        break;

    case SF_GRAPHIC_CTRL_LCDC_CP2COMPRESS_FB_AND_SEND_CMPRATE_SET:
        if (args)
        {
            cmpr_rate = *((uint8_t *)args);
        }
        break;
#else
    case SF_GRAPHIC_CTRL_LCDC_CP2COMPRESS_FB_AND_SEND_CMPRATE_GET:
        if (args)
        {
            *((uint8_t *)args) = 0;
        }
        break;
#endif /* COPY2COMPRESS_FB_AND_SEND */

    case SF_GRAPHIC_CTRL_LCDC_OUT_FORMAT:
        if (args)
        {
            uint16_t color_f = *((uint16_t *)args);
            if (!IS_DRV_LCD_ERROR())
            {
                if (drv_lcd.p_drv_ops->p_ops->SetColorMode)
                {
                    disable_low_power(&drv_lcd);
                    drv_lcd.p_drv_ops->p_ops->SetColorMode(&drv_lcd.hlcdc, color_f);
                    enable_low_power(&drv_lcd);
                }
            }
        }
        break;
#endif

    /**********************************************/
    /******************Test only  END************/
    /**********************************************/

    default:
        lcd_layer_control(&drv_lcd, cmd, args);
        break;
    }

    return RT_EOK;
}

static void api_lcd_set_pixel(const char *pixel, int x, int y)
{
    if (!IS_DRV_LCD_ERROR())
    {
        LCD_MsgTypeDef msg;

        msg.id = LCD_MSG_SET_PIXEL;
        msg.driver = &drv_lcd;
        msg.content.pixel.data = (const uint8_t *)pixel;
        msg.content.pixel.x = x;
        msg.content.pixel.y = y;

        send_msg_to_lcd_task(&msg);
    }
}

static void api_lcd_get_pixel(char *pixel, int x, int y)
{
    if (NULL == pixel)
    {
        return;
    }

    if (!IS_DRV_LCD_ERROR())
    {
        LCD_MsgTypeDef msg;

        msg.id = LCD_MSG_GET_PIXEL;
        msg.driver = &drv_lcd;
        msg.content.pixel.data = (const uint8_t *)pixel;
        msg.content.pixel.x = x;
        msg.content.pixel.y = y;

        send_msg_to_lcd_task(&msg);
    }
}

static rt_err_t draw_core(LCD_DrvTypeDef *p_drvlcd, const uint8_t *pixels, int x0, int y0, int x1, int y1)
{
    rt_err_t err = RT_ERROR;

    RT_ASSERT(pixels != NULL);
    RT_ASSERT((x0 <= x1) && (y0 <= y1));

    RT_ASSERT(0 == p_drvlcd->draw_lock);

    p_drvlcd->draw_lock = 1;
    if (IS_DRV_LCD_ERROR() || p_drvlcd->skip_draw_core
#ifdef SKIP_GPU_ERROR_FRAME
            || gpu_timeout_cnt
#endif /* SKIP_GPU_ERROR_FRAME */
       )
    {
#ifdef SKIP_GPU_ERROR_FRAME
        gpu_timeout_cnt = 0;
#endif /* SKIP_GPU_ERROR_FRAME */
        err = RT_EOK;//Do nothing if LCD ERROR.
    }
    else if (p_drvlcd->p_drv_ops->p_ops->WriteMultiplePixels)
    {

#ifdef BSP_USE_LCDC2_ON_HPSYS

#ifndef LPSYS_FRAMEBUFFER_START_ADDR
        uint8_t *lcpu_buf = (uint8_t *)0x20440000;
        LOG_W("lcpu_buf 0x%x, TODO: define LPSYS buffer in mem_map.h", lcpu_buf);
#else
        uint8_t *lcpu_buf = (uint8_t *)LPSYS_FRAMEBUFFER_START_ADDR;
#endif
        /*LCDC2 can't access HPSYS memory, replace with lcpu buf here*/
        copy2buf(lcpu_buf, pixels, p_drvlcd->buf_format, x0, y0, x1, y1);
        pixels = (const uint8_t *)lcpu_buf;
#endif /* BSP_USE_LCDC2_ON_HPSYS */

        LOG_D("draw_core %x, [%d,%d,%d,%d]", pixels, x0, y0, x1, y1);

#ifdef CONFIG_PM
        pm_stay(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */
        disable_low_power(p_drvlcd);

        int new_x0, new_x1, new_y0, new_y1;//Layer coordinates
        new_x0 = x0;
        new_x1 = x1;
        new_y0 = y0;
        new_y1 = y1;

        if (LCD_ROTATE_180_DEGREE == p_drvlcd->rotate)
        {
#ifdef LCDC_SUPPORT_H_MIRROR
            new_x0 = FLIP_V_BY_AREA(FLIP_V_BY_AREA(x0, 0, p_drvlcd->p_drv_ops->lcd_horizonal_res - 1), p_drvlcd->hlcdc.roi.x0, p_drvlcd->hlcdc.roi.x1);
            new_x1 = FLIP_V_BY_AREA(FLIP_V_BY_AREA(x1, 0, p_drvlcd->p_drv_ops->lcd_horizonal_res - 1), p_drvlcd->hlcdc.roi.x0, p_drvlcd->hlcdc.roi.x1);
#endif /* LCDC_SUPPORT_H_MIRROR */

#ifdef LCDC_SUPPORT_V_MIRROR
            new_y0 = FLIP_V_BY_AREA(y1, 0, p_drvlcd->p_drv_ops->lcd_vertical_res - 1);
            new_y1 = FLIP_V_BY_AREA(y0, 0, p_drvlcd->p_drv_ops->lcd_vertical_res - 1);
#endif /* LCDC_SUPPORT_V_MIRROR */

            RT_ASSERT((new_x0 <= new_x1) && (new_y0 <= new_y1));

            //Make ROI & Layer's coordinate positive
            int off_x, off_y;
            off_x = (new_x0 < 0) ? (0 - new_x0) : 0;
            off_y = (new_y0 < 0) ? (0 - new_y0) : 0;

            if ((off_x > 0) || (off_y > 0))
            {
                p_drvlcd->hlcdc.roi.x0 += off_x;
                p_drvlcd->hlcdc.roi.y0 += off_y;
                p_drvlcd->hlcdc.roi.x1 += off_x;
                p_drvlcd->hlcdc.roi.y1 += off_y;

                new_x0 += off_x;
                new_y0 += off_y;
                new_x1 += off_x;
                new_y1 += off_y;
            }
        }

        err = RT_EOK;
        if (p_drvlcd->p_drv_ops->p_ops->ESDDetect != NULL)
        {
            uint32_t cur_tick = (uint32_t)clock_systime_ticks();
            //Check ESD every 3 seconds
            if (HAL_GetElapsedTick(p_drvlcd->last_esd_check_tick, cur_tick) > MSEC2TICK(3000))
            {
                uint32_t ret_v = p_drvlcd->p_drv_ops->p_ops->ESDDetect(&p_drvlcd->hlcdc);

                if (ret_v != 0)
                {
                    LOG_E("ESD error %d", ret_v);
                    err = -RT_ETIMEOUT;//Go to timeout handler
                }

                p_drvlcd->last_esd_check_tick = cur_tick;
            }
        }

#if defined(LCDC_SUPPORT_EXTERNAL_LINEBUF)&&defined(SRAM_BUF_1LINE)
        if (check_line_bufer_overwrite())
        {
            LOG_E("Line buffer overwritten!!");
            RT_ASSERT(0);
        }
#else
#ifdef BSP_USING_RAMLESS_LCD
#ifdef BSP_LCDC_USING_DPI
        if (HAL_LCDC_IS_PTC_AUX_IF(p_drvlcd->hlcdc.Init.lcd_itf))
        {
            if (check_line_bufer_overwrite())
            {
                LOG_E("RAMLESS DPI overwritten!!");
                RT_ASSERT(0);
            }
        }
#endif
#endif
#endif

        //Start async send
        if (RT_EOK == err)
        {
            p_drvlcd->hlcdc.XferCpltCallback = SendLayerDataCpltCbk;
            p_drvlcd->hlcdc.XferErrorCallback = SendLayerDataErrCbk;
            p_drvlcd->hlcdc.debug_cnt0++;
#ifdef LCDC_SUPPORT_LINE_DONE_IRQ
            p_drvlcd->hlcdc.XferLineCallback = SendLineDoneCpltCbk;
#endif /* LCDC_SUPPORT_LINE_DONE_IRQ */

#ifdef QAD_SPI_USE_GPIO_CS
            gpio_cs_enable();
#endif /* QAD_SPI_USE_GPIO_CS */

            //enter_critical_section();//In case of task switch between 'get tick' and 'WriteMultiplePixels'
            p_drvlcd->start_tick = (uint32_t)clock_systime_ticks();
            p_drvlcd->p_drv_ops->p_ops->WriteMultiplePixels(&p_drvlcd->hlcdc, pixels, new_x0, new_y0, new_x1, new_y1);
            //leave_critical_section();

            /* --------- Wait send compelete -----------------*/
            err = nxsem_tickwait_uninterruptible(&p_drvlcd->draw_sem.sem,
                                                 MAX_LCD_DRAW_TIME);
            if (err == 0) p_drvlcd->draw_sem.value = 0;

#ifdef QAD_SPI_USE_GPIO_CS
            gpio_cs_disable();
#endif /* QAD_SPI_USE_GPIO_CS */

            //Clear all callback
            p_drvlcd->hlcdc.XferCpltCallback = NULL;
            p_drvlcd->hlcdc.XferErrorCallback = NULL;
#ifdef LCDC_SUPPORT_LINE_DONE_IRQ
            p_drvlcd->hlcdc.XferLineCallback = NULL;
#endif /* LCDC_SUPPORT_LINE_DONE_IRQ */

        }

        p_drvlcd->statistics.draw_core_cnt++;
        if (RT_EOK == err)
        {
            p_drvlcd->timeout_retry_cnt = MAX_TIMEOUT_RETRY;
            p_drvlcd->end_tick = (uint32_t)clock_systime_ticks();
            if (p_drvlcd->send_time_log)
            {
                LOG_I("draw_core buf=%x done, cost=%d(rt_ticks)", pixels, (p_drvlcd->end_tick - p_drvlcd->start_tick));
            }


            if ((LCD_STATUS_INITIALIZED == p_drvlcd->status) && (y1 >= p_drvlcd->p_drv_ops->lcd_vertical_res - 1))
            {
                LOG_I("Auto turn on display.");
                lcd_set_brightness(p_drvlcd->brightness);
                lcd_display_on();
            }

            if ((p_drvlcd->end_tick - p_drvlcd->start_tick) > p_drvlcd->statistics.draw_core_max)
                p_drvlcd->statistics.draw_core_max = p_drvlcd->end_tick - p_drvlcd->start_tick;
            if ((p_drvlcd->end_tick - p_drvlcd->start_tick) < p_drvlcd->statistics.draw_core_min)
                p_drvlcd->statistics.draw_core_min = p_drvlcd->end_tick - p_drvlcd->start_tick;

        }
        else if (-RT_ETIMEOUT == err)
        {
            LOG_E("draw_core timeout");

            /*Reset 'draw_sem' in case of 'XferCpltCallback' invoked after timeout*/
            while (nxsem_trywait(&p_drvlcd->draw_sem.sem) == 0) {}
            p_drvlcd->draw_sem.value = 0;
            rt_err_t err2 = nxsem_post(&p_drvlcd->draw_sem.sem);
            RT_ASSERT(RT_EOK == err2);

            p_drvlcd->draw_error = 1;
            p_drvlcd->statistics.draw_core_err_cnt++;
            lcd_driver_print_error_info();
            usleep(30 * 1000);//Wait LCDC finish if it was just started.
            lcd_driver_print_error_info();

            if (p_drvlcd->p_drv_ops->p_ops->TimeoutDbg != NULL)
                p_drvlcd->p_drv_ops->p_ops->TimeoutDbg(&p_drvlcd->hlcdc);

            if (1 == p_drvlcd->assert_timeout)
            {
                //Stop and assert
                set_drv_lcd_state(LCD_STATUS_DISPLAY_TIMEOUT);

                lcd_driver_error_handle();
                LOG_E("lcd_timeout_error %s, %d", __FUNCTION__, __LINE__);
                RT_ASSERT(0);
            }
            else if ((2 == p_drvlcd->assert_timeout) || (0 == p_drvlcd->timeout_retry_cnt))
            {
                LOG_E("Clear p_drv_ops");
                p_drvlcd->p_drv_ops = NULL;
                p_drvlcd->timeout_retry_cnt = MAX_TIMEOUT_RETRY;
                set_drv_lcd_state(LCD_STATUS_NOT_FIND_LCD);

                err = RT_EOK; //Not return error here
            }
            else
            {
                //Reset LCD and LCDC
                RT_ASSERT(p_drvlcd->p_drv_ops != NULL);
                RT_ASSERT(p_drvlcd->p_drv_ops->p_ops->TimeoutReset != NULL);

                LOG_E("draw_core timeout reset LCD START(%d)", p_drvlcd->timeout_retry_cnt);

                p_drvlcd->p_drv_ops->p_ops->TimeoutReset(&p_drvlcd->hlcdc);

                set_drv_lcd_state(LCD_STATUS_INITIALIZED);

                //SendLayerDataCpltCbk(&drv_lcd.hlcdc);
                LOG_E("draw_core timeout reset LCD  END");
                if (p_drvlcd->timeout_retry_cnt > 0) p_drvlcd->timeout_retry_cnt--;
                err = RT_EOK; //Not return error here
            }
        }
        else
        {
            RT_ASSERT(0); //Wait sema err;
        }

        enable_low_power(p_drvlcd);
#ifdef CONFIG_PM
        pm_relax(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */

        if ((uint32_t)clock_systime_ticks() - p_drvlcd->statistics.start_tick  > 2 * RT_TICK_PER_SECOND)
        {
            if (p_drvlcd->statistics_log)
            {
                uint32_t fps = 0;
                uint32_t seconds = ((uint32_t)clock_systime_ticks() - p_drvlcd->statistics.start_tick) / RT_TICK_PER_SECOND;
                if (seconds > 0) fps = (p_drvlcd->statistics.draw_core_cnt + (seconds >> 1)) / seconds;

                LOG_I("fps=%d,flush_time[%d~%d],err_cnt=%d",
                      fps,
                      p_drvlcd->statistics.draw_core_min,
                      p_drvlcd->statistics.draw_core_max,
                      p_drvlcd->statistics.draw_core_err_cnt);
            }

            p_drvlcd->statistics.draw_core_cnt = 0;
            p_drvlcd->statistics.draw_core_max = 0;
            p_drvlcd->statistics.draw_core_min = UINT32_MAX;
            p_drvlcd->statistics.start_tick = (uint32_t)clock_systime_ticks();
        }

    }

    p_drvlcd->draw_lock = 0;

    return err;
}

static void api_lcd_draw_rect(const char *pixels, int x0, int y0, int x1, int y1)
{
    LCD_MsgTypeDef msg;

    msg.id = LCD_MSG_DRAW_RECT;
    msg.driver = &drv_lcd;
    msg.content.draw_ctx.pixels = (const uint8_t *)pixels;
    msg.content.draw_ctx.area.x0 = x0;
    msg.content.draw_ctx.area.y0 = y0;
    msg.content.draw_ctx.area.x1 = x1;
    msg.content.draw_ctx.area.y1 = y1;

    send_msg_to_lcd_task(&msg);
}

static void api_lcd_draw_rect_async(const char *pixels, int x0, int y0, int x1, int y1)
{
    drv_lcd.debug_cnt1++;

    LCD_MsgTypeDef msg;

    msg.id = LCD_MSG_DRAW_RECT_ASYNC;
    msg.driver = &drv_lcd;
    msg.content.draw_ctx.pixels = (const uint8_t *)pixels;
    msg.content.draw_ctx.area.x0 = x0;
    msg.content.draw_ctx.area.y0 = y0;
    msg.content.draw_ctx.area.x1 = x1;
    msg.content.draw_ctx.area.y1 = y1;

    send_msg_to_lcd_task(&msg);
}

static void set_window(int x0, int y0, int x1, int y1)
{
    if (!IS_DRV_LCD_ERROR())
    {
        if (drv_lcd.p_drv_ops->p_ops->SetRegion)
        {
            int new_x0, new_x1, new_y0, new_y1;

            disable_low_power(&drv_lcd);

            if (drv_lcd.send_time_log)
            {
                LOG_I("gap %02d ms, set_window x0x1y0y1[%d,%d,%d,%d]",
                      ((uint32_t)clock_systime_ticks() - drv_lcd.end_tick) * 1000 / RT_TICK_PER_SECOND, //elapsed ms util last draw_core done.
                      x0, x1, y0, y1);
            }
            new_x0 = x0;
            new_x1 = x1;
            new_y0 = y0;
            new_y1 = y1;

            if (LCD_ROTATE_180_DEGREE == drv_lcd.rotate)
            {
#ifdef LCDC_SUPPORT_H_MIRROR
                new_x0 = FLIP_V_BY_AREA(x1, 0, drv_lcd.p_drv_ops->lcd_horizonal_res - 1);
                new_x1 = FLIP_V_BY_AREA(x0, 0, drv_lcd.p_drv_ops->lcd_horizonal_res - 1);
#endif /* LCDC_SUPPORT_H_MIRROR */

#ifdef LCDC_SUPPORT_V_MIRROR
                new_y0 = FLIP_V_BY_AREA(y1, 0, drv_lcd.p_drv_ops->lcd_vertical_res - 1);
                new_y1 = FLIP_V_BY_AREA(y0, 0, drv_lcd.p_drv_ops->lcd_vertical_res - 1);
#endif /* LCDC_SUPPORT_V_MIRROR */
            }

            RT_ASSERT((new_x0 <= new_x1) && (new_y0 <= new_y1));
            RT_ASSERT((new_x1 - new_x0 + 1) <= drv_lcd.p_drv_ops->lcd_horizonal_res);
            RT_ASSERT((new_y1 - new_y0 + 1) <= drv_lcd.p_drv_ops->lcd_vertical_res);

            drv_lcd.p_drv_ops->p_ops->SetRegion(&drv_lcd.hlcdc, new_x0, new_y0, new_x1, new_y1);
            enable_low_power(&drv_lcd);

        }
    }
}

static void api_lcd_set_window(int x0, int y0, int x1, int y1)
{
    LCD_MsgTypeDef msg;

    msg.id = LCD_MSG_SET_WINDOW;
    msg.driver = &drv_lcd;
    msg.content.window.x0 = x0;
    msg.content.window.y0 = y0;
    msg.content.window.x1 = x1;
    msg.content.window.y1 = y1;

    send_msg_to_lcd_task(&msg);
}

static void lcd_display_on(void)
{
    if (!IS_DRV_LCD_ERROR())
    {
        LOG_I("display on");

        disable_low_power(&drv_lcd);
        if (drv_lcd.p_drv_ops->p_ops->DisplayOn)
        {
            drv_lcd.p_drv_ops->p_ops->DisplayOn(&drv_lcd.hlcdc);
        }
        enable_low_power(&drv_lcd);

        set_drv_lcd_state(LCD_STATUS_DISPLAY_ON);
    }
}

static void lcd_display_off(void)
{
    if (!IS_DRV_LCD_ERROR())
    {
        LOG_I("display off");

        disable_low_power(&drv_lcd);
        if (drv_lcd.p_drv_ops->p_ops->SetBrightness)
        {
            drv_lcd.p_drv_ops->p_ops->SetBrightness(&drv_lcd.hlcdc, MIN_BRIGHTNESS_LEVEL);
        }
        if (drv_lcd.p_drv_ops->p_ops->DisplayOff)
        {
            drv_lcd.p_drv_ops->p_ops->DisplayOff(&drv_lcd.hlcdc);
        }
        enable_low_power(&drv_lcd);
        HAL_LCDC_DeInit(&drv_lcd.hlcdc);

        set_drv_lcd_state(LCD_STATUS_DISPLAY_OFF);
    }
}

static void lcd_set_idle_status(uint8_t status)
{
    lcd_idle_status = status;
}

L1_RET_CODE_SECT(lcd_get_idle_status, uint8_t lcd_get_idle_status(void))
{
    return lcd_idle_status;
}

static void lcd_idlemode_on(void)
{
    if (!IS_DRV_LCD_ERROR())
    {
        if (drv_lcd.p_drv_ops->p_ops->IdleModeOn)
        {
            disable_low_power(&drv_lcd);
            drv_lcd.p_drv_ops->p_ops->IdleModeOn(&drv_lcd.hlcdc);
            enable_low_power(&drv_lcd);
            lcd_set_idle_status(1);
        }

        set_drv_lcd_state(LCD_STATUS_IDLE_MODE);
    }
}

static void lcd_idlemode_off(void)
{
#if 1
    if (!IS_DRV_LCD_ERROR())
    {
        if (drv_lcd.p_drv_ops->p_ops->IdleModeOff)
        {
            disable_low_power(&drv_lcd);
            drv_lcd.p_drv_ops->p_ops->IdleModeOff(&drv_lcd.hlcdc);
            enable_low_power(&drv_lcd);
            lcd_set_idle_status(0);
        }

        set_drv_lcd_state(LCD_STATUS_DISPLAY_ON);
    }
#else
    BSP_LCD_PowerDown();


#ifdef HAL_EPIC_MODULE_ENABLED
    epic = NULL;
#endif

    nxsem_destroy(&drv_lcd.sem.sem);

#ifdef COPY2COMPRESS_FB_AND_SEND
    copy2compress_fb_deinit();
#endif /* COPY2COMPRESS_FB_AND_SEND */
    api_lcd_open(NULL, 0);
    /* Display On */
    lcd_display_on();

#endif /* 0 */
}

#if  0//def CONFIG_PM
static const uint8_t lcd_brightness[PM_SLEEP_MODE_MAX] =
{
    100,
    100,
    100,
    50,
    0,
    0,
};

static int lcd_suspend(const struct rt_device *device, uint8_t mode)
{
    int r = RT_EOK;

    if (drv_lcd.brightness != lcd_brightness[mode])
    {
        lcd_set_brightness(lcd_brightness[mode]);
        drv_lcd.brightness = lcd_brightness[mode];
    }

    return r;
}

void lcd_resume(const struct rt_device *device, uint8_t mode)
{
    if (drv_lcd.brightness != lcd_brightness[PM_SLEEP_MODE_IDLE])
    {
        lcd_set_brightness(lcd_brightness[PM_SLEEP_MODE_IDLE]);
        drv_lcd.brightness = lcd_brightness[PM_SLEEP_MODE_IDLE];
    }
    return ;
}

static const struct rt_device_pm_ops lcd_pm_op =
{
    .suspend = lcd_suspend,
    .resume = lcd_resume,
};
#endif

static void lcd_rotate(uint16_t degree)
{
    if (!IS_DRV_LCD_ERROR())
    {
        LOG_I("Rotate %d degree", degree);
        disable_low_power(&drv_lcd);
        if (drv_lcd.p_drv_ops->p_ops->Rotate)
            drv_lcd.p_drv_ops->p_ops->Rotate(&drv_lcd.hlcdc, (LCD_DrvRotateTypeDef)degree);
        HAL_LCDC_LayerRotate(&drv_lcd.hlcdc, drv_lcd.select_layer, (HAL_LCDC_RotateDef)degree);
        drv_lcd.rotate = (LCD_DrvRotateTypeDef)degree;
        enable_low_power(&drv_lcd);
    }
}

static int lcd_task_entry(int argc, FAR char *argv[])
{
    UNUSED(argc);
    UNUSED(argv);
    lcd_task(drv_lcd.mq);
    return 0;
}

static void lcd_task(void *param)
{
    rt_mq_t msg_queue = (rt_mq_t) param;
    LCD_MsgTypeDef msg;
    rt_err_t err;

    while (1)
    {
        LCD_DrvTypeDef *p_drvlcd;
        rt_tick_t start_tick;

        if (msg_queue == NULL || sizeof(msg) < msg_queue->msg_size)
        {
            err = -EINVAL;
        }
        else
        {
            err = nxsem_wait_uninterruptible(&msg_queue->items);
            if (err == 0)
            {
                nxsem_wait_uninterruptible(&msg_queue->lock);
                memcpy(&msg,
                       msg_queue->buffer +
                       msg_queue->head * msg_queue->msg_size,
                       msg_queue->msg_size);
                msg_queue->head =
                    (msg_queue->head + 1) % msg_queue->depth;
                msg_queue->entry--;
                nxsem_post(&msg_queue->lock);
                nxsem_post(&msg_queue->slots);
            }
        }

        RT_ASSERT(RT_EOK == err);
        p_drvlcd = msg.driver;

        start_tick = (uint32_t)clock_systime_ticks();

        LOG_D("lcd_task exec msg%x: [%s].", msg.tick, lcd_msg_to_name(msg.id));
#ifdef CONFIG_PM
        pm_stay(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */

        err = api_lock(p_drvlcd);
        if (RT_EOK == err)
        {
            switch (msg.id)
            {
            case LCD_MSG_OPEN:
            {
                LOG_I("open");

#ifdef BSP_USING_EPIC
                drv_gpu_open();
#endif /* BSP_USING_EPIC */
                lcd_hw_open();

                /*Set LCDC background*/
                HAL_LCDC_SetBgColor(&drv_lcd.hlcdc, 0, 0, 0);

                /*Set default layer configuration*/
                HAL_LCDC_LayerReset(&drv_lcd.hlcdc, HAL_LCDC_LAYER_DEFAULT);

                if (drv_lcd.p_drv_ops)
                {
                    drv_lcd.buf_format = drv_lcd.hlcdc.Init.color_mode;
                    HAL_LCDC_LayerSetFormat(&drv_lcd.hlcdc,
                                            drv_lcd.select_layer,
                                            drv_lcd.hlcdc.Init.color_mode);
                    set_drv_lcd_state(LCD_STATUS_INITIALIZED);
                }
                else
                {
                    LOG_I("Close LCD to save power");
                    lcd_hw_close();
                    set_drv_lcd_state(LCD_STATUS_NOT_FIND_LCD);
                }

                LOG_I("open done.");
            }
            break;

            case LCD_MSG_CLOSE:
            {
                LOG_I("close");
#ifdef BSP_USING_EPIC
                drv_gpu_close();
#endif /* BSP_USING_EPIC */
                lcd_display_off();
                lcd_hw_close();
                LOG_I("close done.");
            }
            break;

            case LCD_MSG_POWER_ON:
            {
                LOG_I("Power on");

#ifdef BSP_USING_EPIC
                drv_gpu_open();//Keep gpu_open before lcd_hw_open. Issue-2314
#endif /* BSP_USING_EPIC */
                lcd_hw_open();
                if (p_drvlcd->p_drv_ops)
                {
                    set_drv_lcd_state(LCD_STATUS_INITIALIZED); //Auto set backlight after send first framebuffer
                }
                else
                {
                    LOG_I("Close LCD to save power");
                    lcd_hw_close();
                    set_drv_lcd_state(LCD_STATUS_NOT_FIND_LCD);
                }
                LOG_I("Power on done.");

            }
            break;

            case LCD_MSG_POWER_OFF:
            {
                LOG_I("Power off");
#ifdef BSP_USING_EPIC
                drv_gpu_close();
#endif /* BSP_USING_EPIC */
                lcd_display_off();
                lcd_hw_close();
                LOG_I("Power off done");
            }
            break;

            case LCD_MSG_SET_MODE:
            {
                LOG_I("idle mode on=%d", msg.content.idle_mode_on);

                if (msg.content.idle_mode_on)
                {
                    lcd_idlemode_on();
                }
                else
                {
                    lcd_idlemode_off();
                }
            }
            break;

            case LCD_MSG_CTRL_SET_LCD_PRESENT:
            {
                LOG_I("Set lcd present %d", msg.content.is_lcd_present);

                drv_lcd.force_lcd_missing = !msg.content.is_lcd_present;
                drv_lcd.p_drv_ops = NULL;
                set_drv_lcd_state(LCD_STATUS_NOT_FIND_LCD);
            }
            break;

            case LCD_MSG_CTRL_ASSERT_IF_DRAWTIMEOUT:
            {
                LOG_I("Set assert_timeout %d", msg.content.assert_timeout);

                drv_lcd.assert_timeout = msg.content.assert_timeout;
            }
            break;

            case LCD_MSG_DRAW_RECT_ASYNC:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                LCD_DrawCtxDef *p_drawctx = &msg.content.draw_ctx;

                LOG_D("api_lcd_draw_rect_async %x, [%d,%d,%d,%d]", p_drawctx->pixels,
                      p_drawctx->area.x0, p_drawctx->area.y0,
                      p_drawctx->area.x1, p_drawctx->area.y1);
                err = draw_core(p_drvlcd, p_drawctx->pixels,
                                p_drawctx->area.x0, p_drawctx->area.y0,
                                p_drawctx->area.x1, p_drawctx->area.y1);
                RT_ASSERT(RT_EOK == err);

                aysnc_send_cmplt_cbk(p_drvlcd, p_drawctx->pixels);
            }
            break;

            case LCD_MSG_DRAW_RECT:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                LCD_DrawCtxDef *p_drawctx = &msg.content.draw_ctx;

                LOG_D("api_lcd_draw_rect %x, [%d,%d,%d,%d]", p_drawctx->pixels,
                      p_drawctx->area.x0, p_drawctx->area.y0,
                      p_drawctx->area.x1, p_drawctx->area.y1);
                err = draw_core(p_drvlcd, p_drawctx->pixels,
                                p_drawctx->area.x0, p_drawctx->area.y0,
                                p_drawctx->area.x1, p_drawctx->area.y1);
                RT_ASSERT(RT_EOK == err);

            }
            break;

#ifdef COPY2COMPRESS_FB_AND_SEND
            case LCD_MSG_DRAW_COMP_RECT_ASYNC:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                frame_buf_t *compressed_buffer = (frame_buf_t *)msg.content.compress_buf;

                err = nxsem_tickwait_uninterruptible(&compressed_buffer->sema.sem,
                                                     MSEC2TICK(MAX_LCD_DRAW_TIME));
                if (err == 0) compressed_buffer->sema.value = 0;

                if (RT_EOK == err)
                {
                    LOG_D("comressed_buf set_window [%d,%d,%d,%d]",
                          compressed_buffer->window.x0, compressed_buffer->window.y0,
                          compressed_buffer->window.x1, compressed_buffer->window.y1);
                    set_window(compressed_buffer->window.x0, compressed_buffer->window.y0,
                               compressed_buffer->window.x1, compressed_buffer->window.y1);

                    HAL_LCDC_LayerSetCmpr(&p_drvlcd->hlcdc, p_drvlcd->select_layer, cmpr_rate);

                    EventStartA(3);

                    LOG_D("comressed_buf draw %x, [%d,%d,%d,%d]", compressed_buffer->addr,
                          compressed_buffer->fb_rect.x0, compressed_buffer->fb_rect.y0,
                          compressed_buffer->fb_rect.x1, compressed_buffer->fb_rect.y1);
                    err = draw_core(p_drvlcd, (const uint8_t *)compressed_buffer->addr,
                                    compressed_buffer->fb_rect.x0, compressed_buffer->fb_rect.y0,
                                    compressed_buffer->fb_rect.x1, compressed_buffer->fb_rect.y1);
                    RT_ASSERT(RT_EOK == err);

                    /*Close compress layer after compress buf send done.
                        In case send uncompressed buf through 'draw_rect' API after
                    */
                    HAL_LCDC_LayerSetCmpr(&p_drvlcd->hlcdc, p_drvlcd->select_layer, 0);

                    //Free compressed buf
                    {
                        //RT_ASSERT(compress_fb_ctx.flush_busy);
                        EventStopA(3);
                        LOG_D("comressed_buf free %x", compressed_buffer->addr);
                        free_frame_buf(compressed_buffer);
                    }
                    err = nxsem_post(&compressed_buffer->sema.sem);
                    if (err == 0) compressed_buffer->sema.value = 1;
                    RT_ASSERT(RT_EOK == err);
                }
                else
                {
                    LOG_E("%d, skiped compressed_buf %x, elapsed %d ticks", err, compressed_buffer->addr,
                          (uint32_t)clock_systime_ticks() - compressed_buffer->start_tick);

                    free_frame_buf(compressed_buffer);
                }

            }
            break;
#endif /* COPY2COMPRESS_FB_AND_SEND */

            case LCD_MSG_FLUSH_RECT_ASYNC:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                lcd_flush_info_t *flush_info = (lcd_flush_info_t *)&msg.content.flush;

                if (flush_info->cmpr_rate > 0)
                {
                    int32_t new_x1 = flush_info->window.x1;
                    if (new_x1 < flush_info->pixel_area.x1)
                    {
                        //The end of compressed fb should be decoded.
                        new_x1 = flush_info->pixel_area.x1;
                        new_x1 = RT_ALIGN(new_x1, p_drvlcd->p_drv_ops->pixel_align) - 1;

                        if ((new_x1 > flush_info->pixel_area.x1)
                                && (new_x1 < p_drvlcd->p_drv_ops->lcd_horizonal_res))
                        {
                            LOG_E("Background%d,%d,%d",
                                  new_x1, flush_info->window.x1, flush_info->pixel_area.x1);
                        }

                        flush_info->window.x1 = new_x1;
                    }
                }

                LOG_D("set_window [%d,%d,%d,%d]",
                      flush_info->window.x0, flush_info->window.y0,
                      flush_info->window.x1, flush_info->window.y1);
                set_window(flush_info->window.x0, flush_info->window.y0,
                           flush_info->window.x1, flush_info->window.y1);

                HAL_LCDC_LayerSetCmpr(&p_drvlcd->hlcdc, p_drvlcd->select_layer, flush_info->cmpr_rate);
                p_drvlcd->buf_format = flush_info->color_format;
                HAL_LCDC_LayerSetFormat(&p_drvlcd->hlcdc, p_drvlcd->select_layer,
                                        lcd_format_to_hal_lcd_format(flush_info->color_format));

                LOG_D("draw %x, [%d,%d,%d,%d]", flush_info->pixel,
                      flush_info->pixel_area.x0, flush_info->pixel_area.y0,
                      flush_info->pixel_area.x1, flush_info->pixel_area.y1);
                err = draw_core(p_drvlcd, (const uint8_t *)flush_info->pixel,
                                flush_info->pixel_area.x0, flush_info->pixel_area.y0,
                                flush_info->pixel_area.x1, flush_info->pixel_area.y1);
                RT_ASSERT(RT_EOK == err);

                /*Close compress layer after compress buf send done.
                    In case send uncompressed buf through 'draw_rect' API after
                */
                HAL_LCDC_LayerSetCmpr(&p_drvlcd->hlcdc, p_drvlcd->select_layer, 0);

                aysnc_send_cmplt_cbk(p_drvlcd, flush_info->pixel);
            }
            break;

            case LCD_MSG_SET_WINDOW:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                LCD_AreaDef    *p_window = &msg.content.window;

                LOG_D("lcd_set_window [%d,%d,%d,%d]",
                      p_window->x0, p_window->y0, p_window->x1, p_window->y1);
                set_window(p_window->x0, p_window->y0, p_window->x1, p_window->y1);

            }
            break;

            case LCD_MSG_SET_BRIGHTNESS:
            {
                lcd_set_brightness(msg.content.brightness);
                lcd_display_on();
            }
            break;

            case LCD_MSG_GET_BRIGHTNESS_ASYNC:
            {
                if (msg.content.p_brightness_ret)
                {
                    LOG_D("GET_BRIGHTNESS_ASYNC %p, %d", msg.content.p_brightness_ret, p_drvlcd->brightness);

                    *msg.content.p_brightness_ret = p_drvlcd->brightness;
                }
            }
            break;

            case LCD_MSG_SET_PIXEL:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                if (p_drvlcd->p_drv_ops->p_ops->WritePixel)
                {
                    disable_low_power(p_drvlcd);
                    p_drvlcd->p_drv_ops->p_ops->WritePixel(&p_drvlcd->hlcdc,
                                                           msg.content.pixel.x,
                                                           msg.content.pixel.y,
                                                           msg.content.pixel.data);
                    enable_low_power(p_drvlcd);
                }
            }
            break;

            case LCD_MSG_SET_NEXT_TE:
            {
                uint8_t TE_on = msg.content.TE_on;
                LOG_D("TE_on=%d", TE_on);
                HAL_LCDC_Next_Frame_TE(&drv_lcd.hlcdc, (0 == TE_on) ? false : true);
            }
            break;

            case LCD_MSG_GET_PIXEL:
            {
                RT_ASSERT(!IS_LCDC_OFF());
                if (p_drvlcd->p_drv_ops->p_ops->ReadPixel)
                {
                    disable_low_power(p_drvlcd);
                    uint32_t v = p_drvlcd->p_drv_ops->p_ops->ReadPixel(&p_drvlcd->hlcdc,
                                 msg.content.pixel.x,
                                 msg.content.pixel.y);
                    enable_low_power(p_drvlcd);

                    *(uint32_t *)msg.content.pixel.data = v;
                }

            }
            break;

            case LCD_MSG_CONTROL:
            {
                exe_lcd_control_cmds(msg.content.ctrl_ctx.dev,
                                     msg.content.ctrl_ctx.cmd,
                                     msg.content.ctrl_ctx.args
                                    );
            }
            break;

            default:
                RT_ASSERT(0);
                break;
            }

            api_unlock(p_drvlcd);
        }
        else
        {
            WAIT_SEMA_TIMEOUT();
            if (LCD_MSG_DRAW_RECT_ASYNC == (msg.id))
            {
                aysnc_send_cmplt_cbk(p_drvlcd, (uint8_t *)msg.content.draw_ctx.pixels);
            }
        }

#ifdef CONFIG_PM
        pm_relax(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */

        if (IS_SYNC_MSG_ID(msg.id))
        {
            err = nxsem_post(&p_drvlcd->sync_msg_sem.sem);
            if (err == 0) p_drvlcd->sync_msg_sem.value = 1;
            RT_ASSERT(RT_EOK == err);
        }

        LOG_D("lcd_task exec msg%x: [%s] cost=%dms.", msg.tick, lcd_msg_to_name(msg.id),
              (uint32_t)clock_systime_ticks() - start_tick);
    }

}

static int nuttx_lcd_getvideoinfo(FAR struct lcd_dev_s *dev,
                                  FAR struct fb_videoinfo_s *vinfo)
{
    struct rt_device_graphic_info info;

    if ((dev == NULL) || (vinfo == NULL)) return -EINVAL;
    exe_lcd_control_cmds(dev, RTGRAPHIC_CTRL_GET_INFO, &info);
    if (info.bits_per_pixel == 0) info.bits_per_pixel = 16;
    memset(vinfo, 0, sizeof(*vinfo));
    vinfo->fmt = (info.bits_per_pixel == 16) ? FB_FMT_RGB16_565 :
                 (info.bits_per_pixel == 24) ? FB_FMT_RGB24 : FB_FMT_RGB32;
    vinfo->xres = info.width;
    vinfo->yres = info.height;
    vinfo->nplanes = 1;
    return 0;
}

static int nuttx_lcd_putrun(FAR struct lcd_dev_s *dev, fb_coord_t row,
                            fb_coord_t col, FAR const uint8_t *buffer,
                            size_t npixels)
{
    UNUSED(dev);
    if ((buffer == NULL) || (npixels == 0)) return -EINVAL;
    api_lcd_set_window(col, row, col + npixels - 1, row);
    api_lcd_draw_rect((const char *)buffer, col, row,
                      col + npixels - 1, row);
    return 0;
}

static int nuttx_lcd_putarea(FAR struct lcd_dev_s *dev,
                             fb_coord_t row_start, fb_coord_t row_end,
                             fb_coord_t col_start, fb_coord_t col_end,
                             FAR const uint8_t *buffer, fb_coord_t stride)
{
    struct rt_device_graphic_info info;
    size_t line_bytes;

    if ((dev == NULL) || (buffer == NULL) || (row_start > row_end) ||
        (col_start > col_end)) return -EINVAL;
    exe_lcd_control_cmds(dev, RTGRAPHIC_CTRL_GET_INFO, &info);
    line_bytes = (col_end - col_start + 1) * info.bits_per_pixel / 8;
    if ((stride == 0) || (stride == line_bytes))
    {
        api_lcd_set_window(col_start, row_start, col_end, row_end);
        api_lcd_draw_rect((const char *)buffer, col_start, row_start,
                          col_end, row_end);
    }
    else
    {
        for (fb_coord_t row = row_start; row <= row_end; row++)
        {
            api_lcd_set_window(col_start, row, col_end, row);
            api_lcd_draw_rect((const char *)buffer, col_start, row,
                              col_end, row);
            buffer += stride;
        }
    }
    return 0;
}

static int nuttx_lcd_getplaneinfo(FAR struct lcd_dev_s *dev,
                                  unsigned int planeno,
                                  FAR struct lcd_planeinfo_s *pinfo)
{
    struct rt_device_graphic_info info;

    if ((dev == NULL) || (pinfo == NULL) || (planeno != 0)) return -EINVAL;
    exe_lcd_control_cmds(dev, RTGRAPHIC_CTRL_GET_INFO, &info);
    memset(pinfo, 0, sizeof(*pinfo));
    pinfo->putrun = nuttx_lcd_putrun;
    pinfo->putarea = nuttx_lcd_putarea;
    pinfo->bpp = info.bits_per_pixel != 0 ? info.bits_per_pixel : 16;
    pinfo->dev = dev;
    return 0;
}

static int nuttx_lcd_velaride_request(FAR struct lcd_dev_s *dev, int cmd,
                                      unsigned long arg)
{
    struct velaride_lcd_req_s req;

    if (drv_lcd.status == LCD_STATUS_NONE)
    {
        return -ENODEV;
    }

    req.arg = arg;
    req.ret = -EIO;
    api_lcd_control(dev, cmd, &req);
    return req.ret;
}

static int nuttx_lcd_getpower(FAR struct lcd_dev_s *dev)
{
    UNUSED(dev);
    return (drv_lcd.status == LCD_STATUS_DISPLAY_ON && velaride_panel_on) ?
           CONFIG_LCD_MAXPOWER : 0;
}

static int nuttx_lcd_setpower(FAR struct lcd_dev_s *dev, int power)
{
    return nuttx_lcd_velaride_request(dev, LCDDEVIO_SETPOWER, power > 0);
}

static int nuttx_lcd_getcontrast(FAR struct lcd_dev_s *dev)
{
    UNUSED(dev);
    return drv_lcd.brightness;
}

static int nuttx_lcd_setcontrast(FAR struct lcd_dev_s *dev,
                                 unsigned int contrast)
{
    uint8_t brightness = contrast > 100 ? 100 : contrast;
    return api_lcd_control(dev, RTGRAPHIC_CTRL_SET_BRIGHTNESS, &brightness);
}

static int nuttx_lcd_getareaalign(FAR struct lcd_dev_s *dev,
                                  FAR struct lcddev_area_align_s *align)
{
    uint16_t pixel_align = drv_lcd.p_drv_ops != NULL ?
                           drv_lcd.p_drv_ops->pixel_align : 1;
    UNUSED(dev);
    if (align == NULL) return -EINVAL;
    align->row_start_align = pixel_align;
    align->height_align = pixel_align;
    align->col_start_align = pixel_align;
    align->width_align = pixel_align;
    align->buf_align = sizeof(uint32_t);
    return 0;
}

static int nuttx_lcd_waitidle(FAR struct lcd_dev_s *dev, unsigned int ms)
{
    clock_t start = clock_systime_ticks();
    bool busy;

    do
    {
        busy = false;
        api_lcd_control(dev, RTGRAPHIC_CTRL_GET_BUSY, &busy);
        if (!busy)
        {
            return 0;
        }

        nxsig_usleep(1000);
    }
    while (TICK2MSEC(clock_systime_ticks() - start) < ms);

    return -ETIMEDOUT;
}

static int nuttx_lcd_ioctl(FAR struct lcd_dev_s *dev, int cmd,
                           unsigned long arg)
{
    uint8_t brightness;

    switch (cmd)
    {
    case LCDDEVIO_GETBRIGHTNESS:
        return drv_lcd.brightness;

    case LCDDEVIO_SETBRIGHTNESS:
        if (arg < 20 || arg > 80)
        {
            return -EINVAL;
        }

        brightness = (uint8_t)arg;
        api_lcd_control(dev, RTGRAPHIC_CTRL_SET_BRIGHTNESS, &brightness);
        return drv_lcd.brightness == brightness ? 0 : -EIO;

    case LCDDEVIO_WAITAREA:
        return nuttx_lcd_waitidle(dev, arg > 0 ? (unsigned int)arg : 200);

    case LCDDEVIO_CHECKSTATE:
    case LCDDEVIO_DUMPSTATE:
    case LCDDEVIO_REINITIALIZE:
        return nuttx_lcd_velaride_request(dev, cmd, arg);

    case LCDDEVIO_PUTAREA_ASYNC:
        return -ENOTTY;

    default:
        return api_lcd_control(dev, cmd, (void *)(uintptr_t)arg);
    }
}

static uint16_t nuttx_lcd_openrefs;

static int nuttx_lcd_open(FAR struct lcd_dev_s *dev)
{
    static bool initialized;
    int ret;

    if (!initialized)
    {
        ret = api_lcd_init(dev);
        if (ret < 0) return ret;
        initialized = true;
    }

    if (drv_lcd.status != LCD_STATUS_NONE)
    {
        nuttx_lcd_openrefs++;
        return 0;
    }

    ret = api_lcd_open(dev, 0);
    if (ret >= 0) nuttx_lcd_openrefs = 1;
    return ret;
}

static int nuttx_lcd_close(FAR struct lcd_dev_s *dev)
{
    UNUSED(dev);

    /* Keep the panel and LCDC running after the last close.  VelaRide opens
     * /dev/lcd0 briefly for probes and diagnostics; powering the panel down
     * on each close would re-run its init sequence under the live UI.
     */

    if (nuttx_lcd_openrefs == 0) return -EINVAL;
    nuttx_lcd_openrefs--;
    return 0;
}

static int lcd_hw_init(void)
{

    _lcd_low_level_init();

    memset(&drv_lcd, 0, sizeof(drv_lcd));

#ifdef DRV_LCD_USE_LCDC1
    drv_lcd.hlcdc.Instance = LCDC1;
#else
    drv_lcd.hlcdc.Instance = LCDC2;
#endif

    drv_lcd.select_layer = HAL_LCDC_LAYER_DEFAULT;

    drv_lcd.parent.getvideoinfo = nuttx_lcd_getvideoinfo;
    drv_lcd.parent.getplaneinfo = nuttx_lcd_getplaneinfo;
    drv_lcd.parent.getpower = nuttx_lcd_getpower;
    drv_lcd.parent.setpower = nuttx_lcd_setpower;
    drv_lcd.parent.getcontrast = nuttx_lcd_getcontrast;
    drv_lcd.parent.setcontrast = nuttx_lcd_setcontrast;
    drv_lcd.parent.getareaalign = nuttx_lcd_getareaalign;
    drv_lcd.parent.ioctl = nuttx_lcd_ioctl;
    drv_lcd.parent.open = nuttx_lcd_open;
    drv_lcd.parent.close = nuttx_lcd_close;

    if (drv_lcd_irq_initialize() < 0)
    {
        LOG_E("failed to attach LCDC1 IRQ");
        return -EIO;
    }

    drv_lcd.status = LCD_STATUS_NONE;
    drv_lcd.auto_lowpower = 1;
    drv_lcd.draw_lock = 0;
    drv_lcd.rotate = LCD_ROTATE_0_DEGREE;
    drv_lcd.assert_timeout = 1;
    drv_lcd.timeout_retry_cnt = MAX_TIMEOUT_RETRY;

    return 0;
}
INIT_BOARD_EXPORT(lcd_hw_init);

int board_lcd_initialize(void)
{
    static bool initialized;
    int ret;

    if (initialized) return 0;
    ret = EXT_DMA_Init();
    if (ret < 0) return ret;
    ret = lcd_hw_init();
    if (ret < 0) return ret;
#ifdef LCD_USING_PWM_AS_BACKLIGHT
    ret = lcd_backlight_init();
    if ((ret < 0) && (ret != -EEXIST)) return ret;
#endif
#ifdef CONFIG_LCD_DEV
    ret = lcddev_register(0);
    if ((ret < 0) && (ret != -EEXIST)) return ret;
#endif
    initialized = true;
    return 0;
}

FAR struct lcd_dev_s *board_lcd_getdev(int devno)
{
    return devno == 0 ? &drv_lcd.parent : NULL;
}

#ifdef COPY2COMPRESS_FB_AND_SEND

static void copy2compress_fb_init(void)
{
    compress_fb_ctx.frame_buf[0].addr = compress_buf1;
    compress_fb_ctx.frame_buf[0].writetimes = 0;
    nxsem_init(&compress_fb_ctx.frame_buf[0].sema.sem, 0, 1);
    compress_fb_ctx.frame_buf[0].sema.value = 1;

#if (COMPRESSED_FRAME_BUF_NUM > 1)
    compress_fb_ctx.frame_buf[1].addr = compress_buf2;
    compress_fb_ctx.frame_buf[1].writetimes = 0;
    nxsem_init(&compress_fb_ctx.frame_buf[1].sema.sem, 0, 1);
    compress_fb_ctx.frame_buf[1].sema.value = 1;
#endif

    nxsem_init(&compress_fb_ctx.dma_sema.sem, 0, 1);
    compress_fb_ctx.dma_sema.value = 1;

}

static void copy2compress_fb_deinit(void)
{

    nxsem_destroy(&compress_fb_ctx.dma_sema.sem);
    nxsem_destroy(&compress_fb_ctx.frame_buf[0].sema.sem);
#if (COMPRESSED_FRAME_BUF_NUM > 1)
    nxsem_destroy(&compress_fb_ctx.frame_buf[1].sema.sem);
#endif
}

static void copy2compress_fb_dma_done_cb(void)
{
    rt_err_t err;

    frame_buf_t *compressed_buffer = compress_fb_ctx.dma_copy_buf;
    compressed_buffer->cp_done_tick = (uint32_t)clock_systime_ticks();

#ifndef BSP_USE_LCDC2_ON_HPSYS
    err = nxsem_post(&compress_fb_ctx.dma_sema.sem);
    if (err == 0) compress_fb_ctx.dma_sema.value = 1;
    RT_ASSERT(RT_EOK == err);

    EventStopA(2);
#ifdef CONFIG_PM
    pm_relax(PM_IDLE_DOMAIN, PM_IDLE);

#endif  /* CONFIG_PM */
#endif /* BSP_USE_LCDC2_ON_HPSYS */

    //4. Check compressed buffer
    RT_ASSERT(COMPRESS_BUFF_MAGIC_FLAG == compressed_buffer->addr[COMPRESS_BUF_SIZE_IN_WORDS]); //Check overflow

    err = nxsem_post(&compressed_buffer->sema.sem);
    if (err == 0) compressed_buffer->sema.value = 1;
    RT_ASSERT(RT_EOK == err);

    if (1 == compressed_buffer->writetimes) //Send msg only first time, ignore overwrite msg. And prevent lcd_task mq overflow
    {
        LCD_MsgTypeDef msg;

        msg.id = LCD_MSG_DRAW_COMP_RECT_ASYNC;
        msg.driver = &drv_lcd;
        msg.content.compress_buf = compressed_buffer;
        send_msg_to_lcd_task(&msg);

        LOG_D("send msg%x LCD_MSG_DRAW_COMP_RECT_ASYNC %x.", msg.tick, compressed_buffer->addr);
    }

    //Pixels were copy to comressed buf, release it.
    aysnc_send_cmplt_cbk(&drv_lcd, (uint8_t *)compress_fb_ctx.dma_copy_src_buf);

}

static void dma_err_cb(void)
{
    LOG_E("dma_err_cb extdma error(%x).", EXT_DMA_GetError());

    //RT_ASSERT(0);
}

/* Allocate available frame buffer for write  */
static frame_buf_t *alloc_frame_buf(void)
{
    frame_buf_t *buf = RT_NULL;
    uint32_t i;

    irqstate_t flags = enter_critical_section(); //In case of sem changed if switch to lcd_task
    for (i = 0; i < COMPRESSED_FRAME_BUF_NUM; i++)
    {
        buf = &compress_fb_ctx.frame_buf[i];

        int sem_result = nxsem_trywait(&buf->sema.sem);
        if (sem_result == 0)
        {
            buf->sema.value = 0;
            break;
        }
    }
    leave_critical_section(flags);

    if (COMPRESSED_FRAME_BUF_NUM == i)
    {
#if (1 == COMPRESSED_FRAME_BUF_NUM)
        LOG_D("Wait the only 1 cmpbuf free");
        rt_err_t err = nxsem_tickwait_uninterruptible(&buf->sema.sem,
                                                      MSEC2TICK(MAX_LCD_DRAW_TIME));
        if (err == 0) buf->sema.value = 0;
        if (RT_EOK != err)
        {
            WAIT_SEMA_TIMEOUT();
            return NULL;
        }
#else
        RT_ASSERT(0); //Always get a buf which is not been flushing
#endif
    }

    return buf;
}

/* release frame buffer */
static void free_frame_buf(frame_buf_t *buf)
{

    buf->writetimes = 0;
    buf->end_tick = (uint32_t)clock_systime_ticks();

}

#if 0
/* get frame buffer for flushing */
static frame_buf_t *get_pending_frame_buf(void)
{
    frame_buf_t *buf = RT_NULL;

    if (FRAME_BUF_EMPTY != get_frame_buf_status())
    {
        if (compress_fb_ctx.frame_buf[compress_fb_ctx.rd_idx].data_ready)
        {
            buf = &compress_fb_ctx.frame_buf[compress_fb_ctx.rd_idx];
        }
    }

    return buf;
}
#endif /* 0 */

static frame_buf_t *copy2compress_fb_async(const char *pixels, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    rt_err_t err;

    EXT_DMA_CmprTypeDef cmpr;
    uint32_t bytes_per_pixel;
    frame_buf_t *free_buffer;

    RT_ASSERT((x0 < x1) && (y0 < y1));

#ifndef BSP_USE_LCDC2_ON_HPSYS
#ifdef CONFIG_PM
    pm_stay(PM_IDLE_DOMAIN, PM_IDLE);
#endif  /* CONFIG_PM */

    err = nxsem_tickwait_uninterruptible(&compress_fb_ctx.dma_sema.sem,
                                          MSEC2TICK(1000));
    if (err == 0) compress_fb_ctx.dma_sema.value = 0;
    RT_ASSERT(RT_EOK == err);
#endif /* BSP_USE_LCDC2_ON_HPSYS */

    //1.Allocate compressed buffer
    EventStartA(1);
    free_buffer = alloc_frame_buf();
    RT_ASSERT(NULL != free_buffer);

    LOG_D("Allocated compress_fb %x", free_buffer->addr);
    EventStopA(1);

    free_buffer->start_tick = (uint32_t)clock_systime_ticks();
    free_buffer->writetimes++;

    //2. Initial compressed buffer
    if (free_buffer->writetimes > 1)
    {
        //Join old window with new one
        free_buffer->window.x0 = MIN(free_buffer->window.x0, compress_fb_ctx.tmp_window.x0);
        free_buffer->window.y0 = MIN(free_buffer->window.y0, compress_fb_ctx.tmp_window.y0);
        free_buffer->window.x1 = MAX(free_buffer->window.x1, compress_fb_ctx.tmp_window.x1);
        free_buffer->window.y1 = MAX(free_buffer->window.y1, compress_fb_ctx.tmp_window.y1);
    }
    else
    {
        memcpy(&(free_buffer->window), &(compress_fb_ctx.tmp_window), sizeof(free_buffer->window));
    }

    free_buffer->fb_rect.x0 = x0;
    free_buffer->fb_rect.y0 = y0;
    free_buffer->fb_rect.x1 = x1;
    free_buffer->fb_rect.y1 = y1;
    free_buffer->cmpr_rate = cmpr.cmpr_rate;
    free_buffer->addr[COMPRESS_BUF_SIZE_IN_WORDS] = COMPRESS_BUFF_MAGIC_FLAG;

    //3. Copy the pixels to compressed buffer
    LOG_D("copy2compress_fb_async window [%d,%d,%d,%d]",
          free_buffer->window.x0, free_buffer->window.y0,
          free_buffer->window.x1, free_buffer->window.y1);
    LOG_D("copy2compress_fb_async %x->%x, buf[%d,%d,%d,%d]", pixels, free_buffer->addr, x0, y0, x1, y1);
#ifdef BSP_USE_LCDC2_ON_HPSYS
    //Copy to LSPYS ram use memcpy
    copy2buf(free_buffer->addr, pixels, drv_lcd.buf_format, x0, y0, x1, y1);
    compress_fb_ctx.dma_copy_src_buf = pixels;
    compress_fb_ctx.dma_copy_buf = free_buffer;

    copy2compress_fb_dma_done_cb();
#else

    cmpr.cmpr_rate = cmpr_rate;
    if (cmpr.cmpr_rate > 0)
    {
        cmpr.cmpr_en = true;
    }
    else
    {
        cmpr.cmpr_en = false;
    }

    switch (drv_lcd.buf_format)
    {
    case RTGRAPHIC_PIXEL_FORMAT_RGB565:
        cmpr.src_format = EXTDMA_CMPRCR_SRCFMT_RGB565;
        bytes_per_pixel  = 2;
        break;
    case RTGRAPHIC_PIXEL_FORMAT_RGB888:
        cmpr.src_format = EXTDMA_CMPRCR_SRCFMT_RGB888;
        bytes_per_pixel = 3;
        break;

    default:
        RT_ASSERT(0);
        break;
    }

    RT_ASSERT(cmpr.src_format == COMPRESSED_FRAME_BUF_FMT);

    cmpr.col_num = x1 - x0 + 1;
    cmpr.row_num = y1 - y0 + 1;
    RT_ASSERT(MAX_LINEBUFFER_BYTES >= cmpr.col_num * bytes_per_pixel);
    RT_ASSERT(MAX_LINE_NUM >= cmpr.row_num);

    err = EXT_DMA_ConfigCmpr(1, 1, &cmpr);
    RT_ASSERT(RT_EOK == err);

    EXT_DMA_Register_Callback(EXT_DMA_XFER_CPLT_CB_ID, copy2compress_fb_dma_done_cb);
    EXT_DMA_Register_Callback(EXT_DMA_XFER_ERROR_CB_ID, dma_err_cb);
    EventStartA(2);
    compress_fb_ctx.dma_copy_src_buf = pixels;
    compress_fb_ctx.dma_copy_buf = free_buffer;
    err = EXT_DMA_START_ASYNC((uint32_t)pixels, (uint32_t)free_buffer->addr, RT_ALIGN(bytes_per_pixel * cmpr.col_num * cmpr.row_num, 4) / 4);
    RT_ASSERT(RT_EOK == err);

#endif /* BSP_USE_LCDC2_ON_HPSYS */

    return free_buffer;
}

static void api_copy2compress_fb_and_send_sync(const char *pixels, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    /**/
    api_lcd_set_window(compress_fb_ctx.tmp_window.x0,
                       compress_fb_ctx.tmp_window.y0,
                       compress_fb_ctx.tmp_window.x1,
                       compress_fb_ctx.tmp_window.y1);

    api_lcd_draw_rect(pixels, x0, y0, x1, y1);
}

static void api_copy2compress_fb_and_send_async(const char *pixels, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    drv_lcd.debug_cnt1++;

    if (!IS_DRV_LCD_ERROR())
    {
        //Invoke 'copy2compress_fb_xxx' in current thread
        copy2compress_fb_async(pixels, x0, y0, x1, y1);
    }
    else
    {
        //None LCD or LCD error, do nothing, call cmplt cbk directly.
        aysnc_send_cmplt_cbk(&drv_lcd, (uint8_t *)pixels);
    }

}

static void api_compress_fb_set_window(int x0, int y0, int x1, int y1)
{
    if (IS_DRV_LCD_ERROR()) return;

    RT_ASSERT((x0 <= x1) && (y0 <= y1));
    RT_ASSERT((x1 - x0 + 1) <= drv_lcd.p_drv_ops->lcd_horizonal_res);
    RT_ASSERT((y1 - y0 + 1) <= drv_lcd.p_drv_ops->lcd_vertical_res);

    compress_fb_ctx.tmp_window.x0 = x0;
    compress_fb_ctx.tmp_window.y0 = y0;
    compress_fb_ctx.tmp_window.x1 = x1;
    compress_fb_ctx.tmp_window.y1 = y1;
}

#endif /* COPY2COMPRESS_FB_AND_SEND */

LCDC_HandleTypeDef *debug_get_drv_lcd_handler(void)
{
    return &drv_lcd.hlcdc;
}

#ifdef LCD_USING_PWM_AS_BACKLIGHT
static uint8_t lcd_backlight_level;       // save local bl, check previous level
static int lcd_backlight_pwm_fd = -1;

#ifndef LCD_PWM_BACKLIGHT_PEROID
    #define LCD_PWM_BACKLIGHT_PEROID (10*1000)  /*set pwm peroid default: 100k*/
#endif

static int lcd_backlight_pwm_open(void)
{
    if (lcd_backlight_pwm_fd >= 0)
    {
        return lcd_backlight_pwm_fd;
    }

    lcd_backlight_pwm_fd = open("/dev/pwm0", O_RDWR);
    if (lcd_backlight_pwm_fd < 0)
    {
        int ret = -errno;
        LOG_E("open /dev/pwm0 failed: %d", ret);
        return ret;
    }

    return lcd_backlight_pwm_fd;
}

static ssize_t backligt_get(FAR struct file *filep, FAR char *buffer,
                            size_t size)
{
    struct pwm_info_s info = {0};
    int fd;

    UNUSED(filep);
    if ((buffer == NULL) || (size == 0))
    {
        return 0;
    }

    *buffer = (char)lcd_backlight_level;
    fd = lcd_backlight_pwm_open();
    if (fd >= 0 && ioctl(fd, PWMIOC_GETCHARACTERISTICS,
                         (unsigned long)(uintptr_t)&info) >= 0)
    {
#ifdef CONFIG_PWM_MULTICHAN
        LOG_I("pwm_config freq=%lu,duty=%lu", (unsigned long)info.frequency,
              (unsigned long)info.channels[0].duty);
#else
        LOG_I("pwm_config freq=%lu,duty=%lu", (unsigned long)info.frequency,
              (unsigned long)info.duty);
#endif
    }

    LOG_I("backligt_get %d%%", lcd_backlight_level);
    return 1;
}

static ssize_t backligt_set(FAR struct file *filep, FAR const char *buffer,
                            size_t size)
{
    struct pwm_info_s info = {0};
    uint8_t percent;
    int fd;
    int ret;

    UNUSED(filep);
    if ((buffer == NULL) || (size == 0))
    {
        return 0;
    }

    percent = (uint8_t)*buffer;
    if (percent > 100) percent = 100;

    fd = lcd_backlight_pwm_open();
    if (fd < 0)
    {
        return fd;
    }

    info.frequency = 1000000000U / LCD_PWM_BACKLIGHT_PEROID;
#ifdef CONFIG_PWM_MULTICHAN
#ifndef LCD_PWM_BACKLIGHT_CHANEL_NUM
#define LCD_PWM_BACKLIGHT_CHANEL_NUM 1
#endif
    info.channels[0].channel = LCD_PWM_BACKLIGHT_CHANEL_NUM;
    info.channels[0].duty = (ub16_t)((uint32_t)percent * 65535U / 100U);
#if CONFIG_PWM_NCHANNELS > 1
    info.channels[1].channel = -1;
#endif
#else
    info.duty = (ub16_t)((uint32_t)percent * 65535U / 100U);
#endif

    LOG_I("backligt_set %d%%", percent);
    ret = ioctl(fd, PWMIOC_SETCHARACTERISTICS,
                (unsigned long)(uintptr_t)&info);
    if (ret < 0)
    {
        return -errno;
    }

    ret = ioctl(fd, percent == 0 ? PWMIOC_STOP : PWMIOC_START, 0);
    if (ret < 0)
    {
        return -errno;
    }

    lcd_backlight_level = percent;
    return 1;
}

static const struct file_operations lcd_backlight_fops =
{
    .read = backligt_get,
    .write = backligt_set,
};

static int lcd_backlight_init(void)
{
    return register_driver("/dev/lcdlight", &lcd_backlight_fops,
                           0666, NULL);
}

INIT_BOARD_EXPORT(lcd_backlight_init);
#ifdef RT_USING_FINSH
static rt_err_t get_lcd_pwm_bglit(int argc, char **argv)
{
    struct file file = {0};
    uint8_t level = 0;
    backligt_get(&file, (FAR char *)&level, 1);

    LOG_I("level=%d", level);
    return 0;
}

MSH_CMD_EXPORT(get_lcd_pwm_bglit, get_lcd_pwm_bglit);
#endif

#endif /* LCD_USING_PWM_AS_BACKLIGHT */

#ifdef RT_USING_FINSH

#define DEBUG_PRINTF(...)   LOG_E(__VA_ARGS__)

/*
static rt_err_t api_lcd_init(int argc, char **argv)
{
    if (IS_DRV_LCD_ERROR()) return  RT_EOK;

    drv_lcd.p_drv_ops->p_ops->Init(&drv_lcd.hlcdc);

    return 0;
}

MSH_CMD_EXPORT(api_lcd_init, api_lcd_init);
*/

static rt_err_t lcd_rreg(int argc, char **argv)
{
    uint32_t reg, reg_len, data_len;
    uint32_t read_freq = 2 * 1000 * 1000;
    uint32_t data = 0;

    HAL_StatusTypeDef hal_err;
    rt_err_t rt_err;

    if (argc < 4)
    {
        DEBUG_PRINTF("lcd_rreg <reg_addr> <reg_addr_len> <data_len>");
        return 0;
    }

    reg       = strtoul(argv[1], 0, 16);
    reg_len   = strtoul(argv[2], 0, 10);
    data_len  = strtoul(argv[3], 0, 10);
    if (argc > 4)
    {
        read_freq = strtoul(argv[4], 0, 10);
    }

    if ((0 == reg_len) || (reg_len > 4))
    {
        DEBUG_PRINTF("reg_len should be 1~4");
        return 0;
    }
    else if ((reg >> (reg_len * 8)) != 0)
    {
        DEBUG_PRINTF("reg_addr[0x%x] overflow? Maximum reg_addr_len is %d byte(s).", reg, reg_len);
        return 0;
    }

    DEBUG_PRINTF("lcd_rreg%d [%x] %d(byte)", reg_len, reg, data_len);
    rt_err = api_lock(&drv_lcd);
    RT_ASSERT(RT_EOK == rt_err);
    disable_low_power(&drv_lcd);

#ifdef BSP_USING_RAMLESS_LCD
    rt_base_t level = (rt_base_t)enter_critical_section(); //In case RAMLESS FSM is running

    uint8_t ramless_running = drv_lcd.hlcdc.running;
    if (ramless_running)
    {
        HAL_LCDC_RAMLESS_Stop(&drv_lcd.hlcdc);
    }
#endif /* BSP_USING_RAMLESS_LCD */

    if (HAL_LCDC_IS_SPI_IF(drv_lcd.hlcdc.Init.lcd_itf) || HAL_LCDC_IS_DBI_IF(drv_lcd.hlcdc.Init.lcd_itf))
    {
        DEBUG_PRINTF("SPI/DBI r_freq=%d", read_freq);
        uint32_t prev_freq = drv_lcd.hlcdc.Init.freq;

        HAL_LCDC_SetFreq(&drv_lcd.hlcdc, read_freq); //read mode min cycle 300ns
        hal_err = HAL_LCDC_ReadDatas(&drv_lcd.hlcdc, reg, reg_len, (uint8_t *)&data, data_len);
        HAL_LCDC_SetFreq(&drv_lcd.hlcdc, prev_freq); //Restore normal frequency
    }
    else
    {
        hal_err = HAL_LCDC_ReadDatas(&drv_lcd.hlcdc, reg, reg_len, (uint8_t *)&data, data_len);
    }

#ifdef BSP_USING_RAMLESS_LCD
    if (ramless_running)
    {
        HAL_LCDC_RAMLESS_Start(&drv_lcd.hlcdc);
    }
    leave_critical_section((irqstate_t)level);
#endif /* BSP_USING_RAMLESS_LCD */
    enable_low_power(&drv_lcd);

    api_unlock(&drv_lcd);

    if (HAL_OK == hal_err)
        DEBUG_PRINTF("result=%08x\n", data);
    else
        DEBUG_PRINTF("ERROR=%d\n", hal_err);

    return 0;
}
MSH_CMD_EXPORT(lcd_rreg, lcd_rreg);

static rt_err_t lcd_wreg(int argc, char **argv)
{
    uint32_t reg, reg_len, data_len;
    uint8_t   parameter[4];
    HAL_StatusTypeDef hal_err;
    rt_err_t rt_err;

    if (argc < 3)
    {
        DEBUG_PRINTF("lcd_wreg <reg_addr> <reg_addr_len> [data0] [data1] ... [data3]");
        return 0;
    }

    reg       = strtoul(argv[1], 0, 16);
    reg_len   = strtoul(argv[2], 0, 10);
    data_len  = argc - 3;
    if ((0 == reg_len) || (reg_len > 4))
    {
        DEBUG_PRINTF("reg_len should be 1~4");
        return 0;
    }
    else if ((reg >> (reg_len * 8)) != 0)
    {
        DEBUG_PRINTF("reg_addr[0x%x] overflow? Maximum reg_addr_len is %d byte(s).", reg, reg_len);
        return 0;
    }

    for (uint32_t i = 3; i < argc; i++)
    {
        parameter[i - 3] = strtoul(argv[i], 0, 16);
    }

    DEBUG_PRINTF("lcd_wreg%d reg[%x] %d(byte)", reg_len, reg, data_len);
    rt_err = api_lock(&drv_lcd);
    RT_ASSERT(RT_EOK == rt_err);

    disable_low_power(&drv_lcd);
#ifdef BSP_USING_RAMLESS_LCD
    rt_base_t level = (rt_base_t)enter_critical_section(); //In case RAMLESS FSM is running

    uint8_t ramless_running = drv_lcd.hlcdc.running;
    if (ramless_running)
    {
        HAL_LCDC_RAMLESS_Stop(&drv_lcd.hlcdc);
    }
#endif /* BSP_USING_RAMLESS_LCD */

    hal_err = HAL_LCDC_WriteDatas(&drv_lcd.hlcdc, reg, reg_len, parameter, data_len);

#ifdef BSP_USING_RAMLESS_LCD
    if (ramless_running)
    {
        HAL_LCDC_RAMLESS_Start(&drv_lcd.hlcdc);
    }
    leave_critical_section((irqstate_t)level);
#endif /* BSP_USING_RAMLESS_LCD */
    enable_low_power(&drv_lcd);
    api_unlock(&drv_lcd);

    if (HAL_OK == hal_err)
        DEBUG_PRINTF("Done.\n");
    else
        DEBUG_PRINTF("ERROR=%d\n", hal_err);

    return 0;

}
MSH_CMD_EXPORT(lcd_wreg, lcd_wreg);

static rt_err_t lcd_ctrl(int argc, char **argv)
{
    if (argc < 2)
    {
        DEBUG_PRINTF("lcd_ctrl [OPTION] [VALUE]\n");
        DEBUG_PRINTF("    OPTION:on,off,br\n");
        return RT_EOK;
    }

    if (!drv_lcd.p_drv_ops)
    {
        DEBUG_PRINTF("lcd device not found\n");
    }

    if (strcmp(argv[1], "open") == 0)
    {
        api_lcd_init(&drv_lcd.parent);
        api_lcd_open(&drv_lcd.parent, 0);
    }
    else if (strcmp(argv[1], "close") == 0)
    {
        api_lcd_close(&drv_lcd.parent);
    }
    else if (strcmp(argv[1], "on") == 0)
    {
        api_lcd_control(&drv_lcd.parent, RTGRAPHIC_CTRL_POWERON, NULL);
    }
    else if (strcmp(argv[1], "off") == 0)
    {
        api_lcd_control(&drv_lcd.parent, RTGRAPHIC_CTRL_POWEROFF, NULL);
    }
    else if (strcmp(argv[1], "off_on") == 0)
    {
        api_lcd_control(&drv_lcd.parent, RTGRAPHIC_CTRL_POWEROFF, NULL);
        api_lcd_control(&drv_lcd.parent, RTGRAPHIC_CTRL_POWERON, NULL);
    }
    else if (strcmp(argv[1], "br") == 0)
    {
        if (argc > 2)
        {
            uint32_t v = strtoul(argv[2], 0, 10);
            api_lcd_control(&drv_lcd.parent, RTGRAPHIC_CTRL_SET_BRIGHTNESS, &v);
        }
        else
        {
            int fd = open("/dev/lcdlight", O_RDONLY);
            if (fd >= 0)
            {
                uint8_t val;
                if (1 == read(fd, &val, 1))
                {
                    LOG_I("'lcdlight' device brightness level=%d", val);
                }
                else
                {
                    LOG_E("Read 'lcdlight' device brightness level fail");
                }
                close(fd);
            }
            else
            {
                LOG_I("No 'lcdlight' device found.");
            }

            LOG_I("drv_lcd record brightness level=%d", drv_lcd.brightness);
        }
    }
    else if (strcmp(argv[1], "rotate") == 0)
    {
        if (argc > 2)
        {
            uint16_t angle = strtoul(argv[2], 0, 10);
            if (180 == angle)
                api_lcd_control(&drv_lcd.parent, RTGRAPHIC_CTRL_ROTATE_180, NULL);
        }
        else
        {
            DEBUG_PRINTF("lcd_ctrl rotate 180\n");
        }
    }
    else if (strcmp(argv[1], "log") == 0)
    {
        if (argc > 2)
        {
            uint16_t v = strtoul(argv[2], 0, 10);

            drv_lcd.send_time_log = (v == 0) ? 0 : 1;
        }
        DEBUG_PRINTF("log %d\n", drv_lcd.send_time_log);
    }
    else if (strcmp(argv[1], "freq") == 0)
    {
        if (argc > 2)
        {
            uint32_t freq = strtoul(argv[2], 0, 10);

            HAL_LCDC_SetFreq(&drv_lcd.hlcdc, freq);
        }
        DEBUG_PRINTF("freq %d\n", drv_lcd.hlcdc.Init.freq);
    }
    else if (strcmp(argv[1], "te") == 0)
    {
        if (argc > 2)
        {
            uint32_t te = strtoul(argv[2], 0, 10);

            HAL_LCDC_Enable_TE(&drv_lcd.hlcdc, te);
            DEBUG_PRINTF("te= %d\n", te);
        }
    }
    else if (strcmp(argv[1], "assert") == 0)
    {
        if (argc > 2)
        {
            uint32_t v = strtoul(argv[2], 0, 10);

            drv_lcd.assert_timeout = v;
            DEBUG_PRINTF("assert= %d\n", v);
        }
    }
    else if (strcmp(argv[1], "fps") == 0)
    {
        if (argc > 2)
        {
            uint32_t v = strtoul(argv[2], 0, 10);

            drv_lcd.statistics_log = v;
            DEBUG_PRINTF("fps_log= %d\n", v);
        }
    }
    else if (strcmp(argv[1], "no_draw") == 0)
    {
        if (argc > 2)
        {
            uint32_t v = strtoul(argv[2], 0, 10);

            drv_lcd.skip_draw_core = v;
            DEBUG_PRINTF("skip_draw_core= %d\n", v);
        }
    }

#if 0
    else if (strcmp(argv[1], "swrd") == 0)
    {
        if (argc > 2)
        {
            uint16_t v = strtoul(argv[2], 0, 10);

            drv_lcd.hlcdc.Init.cfg.spi.readback_from_Dx = v;
        }
        DEBUG_PRINTF("readback_from_Dx %d\n", drv_lcd.hlcdc.Init.cfg.spi.readback_from_Dx);
    }
    else if (strcmp(argv[1], "auto_lp") == 0)
    {
        if (argc > 2)
        {
            uint16_t v = strtoul(argv[2], 0, 10);
            drv_lcd.auto_lowpower = v;
            DEBUG_PRINTF("lcd auto_lowpower =%d", v);
        }
    }
    else if (strcmp(argv[1], "cmprate") == 0)
    {
        uint32_t cmprate;
        if (argc > 2)
        {
            cmprate = strtoul(argv[2], 0, 10);
            api_lcd_control(&drv_lcd.parent, SF_GRAPHIC_CTRL_LCDC_LAYER_BUF_CMPR_RATE, &cmprate);
            DEBUG_PRINTF("lcd comapre rate is %d.\n", cmprate);
        }
    }
    else if (strcmp(argv[1], "set_window") == 0)
    {
        if (argc > 5)
        {
            uint16_t x0 = strtoul(argv[2], 0, 10);
            uint16_t x1 = strtoul(argv[3], 0, 10);
            uint16_t y0 = strtoul(argv[4], 0, 10);
            uint16_t y1 = strtoul(argv[5], 0, 10);
            DEBUG_PRINTF("set_windown [x0x1:%d,%d,y0y1:%d,%d]", x0, x1, y0, y1);

            api_lcd_set_window(x0,  y0, x1, y1);

        }
    }
    else if (strcmp(argv[1], "draw_layer") == 0)
    {
        if (argc > 3)
        {
            LCDC_LayerCfgTypeDef *p_layer = &drv_lcd.hlcdc.Layer[drv_lcd.select_layer];
            uint16_t x0 = strtoul(argv[2], 0, 10);
            uint16_t y0 = strtoul(argv[3], 0, 10);
            uint16_t x1 = x0 + (p_layer->data_area.x1 - p_layer->data_area.x0); //Keep layer size
            uint16_t y1 = y0 + (p_layer->data_area.y1 - p_layer->data_area.y0);

            DEBUG_PRINTF("draw_layer 0x%x [x0x1:%d,%d,y0y1:%d,%d]", p_layer->data, x0, x1, y0, y1);
            api_lcd_draw_rect_async((const char *) p_layer->data, x0, y0, x1, y1);

        }
    }
#endif /* 0 */

    return 0;
}
MSH_CMD_EXPORT(lcd_ctrl, lcd control);
#endif /* RT_USING_FINSH */
