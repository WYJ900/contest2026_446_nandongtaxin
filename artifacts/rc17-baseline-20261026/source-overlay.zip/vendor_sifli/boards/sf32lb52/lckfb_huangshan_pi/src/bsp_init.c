/*
 * SPDX-FileCopyrightText: 2019-2022 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "bsp_board.h"
#include "bf0_hal_rtc.h"

#include <stdio.h>

#ifndef LXT_LP_CYCLE
    #define LXT_LP_CYCLE 200
#endif

static uint16_t mpi1_div = 1;
static uint16_t mpi2_div = 1;

static uint32_t otp_flash_addr = AUTO_FLASH_MAC_ADDRESS;

#define FUNC_BSP_FLASH_DIV_GET(i) \
uint16_t BSP_GetFlash##i##DIV(void) \
{ \
    return mpi##i##_div; \
}\

#define FUNC_BSP_FLASH_DIV_SET(i) \
void BSP_SetFlash##i##DIV(uint16_t div) \
{ \
    mpi##i##_div = div; \
}\

FUNC_BSP_FLASH_DIV_GET(1);
FUNC_BSP_FLASH_DIV_GET(2);

FUNC_BSP_FLASH_DIV_SET(1)
FUNC_BSP_FLASH_DIV_SET(2)

int rt_psram_init(void);
int rt_hw_flash1_init(uint8_t auto_detect);
int rt_hw_flash2_init(uint8_t auto_detect);
int rt_hw_flash_init(void);

uint32_t BSP_GetOtpBase(void)
{
    return otp_flash_addr;
}

#ifdef SOC_BF0_HCPU
#define HXT_DELAY_EXP_VAL 1000
static void LRC_init(void)
{
    HAL_PMU_RC10Kconfig();

    HAL_RC_CAL_update_reference_cycle_on_48M(LXT_LP_CYCLE);
    uint32_t ref_cnt = HAL_RC_CAL_get_reference_cycle_on_48M();
    uint32_t cycle_t = (uint32_t)ref_cnt / (48 * LXT_LP_CYCLE);

    HAL_PMU_SET_HXT3_RDY_DELAY((HXT_DELAY_EXP_VAL / cycle_t + 1));
}
#endif

#ifdef BSP_USING_PSRAM
static void board_init_psram(void)
{
    qspi_configure_t qspi_cfg =
    {
        .Instance = hwp_qspi1,
        .SpiMode = BSP_QSPI1_MODE,
        .msize = BSP_QSPI1_MEM_SIZE,
        .base = QSPI1_MEM_BASE,
    };
    uint32_t pid = (hwp_hpsys_cfg->IDR & HPSYS_CFG_IDR_PID_Msk) >> HPSYS_CFG_IDR_PID_Pos;
    pid &= 7;

    switch (pid)
    {
    case 5: //BOOT_PSRAM_APS_16P:
        qspi_cfg.SpiMode = SPI_MODE_PSRAM;         // 16Mb APM QSPI PSRAM
        break;
    case 4: //BOOT_PSRAM_APS_32P:
        qspi_cfg.SpiMode = SPI_MODE_LEGPSRAM;    // 32Mb APM LEGACY PSRAM
        break;
    case 6: //BOOT_PSRAM_WINBOND:                // Winbond HYPERBUS PSRAM
        qspi_cfg.SpiMode = SPI_MODE_HBPSRAM;
        break;
    case 3: // BOOT_PSRAM_APS_64P:
    case 2: //BOOT_PSRAM_APS_128P:
        qspi_cfg.SpiMode = SPI_MODE_OPSRAM;      // 64Mb APM XCELLA PSRAM
        break;
    default:
        qspi_cfg.SpiMode = SPI_MODE_NOR;
        break;
    }
    static FLASH_HandleTypeDef f_handle;
    if (PM_STANDBY_BOOT != SystemPowerOnModeGet())
        f_handle.wakeup = 0;
    else
        f_handle.wakeup = 1;
    HAL_MPI_PSRAM_Init(&f_handle, &qspi_cfg, mpi1_div);
}
#endif

/* The CPU fetches from XIP on MPI2 while its divider and clock source
 * change.  Running the switch from flash makes boot depend on where the
 * linker happens to place these instructions: a fetch that meets the mux
 * transition hangs the core right after HAL_Init starts.  Do both writes
 * from SRAM and let the new clock settle before returning to NOR.
 */

static void __attribute__((section(".ramfunc"), noinline))
bsp_flash2_clock_switch(uint32_t div)
{
    uint32_t csr;
    int i;

    __DSB();
    __ISB();
    hwp_qspi2->PSCLR = div;
    csr = hwp_hpsys_rcc->CSR & ~(3u << RCC_CLK_MOD_FLASH2);
    hwp_hpsys_rcc->CSR = csr |
                         ((RCC_CLK_FLASH_DLL2 & 3u) << RCC_CLK_MOD_FLASH2);
    __DSB();
    for (i = 0; i < 64; i++)
    {
        __NOP();
    }

    __ISB();
}

void BSP_Board_PreInit(void)
{
#ifdef SOC_BF0_HCPU

    //__asm("B .");
    /* not switch back to XT48 if other clock source has been selected already */
    if (RCC_SYSCLK_HRC48 == HAL_RCC_HCPU_GetClockSrc(RCC_CLK_MOD_SYS))
    {
        // To avoid somebody cancel request.
        HAL_HPAON_EnableXT48();
        HAL_RCC_HCPU_ClockSelect(RCC_CLK_MOD_SYS, RCC_SYSCLK_HXT48);
    }

    HAL_RCC_HCPU_ClockSelect(RCC_CLK_MOD_HP_PERI, RCC_CLK_PERI_HXT48);

    if (PM_STANDBY_BOOT != SystemPowerOnModeGet())
    {
        // Halt LCPU first to avoid LCPU in running state
        HAL_HPAON_WakeCore(CORE_ID_LCPU);
        HAL_RCC_Reset_and_Halt_LCPU(1);
#ifndef USE_ATE_MODE
        // get system configure from EFUSE
        BSP_System_Config();
#endif
        HAL_HPAON_StartGTimer();
        HAL_PMU_EnableRC32K(1);
        HAL_PMU_LpCLockSelect(PMU_LPCLK_RC32);

        HAL_PMU_EnableDLL(1);

#ifndef LXT_DISABLE
        HAL_PMU_EnableXTAL32();
        if (HAL_PMU_LXTReady() == HAL_OK)
        {
            // RTC/GTIME/LPTIME Using same low power clock source
            HAL_RTC_ENABLE_LXT();
        }
#endif

#ifndef CFG_BOOTLOADER
        {
            HAL_PMU_SetWdt((uint32_t)hwp_wdt2);   // Add reboot cause for watchdog2
        }

#endif/* CFG_BOOTLOADER */
        HAL_RCC_LCPU_ClockSelect(RCC_CLK_MOD_LP_PERI, RCC_CLK_PERI_HXT48);

        HAL_HPAON_CANCEL_LP_ACTIVE_REQUEST();
        if (HAL_LXT_DISABLED())
            LRC_init();
    }

#ifndef USE_ATE_MODE
    HAL_RCC_HCPU_ConfigHCLK(240);
#else
    HAL_RCC_HCPU_SetDiv(1, 1, 6);
    HAL_RCC_HCPU_EnableDLL1(240000000); // only set freq here, pmu should changed by hardware directly
    HAL_RCC_HCPU_ClockSelect(RCC_CLK_MOD_SYS, RCC_SYSCLK_DLL1);
#endif /* USE_ATE_MODE */

#if defined(BSP_USING_USBD) || defined(BSP_USING_USBH)
    HAL_RCC_HCPU_EnableDLL2(240000000);
    // Make sure USB clock is 60M = 120M/2
    hwp_hpsys_rcc->USBCR = 4;                       // Divider is 2
    hwp_hpsys_rcc->CSR |= HPSYS_RCC_CSR_SEL_USBC;   // Use DLL2 (0 is SYSCLK, 1 is DLL2)
#else
    HAL_RCC_HCPU_EnableDLL2(288000000);
#endif

    // Reset sysclk used by HAL_Delay_us
    HAL_Delay_us(0);
    //HAL_sw_breakpoint();

    /* NuttX executes directly from NOR on MPI2 (0x12000000).  Set the
     * divider before switching the source.  DLL2/3 gives 96 MHz normally,
     * or 80 MHz when USB requires DLL2 to run at 240 MHz.  Both are within
     * the 104 MHz limit of the XT25F128F 0xeb SDR mode with six total
     * latency clocks.  The old early return skipped this SDK clock setup
     * and left XIP on the 48 MHz source with divider 2 (about 24 MHz).
     */

    mpi2_div = 3;
    bsp_flash2_clock_switch(mpi2_div);

    /* In NuttX flow, chip layer will handle pin/PSRAM/flash early init. */
    return;

    mpi1_div = 2;   // for OPI Psram driver alway set 1, for QSPI PSRAM depend on this setting, for flash depend on flash request, 2 or 3
    mpi2_div = 4;

    /* Init the low level hardware */
    HAL_MspInit();
    HAL_RCC_HCPU_ClockSelect(RCC_CLK_MOD_FLASH1, RCC_CLK_FLASH_DLL2);
#if defined (BSP_USING_PSRAM)
    // only set 1.8 for PSRAM, do NOT set if no psram !!!
    HAL_PMU_ConfigPeriLdo(PMU_PERI_LDO_1V8, true, true);

#ifdef BSP_USING_RTTHREAD
    rt_psram_init();
#else
    board_init_psram();
#endif /* BSP_USING_RTTHREAD */
#endif

    HAL_RCC_HCPU_ClockSelect(RCC_CLK_MOD_FLASH2, RCC_CLK_FLASH_DLL2);
#if defined(BSP_USING_NOR_FLASH1) || defined(BSP_USING_NOR_FLASH2)
    // TODO: move select FLASH1 clock to here if MPI1 used as FLASH.
#ifdef BSP_USING_NOR_FLASH1
    mpi1_div = 3;
#endif
    if (PM_STANDBY_BOOT == SystemPowerOnModeGet())
    {
        //TODO: pin device is not restored
        HAL_HPAON_ENABLE_PAD();
        /* rt_hw_flash_init cannot be called as data has not been restored at this moment,
           so rt_sem_init cannot be called */
#if defined(BSP_USING_NOR_FLASH1)
        BSP_Flash_hw1_init();
#endif
#if defined(BSP_USING_NOR_FLASH2)
        BSP_Flash_hw2_init();
#endif
    }
    else
    {
#ifdef BSP_USING_RTTHREAD
        rt_hw_flash_init();
#else
        BSP_Flash_Init();
#endif
    }
#endif /* BSP_USING_NOR_FLASH3 */

#elif defined(SOC_BF0_LCPU)
    HAL_LPAON_EnableXT48();
    HAL_RCC_LCPU_ClockSelect(RCC_CLK_MOD_SYS, RCC_SYSCLK_HXT48);
    HAL_RCC_LCPU_ClockSelect(RCC_CLK_MOD_LP_PERI, RCC_CLK_PERI_HXT48);
    HAL_RCC_LCPU_SetDiv(2, 1, 3);
    HAL_MspInit();
#endif
}

extern void BSP_PIN_Init(void);
// Called in HAL_MspInit
void BSP_IO_Init(void)
{
    BSP_PIN_Init();
    BSP_Power_Up(true);
}

__WEAK void SystemClock_Config(void)
{

}

static void sf32lb52_cache_dump(void)
{
#if defined(SOC_BF0_HCPU) && defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
#define SF32LB52_SCB_CACR         (*(volatile uint32_t *)0xe000ef9cu)
#define SF32LB52_SCB_CACR_FORCEWT (1u << 2)
    uint32_t ccsidr;
    uint32_t csselr;
    uint32_t line_size;
    uint32_t sets;
    uint32_t ways;
    uint32_t regions;
    uint32_t rnr;

    csselr = SCB->CSSELR;
    SCB->CSSELR = 0; /* Level 1 data/unified cache */
    __DSB();
    ccsidr = SCB->CCSIDR;
    SCB->CSSELR = csselr;
    __DSB();
    __ISB();

    line_size = 1u << (((ccsidr & SCB_CCSIDR_LINESIZE_Msk) >>
                        SCB_CCSIDR_LINESIZE_Pos) + 4u);
    sets = ((ccsidr & SCB_CCSIDR_NUMSETS_Msk) >>
            SCB_CCSIDR_NUMSETS_Pos) + 1u;
    ways = ((ccsidr & SCB_CCSIDR_ASSOCIATIVITY_Msk) >>
            SCB_CCSIDR_ASSOCIATIVITY_Pos) + 1u;

    printf("[sf32lb52-cache] CCR=0x%08lx CACR=0x%08lx CTR=0x%08lx "
           "I=%lu D=%lu FORCEWT=%lu\n",
        (unsigned long)SCB->CCR,
        (unsigned long)SF32LB52_SCB_CACR,
        (unsigned long)SCB->CTR,
        (unsigned long)((SCB->CCR & SCB_CCR_IC_Msk) != 0),
        (unsigned long)((SCB->CCR & SCB_CCR_DC_Msk) != 0),
        (unsigned long)((SF32LB52_SCB_CACR &
                 SF32LB52_SCB_CACR_FORCEWT) != 0));
    printf("[sf32lb52-cache] D-CCSIDR=0x%08lx line=%lu sets=%lu ways=%lu "
           "size=%lu bytes WT=%lu WB=%lu RA=%lu WA=%lu\n",
        (unsigned long)ccsidr,
        (unsigned long)line_size,
        (unsigned long)sets,
        (unsigned long)ways,
        (unsigned long)(line_size * sets * ways),
        (unsigned long)((ccsidr & SCB_CCSIDR_WT_Msk) != 0),
        (unsigned long)((ccsidr & SCB_CCSIDR_WB_Msk) != 0),
        (unsigned long)((ccsidr & SCB_CCSIDR_RA_Msk) != 0),
        (unsigned long)((ccsidr & SCB_CCSIDR_WA_Msk) != 0));

    rnr = MPU->RNR;
    regions = (MPU->TYPE & MPU_TYPE_DREGION_Msk) >> MPU_TYPE_DREGION_Pos;
    printf("[sf32lb52-cache] MPU TYPE=0x%08lx CTRL=0x%08lx regions=%lu "
           "MAIR0=0x%08lx MAIR1=0x%08lx\n",
        (unsigned long)MPU->TYPE,
        (unsigned long)MPU->CTRL,
        (unsigned long)regions,
        (unsigned long)MPU->MAIR0,
        (unsigned long)MPU->MAIR1);

    for (uint32_t i = 0; i < regions; i++)
    {
        uint32_t rbar;
        uint32_t rlar;

        MPU->RNR = i;
        __DSB();
        rbar = MPU->RBAR;
        rlar = MPU->RLAR;
        if ((rlar & MPU_RLAR_EN_Msk) != 0)
        {
            printf("[sf32lb52-cache] MPU R%lu RBAR=0x%08lx RLAR=0x%08lx\n",
                (unsigned long)i,
                (unsigned long)rbar,
                (unsigned long)rlar);
        }
    }

    MPU->RNR = rnr;
    __DSB();
#undef SF32LB52_SCB_CACR
#undef SF32LB52_SCB_CACR_FORCEWT
#endif
}

void sf32lb52_clock_dump(void)
{
#ifdef SOC_BF0_HCPU
    uint32_t flash1_src = HAL_RCC_HCPU_GetClockSrc(RCC_CLK_MOD_FLASH1);
    uint32_t flash2_src = HAL_RCC_HCPU_GetClockSrc(RCC_CLK_MOD_FLASH2);
    uint32_t flash1_div = hwp_qspi1->PSCLR & MPI_PSCLR_DIV_Msk;
    uint32_t flash2_div = hwp_qspi2->PSCLR & MPI_PSCLR_DIV_Msk;
    uint32_t flash1_parent;
    uint32_t flash2_parent;

    flash1_parent = flash1_src == RCC_CLK_FLASH_DLL2 ?
                    HAL_RCC_HCPU_GetDLL2Freq() : 48000000u;
    flash2_parent = flash2_src == RCC_CLK_FLASH_DLL2 ?
                    HAL_RCC_HCPU_GetDLL2Freq() : 48000000u;
    printf("[sf32lb52-clock] hcpu_hclk=%lu Hz\n",
        (unsigned long)HAL_RCC_GetHCLKFreq(CORE_ID_HCPU));
    printf("[sf32lb52-clock] lcpu_hclk=%lu Hz\n",
        (unsigned long)HAL_RCC_GetHCLKFreq(CORE_ID_LCPU));
    printf("[sf32lb52-clock] dll1=%lu Hz dll2=%lu Hz\n",
        (unsigned long)HAL_RCC_HCPU_GetDLL1Freq(),
        (unsigned long)HAL_RCC_HCPU_GetDLL2Freq());
    printf("[sf32lb52-clock] sys_src=%d hp_peri_src=%d flash1_src=%d flash2_src=%d\n",
        HAL_RCC_HCPU_GetClockSrc(RCC_CLK_MOD_SYS),
        HAL_RCC_HCPU_GetClockSrc(RCC_CLK_MOD_HP_PERI),
        (int)flash1_src,
        (int)flash2_src);
    printf("[sf32lb52-clock] flash1_div=%lu freq~%lu Hz flash2_div=%lu freq~%lu Hz\n",
        (unsigned long)flash1_div,
        (unsigned long)(flash1_div ? flash1_parent / flash1_div : 0),
        (unsigned long)flash2_div,
        (unsigned long)(flash2_div ? flash2_parent / flash2_div : 0));
    printf("[sf32lb52-clock] RCC CSR=0x%08lx CFGR=0x%08lx DLL1CR=0x%08lx DLL2CR=0x%08lx\n",
        (unsigned long)hwp_hpsys_rcc->CSR,
        (unsigned long)hwp_hpsys_rcc->CFGR,
        (unsigned long)hwp_hpsys_rcc->DLL1CR,
        (unsigned long)hwp_hpsys_rcc->DLL2CR);
    printf("[sf32lb52-flash2] CR=0x%08lx DCR=0x%08lx PSCLR=0x%08lx "
           "HCMDR=0x%08lx HRCCR=0x%08lx FIFOCR=0x%08lx MISCR=0x%08lx\n",
        (unsigned long)hwp_qspi2->CR,
        (unsigned long)hwp_qspi2->DCR,
        (unsigned long)hwp_qspi2->PSCLR,
        (unsigned long)hwp_qspi2->HCMDR,
        (unsigned long)hwp_qspi2->HRCCR,
        (unsigned long)hwp_qspi2->FIFOCR,
        (unsigned long)hwp_qspi2->MISCR);
    printf("[sf32lb52-flash2] prefetch=%lu pre_start=0x%08lx pre_end=0x%08lx\n",
        (unsigned long)((hwp_qspi2->CR & MPI_CR_PREFE_Msk) != 0),
        (unsigned long)hwp_qspi2->PRSAR,
        (unsigned long)hwp_qspi2->PREAR);
    sf32lb52_cache_dump();
#endif
}

