#include "bsp_board.h"


#ifdef BSP_USING_LCD
#define LCD_RESET_PIN           (0)         // GPIO_A00
#define TP_RESET                (9)         // GPIO_A09

#ifdef LCD_USING_CO5300
    #define LCD_VADD_EN             (1)
#endif


/***************************LCD ***********************************/
extern void BSP_PIN_LCD(void);
void BSP_LCD_Reset(uint8_t high1_low0)
{
    BSP_GPIO_Set(LCD_RESET_PIN, high1_low0, 1);
}

void BSP_LCD_PowerDown(void)
{
    BSP_PIN_LCD();
    BSP_GPIO_Set(LCD_RESET_PIN, 0, 1);
#ifdef LCD_USING_CO5300
    BSP_GPIO_Set(LCD_VADD_EN, 0, 1);
    HAL_Delay_us(1000);
    /* VSYS and VCC_3V3 also supply other board devices. Display recovery
     * must not cycle those shared rails underneath active drivers.
     */
#endif
}

void BSP_LCD_PowerUp(void)
{
    BSP_PIN_LCD();

#ifdef LCD_USING_CO5300
    BSP_GPIO_Set(LCD_RESET_PIN, 0, 1);
    HAL_Delay_us(5000);
    BSP_GPIO_Set(LCD_VADD_EN, 1, 1);
    HAL_Delay_us(5000);
#endif
}


/***************************Touch ***********************************/
extern void BSP_PIN_Touch(void);
void BSP_TP_PowerUp(void)
{
    // TODO: Setup TP power up pin
    BSP_PIN_Touch();
    BSP_GPIO_Set(TP_RESET,  1, 1);
}

void BSP_TP_PowerDown(void)
{
    // TODO: Setup TP power down pin
    BSP_GPIO_Set(TP_RESET,  0, 1);
}
void BSP_TP_Reset(uint8_t high1_low0)
{
    BSP_GPIO_Set(TP_RESET, high1_low0, 1);
}

#endif
