/*
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

//#include <rtthread.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <board.h>


extern void ble_rf_power_set(int8_t txpwr);
extern void blebredr_rf_power_set(uint8_t type, int8_t txpwr);
uint8_t is_br = 0;

static void cw_rf_power_set(uint8_t pa)
{
    int8_t pwr = 0;
    switch (pa)
    {
    case 0:
        pwr = 0;
        break;
    case 1:
        pwr = 4;
        break;
    case 2:
        pwr = 10;
        break;
    default:
        pwr = pa;
        break;
    }
    //ble_rf_power_set(pwr);
    blebredr_rf_power_set(0, pwr);
}

static void cw_rf_channel_set(uint8_t channel)
{
    //RADIOCNTL1    FORCE_TX_VAL    0x4009_0074[21] w   0x0 force tx off
    //hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_FORCE_TX_VAL;
    HAL_Delay_us(20);

    //RADIOCNTL1    FORCE_CHANNEL   0x4009_0074[30] w   0x1 ??channel number?force
    //RADIOCNTL1    CHANNEL 0x4009_0074[29:23]  w   0xN ???chnnelN,?2402+2*N MHz
    hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_CHANNEL;
    if (is_br == 0)
    {
        hwp_bt_mac->DMRADIOCNTL1 |= (2 * channel) << BT_MAC_DMRADIOCNTL1_CHANNEL_Pos;
    }
    else
    {
        hwp_bt_mac->DMRADIOCNTL1 |= (channel) << BT_MAC_DMRADIOCNTL1_CHANNEL_Pos;
    }
    HAL_Delay_us(20);
    hwp_bt_mac->DMRADIOCNTL1 |= BT_MAC_DMRADIOCNTL1_FORCE_CHANNEL;

    hwp_bt_mac->DMRADIOCNTL1 |= 1 << BT_MAC_DMRADIOCNTL1_FORCE_TX_VAL_Pos;
    HAL_Delay_us(20);
}

static void cw_config_start(uint8_t pa, uint8_t channel)
{
    HAL_RCC_Reset_and_Halt_LCPU(0);
    //LB52X_MAC_RESET   LB55X_MAC_RESET 0x4000_0000[20] w   0x1 reset MAC
    hwp_lpsys_rcc->RSTR2 |= LPSYS_RCC_RSTR2_MAC;
    HAL_Delay_us(20);
    hwp_lpsys_rcc->RSTR2 &= ~LPSYS_RCC_RSTR2_MAC;

    //RADIOCNTL1    FORCE_SYNCWORD  0x4009_0074[31] w   0x1 ??syncword?force,????????
    //RADIOCNTL1    FORCE_NBT_BLE   0x4009_0074[15] w   0x1 ??bt/ble mode???force
    //RADIOCNTL1    FORCE_NBT_BLE_VAL   0x4009_0074[14] w   0x1 ???ble??
    //RADIOCNTL1    FORCE_CHANNEL   0x4009_0074[30] w   0x1 ??channel number?force
    //RADIOCNTL1    CHANNEL 0x4009_0074[29:23]  w   0xN ???chnnelN,?2402+2*N MHz
    hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_FORCE_SYNCWORD;
    hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_FORCE_NBT_BLE;
    hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_FORCE_NBT_BLE_VAL;
    hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_FORCE_CHANNEL;
    hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_CHANNEL;

    hwp_bt_mac->DMRADIOCNTL1 |= 0x01 << BT_MAC_DMRADIOCNTL1_FORCE_SYNCWORD_Pos;
    hwp_bt_mac->DMRADIOCNTL1 |= 0x01 << BT_MAC_DMRADIOCNTL1_FORCE_NBT_BLE_Pos;
    if (is_br == 0)
    {
        hwp_bt_mac->DMRADIOCNTL1 |= 0x01 << BT_MAC_DMRADIOCNTL1_FORCE_NBT_BLE_VAL_Pos;
    }
    //hwp_bt_mac->DMRADIOCNTL1 |= 0x01 << BT_MAC_DMRADIOCNTL1_FORCE_CHANNEL_Pos;

    //TRF_REG1  BRF_PA_PM_LV    0x4008_2834[2:1]    w   0x0
    //TRF_REG1  BRF_PA_CAS_BP_LV    0x4008_2834[0]  w   0x1
    //TRF_REG1  BRF_TRF_LDO_VREF_SEL_LV 0x4008_28534[20:17] w   0xD
    hwp_bt_rfc->TRF_REG1 &= ~BT_RFC_TRF_REG1_BRF_PA_PM_LV;
    hwp_bt_rfc->TRF_REG1 &= ~BT_RFC_TRF_REG1_BRF_PA_CAS_BP_LV;
    hwp_bt_rfc->TRF_REG1 &= ~BT_RFC_TRF_REG1_BRF_TRF_LDO_VREF_SEL_LV;

    hwp_bt_rfc->TRF_REG1 |= 0x1 << BT_RFC_TRF_REG1_BRF_PA_CAS_BP_LV_Pos;
    hwp_bt_rfc->TRF_REG1 |= 0xD << BT_RFC_TRF_REG1_BRF_TRF_LDO_VREF_SEL_LV_Pos;

    //TRF_REG2  BRF_PA_UNIT_SEL_LV  0x4008_2838[15:11]  w   0x1F
    //TRF_REG2  BRF_PA_MCAP_LV  0x4008_2838[10] w   0x1
    hwp_bt_rfc->TRF_REG2 &= ~BT_RFC_TRF_REG2_BRF_PA_MCAP_LV;
    hwp_bt_rfc->TRF_REG2 &= ~BT_RFC_TRF_REG2_BRF_PA_UNIT_SEL_LV;

    hwp_bt_rfc->TRF_REG2 |= 0x1 << BT_RFC_TRF_REG2_BRF_PA_MCAP_LV_Pos;
    hwp_bt_rfc->TRF_REG2 |= 0x1F << BT_RFC_TRF_REG2_BRF_PA_UNIT_SEL_LV_Pos;

    //-- TX_CTRL    MAC_PWR_CTRL_EN 0x4008_40EC[2]  w   0x0 ??pwr target??????
    //TX_CTRL   MOD_METHOD_BR,MOD_METHOD_BLE    0x4008_40EC[3:2]    w   0x0 ???polar ????
    hwp_bt_phy->TX_CTRL &= ~BT_PHY_TX_CTRL_MAC_PWR_CTRL_EN;
    hwp_bt_phy->TX_CTRL &= ~(BT_PHY_TX_CTRL_MOD_METHOD_BLE | BT_PHY_TX_CTRL_MOD_METHOD_BR);

    //-- TX_PA_CFG  PA_CTRL_TARGET  0x5008_4114[7:2]    w   0x3D
    //TX_PA_CFG PA_RAMP_FORCE   0x4008_4120[1:0]    w   0x1 ??ramp
    hwp_bt_phy->TX_PA_CFG &= ~BT_PHY_TX_PA_CFG_PA_RAMP_FORCE;
    hwp_bt_phy->TX_PA_CFG |= 0x1 << BT_PHY_TX_PA_CFG_PA_RAMP_FORCE_Pos;



    //RADIOCNTL1    FORCE_TX    0x5009_0074[22] w   0x1 ??tx force
    //RADIOCNTL1    FORCE_TX_VAL    0x5009_0074[21] w   0x1 force tx on
    hwp_bt_mac->DMRADIOCNTL1 |= 0x1 << BT_MAC_DMRADIOCNTL1_FORCE_TX_Pos;
    //hwp_bt_mac->DMRADIOCNTL1 |= 0x1 << BT_MAC_DMRADIOCNTL1_FORCE_TX_VAL_Pos;
    HAL_Delay_us(20);

    cw_rf_power_set(pa);
    cw_rf_channel_set(channel);
}

static void cw_config_stop(void)
{
    hwp_lpsys_rcc->RSTR2 |= LPSYS_RCC_RSTR2_MAC;
    HAL_Delay_us(20);
    hwp_lpsys_rcc->RSTR2 &= ~LPSYS_RCC_RSTR2_MAC;
    HAL_RCC_ReleaseLCPU();
    //hwp_bt_mac->DMRADIOCNTL1 &= ~BT_MAC_DMRADIOCNTL1_FORCE_TX_VAL;
}

void cw_config(uint8_t is_start, uint8_t pa, uint8_t channel)
{
    if (is_start)
    {
        is_br = 0;
        cw_config_start(pa, channel);
    }
    else
    {
        cw_config_stop();
    }
}
void cw_config_bt(uint8_t is_start, uint8_t pa, uint8_t channel)
{
    if (is_start)
    {
        is_br = 1;
        cw_config_start(pa, channel);
    }
    else
    {
        cw_config_stop();
    }
}
