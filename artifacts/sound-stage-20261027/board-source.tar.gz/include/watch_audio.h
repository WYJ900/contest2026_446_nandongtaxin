/****************************************************************************
 * SPDX-License-Identifier: Apache-2.0
 ****************************************************************************/

#ifndef __BOARDS_SF32LB52_HUANGSHAN_WATCH_AUDIO_H
#define __BOARDS_SF32LB52_HUANGSHAN_WATCH_AUDIO_H

#include <nuttx/compiler.h>
#include <stdbool.h>
#include <stdint.h>

typedef bool (*huangshan_audio_cancel_t)(FAR void *arg);

/* Bounded board playback service, not an audio lower-half. The caller owns
 * a 32-byte aligned packed 16-bit/16-kHz mono buffer, including >=512 zero
 * tail samples. It must stay immutable until return. PCM limit: +/-6000.
 * Gain is restricted to 0 or 6 half-dB units (0 or +3 dB).
 * Sleeps in task context; no ISR use. No hardware is enabled at boot.
 */

int huangshan_watch_audio_play(FAR const uint32_t *packed, uint32_t words,
                              uint32_t samples, int gain,
                              huangshan_audio_cancel_t cancelled,
                              FAR void *arg);

/* Read-only diagnostics: bit 0 PA output, bit 1 DAC, bit 2 ADC enabled. */

uint32_t huangshan_watch_audio_state(void);

#endif
