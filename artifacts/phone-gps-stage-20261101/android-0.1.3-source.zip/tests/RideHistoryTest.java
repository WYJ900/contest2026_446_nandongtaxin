package com.velaride.companion;

import java.io.*;
import java.util.*;

public final class RideHistoryTest {
    private static final class Memory implements RideHistory.Storage {
        byte[] bytes; boolean fail;
        public byte[] read() { return bytes == null ? null : bytes.clone(); }
        public void write(byte[] value) throws IOException {
            if (fail) throw new IOException("disk full");
            bytes = value.clone();
        }
    }
    private static RideHistory.Entry ride(String watch, long sequence, long duration, long synced, String note) {
        return new RideHistory.Entry(watch, sequence, duration, duration / 2, duration / 4, 1, 2, 3, synced, synced, note);
    }
    private static void check(boolean value, String reason) { if (!value) throw new AssertionError(reason); }
    private static void rejects(byte[] bytes) throws Exception {
        try { RideHistory.decode(bytes); throw new AssertionError("Corrupt file accepted"); }
        catch (IOException expected) { }
    }
    public static void main(String[] args) throws Exception {
        Memory disk = new Memory(); RideHistory history = new RideHistory(disk);
        check(history.snapshot().isEmpty(), "Empty storage fabricated records");
        history.upsert(ride("watch-a", 11, 100, 1000, ""));
        history.upsert(ride("watch-a", 11, 100, 2000, "骑行备注，\"清楚\"\n下一行"));
        history.upsert(ride("watch-a", 11, 100, 3000, ""));
        check(history.snapshot().size() == 1, "Repeated sync duplicated a ride");
        RideHistory.Entry first = history.snapshot().get(0);
        check(first.firstSync == 1000 && first.lastSync == 3000 && !first.note.isEmpty(), "Sync lost original time/note");
        history.upsert(ride("watch-b", 11, 100, 4000, ""));
        history.upsert(ride("watch-a", 11, 120, 5000, ""));
        history.upsert(ride("watch-a", 12, 100, 6000, ""));
        check(history.snapshot().size() == 4, "Device or reset sequence collision");
        check(history.snapshot().get(0).sequence == 12, "Wrong order");
        RideHistory reopened = new RideHistory(disk);
        check(reopened.snapshot().size() == 4 && reopened.snapshot().get(3).note.equals(first.note), "Restart lost Unicode/note");
        List<RideHistory.Entry> isolated = reopened.snapshot(); isolated.clear();
        check(reopened.snapshot().size() == 4, "Mutable snapshot leaked");
        byte[] beforeFailure = disk.bytes.clone(); disk.fail = true;
        try { reopened.upsert(ride("watch-a", 13, 60, 7000, "")); throw new AssertionError("Write failure hidden"); }
        catch (IOException expected) { }
        check(reopened.snapshot().size() == 4 && Arrays.equals(beforeFailure, disk.bytes), "Failed save changed records");
        disk.fail = false;
        history.upsert(ride("legacy-unknown", 9, 40, 0, ""));
        check(new RideHistory(disk).snapshot().get(4).firstSync == 0, "Unknown date fabricated");
        byte[] valid = disk.bytes.clone();
        for (int length = 0; length < valid.length; length++) rejects(Arrays.copyOf(valid, length));
        byte[] corrupt = valid.clone(); corrupt[20] ^= 1; rejects(corrupt);
        corrupt = valid.clone(); corrupt[0] ^= 1; rejects(corrupt);
        rejects(Arrays.copyOf(valid, valid.length + 1));
        disk.bytes = corrupt;
        try { new RideHistory(disk); throw new AssertionError("Corrupt history silently reset"); }
        catch (IOException expected) { }
        check(Arrays.equals(disk.bytes, corrupt), "Read failure overwrote original");
        String csv = RideHistory.csv(Collections.singletonList(first));
        check(csv.startsWith("\ufeffwatch,sequence,"), "Missing Excel UTF-8 marker/columns");
        check(csv.contains("\"骑行备注，\"\"清楚\"\"\n下一行\"\r\n"), "CSV escaping lost Unicode/quotes/newline");
        for (String unsafe : new String[]{"=1+1", "+1", "-1", "@SUM(A1)", "  =cmd", "\t=1", "\rabc", "\nabc"}) {
            check(RideHistory.csv(Collections.singletonList(first.withNote(unsafe))).contains("\"'" + unsafe + "\""), "CSV formula not escaped");
        }
        List<RideHistory.Entry> full = new ArrayList<>();
        for (int i = 0; i < RideHistory.MAX_RECORDS; i++) full.add(ride("watch-a", i, 100, i, ""));
        disk.bytes = RideHistory.encode(full); RideHistory capacity = new RideHistory(disk);
        capacity.upsert(ride("watch-a", 0, 100, 9000, "updated"));
        try { capacity.upsert(ride("watch-a", 6000, 100, 9001, "")); throw new AssertionError("Capacity silently evicted records"); }
        catch (IOException expected) { }
        check(new RideHistory(disk).snapshot().size() == RideHistory.MAX_RECORDS, "Capacity lost history");
        try { new RideHistory.Entry("a", 1, 10, 8, 8, 0, 0, 0, 0, 0, ""); throw new AssertionError("Invalid durations accepted"); }
        catch (IllegalArgumentException expected) { }
        System.out.println("PASS: history deduplication, watch/reset isolation, migration, restart, notes, write failure, corruption, capacity and CSV escaping");
    }
}
