/****************************************************************************
 * apps/examples/velaride/velaride.c
 *
 * VelaRide AI 卡片流（LVGL C 版）。
 *
 * 为什么不用快应用：
 *
 *   快应用版（vela-quickapp/src/pages/cards/index.ux）的 <swiper> 滑动由
 *   JS 引擎驱动，输入和渲染之间还有脚本调度开销。
 *
 *   本程序用 LVGL 原生滚动，并通过 NuttX libuv poll 事件驱动地读取触摸
 *   fd，避免触摸读取被 LVGL 的渲染 timer 推迟。显示刷新仍由 LVGL 的
 *   固定周期 timer 驱动，把一个周期内的触摸位移合并成一帧。
 *   做法照官方 watch_v9 的蜂窝菜单（example/multimedia/lvgl/watch_v9/src/
 *   gui_apps/main/app_mainmenu.c）—— LV_SCROLL_SNAP_CENTER 做吸附，
 *   LV_EVENT_SCROLL 里做逐帧变换。
 *
 * 用法（NSH 下）：
 *
 *   velaride
 *
 * 注意：LVGL 是单实例的，快应用（vapp）在跑时会占住显示驱动。
 * 运行前先 kill 掉 vapp，否则报 "disp refr_timer is NULL"。
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <inttypes.h>

#include <lvgl/lvgl.h>

#ifdef CONFIG_LV_USE_NUTTX_LIBUV
#  include <uv.h>
#endif

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

/* 屏幕实测 390×450 RGB565 */

#define SCR_W  390
#define SCR_H  450

#define CARD_COUNT 4

/* 卡片配色。与快应用版保持一致，方便对比手感差异。 */

#define COLOR_BG        lv_color_hex(0x0a0a0a)
#define COLOR_HOME      lv_color_hex(0x0f1729)
#define COLOR_RIDE      lv_color_hex(0x0d1f17)
#define COLOR_ALERT     lv_color_hex(0x241a12)
#define COLOR_REVIEW    lv_color_hex(0x1a1226)

#define COLOR_CYAN      lv_color_hex(0x38bdf8)
#define COLOR_GREEN     lv_color_hex(0x4ade80)
#define COLOR_AMBER     lv_color_hex(0xfbbf24)
#define COLOR_WHITE     lv_color_hex(0xffffff)
#define COLOR_MUTED     lv_color_hex(0x64748b)
#define COLOR_DIM       lv_color_hex(0x475569)
#define COLOR_TRACK     lv_color_hex(0x1e293b)

/* 休息提醒周期（秒）。进度条按这个算百分比。 */

#define REST_CYCLE_SEC (40 * 60)

/* 判定"这是滑动不是点按"的位移阈值（像素）。
 *
 * LVGL 内部用的是 indev->scroll_limit，值来自 lv_indev.c:28 的私有宏
 * LV_INDEV_DEF_SCROLL_LIMIT（= 10）。那个宏在 .c 里不对外，
 * lv_indev_get_scroll_limit() 在 9.1 又只有声明没实现，所以这里取同值。
 * 官方 watch_v9 是直接读 indev->scroll_limit 私有字段。
 */

#define SCROLL_LIMIT 10

/****************************************************************************
 * Private Types
 ****************************************************************************/

/* 一张卡片上需要按数据刷新的控件。不需要刷新的（标题、提示文字）
 * 建完就不再引用，所以不存指针。
 */

struct card_home_s
{
  lv_obj_t *clock;
  lv_obj_t *distance;
  lv_obj_t *duration;
  lv_obj_t *calories;
};

struct card_ride_s
{
  lv_obj_t *elapsed;
  lv_obj_t *speed;
  lv_obj_t *distance;
  lv_obj_t *bar;
  lv_obj_t *motion;
};

struct card_alert_s
{
  lv_obj_t *message;
  lv_obj_t *minutes;
};

struct card_review_s
{
  lv_obj_t *text;
};

struct gesture_perf_s
{
  uint64_t first_input_us;
  uint64_t last_input_us;
  uint64_t first_frame_us;
  uint64_t last_frame_us;
  uint32_t input_events;
  uint32_t frame_events;
  uint32_t max_input_gap_us;
  uint32_t max_frame_gap_us;
  uint64_t pending_first_input_us;
  uint64_t pending_last_input_us;
  uint64_t frame_first_input_us;
  uint64_t frame_last_input_us;
  uint64_t start_first_total_us;
  uint64_t start_last_total_us;
  uint64_t ready_first_total_us;
  uint64_t ready_last_total_us;
  uint32_t start_first_max_us;
  uint32_t start_last_max_us;
  uint32_t ready_first_max_us;
  uint32_t ready_last_max_us;
  uint32_t latency_frames;
  uint64_t frame_refr_start_us;
  uint64_t frame_render_start_us;
  uint64_t frame_flush_start_us;
  uint64_t frame_flush_total_us;
  uint64_t layout_total_us;
  uint64_t raster_total_us;
  uint64_t flush_total_us;
  uint64_t apply_ready_total_us;
  uint64_t first_valid_frame_us;
  uint64_t last_valid_frame_us;
  uint32_t valid_frames;
  uint32_t frame_flush_count;
  uint32_t flush_count;
  uint32_t layout_max_us;
  uint32_t raster_max_us;
  uint32_t flush_max_us;
  uint32_t apply_ready_max_us;
  uint32_t valid_frame_max_gap_us;
  bool frame_applied;
};

struct velaride_s
{
  lv_obj_t *page;                 /* 承载卡片的滚动容器 */
  lv_obj_t *cards[CARD_COUNT];

  struct card_home_s   home;
  struct card_ride_s   ride;
  struct card_alert_s  alert;
  struct card_review_s review;

  uint32_t ride_sec;              /* 骑行秒数，驱动所有派生数据 */

  /* 手势累加状态。照官方 watch_v9 蜂窝菜单的做法：
   * 按下时禁用 LVGL 自带滚动，PRESSING 期间只累加位移，
   * 到 REFR_START（渲染开始那一刻）才一次性应用。
   * 这样位移和渲染严格同步，帧间隔才均匀。
   */

  lv_point_t scroll_sum;
  bool scroll_actived;
  bool scroll_lod_active;
  struct gesture_perf_s perf;
};

/****************************************************************************
 * Private Data
 ****************************************************************************/

static struct velaride_s g_app;
static void *g_draw_buffer;
static uint32_t g_draw_buffer_size;

#ifdef CONFIG_LV_USE_DRAW_EPIC
extern void lv_draw_epic_get_stats(uint32_t *label_tasks,
                                   uint32_t *fallback_tasks);
#endif

/****************************************************************************
 * Private Function Prototypes
 ****************************************************************************/

static lv_obj_t *nearest_card(void);

static void set_scroll_lod(bool enabled)
{
  int card_index;

  if (g_app.scroll_lod_active == enabled)
    {
      return;
    }

  for (card_index = 0; card_index < CARD_COUNT; card_index++)
    {
      lv_obj_t *card = g_app.cards[card_index];
      uint32_t child_count;
      uint32_t child_index;

      if (card == NULL)
        {
          continue;
        }

      child_count = lv_obj_get_child_count(card);
      for (child_index = 0; child_index < child_count; child_index++)
        {
          lv_obj_t *child = lv_obj_get_child(card, child_index);

          if (enabled)
            {
              lv_obj_add_flag(child, LV_OBJ_FLAG_HIDDEN);
            }
          else
            {
              lv_obj_remove_flag(child, LV_OBJ_FLAG_HIDDEN);
            }
        }
    }

  g_app.scroll_lod_active = enabled;
}

#ifdef CONFIG_LV_USE_NUTTX_LIBUV
static void frame_timer_cb(uv_timer_t *timer)
{
  LV_UNUSED(timer);
  _lv_display_refr_timer(NULL);
}
#endif

static uint64_t monotonic_us(void)
{
  struct timespec now;

  if (clock_gettime(CLOCK_MONOTONIC, &now) < 0)
    {
      return 0;
    }

  return (uint64_t)now.tv_sec * 1000000 + now.tv_nsec / 1000;
}

static void perf_record(uint64_t now, uint64_t *first, uint64_t *last,
                        uint32_t *count, uint32_t *max_gap)
{
  if (now == 0)
    {
      return;
    }

  if (*count == 0)
    {
      *first = now;
    }
  else
    {
      uint64_t gap = now - *last;

      if (gap > *max_gap)
        {
          *max_gap = gap > UINT32_MAX ? UINT32_MAX : (uint32_t)gap;
        }
    }

  *last = now;
  (*count)++;
}

static uint32_t perf_rate_x10(uint32_t count, uint64_t first, uint64_t last)
{
  uint64_t elapsed;

  if (count < 2 || last <= first)
    {
      return 0;
    }

  elapsed = last - first;
  return (uint32_t)((uint64_t)(count - 1) * 10000000 / elapsed);
}

static uint32_t perf_clamp_us(uint64_t value)
{
  return value > UINT32_MAX ? UINT32_MAX : (uint32_t)value;
}

static void perf_update_max(uint32_t *max_value, uint64_t value)
{
  uint32_t clamped = perf_clamp_us(value);

  if (clamped > *max_value)
    {
      *max_value = clamped;
    }
}

static void perf_print(void)
{
  uint32_t input_rate = perf_rate_x10(g_app.perf.input_events,
                                      g_app.perf.first_input_us,
                                      g_app.perf.last_input_us);
  uint32_t frame_rate = perf_rate_x10(g_app.perf.frame_events,
                                      g_app.perf.first_frame_us,
                                       g_app.perf.last_frame_us);
  uint32_t valid_rate = perf_rate_x10(g_app.perf.valid_frames,
                                      g_app.perf.first_valid_frame_us,
                                      g_app.perf.last_valid_frame_us);

  if (g_app.perf.input_events < 2)
    {
      return;
    }

  printf("VELARIDE_PERF: input=%" PRIu32 ".%" PRIu32
         "Hz max_gap=%" PRIu32 "ms refresh=%" PRIu32 ".%" PRIu32
         "Hz max_gap=%" PRIu32 "ms samples=%" PRIu32 "/%" PRIu32,
         input_rate / 10, input_rate % 10,
         g_app.perf.max_input_gap_us / 1000,
         frame_rate / 10, frame_rate % 10,
         g_app.perf.max_frame_gap_us / 1000,
         g_app.perf.input_events, g_app.perf.frame_events);

  printf(" valid=%" PRIu32 ".%" PRIu32 "Hz max_gap=%" PRIu32
         "ms frames=%" PRIu32,
         valid_rate / 10, valid_rate % 10,
         g_app.perf.valid_frame_max_gap_us / 1000,
         g_app.perf.valid_frames);

  if (g_app.perf.latency_frames > 0)
    {
      printf(" latency_start(first/latest)=%" PRIu64 "/%" PRIu64
             "us max=%" PRIu32 "/%" PRIu32
             "us latency_ready(first/latest)=%" PRIu64 "/%" PRIu64
             "us max=%" PRIu32 "/%" PRIu32 "us frames=%" PRIu32,
             g_app.perf.start_first_total_us / g_app.perf.latency_frames,
             g_app.perf.start_last_total_us / g_app.perf.latency_frames,
             g_app.perf.start_first_max_us,
             g_app.perf.start_last_max_us,
             g_app.perf.ready_first_total_us / g_app.perf.latency_frames,
             g_app.perf.ready_last_total_us / g_app.perf.latency_frames,
             g_app.perf.ready_first_max_us,
             g_app.perf.ready_last_max_us,
             g_app.perf.latency_frames);
    }

  if (g_app.perf.valid_frames > 0)
    {
      printf(" phases_avg/max_us layout=%" PRIu64 "/%" PRIu32
             " raster=%" PRIu64 "/%" PRIu32
             " flush=%" PRIu64 "/%" PRIu32
             " apply_ready=%" PRIu64 "/%" PRIu32
             " flushes=%" PRIu32,
             g_app.perf.layout_total_us / g_app.perf.valid_frames,
             g_app.perf.layout_max_us,
             g_app.perf.raster_total_us / g_app.perf.valid_frames,
             g_app.perf.raster_max_us,
             g_app.perf.flush_total_us / g_app.perf.valid_frames,
             g_app.perf.flush_max_us,
             g_app.perf.apply_ready_total_us / g_app.perf.valid_frames,
             g_app.perf.apply_ready_max_us,
             g_app.perf.flush_count);
    }

  printf(" buffer=%p/%" PRIu32, g_draw_buffer, g_draw_buffer_size);

#ifdef CONFIG_LV_USE_DRAW_EPIC
  {
    uint32_t label_tasks;
    uint32_t fallback_tasks;

    lv_draw_epic_get_stats(&label_tasks, &fallback_tasks);
    printf(" epic_label=%" PRIu32 " epic_fallback=%" PRIu32,
           label_tasks, fallback_tasks);
  }
#endif

  printf("\n");
}

static void indev_diag_cb(lv_event_t *e)
{
  static uint32_t pressing_count;
  lv_event_code_t code = lv_event_get_code(e);

  if (code == LV_EVENT_PRESSED)
    {
      pressing_count = 0;
      printf("VELARIDE_TOUCH: PRESSED\n");
    }
  else if (code == LV_EVENT_PRESSING)
    {
      if (pressing_count == 0)
        {
          printf("VELARIDE_TOUCH: PRESSING\n");
        }
      pressing_count++;
    }
  else if (code == LV_EVENT_RELEASED)
    {
      printf("VELARIDE_TOUCH: RELEASED pressing=%" PRIu32 "\n",
             pressing_count);
    }
}

/****************************************************************************
 * Private Functions
 ****************************************************************************/

/****************************************************************************
 * Name: make_label
 *
 * Description:
 *   建一个标签的公共套路：设文本、颜色、字体，挂到父对象上。
 *
 * Input Parameters:
 *   parent - 父对象
 *   text   - 初始文本
 *   color  - 文字颜色
 *   font   - 字体，NULL 表示用继承的默认字体
 *
 * Returned Value:
 *   新建的标签对象。
 *
 ****************************************************************************/

static lv_obj_t *make_label(lv_obj_t *parent, const char *text,
                            lv_color_t color, const lv_font_t *font)
{
  lv_obj_t *label = lv_label_create(parent);

  lv_label_set_text(label, text);
  lv_obj_set_style_text_color(label, color, LV_PART_MAIN);

  if (font != NULL)
    {
      lv_obj_set_style_text_font(label, font, LV_PART_MAIN);
    }

  return label;
}

/****************************************************************************
 * Name: make_card
 *
 * Description:
 *   建一张整屏卡片。卡片本身不可滚动（滚动交给父容器），
 *   内部用竖向 flex 居中排布。
 *
 * Input Parameters:
 *   parent - 滚动容器
 *   bg     - 卡片背景色
 *
 * Returned Value:
 *   新建的卡片对象。
 *
 ****************************************************************************/

static lv_obj_t *make_card(lv_obj_t *parent, lv_color_t bg)
{
  lv_obj_t *card = lv_obj_create(parent);

  lv_obj_set_size(card, SCR_W, SCR_H);
  lv_obj_set_style_bg_color(card, bg, LV_PART_MAIN);
  lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_border_width(card, 0, LV_PART_MAIN);
  lv_obj_set_style_radius(card, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_all(card, 24, LV_PART_MAIN);

  /* Match the official watch_v9 icon input flags.  The card is the stable
   * touch target and bubbles pointer events to the page-level gesture
   * handler.  Without EVENT_BUBBLE the page callback never receives
   * PRESSED/PRESSING/RELEASED when a child covers the screen.
   */

  lv_obj_remove_flag(card, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_add_flag(card, LV_OBJ_FLAG_CLICKABLE |
                        LV_OBJ_FLAG_EVENT_BUBBLE |
                        LV_OBJ_FLAG_PRESS_LOCK);

  lv_obj_set_flex_flow(card, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_flex_align(card, LV_FLEX_ALIGN_CENTER,
                        LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

  return card;
}

/****************************************************************************
 * Name: make_stat_row
 *
 * Description:
 *   建一行横排的数据格子（数值在上、单位在下）。
 *   返回的数组按传入顺序填好数值标签，调用方拿去刷新。
 *
 * Input Parameters:
 *   parent  - 父对象
 *   labels  - 单位文字数组
 *   out     - 输出：每个格子的数值标签
 *   count   - 格子数量
 *
 ****************************************************************************/

static void make_stat_row(lv_obj_t *parent, const char * const *labels,
                          lv_obj_t **out, int count)
{
  lv_obj_t *row = lv_obj_create(parent);
  int i;

  lv_obj_remove_style_all(row);
  lv_obj_set_size(row, LV_PCT(100), LV_SIZE_CONTENT);
  lv_obj_remove_flag(row, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_EVENLY,
                        LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

  for (i = 0; i < count; i++)
    {
      lv_obj_t *cell = lv_obj_create(row);

      lv_obj_remove_style_all(cell);
      lv_obj_set_size(cell, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
      lv_obj_remove_flag(cell, LV_OBJ_FLAG_SCROLLABLE |
                               LV_OBJ_FLAG_CLICKABLE);
      lv_obj_set_flex_flow(cell, LV_FLEX_FLOW_COLUMN);
      lv_obj_set_flex_align(cell, LV_FLEX_ALIGN_CENTER,
                            LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

      out[i] = make_label(cell, "0", COLOR_WHITE, &lv_font_montserrat_24);
      make_label(cell, labels[i], COLOR_MUTED, NULL);
    }
}

/****************************************************************************
 * Name: build_card_home
 *
 * Description:
 *   卡片 1：首页概览。时钟 + 今日累计数据。
 *
 ****************************************************************************/

static void build_card_home(void)
{
  static const char * const units[] = { "km", "min", "kcal" };
  lv_obj_t *stats[3];
  lv_obj_t *card = make_card(g_app.page, COLOR_HOME);

  g_app.home.clock = make_label(card, "--:--", COLOR_WHITE,
                                &lv_font_montserrat_48);

  make_label(card, "VelaRide AI", COLOR_CYAN, &lv_font_montserrat_20);
  make_label(card, "Ride Safety Assistant", COLOR_MUTED, NULL);

  make_stat_row(card, units, stats, 3);
  g_app.home.distance = stats[0];
  g_app.home.duration = stats[1];
  g_app.home.calories = stats[2];

  make_label(card, "swipe up for ride data", COLOR_DIM, NULL);

  g_app.cards[0] = card;
}

/****************************************************************************
 * Name: build_card_ride
 *
 * Description:
 *   卡片 2：骑行中。计时、速度、距离、休息进度条。
 *
 ****************************************************************************/

static void build_card_ride(void)
{
  static const char * const units[] = { "km/h", "km" };
  lv_obj_t *stats[2];
  lv_obj_t *card = make_card(g_app.page, COLOR_RIDE);
  lv_obj_t *bar;

  make_label(card, "RIDING", COLOR_MUTED, NULL);

  g_app.ride.elapsed = make_label(card, "00:00:00", COLOR_WHITE,
                                  &lv_font_montserrat_48);

  make_stat_row(card, units, stats, 2);
  g_app.ride.speed = stats[0];
  g_app.ride.distance = stats[1];

  /* 休息周期进度条。用 lv_bar 而非自己画两个 div，
   * 它自带值变化的平滑过渡。
   */

  bar = lv_bar_create(card);
  lv_obj_set_size(bar, 260, 6);
  lv_obj_set_style_bg_color(bar, COLOR_TRACK, LV_PART_MAIN);
  lv_obj_set_style_bg_color(bar, COLOR_GREEN, LV_PART_INDICATOR);
  lv_obj_set_style_radius(bar, 3, LV_PART_MAIN);
  lv_obj_set_style_radius(bar, 3, LV_PART_INDICATOR);
  lv_bar_set_range(bar, 0, 100);
  lv_bar_set_value(bar, 0, LV_ANIM_OFF);
  lv_obj_remove_flag(bar, LV_OBJ_FLAG_CLICKABLE);
  g_app.ride.bar = bar;

  g_app.ride.motion = make_label(card, "idle", COLOR_DIM, NULL);

  g_app.cards[1] = card;
}

/****************************************************************************
 * Name: build_card_alert
 *
 * Description:
 *   卡片 3：安全提醒。
 *
 ****************************************************************************/

static void build_card_alert(void)
{
  lv_obj_t *card = make_card(g_app.page, COLOR_ALERT);

  make_label(card, "!", COLOR_AMBER, &lv_font_montserrat_48);
  make_label(card, "SAFETY", COLOR_MUTED, NULL);

  g_app.alert.message = make_label(card, "Take a 5 min break",
                                   COLOR_AMBER, &lv_font_montserrat_16);

  g_app.alert.minutes = make_label(card, "riding 0 min", COLOR_DIM, NULL);

  g_app.cards[2] = card;
}

/****************************************************************************
 * Name: build_card_review
 *
 * Description:
 *   卡片 4：AI 复盘。文字需要换行，所以显式设宽度加 WRAP 模式。
 *
 ****************************************************************************/

static void build_card_review(void)
{
  lv_obj_t *card = make_card(g_app.page, COLOR_REVIEW);

  make_label(card, "AI REVIEW", COLOR_MUTED, NULL);

  g_app.review.text = make_label(card,
    "Steady pace this session. Consider a break every 40 minutes.",
    lv_color_hex(0xe2e8f0), NULL);

  lv_obj_set_width(g_app.review.text, SCR_W - 60);
  lv_label_set_long_mode(g_app.review.text, LV_LABEL_LONG_WRAP);
  lv_obj_set_style_text_align(g_app.review.text, LV_TEXT_ALIGN_CENTER,
                              LV_PART_MAIN);

  make_label(card, "swipe to return", COLOR_DIM, NULL);

  g_app.cards[3] = card;
}

/****************************************************************************
 * Name: refr_start_cb
 *
 * Description:
 *   渲染开始时应用累加的滚动位移。这是跟手手感的关键。
 *
 *   LVGL 默认滚动是"触摸事件一到就滚"，滚动时机和渲染时机不同步，
 *   帧间隔会抖（实测 8ms~120ms）。官方 watch_v9 的做法是把两者对齐：
 *   PRESSING 只累加不滚，等到 LV_EVENT_REFR_START 这一刻才
 *   `_lv_obj_scroll_by_raw()` 一次性应用。每帧只滚一次、正好在画之前，
 *   帧间隔自然均匀。
 *
 *   对应源码：example/multimedia/lvgl/watch_v9/src/gui_apps/main/
 *   app_mainmenu.c 的 refr_start_cb()（第 1099 行）。
 *
 ****************************************************************************/

static void refr_start_cb(lv_event_t *e)
{
  uint64_t now;

  LV_UNUSED(e);

  g_app.perf.frame_applied = false;
  g_app.perf.frame_flush_count = 0;
  g_app.perf.frame_flush_total_us = 0;
  g_app.perf.frame_refr_start_us = monotonic_us();

  if (g_app.scroll_actived &&
      (g_app.scroll_sum.x != 0 || g_app.scroll_sum.y != 0))
    {
      now = g_app.perf.frame_refr_start_us;
      if (now != 0 && g_app.perf.pending_first_input_us != 0)
        {
          uint64_t first_latency =
            now - g_app.perf.pending_first_input_us;
          uint64_t last_latency =
            now - g_app.perf.pending_last_input_us;

          g_app.perf.frame_first_input_us =
            g_app.perf.pending_first_input_us;
          g_app.perf.frame_last_input_us =
            g_app.perf.pending_last_input_us;
          g_app.perf.pending_first_input_us = 0;
          g_app.perf.pending_last_input_us = 0;

          g_app.perf.start_first_total_us += first_latency;
          g_app.perf.start_last_total_us += last_latency;
          perf_update_max(&g_app.perf.start_first_max_us, first_latency);
          perf_update_max(&g_app.perf.start_last_max_us, last_latency);
        }

      lv_obj_scroll_by_bounded(g_app.page,
                               g_app.scroll_sum.x,
                               g_app.scroll_sum.y,
                               LV_ANIM_OFF);

      g_app.scroll_sum.x = 0;
      g_app.scroll_sum.y = 0;
      g_app.perf.frame_applied = true;
    }
}

static void render_start_cb(lv_event_t *e)
{
  LV_UNUSED(e);
  g_app.perf.frame_render_start_us = monotonic_us();
}

static void flush_start_cb(lv_event_t *e)
{
  LV_UNUSED(e);
  g_app.perf.frame_flush_start_us = monotonic_us();
}

static void flush_finish_cb(lv_event_t *e)
{
  uint64_t now;

  LV_UNUSED(e);
  now = monotonic_us();
  if (now != 0 && g_app.perf.frame_flush_start_us != 0)
    {
      g_app.perf.frame_flush_total_us +=
        now - g_app.perf.frame_flush_start_us;
      g_app.perf.frame_flush_count++;
      g_app.perf.frame_flush_start_us = 0;
    }
}

static void render_ready_cb(lv_event_t *e)
{
  uint64_t now;
  uint64_t layout_us;
  uint64_t render_us;
  uint64_t raster_us;
  uint64_t apply_ready_us;

  LV_UNUSED(e);
  if (!g_app.perf.frame_applied || g_app.perf.frame_flush_count == 0)
    {
      return;
    }

  now = monotonic_us();
  if (now == 0 || g_app.perf.frame_render_start_us == 0 ||
      g_app.perf.frame_refr_start_us == 0)
    {
      return;
    }

  layout_us = g_app.perf.frame_render_start_us -
              g_app.perf.frame_refr_start_us;
  render_us = now - g_app.perf.frame_render_start_us;
  raster_us = render_us > g_app.perf.frame_flush_total_us ?
              render_us - g_app.perf.frame_flush_total_us : 0;
  apply_ready_us = now - g_app.perf.frame_refr_start_us;

  g_app.perf.layout_total_us += layout_us;
  g_app.perf.raster_total_us += raster_us;
  g_app.perf.flush_total_us += g_app.perf.frame_flush_total_us;
  g_app.perf.apply_ready_total_us += apply_ready_us;
  g_app.perf.flush_count += g_app.perf.frame_flush_count;
  perf_update_max(&g_app.perf.layout_max_us, layout_us);
  perf_update_max(&g_app.perf.raster_max_us, raster_us);
  perf_update_max(&g_app.perf.flush_max_us,
                  g_app.perf.frame_flush_total_us);
  perf_update_max(&g_app.perf.apply_ready_max_us, apply_ready_us);
  perf_record(now,
              &g_app.perf.first_valid_frame_us,
              &g_app.perf.last_valid_frame_us,
              &g_app.perf.valid_frames,
              &g_app.perf.valid_frame_max_gap_us);
}

static void refr_ready_cb(lv_event_t *e)
{
  uint64_t now;

  LV_UNUSED(e);

  if (g_app.scroll_actived)
    {
      now = monotonic_us();
      perf_record(now,
                  &g_app.perf.first_frame_us,
                  &g_app.perf.last_frame_us,
                  &g_app.perf.frame_events,
                  &g_app.perf.max_frame_gap_us);

      if (now != 0 && g_app.perf.frame_first_input_us != 0)
        {
          uint64_t first_latency =
            now - g_app.perf.frame_first_input_us;
          uint64_t last_latency =
            now - g_app.perf.frame_last_input_us;

          g_app.perf.ready_first_total_us += first_latency;
          g_app.perf.ready_last_total_us += last_latency;
          perf_update_max(&g_app.perf.ready_first_max_us, first_latency);
          perf_update_max(&g_app.perf.ready_last_max_us, last_latency);
          g_app.perf.latency_frames++;
          g_app.perf.frame_first_input_us = 0;
          g_app.perf.frame_last_input_us = 0;
        }
    }
}

/****************************************************************************
 * Name: page_event_cb
 *
 * Description:
 *   容器手势处理。四个阶段照官方 watch_v9 的 mainmenu_cell_page_event_cb()：
 *
 *     PRESSED   关掉 SCROLLABLE，停掉正在跑的吸附动画，接管滚动
 *     PRESSING  累加位移，超过 scroll_limit 才算真滚动（防误触）
 *     RELEASED  恢复 SCROLLABLE，交回 LVGL 做吸附
 *     （位移的实际应用在 refr_start_cb 里）
 *
 ****************************************************************************/

static void page_event_cb(lv_event_t *e)
{
  lv_event_code_t code = lv_event_get_code(e);

  if (code == LV_EVENT_PRESSED)
    {
      /* 接管滚动：禁掉 LVGL 自带的，并掐掉可能在跑的吸附动画，
       * 否则动画会和手指位移打架。
       */

      lv_obj_remove_flag(g_app.page, LV_OBJ_FLAG_SCROLLABLE);
      lv_anim_delete(g_app.page, NULL);
      set_scroll_lod(true);
      memset(&g_app.perf, 0, sizeof(g_app.perf));
    }
  else if (code == LV_EVENT_PRESSING)
    {
      lv_indev_t *indev = lv_indev_active();
      lv_point_t vect;
      uint64_t now;

      if (indev == NULL)
        {
          return;
        }

      /* 本帧的手指位移增量 */

      lv_indev_get_vect(indev, &vect);

      now = monotonic_us();
      perf_record(now,
                  &g_app.perf.first_input_us,
                  &g_app.perf.last_input_us,
                  &g_app.perf.input_events,
                  &g_app.perf.max_input_gap_us);

      if (now != 0)
        {
          if (g_app.perf.pending_first_input_us == 0)
            {
              g_app.perf.pending_first_input_us = now;
            }

          g_app.perf.pending_last_input_us = now;
        }

      g_app.scroll_sum.x += vect.x;
      g_app.scroll_sum.y += vect.y;

      /* 超过 scroll_limit 才认定为滚动，避免点按被当成滑动。
       * 一旦认定就保持，否则手指停顿会中断滚动。
       */

      if (LV_ABS(g_app.scroll_sum.y) > SCROLL_LIMIT ||
          LV_ABS(g_app.scroll_sum.x) > SCROLL_LIMIT ||
          g_app.scroll_actived)
        {
          g_app.scroll_actived = true;

          /* 独立 16ms 帧泵会进入 REFR_START；实际应用位移时 LVGL 自己
           * 产生一次失效区，不在输入侧重复整屏 invalidate。
           */
        }
    }
  else if (code == LV_EVENT_RELEASED ||
           code == LV_EVENT_PRESS_LOST ||
           code == LV_EVENT_CLICKED)
    {
      /* 交回 LVGL：恢复 SCROLLABLE 后 snap 会把最近的卡片吸附到中心 */

      lv_obj_add_flag(g_app.page, LV_OBJ_FLAG_SCROLLABLE);

      if (g_app.scroll_actived)
        {
          /* RELEASED may arrive before the next timer-paced refresh.  Commit
           * the remaining displacement to object state before choosing the
           * snap target; rendering is still deferred to the refresh timer.
           */

          if (g_app.scroll_sum.x != 0 || g_app.scroll_sum.y != 0)
            {
              lv_obj_scroll_by_bounded(g_app.page,
                                       g_app.scroll_sum.x,
                                       g_app.scroll_sum.y,
                                       LV_ANIM_OFF);
              g_app.scroll_sum.x = 0;
              g_app.scroll_sum.y = 0;
            }

          /* Keep the release path deterministic: settle while details are
           * hidden, then restore the full card once.  Animating the snap with
           * every label visible would reintroduce the expensive glyph path.
           */

          lv_obj_scroll_to_view(nearest_card(), LV_ANIM_OFF);
          perf_print();
        }

      set_scroll_lod(false);
      g_app.scroll_actived = false;
      g_app.scroll_sum.x = 0;
      g_app.scroll_sum.y = 0;
    }
}

/****************************************************************************
 * Name: nearest_card
 *
 * Description:
 *   找离屏幕中心最近的卡片，松手后吸附到它。
 *   对应官方的 mainmenu_cell_predict_focus_icon()。
 *
 * Returned Value:
 *   最近的卡片对象，找不到时返回第一张。
 *
 ****************************************************************************/

static lv_obj_t *nearest_card(void)
{
  lv_obj_t *best = g_app.cards[0];
  int32_t best_dist = INT32_MAX;
  int32_t scr_mid = SCR_H / 2;
  int i;

  for (i = 0; i < CARD_COUNT; i++)
    {
      lv_area_t area;
      int32_t mid;
      int32_t dist;

      lv_obj_get_coords(g_app.cards[i], &area);
      mid = (area.y1 + area.y2) / 2;
      dist = LV_ABS(mid - scr_mid);

      if (dist < best_dist)
        {
          best_dist = dist;
          best = g_app.cards[i];
        }
    }

  return best;
}

/****************************************************************************
 * Name: build_ui
 *
 * Description:
 *   搭建卡片流。
 *
 *   关键是滚动容器的配置 —— 这决定了跟手手感：
 *
 *   - LV_SCROLL_SNAP_CENTER：松手后自动吸附到最近的卡片中心，
 *     照官方 watch_v9 蜂窝菜单（app_mainmenu.c:1424）的做法
 *   - LV_DIR_VER：只吃竖向手势，避免横向误触
 *   - scrollbar OFF：手表屏幕上滚动条没意义
 *
 *   滚动过程由 LVGL 直接跟触摸事件走，不经过脚本层；实际端到端延迟仍需
 *   用真机时间戳测量，不能由 LCD putarea 调用率推断。
 *
 ****************************************************************************/

static void build_ui(void)
{
  lv_obj_t *screen = lv_screen_active();
  lv_obj_t *page;

  lv_obj_set_style_bg_color(screen, COLOR_BG, LV_PART_MAIN);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_remove_flag(screen, LV_OBJ_FLAG_SCROLLABLE);

  page = lv_obj_create(screen);
  lv_obj_remove_style_all(page);
  lv_obj_set_size(page, SCR_W, SCR_H);
  lv_obj_set_pos(page, 0, 0);

  /* 卡片竖排，之间不留缝 —— 每张恰好铺满一屏 */

  lv_obj_set_flex_flow(page, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_style_pad_row(page, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_all(page, 0, LV_PART_MAIN);

  /* 吸附到卡片中心 + 只允许竖滑。
   *
   * SCROLLABLE 必须显式加回来 —— 上面的 lv_obj_remove_style_all()
   * 会把这个 flag 一起清掉，不加回去容器收不到滑动手势
   * （症状：只有每秒定时器刷新的 5 fps，滑动毫无反应）。
   */

  lv_obj_add_flag(page, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scroll_snap_y(page, LV_SCROLL_SNAP_CENTER);
  lv_obj_set_scroll_dir(page, LV_DIR_VER);
  lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF);

  g_app.page = page;

  /* 手势接管 + 位移与渲染同步。这两个回调是跟手手感的核心，
   * 照官方 watch_v9 蜂窝菜单（app_mainmenu.c:1430 / 1432）挂法。
   */

  lv_obj_add_event_cb(page, page_event_cb, LV_EVENT_ALL, NULL);
  lv_display_add_event_cb(lv_display_get_default(), refr_start_cb,
                          LV_EVENT_REFR_START, NULL);
  lv_display_add_event_cb(lv_display_get_default(), refr_ready_cb,
                          LV_EVENT_REFR_READY, NULL);
  lv_display_add_event_cb(lv_display_get_default(), render_start_cb,
                          LV_EVENT_RENDER_START, NULL);
  lv_display_add_event_cb(lv_display_get_default(), render_ready_cb,
                          LV_EVENT_RENDER_READY, NULL);
  lv_display_add_event_cb(lv_display_get_default(), flush_start_cb,
                          LV_EVENT_FLUSH_START, NULL);
  lv_display_add_event_cb(lv_display_get_default(), flush_finish_cb,
                          LV_EVENT_FLUSH_FINISH, NULL);

  build_card_home();
  build_card_ride();
  build_card_alert();
  build_card_review();

  /* 初始定位到第一张。ANIM_OFF 避免启动时看到一次滚动动画。 */

  lv_obj_scroll_to_view(g_app.cards[0], LV_ANIM_OFF);
}

/****************************************************************************
 * Name: update_tick
 *
 * Description:
 *   每秒刷新一次数据。
 *
 *   目前速度和距离是按骑行秒数模拟的（和快应用版一致），
 *   接真实传感器时替换 derive 部分即可，界面代码不用动。
 *
 ****************************************************************************/

static void update_tick(lv_timer_t *timer)
{
  char buf[64];
  time_t now;
  struct tm tm_now;
  uint32_t sec;
  uint32_t minutes;
  int percent;

  LV_UNUSED(timer);

  if (timer != NULL && g_app.scroll_actived)
    {
      return;
    }

  /* --- 时钟 --- */

  now = time(NULL);
  localtime_r(&now, &tm_now);
  snprintf(buf, sizeof(buf), "%02d:%02d", tm_now.tm_hour, tm_now.tm_min);
  lv_label_set_text(g_app.home.clock, buf);

  /* --- 骑行计时 --- */

  sec = ++g_app.ride_sec;
  minutes = sec / 60;

  snprintf(buf, sizeof(buf), "%02" PRIu32 ":%02" PRIu32 ":%02" PRIu32,
           sec / 3600, (sec % 3600) / 60, sec % 60);
  lv_label_set_text(g_app.ride.elapsed, buf);

  /* --- 派生数据（模拟，待接传感器）--- */

  snprintf(buf, sizeof(buf), "%" PRIu32 ".%" PRIu32,
           15 + (sec % 7), sec % 10);
  lv_label_set_text(g_app.ride.speed, buf);

  snprintf(buf, sizeof(buf), "%" PRIu32 ".%" PRIu32,
           sec * 4 / 1000, (sec * 4 / 100) % 10);
  lv_label_set_text(g_app.ride.distance, buf);

  lv_label_set_text(g_app.ride.motion,
                    (sec % 10) < 5 ? "riding" : "cruising");

  percent = (int)((uint64_t)sec * 100 / REST_CYCLE_SEC);
  if (percent > 100)
    {
      percent = 100;
    }

  /* ANIM_ON：每秒一次的值变化走平滑过渡，比直接跳更顺眼 */

  lv_bar_set_value(g_app.ride.bar, percent, LV_ANIM_OFF);

  /* --- 提醒卡片 --- */

  snprintf(buf, sizeof(buf), "riding %" PRIu32 " min", minutes);
  lv_label_set_text(g_app.alert.minutes, buf);

  /* --- 今日累计（暂用固定值，待接持久化）--- */

  if (timer == NULL)
    {
      lv_label_set_text(g_app.home.distance, "12.5");
      lv_label_set_text(g_app.home.duration, "45");
      lv_label_set_text(g_app.home.calories, "180");
    }
}

/****************************************************************************
 * Public Functions
 ****************************************************************************/

int main(int argc, FAR char *argv[])
{
  lv_nuttx_dsc_t info;
  lv_nuttx_result_t result;
#ifdef CONFIG_LV_USE_NUTTX_LIBUV
  lv_nuttx_uv_t uv_info;
  uv_loop_t ui_loop;
  uv_timer_t frame_timer;
  void *uv_data;
  int ret;
#endif

  LV_UNUSED(argc);
  LV_UNUSED(argv);

  /* LVGL 是单实例的。快应用（vapp）在跑时已经占住显示驱动，
   * 两个实例抢驱动会得到 "disp refr_timer is NULL"。
   */

  if (lv_is_initialized())
    {
      printf("velaride: LVGL already initialized (vapp running?).\n");
      printf("velaride: kill the vapp process first.\n");
      return EXIT_FAILURE;
    }

  lv_init();

  lv_nuttx_dsc_init(&info);
#ifdef CONFIG_LV_USE_NUTTX_LCD
  info.fb_path = "/dev/lcd0";
#endif
#ifdef CONFIG_LV_USE_NUTTX_TOUCHSCREEN
  info.input_path = "/dev/input0";
#endif

  lv_nuttx_init(&info, &result);

  if (result.disp == NULL)
    {
      printf("velaride: display init failed\n");
      return EXIT_FAILURE;
    }

  {
    lv_draw_buf_t *draw_buf = lv_display_get_buf_active(result.disp);

    g_draw_buffer = draw_buf != NULL ? draw_buf->data : NULL;
    g_draw_buffer_size = draw_buf != NULL ? draw_buf->data_size : 0;

    printf("velaride: draw buffer=%p size=%" PRIu32 " bytes (%s)\n",
           draw_buf != NULL ? draw_buf->data : NULL,
           draw_buf != NULL ? draw_buf->data_size : 0,
           draw_buf != NULL &&
           (uintptr_t)draw_buf->data < 0x60000000 ? "SRAM/accessible" :
                                                    "PSRAM/unreachable");
  }

  if (result.indev == NULL)
    {
      /* 没有触摸就只能看，不能滑 —— 提示但不退出 */

      printf("velaride: WARNING no input device, swipe unavailable\n");
    }
  else
    {
      lv_indev_add_event_cb(result.indev, indev_diag_cb, LV_EVENT_ALL, NULL);
    }

#ifdef CONFIG_LV_USE_NUTTX_LIBUV
  /* Keep LVGL timers and input on libuv, but do not initialize the FB poll.
   * NuttX lcddev_poll() always reports POLLOUT, so that path renders once per
   * invalidation instead of on a stable cadence.  A dedicated uv timer below
   * drives display refresh every 16 ms.
   */

  memset(&ui_loop, 0, sizeof(ui_loop));
  ret = uv_loop_init(&ui_loop);
  if (ret < 0)
    {
      printf("velaride: uv loop init failed: %s\n", uv_strerror(ret));
      return EXIT_FAILURE;
    }

  memset(&uv_info, 0, sizeof(uv_info));
  uv_info.loop = &ui_loop;
  uv_info.disp = result.disp;
  uv_info.indev = result.indev;

  uv_data = lv_nuttx_uv_init_partial(&uv_info,
                                     LV_NUTTX_UV_INIT_TIMER |
                                     LV_NUTTX_UV_INIT_INPUT);
  if (uv_data == NULL)
    {
      printf("velaride: LVGL libuv integration failed\n");
      uv_loop_close(&ui_loop);
      return EXIT_FAILURE;
    }
#endif

  build_ui();
  update_tick(NULL);
  lv_timer_create(update_tick, 1000, NULL);

#ifdef CONFIG_LV_USE_NUTTX_LIBUV
  /* Commit the initial screen synchronously before replacing LVGL's display
   * timer.  This avoids losing the initial full-screen invalidation while the
   * uv loop has not started yet.
   */

  lv_obj_invalidate(lv_screen_active());
  _lv_display_refr_timer(NULL);

  /* Replace LVGL's pause/resume refresh timer with an unconditional frame
   * pump.  timeout=0 guarantees that the initial full-screen invalidation is
   * drawn as soon as the uv loop starts; repeat=16 batches touch samples into
   * a stable cadence.
   */

  lv_display_delete_refr_timer(result.disp);
  memset(&frame_timer, 0, sizeof(frame_timer));
  ret = uv_timer_init(&ui_loop, &frame_timer);
  if (ret < 0)
    {
      printf("velaride: frame timer init failed: %s\n", uv_strerror(ret));
      lv_nuttx_uv_deinit(&uv_data);
      uv_run(&ui_loop, UV_RUN_NOWAIT);
      uv_loop_close(&ui_loop);
      return EXIT_FAILURE;
    }

  uv_timer_start(&frame_timer, frame_timer_cb, 0, 16);
  printf("velaride: event-driven touch + dedicated 16ms frame pump enabled\n");
  uv_run(&ui_loop, UV_RUN_DEFAULT);
  uv_timer_stop(&frame_timer);
  uv_close((uv_handle_t *)&frame_timer, NULL);
  lv_nuttx_uv_deinit(&uv_data);
  uv_run(&ui_loop, UV_RUN_NOWAIT);
  uv_loop_close(&ui_loop);
#else
  while (1)
    {
      uint32_t idle = lv_timer_handler();

      /* lv_timer_handler 返回距下次任务的毫秒数。返回 0 时给 1ms，
       * 避免空转把 CPU 占满 —— 滚动期间它会返回很小的值，
       * 所以不影响跟手。
       */

      usleep((idle ? idle : 1) * 1000);
    }
#endif

  return EXIT_SUCCESS;
}
