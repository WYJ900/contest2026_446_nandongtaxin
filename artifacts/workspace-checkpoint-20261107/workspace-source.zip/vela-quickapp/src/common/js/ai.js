/**
 * velaclaw AI 访问层。
 *
 * 两个约束决定了这个模块的写法：
 *
 * 1. **不能顶层 import `@system.velaclaw`** —— 当前固件不一定编入该 feature
 *    （依赖 CONFIG_EXAMPLES_AI_AGENT_VELA）。顶层 import 会在模块加载期就抛，
 *    整个页面渲染不出来（黑屏）。所以只在真正调用时才 require。
 * 2. **设备当前无网络** —— ask() 能到 ai_agent 守护进程但拿不到 LLM 回复，
 *    详见 project-docs/NEXT_STEPS.md ①。因此每次调用都要能降级到本地兜底文案，
 *    界面不能因为 AI 不可用就空着。
 */

/** ask() 的超时上限（毫秒）。没网时守断进程可能一直不回，必须自己断。 */
const ASK_TIMEOUT_MS = 15000;

let cached = null;
let probed = false;

/**
 * 取 velaclaw 模块，拿不到返回 null。结果缓存，避免每次调用都吃一次异常开销。
 * @returns {Object|null} velaclaw 模块或 null
 */
function getVelaclaw() {
  if (probed) {
    return cached;
  }
  probed = true;
  try {
    cached = require('@system.velaclaw');
  } catch (err) {
    console.warn('velaclaw feature 不可用: ' + err);
    cached = null;
  }
  return cached;
}

/**
 * velaclaw feature 是否可用。用于界面显示「AI 在线 / 离线」。
 * @returns {boolean} 能拿到 feature 返回 true
 */
export function isAvailable() {
  return getVelaclaw() !== null;
}

/**
 * 向 AI 提问，带超时和兜底。**不会 reject**，调用方不需要 try/catch。
 * @param {string} query 提问内容
 * @param {string} fallback AI 不可用或超时时返回的本地文案
 * @returns {Promise<{ok: boolean, text: string}>} ok 为 true 表示 text 来自 AI
 */
export function ask(query, fallback) {
  const velaclaw = getVelaclaw();
  if (!velaclaw) {
    return Promise.resolve({ ok: false, text: fallback });
  }

  return new Promise((resolve) => {
    let settled = false;
    /**
     * 只结算一次，超时和正常返回谁先到算谁。
     * @param {boolean} ok 是否来自 AI
     * @param {string} text 结果文案
     * @returns {void}
     */
    const done = (ok, text) => {
      if (!settled) {
        settled = true;
        resolve({ ok, text });
      }
    };

    const timer = setTimeout(() => {
      console.warn('AI_ASK: 超时 ' + ASK_TIMEOUT_MS + 'ms');
      done(false, fallback);
    }, ASK_TIMEOUT_MS);

    try {
      Promise.resolve(velaclaw.ask({ query }))
        .then((res) => {
          clearTimeout(timer);
          const reply = res && res.reply;
          if (reply) {
            done(true, String(reply));
          } else {
            console.warn('AI_ASK: 回复为空 ' + JSON.stringify(res));
            done(false, fallback);
          }
        })
        .catch((err) => {
          clearTimeout(timer);
          console.warn('AI_ASK: 失败 ' + JSON.stringify(err));
          done(false, fallback);
        });
    } catch (err) {
      // ask() 本身同步抛（feature 存在但底层没起来）也要兜住
      clearTimeout(timer);
      console.warn('AI_ASK: 同步抛出 ' + err);
      done(false, fallback);
    }
  });
}
