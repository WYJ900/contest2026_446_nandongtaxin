/**
 * 格式化工具。原先 home/ride/review 三个页面各自实现了一份补零和时长格式化，
 * 这里统一收口，避免同一段逻辑在多处漂移。
 */

/**
 * 个位数补零。
 * @param {number} n 待补零的数
 * @returns {string} 两位字符串
 */
export function pad2(n) {
  return n < 10 ? `0${n}` : `${n}`;
}

/**
 * 当前时间 `HH:mm`。
 * @returns {string} 形如 `09:05`
 */
export function nowHM() {
  const d = new Date();
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/**
 * 秒数转 `HH:mm:ss`。
 * @param {number} seconds 总秒数
 * @returns {string} 形如 `00:45:32`
 */
export function hms(seconds) {
  const s = Math.max(0, Math.floor(seconds));
  return `${pad2(Math.floor(s / 3600))}:${pad2(Math.floor((s % 3600) / 60))}:${pad2(s % 60)}`;
}

/**
 * 日期转 `YYYY-MM-DD`。
 * @param {Date} date 日期对象
 * @returns {string} 形如 `2026-08-28`
 */
export function ymd(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

/**
 * 时间戳转 `HH:mm`，用于事件记录时间列。
 * @param {number} ts 毫秒时间戳
 * @returns {string} 形如 `14:30`
 */
export function tsToHM(ts) {
  const d = new Date(ts);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/**
 * 保留一位小数的字符串。避免 toFixed 在 undefined 上抛错。
 * @param {number} v 数值
 * @returns {string} 形如 `12.5`
 */
export function one(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n.toFixed(1) : '0.0';
}
