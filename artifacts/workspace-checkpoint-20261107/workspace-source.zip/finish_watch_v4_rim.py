from inspect_watch_mesh import ROOT,stats
import numpy as np,trimesh,manifold3d as md,pymeshlab as pm,shapely,json
from shapely.geometry import Polygon
P=ROOT/'20261018_V4_工作记录'
original=trimesh.load_mesh(ROOT/'修复版_单件STL'/'外壳_修复.stl')
so=md.Manifold(md.Mesh64(original.vertices,original.faces.astype('uint64')))
polys=[Polygon(p) for p in so.slice(-4.0).to_polygons()]
outer=max(polys,key=lambda p:p.area)
m=trimesh.load_mesh(P/'main_final.stl');v=m.vertices.copy()
d=shapely.distance(shapely.points(v[:,:2]),outer.boundary)
weight=np.clip(1-d/.14,0,1)*np.clip((-3.72-v[:,2])/.34,0,1)
radial=v[:,:2]-np.array(outer.centroid.coords[0]);radial/=np.linalg.norm(radial,axis=1)[:,None]
delta=np.c_[radial*(.12*weight[:,None]),np.zeros(len(v))]
m.vertices=v+delta;m.export(P/'main_deliver.stl');m=trimesh.load_mesh(P/'main_deliver.stl')
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices,face_matrix=m.faces));ms.compute_selection_by_self_intersections_per_face()
result={'stats':stats(m),'self_intersection_faces':int(ms.current_mesh().face_selection_array().sum()),'max_exterior_rim_shift_mm':float(np.linalg.norm(delta,axis=1).max()),'moved_vertices':int(np.sum(weight>0))}
(P/'rim_finish.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(result,flush=True)
