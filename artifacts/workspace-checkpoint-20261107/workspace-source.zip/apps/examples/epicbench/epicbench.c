/****************************************************************************
 * apps/examples/epicbench/epicbench.c
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License.  You may obtain a copy
 * of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 ****************************************************************************/

/* EPIC 硬件图形加速基准测试。
 *
 * 回答两个问题：
 *
 *   1. EPIC 能不能在 openvela/NuttX 上直接跑？
 *      思澈官方黄山派表盘示例走 EPIC 拿到丝滑效果，但那套代码依赖
 *      RT-Thread（rtthread.h / gui_app_fwk.h）。不过实测 bf0_hal_epic.c
 *      里 9 处 rtthread 引用全部是注释状态，HAL 层已被移植方清理成裸实现，
 *      只依赖 bf0_hal.h。所以理论上可以直接调，本程序验证这一点。
 *
 *   2. EPIC 比 CPU 快多少？
 *      实测背景：LVGL 软渲染下滑动只有 2.9 fps（纯色空卡片 7.1 fps），
 *      而 LCD 送屏仅占 17ms/帧，说明瓶颈在像素填充与合成。
 *      本程序用同一块 buffer 分别跑 CPU memset 和 EPIC 硬件填充，直接对比。
 *
 * 用法（NSH 下）：
 *
 *   epicbench            # 跑全部测试
 *
 * 输出示例：
 *
 *   EPIC_BENCH: init ok, instance=0x50080000
 *   EPIC_BENCH: fill  CPU=118ms  EPIC=6ms   speedup=19.6x
 *   EPIC_BENCH: blit  CPU=142ms  EPIC=9ms   speedup=15.8x
 */

#include <nuttx/config.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sched.h>
#include <errno.h>
#include <inttypes.h>

#include <nuttx/cache.h>
#include <nuttx/irq.h>
#include <nuttx/arch.h>    /* up_enable_irq() */
#include <arch/irq.h>

#include <sfconfig.h>      /* NX_IRQ()：芯片中断号 → NuttX 中断号 */

#include "bf0_hal.h"
#include "bf0_hal_epic.h"
#include "bf0_hal_ezip.h"   /* HAL_EZIP_Init()，EPIC 的 Init 依赖 hezip */

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

/* 测试区域尺寸。
 *
 * 不用全屏 390×450：本基准只测 SRAM（0x2000_0000 段）上的单位像素吞吐。
 * 早期把 buffer 放 PSRAM（0x6014_52c0）时 state 停在 BUSY、EOF_IRQ 恒为 0，
 * 当时同时存在 hezip 为空的问题，不能据此断定 EPIC 无法访问 PSRAM（见交接文档）。
 *
 * 而 SRAM 只有 512KB 且已用 76%，塞不下两个 351KB 全屏 buffer。
 * 改成 200×200 只测单位像素吞吐，按比例外推到全屏，结论不受影响。
 */

#define BENCH_W      100
#define BENCH_H      100
#define BENCH_BPP    2
#define BENCH_BYTES  ((size_t)BENCH_W * BENCH_H * BENCH_BPP)

/* 全屏像素数，用于把测试结果外推成"相当于全屏多少 ms" */

#define FULL_W       390
#define FULL_H       450

/* 每项测试重复次数，取平均以抵掉单次抖动 */

#define BENCH_ROUNDS 10

/****************************************************************************
 * Private Data
 ****************************************************************************/

static EPIC_HandleTypeDef g_epic;

/* EZIP handle 必须给 —— HAL_EPIC_Init 第一行就是：
 *
 *   #ifdef HAL_EZIP_MODULE_ENABLED
 *       epic->hezip->user_data = (void *)epic;
 *   #endif
 *
 * 本板 HAL_EZIP_MODULE_ENABLED 是开的（bf0_hal_conf_hcpu.h:30），
 * hezip 为 NULL 时这里就是空指针写入。Init 仍会返回 HAL_OK，但硬件
 * 后续跑不完 —— 实测 state 停在 BUSY、EOF_IRQ 恒为 0。
 *
 * 官方示例 example/hal/epic/src/main.c 的顺序是：
 *   hezip = &ezip_handle; hezip->Instance = EZIP;
 *   HAL_EZIP_Init(hezip); 然后才 HAL_EPIC_Init。
 */

static EZIP_HandleTypeDef g_ezip;

/* EPIC 的源和目标 buffer。
 *
 * 本基准固定用 SRAM 静态数组，只测片上内存吞吐；NuttX 用户堆主要在 PSRAM。
 * 静态数组落在 .bss，链接进 SRAM。
 * 64 字节对齐是 cache line 要求，EPIC 作为 DMA master 需要。
 */

static uint8_t g_buf_a[BENCH_BYTES] __attribute__((aligned(64)));
static uint8_t g_buf_b[BENCH_BYTES] __attribute__((aligned(64)));

/* EPIC 完成标志。HAL 的阻塞版接口内部自己轮询，这里只用于中断版验证。 */

static volatile bool g_epic_done;

/****************************************************************************
 * Private Functions
 ****************************************************************************/

/****************************************************************************
 * Name: now_us
 *
 * Description:
 *   单调时钟当前值（微秒）。基准测试全部用它计时，避免 RTC 被调整影响。
 *
 ****************************************************************************/

static uint64_t now_us(void)
{
  struct timespec ts;

  if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0)
    {
      return 0;
    }

  return (uint64_t)ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
}

/****************************************************************************
 * Name: epic_cplt_cb
 *
 * Description:
 *   EPIC 传输完成回调，供中断版接口使用。
 *
 ****************************************************************************/

static void epic_cplt_cb(EPIC_HandleTypeDef *epic)
{
  (void)epic;
  g_epic_done = true;
}

/****************************************************************************
 * Name: epic_isr
 *
 * Description:
 *   EPIC 中断服务例程。HAL 只提供 HAL_EPIC_IRQHandler，挂到 NuttX 向量表
 *   这一步得自己做 —— 接法照 sf32lb_lcd.c 里 LCDC1_IRQn 的写法。
 *
 *   不接中断的后果：中断版接口（Copy_IT / FillStart_IT）永远等不到完成
 *   回调；阻塞版接口内部也依赖中断清状态，实测跑分会在 8.8ms 和 23ms
 *   之间跳，数字不可信。
 *
 ****************************************************************************/

static int epic_isr(int irq, FAR void *context, FAR void *arg)
{
  (void)irq;
  (void)context;

  HAL_EPIC_IRQHandler((EPIC_HandleTypeDef *)arg);
  return OK;
}

/****************************************************************************
 * Name: epic_wait_done
 *
 * Description:
 *   等 EPIC 完成回调。设上限避免中断没接上时死等。
 *   不用 usleep 让出 CPU —— EPIC 单次操作只有毫秒级，usleep 的调度延迟
 *   （至少一个 tick，1ms）会把测量结果整体抬高。忙等更准。
 *
 * Returned Value:
 *   完成返回 true，超时返回 false 并打印诊断。
 *
 ****************************************************************************/

static bool epic_wait_done(const char *what)
{
  /* 等 EPIC 空闲。判据是 handle 的 State 回到 READY，而不是等自己的
   * XferCpltCallback —— 实测 buffer 放对（SRAM）之后 State 已经能正常
   * 回到 READY=1，说明硬件跑完了，但用户回调没被调到。
   *
   * 原因是 HAL 内部用 IntXferCpltCallback 处理完成事件，XferCpltCallback
   * 只在特定 api_type 下转发；阻塞版接口（HAL_EPIC_FillStart）本身就自带
   * 轮询等待，返回时已经完成。所以这里只做兜底确认，不依赖中断路径。
   */

  uint32_t spins = 0;

  while (g_epic.State != HAL_EPIC_STATE_READY && !g_epic_done)
    {
      if (++spins > 200000)
        {
          printf("EPIC_BENCH: %s 未完成，state=%d err=%" PRIu32 "\n",
                 what, (int)g_epic.State, g_epic.ErrorCode);
          return false;
        }

      if ((spins & 0xff) == 0)
        {
          sched_yield();
        }
    }

  return true;
}

/****************************************************************************
 * Name: bench_cpu_fill
 *
 * Description:
 *   CPU 填充基准：整屏填成单色。这是 LVGL 软渲染画纯色矩形时做的事，
 *   用 memset 已经是 CPU 能做到的最快路径（RGB565 高低字节相同时成立），
 *   所以这个数字是 CPU 侧的乐观上界。
 *
 * Returned Value:
 *   平均单次耗时（微秒）。
 *
 ****************************************************************************/

static uint64_t bench_cpu_fill(uint8_t *buf)
{
  uint64_t t0 = now_us();
  int i;

  for (i = 0; i < BENCH_ROUNDS; i++)
    {
      /* 0x1F 高低字节相同，memset 能正确铺出 RGB565 的蓝色 */

      memset(buf, 0x1f, BENCH_BYTES);
    }

  return (now_us() - t0) / BENCH_ROUNDS;
}

/****************************************************************************
 * Name: bench_epic_fill
 *
 * Description:
 *   EPIC 硬件填充基准，与 bench_cpu_fill 填同样大小的区域。
 *
 * Returned Value:
 *   平均单次耗时（微秒），失败返回 0。
 *
 ****************************************************************************/

static uint64_t bench_epic_fill(uint8_t *buf)
{
  EPIC_FillingCfgTypeDef cfg;
  uint64_t t0;
  int i;

  t0 = now_us();

  for (i = 0; i < BENCH_ROUNDS; i++)
    {
      HAL_EPIC_FillDataInit(&cfg);

      cfg.start       = buf;
      cfg.color_mode  = EPIC_COLOR_RGB565;
      cfg.width       = BENCH_W;
      cfg.height      = BENCH_H;
      cfg.total_width = BENCH_W;
      cfg.color_r     = 0x00;
      cfg.color_g     = 0x00;
      cfg.color_b     = 0xff;
      cfg.alpha       = 255;

      /* EPIC 是 DMA 类硬件，写之前得让它看到最新内存内容，
       * 完成后要让 CPU 看到硬件写入的结果。
       */

      up_clean_dcache((uintptr_t)buf, (uintptr_t)buf + BENCH_BYTES);

      /* 用中断版而非阻塞版：阻塞版内部也依赖中断清状态，
       * 中断没接时跑分会在 8.8ms 和 23ms 之间跳。中断版配合
       * 自己等标志位，能确保测到的是硬件真实完成时间。
       */

      /* 用阻塞版 —— 官方示例 example/hal/epic/src/main.c 就是这么调的，
       * 它内部自己轮询等硬件完成，返回时结果已经可用。
       * 中断版（_IT）需要 HAL 的 IntXferCpltCallback 链路，多一层不确定性。
       */

      g_epic_done = false;

      if (HAL_EPIC_FillStart(&g_epic, &cfg) != HAL_OK)
        {
          printf("EPIC_BENCH: HAL_EPIC_FillStart failed, state=%d err=%"
                 PRIu32 "\n", (int)g_epic.State, g_epic.ErrorCode);
          return 0;
        }

      if (!epic_wait_done("fill"))
        {
          return 0;
        }

      up_invalidate_dcache((uintptr_t)buf, (uintptr_t)buf + BENCH_BYTES);
    }

  return (now_us() - t0) / BENCH_ROUNDS;
}

/****************************************************************************
 * Name: bench_cpu_blit
 *
 * Description:
 *   CPU 整屏拷贝基准。滑动时 LVGL 要把卡片内容搬到新位置，本质是这个操作。
 *
 * Returned Value:
 *   平均单次耗时（微秒）。
 *
 ****************************************************************************/

static uint64_t bench_cpu_blit(uint8_t *dst, const uint8_t *src)
{
  uint64_t t0 = now_us();
  int i;

  for (i = 0; i < BENCH_ROUNDS; i++)
    {
      memcpy(dst, src, BENCH_BYTES);
    }

  return (now_us() - t0) / BENCH_ROUNDS;
}

/****************************************************************************
 * Name: bench_epic_blit
 *
 * Description:
 *   EPIC 整屏拷贝基准，对应 HAL_EPIC_Copy_IT。
 *   用中断版是因为 HAL 没提供阻塞版 Copy，需要自己等完成标志。
 *
 * Returned Value:
 *   平均单次耗时（微秒），失败返回 0。
 *
 ****************************************************************************/

static uint64_t bench_epic_blit(uint8_t *dst, uint8_t *src)
{
  EPIC_BlendingDataType s;
  EPIC_BlendingDataType d;
  uint64_t t0;
  int i;

  t0 = now_us();

  for (i = 0; i < BENCH_ROUNDS; i++)
    {
      memset(&s, 0, sizeof(s));
      memset(&d, 0, sizeof(d));

      s.data        = src;
      s.color_mode  = EPIC_COLOR_RGB565;
      s.width       = BENCH_W;
      s.height      = BENCH_H;
      s.total_width = BENCH_W;

      d.data        = dst;
      d.color_mode  = EPIC_COLOR_RGB565;
      d.width       = BENCH_W;
      d.height      = BENCH_H;
      d.total_width = BENCH_W;

      up_clean_dcache((uintptr_t)src, (uintptr_t)src + BENCH_BYTES);
      up_clean_dcache((uintptr_t)dst, (uintptr_t)dst + BENCH_BYTES);

      g_epic_done = false;

      if (HAL_EPIC_Copy_IT(&g_epic, &s, &d) != HAL_OK)
        {
          printf("EPIC_BENCH: HAL_EPIC_Copy_IT failed, state=%d err=%" PRIu32 "\n",
                 (int)g_epic.State, g_epic.ErrorCode);
          return 0;
        }

      if (!epic_wait_done("blit"))
        {
          return 0;
        }

      up_invalidate_dcache((uintptr_t)dst, (uintptr_t)dst + BENCH_BYTES);
    }

  return (now_us() - t0) / BENCH_ROUNDS;
}

/****************************************************************************
 * Name: report
 *
 * Description:
 *   打印一项对比结果。加速比用定点算，避免引入浮点格式化。
 *
 ****************************************************************************/

static void report(const char *name, uint64_t cpu_us, uint64_t epic_us)
{
  /* 测试区域是 200×200，按像素数外推到全屏 390×450，
   * 这样能直接和实测的送屏 17ms / 帧率数据对比。
   */

  const uint32_t scale_num = (uint32_t)FULL_W * FULL_H;
  const uint32_t scale_den = (uint32_t)BENCH_W * BENCH_H;

  if (epic_us == 0)
    {
      printf("EPIC_BENCH: %-4s CPU=%" PRIu64 "us  EPIC=FAILED\n",
             name, cpu_us);
      return;
    }

  {
    uint32_t ratio_x10 = (uint32_t)(cpu_us * 10 / epic_us);
    uint32_t cpu_full_ms = (uint32_t)(cpu_us * scale_num / scale_den / 1000);
    uint32_t epic_full_ms = (uint32_t)(epic_us * scale_num / scale_den / 1000);

    printf("EPIC_BENCH: %-4s CPU=%" PRIu64 "us  EPIC=%" PRIu64
           "us  speedup=%" PRIu32 ".%" PRIu32 "x"
           "   [full screen: CPU=%" PRIu32 "ms EPIC=%" PRIu32 "ms]\n",
           name, cpu_us, epic_us, ratio_x10 / 10, ratio_x10 % 10,
           cpu_full_ms, epic_full_ms);
  }
}

/****************************************************************************
 * Public Functions
 ****************************************************************************/

int main(int argc, FAR char *argv[])
{
  uint8_t *buf_a = g_buf_a;
  uint8_t *buf_b = g_buf_b;
  int ret = EXIT_FAILURE;

  (void)argc;
  (void)argv;

  printf("EPIC_BENCH: %dx%d RGB565, %zu bytes, %d rounds\n",
         BENCH_W, BENCH_H, BENCH_BYTES, BENCH_ROUNDS);

  memset(buf_a, 0xa5, BENCH_BYTES);
  memset(buf_b, 0x00, BENCH_BYTES);

  /* 打地址确认落在 SRAM（0x2000_xxxx）而不是 PSRAM（0x6000_xxxx）。
   * PSRAM 上的 EPIC 行为以 my-contest-repo/docs/HANDOFF_EPIC_20261017.md 为准。
   */

  printf("EPIC_BENCH: buf_a=%p buf_b=%p (SRAM 应为 0x2xxxxxxx)\n",
         buf_a, buf_b);

  /* --- EPIC 初始化 -------------------------------------------------- */

  memset(&g_epic, 0, sizeof(g_epic));
  memset(&g_ezip, 0, sizeof(g_ezip));

  /* 顺序照官方示例 example/hal/epic/src/main.c：
   * EZIP 先就位再 Init EPIC，否则 HAL_EPIC_Init 会往 NULL 写。
   */

  g_epic.hezip = &g_ezip;
  g_epic.hezip->Instance = EZIP;

  if (HAL_EZIP_Init(g_epic.hezip) != HAL_OK)
    {
      printf("EPIC_BENCH: HAL_EZIP_Init 失败\n");
      goto out;
    }

  g_epic.Instance = EPIC;

  if (HAL_EPIC_Init(&g_epic) != HAL_OK)
    {
      printf("EPIC_BENCH: HAL_EPIC_Init 失败 err=%" PRIu32 "\n",
             g_epic.ErrorCode);
      printf("EPIC_BENCH: 结论 —— EPIC 在当前固件上起不来\n");
      goto out;
    }

  printf("EPIC_BENCH: init ok, instance=%p state=%d\n",
         g_epic.Instance, (int)g_epic.State);

  /* 挂中断。HAL_EPIC_Init 只开时钟和配寄存器，向量表这步 HAL 不管。 */

  g_epic.XferCpltCallback = epic_cplt_cb;

  if (irq_attach(NX_IRQ(EPIC_IRQn), epic_isr, &g_epic) != 0)
    {
      printf("EPIC_BENCH: irq_attach(EPIC_IRQn=%d) 失败\n", (int)EPIC_IRQn);
      goto out;
    }

  up_enable_irq(NX_IRQ(EPIC_IRQn));
  printf("EPIC_BENCH: irq attached, EPIC_IRQn=%d nx_irq=%d\n",
         (int)EPIC_IRQn, NX_IRQ(EPIC_IRQn));

  /* --- 填充对比 ----------------------------------------------------- */

  report("fill", bench_cpu_fill(buf_a), bench_epic_fill(buf_a));

  /* --- 拷贝对比 ----------------------------------------------------- */

  report("blit", bench_cpu_blit(buf_b, buf_a), bench_epic_blit(buf_b, buf_a));

  ret = EXIT_SUCCESS;

out:
  /* buffer 是静态数组，不需要 free */

  return ret;
}
