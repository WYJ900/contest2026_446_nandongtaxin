/****************************************************************************
 * apps/examples/velaclock/velaclock.c
 *
 * VelaRide AI 数字时钟：从 RTC 读时间，用 LVGL 画在黄山派屏幕上。
 * 用于验证图形栈与 RTC 在真机上可用。
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <stdio.h>
#include <time.h>
#include <unistd.h>

#include <lvgl/lvgl.h>

/****************************************************************************
 * Private Data
 ****************************************************************************/

static lv_obj_t *g_time_label;
static lv_obj_t *g_date_label;

/****************************************************************************
 * Private Functions
 ****************************************************************************/

/****************************************************************************
 * Name: update_clock
 *
 * Description:
 *   LVGL 定时器回调，每秒读一次系统时间并刷新标签。
 *   时间源是 RTC（CONFIG_RTC_DATETIME），未校准时会从 1970 起算。
 *
 ****************************************************************************/

static void update_clock(lv_timer_t *timer)
{
  char buf[32];
  time_t now;
  struct tm tm_now;

  now = time(NULL);
  localtime_r(&now, &tm_now);

  snprintf(buf, sizeof(buf), "%02d:%02d:%02d",
           tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
  lv_label_set_text(g_time_label, buf);

  snprintf(buf, sizeof(buf), "%04d-%02d-%02d",
           tm_now.tm_year + 1900, tm_now.tm_mon + 1, tm_now.tm_mday);
  lv_label_set_text(g_date_label, buf);
}

/****************************************************************************
 * Name: build_ui
 *
 * Description:
 *   搭建界面：黑底 + 居中大号时间 + 下方日期 + 顶部标题。
 *   屏幕实测 390x450，这里用居中对齐而非绝对坐标，换屏也不用改。
 *
 ****************************************************************************/

static void build_ui(void)
{
  lv_obj_t *screen = lv_screen_active();
  lv_obj_t *title;

  lv_obj_set_style_bg_color(screen, lv_color_black(), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, LV_PART_MAIN);

  title = lv_label_create(screen);
  lv_label_set_text(title, "VelaRide AI");
  lv_obj_set_style_text_color(title, lv_palette_main(LV_PALETTE_CYAN),
                              LV_PART_MAIN);
  lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 60);

  g_time_label = lv_label_create(screen);
  lv_label_set_text(g_time_label, "--:--:--");
  lv_obj_set_style_text_color(g_time_label, lv_color_white(), LV_PART_MAIN);
  /* 用内置 montserrat 大号字体，不依赖 /etc/data/font 里的 TTF */
  lv_obj_set_style_text_font(g_time_label, &lv_font_montserrat_28,
                             LV_PART_MAIN);
  lv_obj_center(g_time_label);

  g_date_label = lv_label_create(screen);
  lv_label_set_text(g_date_label, "-------—--");
  lv_obj_set_style_text_color(g_date_label,
                              lv_palette_main(LV_PALETTE_GREY),
                              LV_PART_MAIN);
  lv_obj_align_to(g_date_label, g_time_label, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
}

/****************************************************************************
 * Public Functions
 ****************************************************************************/

int main(int argc, FAR char *argv[])
{
  lv_nuttx_dsc_t info;
  lv_nuttx_result_t result;

  /* 若已有快应用（vapp）占用 LVGL，这里必须退出，否则两个实例抢显示驱动
   * 会得到 "disp refr_timer is NULL"。先 kill 掉 vapp 再运行本程序。
   */

  if (lv_is_initialized())
    {
      printf("LVGL already initialized (vapp running?). "
             "Kill the vapp process first.\n");
      return -1;
    }

  lv_init();

  lv_nuttx_dsc_init(&info);
#ifdef CONFIG_LV_USE_NUTTX_LCD
  info.fb_path = "/dev/lcd0";
#endif
#ifdef CONFIG_INPUT_TOUCHSCREEN
  info.input_path = "/dev/input0";
#endif

  lv_nuttx_init(&info, &result);

  if (result.disp == NULL)
    {
      printf("velaclock: display init failed\n");
      return 1;
    }

  build_ui();

  /* 立刻画一次，避免启动后有一秒空白 */

  update_clock(NULL);
  lv_timer_create(update_clock, 1000, NULL);

  while (1)
    {
      uint32_t idle = lv_timer_handler();
      idle = idle ? idle : 1;
      usleep(idle * 1000);
    }

  return 0;
}
