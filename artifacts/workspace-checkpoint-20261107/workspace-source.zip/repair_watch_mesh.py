"""Conservative STL cleanup. Never changes source STL files or joins distinct parts."""
from pathlib import Path
import hashlib
import json
import zipfile
import numpy as np
import trimesh
import manifold3d
import pymeshlab as pm
from inspect_watch_mesh import ROOT, stats

OUT = ROOT / '修复版_单件STL'
OUT.mkdir(exist_ok=True)

def intersect_count(m):
    ms = pm.MeshSet()
    ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices, face_matrix=m.faces))
    ms.compute_selection_by_self_intersections_per_face()
    return int(ms.current_mesh().face_selection_array().sum()), ms.get_topological_measures()

def normal_stats(path):
    dtype = np.dtype([('normal','<f4',(3,)),('v','<f4',(3,3)),('attr','<u2')])
    a = np.frombuffer(path.read_bytes(), dtype=dtype, offset=84)
    v = a['v'].astype(float)
    c = np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0])
    return int(np.sum(np.einsum('ij,ij->i', c, a['normal']) < 0))

results=[]
for source in sorted(ROOT.glob('*.stl')):
    original = trimesh.load_mesh(source)
    # A new object deliberately recomputes normals from winding, not stored STL normals.
    cleaned = trimesh.Trimesh(original.vertices.copy(), original.faces.copy(), process=False)
    old_intersections, old_topology = intersect_count(original)
    method = '重新计算并导出三角面法线；几何坐标不变'
    if source.name in ('外壳.stl','底部外壳.stl'):
        solid = manifold3d.Manifold(manifold3d.Mesh(np.asarray(original.vertices,dtype=np.float32),np.asarray(original.faces,dtype=np.uint32)))
        assert solid.status() == manifold3d.Error.NoError
        optimized = solid.simplify(0.00001)
        assert optimized.status() == manifold3d.Error.NoError
        mesh = optimized.to_mesh()
        cleaned = trimesh.Trimesh(mesh.vert_properties[:,:3],mesh.tri_verts,process=False)
        method = '以0.00001 mm容差清理局部退化/极瘦三角面；重新导出法线；不补设计孔、不缩放、不合并零件'
    cleaned.fix_normals(multibody=True)
    target = OUT / (source.stem + '_修复.stl')
    cleaned.export(target)
    reloaded = trimesh.load_mesh(target)
    after = stats(reloaded)
    intersections, topology = intersect_count(reloaded)
    normals_bad = normal_stats(target)
    assert after['watertight'] and after['winding'] and after['volume'] > 0
    assert after['boundary_edges'] == after['nonmanifold_edges'] == after['degenerate_faces'] == after['duplicate_faces'] == 0
    assert topology['connected_components_number'] == 1 and topology['non_two_manifold_vertices'] == 0
    assert intersections == normals_bad == 0
    assert old_topology['genus'] == topology['genus'], 'Designed topology changed'
    assert np.max(np.abs(reloaded.bounds-original.bounds)) < 0.0001
    # Bidirectional sampled surface distances supplement the topology checks.
    np.random.seed(20261017)
    samples_old,_ = trimesh.sample.sample_surface(original, 12000)
    samples_new,_ = trimesh.sample.sample_surface(reloaded, 12000)
    max_distance = max(float(trimesh.proximity.closest_point(reloaded,samples_old)[1].max()),
                       float(trimesh.proximity.closest_point(original,samples_new)[1].max()))
    assert max_distance < 0.0001
    result = dict(file=source.name, output=target.name, method=method,
                  source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  before=stats(original), before_self_intersection_faces=old_intersections,
                  before_stored_normals_opposed=normal_stats(source), after=after,
                  after_self_intersection_faces=intersections, after_stored_normals_opposed=normals_bad,
                  topology_before=old_topology, topology_after=topology,
                  sampled_bidirectional_max_distance_mm=max_distance,
                  volume_change_mm3=float(reloaded.volume-original.volume))
    results.append(result)
    print(json.dumps({k:result[k] for k in ['file','before_self_intersection_faces','after_self_intersection_faces','sampled_bidirectional_max_distance_mm','volume_change_mm3']},ensure_ascii=False),flush=True)

(OUT/'verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['黄山派 watch 表带版 STL 检查与清理记录',
       '原文件保留在上一级目录。此目录中的六个 STL 为六种独立零件，每个文件只含一个连通实体。',
       '单位按原模型毫米解释；没有缩放、平移、拼装或把多个零件合并为一个文件。',
       '网站当前文件异常对话框标记的是“外壳.stl”。',
       '本地原件检查：全部为单连通、封闭、边绕序一致；主外壳另检测到2个退化面及5个自相交关联面。',
       '两个壳体采用0.00001 mm容差清理；其余四件只重新导出法线，保留原几何。',
       '清理后重新读取STL检查：每件1个连通体，边界边0、非流形边/顶点0、退化面0、自相交面0、法线反向记录0。',
       '原始设计的孔道拓扑（genus）和包围盒保持；没有填掉螺丝孔或按钮开口。',
       '这是本地网格检查通过，不代表嘉立创平台审核已经通过，也不保证材料收缩后的装配公差。',
       '上传：一次选取本目录六个 *_修复.stl 文件，每个单独作为零件。ZIP只作交付打包，不要合并成一个装配STL。',
       '', '逐件验证：']
for r in results:
    lines.append(f"{r['output']} | {r['before']['faces']}→{r['after']['faces']}面 | 最大抽样表面偏差 {r['sampled_bidirectional_max_distance_mm']:.9f} mm | 体积变化 {r['volume_change_mm3']:.9f} mm³")
lines.extend(['','方法文档：https://trimesh.org/trimesh.repair.html',
              'https://pymeshlab.readthedocs.io/en/latest/filter_list.html#compute-selection-by-self-intersections-per-face'])
(OUT/'检查说明.txt').write_text('\n'.join(lines),encoding='utf-8-sig')
with zipfile.ZipFile(ROOT/'黄山派_watch表带版_修复STL.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.iterdir():
        if p.is_file(): z.write(p,p.name)
print('OUTPUT',OUT,flush=True)
