from inspect_watch_mesh import ROOT,stats
import numpy as np,trimesh,manifold3d as md,pymeshlab as pm,json
from scipy.spatial import ConvexHull
OUT=ROOT/'局部加厚V3_待复核';OUT.mkdir(exist_ok=True)
names=['外壳','底部外壳','上横杆','下横杆','V0.2黄山派-按钮其一','V0.2黄山派-按钮其二']
meshes=[trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{n}_修复.stl') for n in names]
def s(m):return md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)))
def m(s):
 a=s.to_mesh();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
def box(lo,hi):return md.Manifold.cube(np.array(hi)-lo).translate(lo)
solids=[s(x) for x in meshes];main,back,bar=solids[:3]
main=main.simplify(.003)
back_new=back
for x,y in [(-46.326612,32.785691),(-15.571870,32.785691),(-42.136924,2.476229),(-19.761558,2.476229)]:
 ring=(md.Manifold.cylinder(4.75,2.4,circular_segments=96)-md.Manifold.cylinder(4.85,1.6,circular_segments=96).translate([0,0,-.05])).translate([x,y,-3.6088265])
 back_new=back_new+ring
z=-4.0732;zb=meshes[1].bounds[0,2]+.01
floor=back.slice(-4.0632).simplify(.01).offset(-.01).extrude(z-zb).translate([0,0,zb])
back_new=(back_new+floor).simplify(.001)

# Replace only the bar's outer envelope; subtract its exact projected axial bore.
v=meshes[2].vertices
bore_mask=((v[:,1]-7.485624)**2+(v[:,2]-5.7)**2<1.1**2)
yz=np.unique(v[bore_mask][:,[1,2]],axis=0);poly=yz[ConvexHull(yz).vertices]
hole=md.CrossSection([poly],md.FillRule.EvenOdd).extrude(38).transform([[0,0,1,-50],[1,0,0,0],[0,1,0,0]])
outer=s(meshes[2].convex_hull).scale([1,1.08,1.4]).translate([0,-7.485624*.08,-2.28])
bar_new=(outer-hole).simplify(.0001)

# Small, fully overlapping solid rails outside the long-slot mouths.
pads=[]
for y0,y1 in [(-4.25,-2.95),(44.36,45.66)]:
 pads.append(box([-43.8,y0,-4.80],[-18.1,y1,-2.30]))
 pads.append(box([-43.8,y0,-1.00],[-18.1,y1,1.30]))
# Local rings at the four cross-bar screw entries. Original screw clearance remains open.
for cy,cz in [(7.485624,5.7),(37.5926,4.8)]:
 for x0 in [-51.5,-12.4]:
  ring=(md.Manifold.cylinder(2.0,3.0,circular_segments=96)-md.Manifold.cylinder(2.2,1.85,circular_segments=96).translate([0,0,-.1])).rotate([0,90,0]).translate([x0,cy,cz])
  pads.append(ring)
add=md.Manifold.batch_boolean(pads,md.OpType.Add)
envelope=s(meshes[0].convex_hull).minkowski_sum(md.Manifold.sphere(1.0,circular_segments=16))
add=add^envelope
# The precise source mesh remains the base; source slot clearance cutters below
# protect the straight-through opening while the other assembled parts guard fit.
# Preserve the old straight-through slot clearance even through the new outer rails.
stock=md.CrossSection.square([36,4.7]).translate([-49,-.9])
for y0,y1 in [(-8,5),(36,49)]:
 section_solid=(solids[0]^box([-55,y0,-8],[-6,y1,12])).rotate([90,0,0]).project()
 keepout=stock-section_solid
 cutter=keepout.offset(.01).extrude(y1-y0).transform([[1,0,0,0],[0,0,1,y0],[0,-1,0,0]])
 add=add-cutter
guard=back_new.minkowski_sum(md.Manifold.cube([.3,.3,.3],center=True))
for other in [bar_new]+solids[3:]:guard=guard+other.minkowski_sum(md.Manifold.cube([.2,.2,.2],center=True))
main_new=(main+(add-guard)).simplify(.0001)
new=[main_new,back_new,bar_new]+solids[3:]
reports=[]
for i,body in enumerate(new):
 path=OUT/f'{names[i]}_V3.stl';m(body).export(path);r=trimesh.load_mesh(path)
 r.merge_vertices(digits_vertex=4);r.update_faces(r.nondegenerate_faces());r.update_faces(r.unique_faces());r.remove_unreferenced_vertices();r.fix_normals(multibody=True)
 r.export(path);r=trimesh.load_mesh(path);new[i]=s(r)
 ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=r.vertices,face_matrix=r.faces));ms.compute_selection_by_self_intersections_per_face()
 info=dict(name=names[i],file=path.name,stats=stats(r),euler=int(r.euler_number),self_intersections=int(ms.current_mesh().face_selection_array().sum()),components=len(r.split(only_watertight=False)))
 reports.append(info);print(json.dumps(info,ensure_ascii=False),flush=True)
collisions=[]
for i in range(3):
 for j in range(i+1,6):
  a=(solids[i]^solids[j]).volume();b=(new[i]^new[j]).volume()
  d=dict(a=names[i],b=names[j],before=a,after=b);collisions.append(d);print('COLLISION',d,flush=True)
(OUT/'verification.json').write_text(json.dumps(dict(parts=reports,collisions=collisions),ensure_ascii=False,indent=2),encoding='utf-8')
