import numpy as np, trimesh, manifold3d as md
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from inspect_watch_mesh import ROOT
WORK=ROOT/'局部加厚工作记录'
names=['外壳','底部外壳','上横杆','下横杆','V0.2黄山派-按钮其一','V0.2黄山派-按钮其二']
meshes=[trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{n}_修复.stl') for n in names]
solids=[md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32))) for m in meshes]
for i in range(len(solids)):
    for j in range(i+1,len(solids)):
        v=(solids[i]^solids[j]).volume()
        if v>1e-7: print('existing_overlap',names[i],names[j],v,flush=True)
fig,axs=plt.subplots(2,3,figsize=(16,8))
for ax,x in zip(axs.flat,[-46.325,-42.135,-40,-31,-20,-15.57]):
    for n,m,c in zip(names,meshes,['#005daa','#dd7819','#43a23a','#942abb','#bb3843','#bb3843']):
        sec=m.section(plane_origin=[x,0,0],plane_normal=[1,0,0])
        if sec:
            for p in sec.discrete: ax.plot(p[:,1],p[:,2],color=c,lw=.8)
    ax.set_title(f'YZ at X={x}'); ax.set_aspect('equal');ax.grid(alpha=.3)
fig.tight_layout();fig.savefig(WORK/'assembly_YZ_sections.png',dpi=180)
for z in [-3.55,-2,0,1.13]:
    print('back z',z,flush=True)
    for poly in solids[1].slice(z).to_polygons():
        p=np.asarray(poly)
        if len(p)<20: continue
        A=np.c_[2*p[:,0],2*p[:,1],np.ones(len(p))]; b=np.sum(p*p,axis=1)
        cx,cy,c=np.linalg.lstsq(A,b,rcond=None)[0];r=np.sqrt(c+cx*cx+cy*cy)
        residual=np.max(abs(np.linalg.norm(p-[cx,cy],axis=1)-r))
        if residual<.01: print('circle',cx,cy,r,'residual',residual,flush=True)
print(md.Manifold.cylinder.__doc__)
