from pathlib import Path
import json
import numpy as np
import trimesh

ROOT = Path(__file__).parent / '黄山派适配模型（watch表带版本）【个人制作】'
if not ROOT.is_dir():
    ROOT = Path(__file__).parent.parent

def stats(m):
    counts = np.bincount(m.edges_unique_inverse)
    return dict(vertices=len(m.vertices), faces=len(m.faces),
                watertight=bool(m.is_watertight), winding=bool(m.is_winding_consistent),
                volume=float(m.volume), bounds=m.bounds.tolist(),
                boundary_edges=int(np.sum(counts == 1)), nonmanifold_edges=int(np.sum(counts > 2)),
                degenerate_faces=int(np.sum(~m.nondegenerate_faces())),
                duplicate_faces=int(np.sum(~m.unique_faces())))

def analyze(path):
    raw = trimesh.load_mesh(path, process=False)
    m = raw.copy()
    m.merge_vertices()
    parts = m.split(only_watertight=False)
    result = dict(file=path.name, raw_faces=len(raw.faces), merged=stats(m), components=[stats(p) for p in parts])
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result

if __name__ == '__main__':
    results = [analyze(p) for p in sorted(ROOT.glob('*.stl'))]
    (ROOT / 'mesh_diagnosis.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
