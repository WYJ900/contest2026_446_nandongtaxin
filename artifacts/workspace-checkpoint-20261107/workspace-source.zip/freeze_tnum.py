import sys
from fontTools.ttLib import TTFont
src, dst = sys.argv[1], sys.argv[2]
f = TTFont(src)
gsub = f['GSUB'].table
idx = [i for fr in gsub.FeatureList.FeatureRecord if fr.FeatureTag == 'tnum' for i in fr.Feature.LookupListIndex]
mapping = {}
for i in idx:
    for st in gsub.LookupList.Lookup[i].SubTable:
        st = getattr(st, 'ExtSubTable', st)
        if hasattr(st, 'mapping'):
            mapping.update(st.mapping)
for table in f['cmap'].tables:
    if table.isUnicode():
        for cp, g in list(table.cmap.items()):
            if g in mapping:
                table.cmap[cp] = mapping[g]
f.save(dst)
hm = f['hmtx']; cm = f.getBestCmap()
print(dst, [hm[cm[ord(c)]][0] for c in '0123456789'])
