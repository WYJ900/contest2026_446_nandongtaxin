from pathlib import Path
import numpy as np, trimesh, manifold3d as md
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from inspect_watch_mesh import ROOT
WORK = ROOT / '局部加厚工作记录'
WORK.mkdir(exist_ok=True)
def load(name): return trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{name}_修复.stl')
def solid(m): return md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)))

for name,short in [('外壳','main'),('底部外壳','back')]:
    m=load(name); s=solid(m)
    fig,axs=plt.subplots(2,3,figsize=(15,9))
    for ax,z in zip(axs.flat,[-4,-2.5,-1,0,1,4]):
        cs=s.slice(z).to_polygons()
        for poly in cs:
            p=np.asarray(poly); p=np.vstack([p,p[0]])
            ax.plot(p[:,0],p[:,1],lw=.7)
            if short=='back' and z in [-1,0,1]:
                print(short,z,'loop n',len(p),'bounds',np.min(p,axis=0),np.max(p,axis=0),flush=True)
        ax.set_title(f'{short} Z={z} mm');ax.set_aspect('equal');ax.grid(alpha=.3)
    fig.tight_layout();fig.savefig(WORK/f'{short}_sections.png',dpi=160);plt.close(fig)
    np.random.seed(17)
    points,faces=trimesh.sample.sample_surface(m,18000)
    normals=m.face_normals[faces]; starts=points-normals*0.0001
    hit,ray,tri=m.ray.intersects_location(starts,-normals,multiple_hits=False)
    dist=np.linalg.norm(hit-points[ray],axis=1)
    opposing=np.einsum('ij,ij->i',normals[ray],m.face_normals[tri])<-.5
    thin=(dist<1)&(dist>.001)&opposing
    np.savez(WORK/f'{short}_thickness_samples.npz',points=points[ray],thickness=dist,opposing=opposing)
    print(short,'thin samples',thin.sum(),'thickness quantiles',np.quantile(dist[opposing],[0,.01,.05,.1,.5]).tolist(),flush=True)
    fig,axs=plt.subplots(1,3,figsize=(16,5))
    for ax,(i,j) in zip(axs,[(0,1),(0,2),(1,2)]):
        ax.scatter(points[:,i],points[:,j],s=.2,c='#cccccc')
        sc=ax.scatter(points[ray][thin,i],points[ray][thin,j],s=3,c=dist[thin],cmap='plasma',vmin=0,vmax=1)
        ax.set_xlabel('XYZ'[i]);ax.set_ylabel('XYZ'[j]);ax.set_aspect('equal');ax.grid(alpha=.2)
    fig.colorbar(sc,ax=axs,label='Opposing-surface ray thickness < 1 mm');fig.suptitle(short)
    fig.savefig(WORK/f'{short}_thin_map.png',dpi=180);plt.close(fig)
