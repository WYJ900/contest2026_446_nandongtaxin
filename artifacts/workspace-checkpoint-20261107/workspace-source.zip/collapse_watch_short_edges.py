from inspect_watch_mesh import ROOT,stats
import trimesh,numpy as np,pymeshlab as pm,json
P=ROOT/'20261018_V4_工作记录'
def si(m):
 ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices,face_matrix=m.faces));ms.compute_selection_by_self_intersections_per_face();return np.asarray(ms.current_mesh().face_selection_array())
def clean(path):
 m=trimesh.load_mesh(path);start=m.copy();changes=[]
 for iteration in range(40):
  selected=si(m);edges=m.edges_unique;lengths=m.edges_unique_length
  candidates=np.where(lengths<.003)[0]
  if not len(candidates):break
  involved=set(m.faces[selected].ravel())
  candidates=sorted(candidates,key=lambda k:(not any(v in involved for v in edges[k]),lengths[k]))
  changed=False
  for k in candidates:
   a,b=edges[k];fa=np.where(np.any(m.faces==a,axis=1))[0];fb=np.where(np.any(m.faces==b,axis=1))[0]
   shared=set(fa)&set(fb)
   if len(shared)!=2:continue
   na=set(m.faces[fa].ravel())-{a,b};nb=set(m.faces[fb].ravel())-{a,b}
   opposite=set(m.faces[list(shared)].ravel())-{a,b}
   if na&nb!=opposite:continue
   verts=m.vertices.copy();verts[a]=(verts[a]+verts[b])/2;faces=m.faces.copy();faces[faces==b]=a
   keep=(faces[:,0]!=faces[:,1])&(faces[:,1]!=faces[:,2])&(faces[:,0]!=faces[:,2]);trial=trimesh.Trimesh(verts,faces[keep],process=False);trial.remove_unreferenced_vertices()
   if not trial.is_watertight or not trial.is_winding_consistent or not np.all(trial.nondegenerate_faces()):continue
   if abs(trial.volume-m.volume)>.02:continue
   after=si(trial)
   if int(after.sum())>int(selected.sum()):continue
   changes.append({'edge_length_mm':float(lengths[k]),'si_before':int(selected.sum()),'si_after':int(after.sum())});m=trial;changed=True;break
  if not changed:break
 m.export(path);m=trimesh.load_mesh(path)
 result={'file':path.name,'stats':stats(m),'self_intersection_faces':int(si(m).sum()),'remaining_edges_below_003':int((m.edges_unique_length<.003).sum()),'changes':changes,'volume_change_mm3':float(m.volume-start.volume)}
 print(json.dumps(result,ensure_ascii=False),flush=True)
 return result
if __name__=='__main__':
 reports=[clean(P/'main_final.stl'),clean(P/'bottom_final.stl')]
 (P/'short_edge_cleanup.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
