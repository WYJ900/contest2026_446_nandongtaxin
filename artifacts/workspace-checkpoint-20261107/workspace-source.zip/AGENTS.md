<!-- CODEGRAPH_START -->
## CodeGraph

In repositories indexed by CodeGraph (a `.codegraph/` directory exists at the repo root), use CodeGraph before grep/find or reading code to locate or understand symbols. Use `codegraph_explore` when available, otherwise `codegraph explore`. Do not create an index without the user's request. Skip CodeGraph when no index exists.
<!-- CODEGRAPH_END -->

## User-required development order and regression protection

The user explicitly requires this order (2026-10-26):

1. Restore and validate all previously accepted watch functions.
2. Add microphone support on that verified baseline and verify that the base functions still work.
3. Add new Bluetooth/phone-app integration and repeat the same base-function checks.

Existing baseline Bluetooth features are themselves old functions to preserve. This order concerns the new integrations, not removal of legacy working features.

Before changing a verified baseline, preserve the exact firmware, configuration, applicable source snapshot/patches, hashes, and the evidence that was actually checked. Do not describe a partially identified source tree as a complete reproducible baseline.

Keep changes limited to the requested feature. Changes to shared startup, clock, pinmux, I2C, DMA, display, touch, or power code need a concrete technical reason and explicit regression checks. Preserve unrelated working edits when synchronizing the canonical and migration trees.

A lit display does not prove touch, gestures, wake detection, or the rest of the UI works. A successful build, serial command, DMA counter, or BLE transaction cannot substitute for the corresponding hardware behavior. A degraded fallback must be labeled as degraded, never accepted as restoration of the original feature set.

On regression, prioritize restoring the original behavior before advancing the next feature stage. Keep the accepted microphone/speaker experiments archived and quiet; never restart continuous sound without an explicit request.

These rules do not add an approval ceremony. Continue already authorized diagnostics, builds, bounded tests, and firmware restoration. Request user input only for genuinely missing information or physical observations/actions that cannot be performed remotely.
