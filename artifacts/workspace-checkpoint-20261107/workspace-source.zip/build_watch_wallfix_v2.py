"""2026-10-18 local wall reinforcement, preserving holes and original coordinates."""
from pathlib import Path
import json, shutil
import numpy as np, trimesh, manifold3d as md, pymeshlab as pm, pymeshfix
from inspect_watch_mesh import ROOT,stats
OUT=ROOT/'局部加厚V2_待复核';OUT.mkdir(exist_ok=True)
names=['外壳','底部外壳','上横杆','下横杆','V0.2黄山派-按钮其一','V0.2黄山派-按钮其二']
meshes=[trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{n}_修复.stl') for n in names]
def solid(m):return md.Manifold(md.Mesh64(np.asarray(m.vertices,dtype=np.float64),np.asarray(m.faces,dtype=np.uint64)))
def mesh(s):
 a=s.to_mesh64();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=False)
def box(lo,hi):return md.Manifold.cube(np.asarray(hi)-lo).translate(lo)
orig=[solid(m) for m in meshes];main,back,upper=orig[:3]

# Back: enlarge outer boss radii only, not bore, position, or top seating plane.
centers=[(-46.326612,32.785691),(-15.571870,32.785691),(-42.136924,2.476229),(-19.761558,2.476229)]
back_new=back
for x,y in centers:
 r=(md.Manifold.cylinder(4.75,2.4,circular_segments=128)-md.Manifold.cylinder(4.85,1.6,circular_segments=128).translate([0,0,-.05])).translate([x,y,-3.6088265])
 back_new=back_new+r
# Fill the lower rolled perimeter below the mating plane, preserving the section's openings.
floor_z=-4.0632
floor_section=back.slice(floor_z)
floor=floor_section.extrude(floor_z-meshes[1].bounds[0,2]).translate([0,0,meshes[1].bounds[0,2]])
back_new=back_new+floor

# Upper bar: add 0.60 mm to each flat Z side, preserving ALL voids inside the old envelope.
lo,hi=meshes[2].bounds
old_void=box(lo,hi)-upper
upper_new=(upper+upper.translate([0,0,.6])+upper.translate([0,0,-.6]))-old_void

def patch_extrude(m,mask,vector):
 direction=np.asarray(vector,dtype=float);inset=direction/np.linalg.norm(direction)*.02
 triangles=m.triangles[mask]
 print('PATCH_PRISMS',len(triangles),vector,flush=True)
 prisms=[md.Manifold.hull_points(np.vstack([v-inset,v+direction])) for v in triangles]
 batches=[md.Manifold.batch_boolean(prisms[k:k+200],md.OpType.Add) for k in range(0,len(prisms),200)]
 return md.Manifold.batch_boolean(batches,md.OpType.Add)

m=mesh(main.simplify(.003));c=m.triangles_center;n=m.face_normals
radial=c[:,:2]-[-30.94924,20.70537]
outward=(np.sum(radial*n[:,:2],axis=1)>5)
patches=[]
# Long-slot lips: front/back external surface only; limited to lower band.
for sign in [-1,1]:
 mask=outward&(n[:,1]*sign>.65)&((c[:,1]-20.70537)*sign>17)&(c[:,2]<2)
 patches.append(patch_extrude(m,mask,[0,sign*1.0,0]))
# Thin inner-corner regions above the long slots: reinforce through the outside corner.
for sign in [-1,1]:
 mask=outward&(n[:,0]*sign>.60)&((c[:,0]+30.94924)*sign>16)&((c[:,1]<10)|(c[:,1]>33))&(c[:,2]<9)&(c[:,2]>-.5)
 patches.append(patch_extrude(m,mask,[sign*.6,0,0]))
add=md.Manifold.batch_boolean(patches,md.OpType.Add)
# Exact existing component solids plus small clearances guard the new material.
guard=back_new.minkowski_sum(md.Manifold.cube([.3,.3,.3],center=True))
for part in [upper_new]+orig[3:]:guard=guard+part.minkowski_sum(md.Manifold.cube([.2,.2,.2],center=True))
main_new=main+(add-guard)
new=[main_new,back_new,upper_new]+orig[3:]

report=[]
for i,body in enumerate(new):
 assert body.status()==md.Error.NoError
 if i<3:
  # Test the serialized STL, not only Manifold's in-memory representation.
  for tolerance in [.001,.003,.005,.01]:
   candidate=body.simplify(tolerance)
   dest=OUT/f'{names[i]}_局部加厚V2.stl';dest.write_text(trimesh.exchange.stl.export_stl_ascii(mesh(candidate)),encoding='ascii')
   r=trimesh.load_mesh(dest)
   nominal=r.copy()
   r.vertices=np.round(r.vertices,5);r.merge_vertices()
   rv,rf=pymeshfix.clean_from_arrays(np.asarray(r.vertices,dtype=np.float64),np.asarray(r.faces,dtype=np.int32),verbose=False,joincomp=False,remove_smallest_components=False)
   r=trimesh.Trimesh(rv,rf,process=True)
   r.fix_normals(multibody=True)
   dest.write_text(trimesh.exchange.stl.export_stl_ascii(r),encoding='ascii')
   r=trimesh.load_mesh(dest)
   ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=r.vertices,face_matrix=r.faces));ms.compute_selection_by_self_intersections_per_face()
   intersections=int(ms.current_mesh().face_selection_array().sum());st=stats(r)
   print(names[i],tolerance,st['watertight'],st['nonmanifold_edges'],st['degenerate_faces'],intersections,'euler',r.euler_number,'original',meshes[i].euler_number,flush=True)
   if st['watertight'] and st['winding'] and st['nonmanifold_edges']==st['degenerate_faces']==intersections==0 and len(r.split(only_watertight=False))==1 and r.euler_number==meshes[i].euler_number:
    np.random.seed(18)
    sample,_=trimesh.sample.sample_surface(r,10000)
    distance=trimesh.proximity.closest_point(nominal,sample)[1]
    print('CLEANUP_DEVIATION',names[i],float(distance.max()),flush=True)
    assert distance.max()<.05
    new[i]=solid(r);break
  else: raise RuntimeError('Serialized mesh failed verification: '+names[i])
 else:
  dest=OUT/f'{names[i]}_修复.stl';shutil.copy2(ROOT/'修复版_单件STL'/dest.name,dest);r=trimesh.load_mesh(dest);st=stats(r);tolerance=0;intersections=0
 report.append(dict(name=names[i],file=dest.name,stats=st,simplify_tolerance_mm=tolerance,self_intersections=intersections,delta_volume_mm3=float(r.volume-meshes[i].volume)))

collisions=[]
for i in range(6):
 for j in range(i+1,6):
  a=(orig[i]^orig[j]).volume();b=(new[i]^new[j]).volume()
  collisions.append(dict(a=names[i],b=names[j],before_mm3=a,after_mm3=b))
  print('INTERSECTION',names[i],names[j],a,b,flush=True)
(OUT/'verification.json').write_text(json.dumps(dict(parts=report,collisions=collisions),ensure_ascii=False,indent=2),encoding='utf-8')
print('OUTPUT',OUT,flush=True)
