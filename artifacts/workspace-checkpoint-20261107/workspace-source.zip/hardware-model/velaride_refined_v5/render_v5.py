"""Render verified V5 views and an isolated five-part exploded scene."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_refined_v5')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V5_Engineering_Package')
s=bpy.data.scenes['VelaRide | Refined V5'];bpy.context.window.scene=s;s.frame_set(1)
cam=s.camera
strap=next(c for c in s.collection.children if c.name.startswith('REFINEDV5_03'))
floor=next(o for o in s.objects if o.name.startswith('Watch studio floor'))
original=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale)
s.render.resolution_percentage=85
strap.hide_render=True
s.render.filepath=str(OUT/'REFERENCE/V5_case_only.png');bpy.ops.render.render(write_still=True)
floor.hide_render=True
cam.location=(-65,-90,-105);cam.rotation_euler=(Vector((0,0,-3))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=85
s.render.filepath=str(OUT/'REFERENCE/V5_rear.png');bpy.ops.render.render(write_still=True)
cam.location,cam.rotation_euler,cam.data.ortho_scale=original
floor.hide_render=False;strap.hide_render=False
s.render.filepath=str(OUT/'REFERENCE/V5_hero.png');bpy.ops.render.render(write_still=True)

for old in [sc for sc in bpy.data.scenes if sc.name.startswith('VelaRide | V5 five-part assembly')]:
    for obj in list(old.objects):
        if len(obj.users_scene)==1:bpy.data.objects.remove(obj,do_unlink=True)
    bpy.data.scenes.remove(old)
expl=bpy.data.scenes.new('VelaRide | V5 five-part assembly')
expl.unit_settings.system=s.unit_settings.system;expl.unit_settings.scale_length=.001
expl.world=s.world.copy()
expl.render.engine=s.render.engine
expl.render.resolution_x=1500;expl.render.resolution_y=1400;expl.render.resolution_percentage=100
expl.render.image_settings.file_format=s.render.image_settings.file_format
bpy.context.window.scene=expl
report=json.loads((ROOT/'verification_v5.json').read_text(encoding='utf-8'))
offsets=[(0,0,0),(0,0,25),(0,0,-25),(-25,0,1),(-38,-22,0)]
colors=[(.055,.065,.08,1),(.12,.15,.19,1),(.06,.07,.09,1),(.02,.40,.34,1),(.9,.32,.05,1)]
for i,(part,offset,color) in enumerate(zip(report['parts'],offsets,colors),1):
    bpy.ops.wm.stl_import(filepath=str(OUT/part['file']),use_scene_unit=False,global_scale=1)
    obj=bpy.context.object;obj.name=f'{i:02d} | '+Path(part['file']).stem
    obj.location=Vector(part['assembly_translation_mm'])+Vector(offset)
    mat=bpy.data.materials.new('V5 assembly part '+str(i));mat.use_nodes=True
    node=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
    node.inputs['Base Color'].default_value=color;node.inputs['Roughness'].default_value=.52
    mat.diffuse_color=color;obj.data.materials.append(mat)
    adjacency={}
    for poly in obj.data.polygons:
        poly.use_smooth=True
        for ek in poly.edge_keys:adjacency.setdefault(tuple(sorted(ek)),[]).append(poly.normal.copy())
    for edge in obj.data.edges:
        ns=adjacency.get(tuple(sorted(edge.vertices)),[])
        edge.use_edge_sharp=len(ns)!=2 or ns[0].dot(ns[1])<math.cos(math.radians(30))
    obj.select_set(False)
for light in [o for o in s.objects if o.type=='LIGHT']:
    ob=light.copy();ob.data=light.data.copy();expl.collection.objects.link(ob)
ecam=cam.copy();ecam.data=cam.data.copy();expl.collection.objects.link(ecam);expl.camera=ecam
ecam.location=(-100,-145,115);target=Vector((-12,0,1))
ecam.rotation_euler=(target-ecam.location).to_track_quat('-Z','Y').to_euler();ecam.data.ortho_scale=133
efloor=floor.copy();efloor.data=floor.data.copy();expl.collection.objects.link(efloor);efloor.location.z=-37;efloor.hide_render=False
expl.render.filepath=str(OUT/'REFERENCE/V5_exploded.png');bpy.ops.render.render(write_still=True)
bpy.context.window.scene=s
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        space=area.spaces.active;space.region_3d.view_rotation=cam.rotation_euler.to_quaternion()
        space.region_3d.view_location=(0,0,0);space.region_3d.view_distance=108;space.overlay.show_overlays=False
s.render.filepath=str(OUT/'REFERENCE/V5_hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_refined_v5.blend'))
print('Rendered front, rear, hero, exploded; saved V5 source.')
