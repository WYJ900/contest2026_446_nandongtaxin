"""Generate an isolated V5 build from the dimensioned V4 source."""
from pathlib import Path
import json
import shutil

ROOT = Path(__file__).resolve().parent
V4 = ROOT.parent / 'velaride_wallfix_v4'
source = (V4 / 'build_v4.py').read_text(encoding='utf-8')
for old, new in [
    ('velaride_wallfix_v4', 'velaride_refined_v5'),
    ('VelaRide | Wall corrected V4', 'VelaRide | Refined V5'),
    ('WALLV4_', 'REFINEDV5_'),
    ('V4 PRINT', 'V5 PRINT'),
    ('wallfix_v4_', 'refined_v5_'),
    ('_V4_', '_V5_'),
    ('V4 | satin graphite nylon', 'V5 | satin graphite nylon'),
]:
    source = source.replace(old, new)

start = source.index('def smooth_outer_sections(sections):')
end = source.index('\ndef loft_ring(', start)
source = source[:start] + '''def smooth_outer_sections(sections):
    # One C2 quintic shoulder replaces multiple Hermite spans. Preserve the
    # full band-interface envelope through z=-1, and keep V4 electronics fixed.
    z0, z1 = sections[0][0], sections[-1][0]
    def ease(t):
        return t*t*t*(10+t*(-15+6*t))
    def blend(a,b,t):
        s=ease(max(0,min(1,t)))
        return tuple(x+(y-x)*s for x,y in zip(a,b))
    count=math.ceil((z1-z0)/.12)
    out=[]
    for i in range(count+1):
        z=z0+(z1-z0)*i/count
        if z<z0+1.2:
            dims=blend((W-.3,62.0,R-.25),(W,62.8,R),(z-z0)/1.2)
        elif z<=-1:
            dims=(W,62.8,R)
        else:
            dims=blend((W,62.8,R),(W-.9,H-.9,R-.45),(z+1)/(z1+1))
        out.append((z,*dims))
    return out

def refined_front_sections(top):
    # Continuous convex taper, matching the midcase at the adhesive seam.
    z0,z1=top+.15,top+1.35
    result=[]
    for i in range(17):
        t=i/16;u=t*t*t*(10+t*(-15+6*t))
        result.append((z0+(z1-z0)*t,W-.9-.6*u,H-.9-.6*u,R-.45-.25*u))
    return result
''' + source[end:]

old="[(top-.05,W-.9,H-.9,R-.45),(top+.5,W-.65,H-.65,R-.3),(top+1.35,W-1.5,H-1.5,R-.7)]"
assert old in source
source=source.replace(old,'refined_front_sections(top)')
# The V4 fixed lips trap the integral keycaps during rear insertion. Replace
# them with a separately installed retainer, captured by the removable rear.
old="""    lip=box('Hidden carrier retaining rail',(1.5,3.5,11.8),(-18.55,panel_y+sy*13.75,-.3),graphite,r=.12)
    apply_mods(lip);boolean(body,lip,'UNION')"""
assert old in source
source=source.replace(old,"    # Inward retaining lips are supplied by removable part 05.")
marker='# Purely illustrative deflection, fixed roots remain fixed. Not an FEA result.'
insert="""# Removable fifth part: insert the key carrier laterally before electronics;
# slide this U-shaped retainer from the rear, then capture it with the cover.
retainer=box('V5 PRINT 05 | removable key retainer',(1.5,28.8,1.4),(-18.35,panel_y,-6.4),graphite,r=.10)
apply_mods(retainer)
for side in (-1,1):
    rail=box('Removable retaining finger',(1.5,2.2,11.8),(-18.35,panel_y+side*13.3,-.3),graphite,r=.10)
    apply_mods(rail);boolean(retainer,rail,'UNION')
bevel(retainer,.06,3);apply_mods(retainer)
retainer['installation']='After lateral insertion of key carrier, slide from rear; rear cover captures crossbar.'
retainer['material']='Unfilled PA12; qualification required.'
retainer['minimum_nominal_section_mm']=1.4
cut=box('Retainer crossbar rear-cover seat',(1.9,29.2,1.2),(-18.35,panel_y,-6.7),None,r=.08)
apply_mods(cut);boolean(back,cut)

"""
assert marker in source
source=source.replace(marker,insert+marker)
source=source.replace("for ob in (body,bezel,back,panel):", "for ob in (body,bezel,back,panel,retainer):")
source=source.replace("        if abs(poly.normal.z)<.8:poly.use_smooth=True", "        poly.use_smooth=True\n    adjacency={}\n    for poly in ob.data.polygons:\n        for ek in poly.edge_keys:adjacency.setdefault(tuple(sorted(ek)),[]).append(poly.normal.copy())\n    for ed in ob.data.edges:\n        ns=adjacency.get(tuple(sorted(ed.vertices)),[])\n        ed.use_edge_sharp=len(ns)!=2 or ns[0].dot(ns[1])<math.cos(math.radians(30))")
source=source.replace("mat('V5 | satin graphite nylon',(.055,.065,.08),.15,.42)", "mat('V5 | satin graphite nylon',(.055,.065,.08),.05,.50)")
source=source.replace("(panel,'04_Key_carrier_V5_NYLON_Q1_mm.stl')]", "(panel,'04_Key_carrier_V5_NYLON_Q1_mm.stl'),(retainer,'05_Key_retainer_V5_PA12_Q1_mm.stl')]")
source=source.replace('Four main printed parts.', 'Five main printed parts; removable internal key retainer.')
source=source.replace('installed from rear, captured by internal rails and rear cover.', 'installed laterally from inside before electronics, captured by removable retainer and rear cover.')
source=source.replace("'Prototype: front frame bonded to midcase. Raised lip captures glass black edge; gasket to tune after measurement.'", "'Front frame requires qualified adhesive bonding; nominal bond gap 0.15 mm. No validated retention rating. Raised lip captures glass black edge; measure actual glass before production.'")
source=source.replace("scene.unit_settings.length_unit='MILLIMETERS'", "scene.unit_settings.length_unit=bpy.data.scenes['VelaRide | Wall corrected V4'].unit_settings.length_unit")
source=source.replace("note=bpy.data.texts.new('EASYPRINT_V2_NOTES.txt')", "note=bpy.data.texts.new('V5_MANUFACTURING_NOTES.txt')")
source=source.replace("b'VelaRide prototype; units mm; fit NOT verified'", "b'VelaRide V5 engineering sample; mm; physical fit not validated'")
source=source.replace("body['prototype_only']=True", "body['prototype_only']=True;body['revision']='V5';body['surface']='C2 quintic outer shoulders; functional interfaces retained'")
source=source.replace("scene.render.resolution_x=1600;scene.render.resolution_y=1500", "scene.render.resolution_x=1600;scene.render.resolution_y=1500")
(ROOT/'build_v5.py').write_text(source,encoding='utf-8')
p=json.loads((V4/'case_parameters.json').read_text(encoding='utf-8'))
boards=json.loads((ROOT.parent/'huangshan_pi/hardware_parameters.json').read_text(encoding='utf-8'))
core_t=next(b['thickness'] for b in boards if b['name']=='core_pcb')
display_t=next(b['thickness'] for b in boards if b['name']=='display_pcb')
p.update(design_revision='Refined V5 engineering sample',
         board_to_board_clear_gap_mm=5.0,
         board_gap_source='User confirmed main-board to display-board spacing is 0.5 cm; modeled as opposing PCB surface clearance, stated to user.',
         display_pcb_center_z_mm=core_t/2+5.0+display_t/2,
         display_spacing_status='5 mm facing-surface gap; PCB thicknesses from supplied EDA stackups',
         print_part_count=5,removable_key_retainer=True,
         retainer_carrier_clearance_nominal_mm=.2,
         outer_axial_max_step_mm=.12,front_bond_gap_nominal_mm=.15,
         physical_fit_verified=False,production_release=False,
         rear_seam_radial_step_nominal_mm=0,
         outer_shoulder_interpolation='C2 quintic, single upper transition',
         manufacturing_process='Nylon additive manufacturing; supplier process and grade pending confirmation')
(ROOT/'case_parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(V4/'apple_profile.json',ROOT/'apple_profile.json')
print('Generated V5 build and parameters:',ROOT)
