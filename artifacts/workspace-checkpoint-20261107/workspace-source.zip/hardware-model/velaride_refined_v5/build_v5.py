"""VelaRide enclosure concept with dimensional 22 mm quick-release interfaces.
Requires the source Huangshan .blend. Saves a NEW file; original is preserved.
Screen-board spacing remains an estimate. Do not infer production fit from renders.
"""
import bpy, bmesh, math, json, ast, sys, struct
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_refined_v5')
SRC=ROOT.parent/'huangshan_pi'
P=json.loads((ROOT/'case_parameters.json').read_text(encoding='utf8'))
sys.path.insert(0,str(SRC))
from extract_hardware import path_points
# Reuse only geometry helper definitions; do not run the source scene builder.
helper_source=(SRC/'build_blender.py').read_text(encoding='utf8')
helper_source=helper_source.replace('mod.segments=segments','mod.segments=max(8,segments)')
helper_source=helper_source.replace('j*90/16','j*90/96').replace('range(17)','range(97)')
helper_source=helper_source.replace('def cylinder(name,r,depth,loc,material,parent=None,n=40):','def cylinder(name,r,depth,loc,material,parent=None,n=160):\n    n=max(n,160) if n>=24 else n')
tree=ast.parse(helper_source)
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'geometry_helpers','exec'))

scene_name='VelaRide | Refined V5'
existing=bpy.data.scenes.get(scene_name)
if existing:
    for c in list(existing.collection.children):
        if c.name.startswith('REFINEDV5_'):
            for o in list(c.all_objects):bpy.data.objects.remove(o,do_unlink=True)
            bpy.data.collections.remove(c)
    bpy.data.scenes.remove(existing)
scene=bpy.data.scenes.new(scene_name)
bpy.context.window.scene=scene
enum(scene.unit_settings,'system','METRIC');scene.unit_settings.scale_length=.001
scene.unit_settings.length_unit=bpy.data.scenes['VelaRide | Wall corrected V4'].unit_settings.length_unit
col=bpy.data.collections.new('REFINEDV5_01_Enclosure');scene.collection.children.link(col)
hardwarecol=bpy.data.collections.new('REFINEDV5_02_Existing_hardware');scene.collection.children.link(hardwarecol)
strapcol=bpy.data.collections.new('REFINEDV5_03_Purchased_strap_preview');scene.collection.children.link(strapcol)
studiocol=bpy.data.collections.new('REFINEDV5_04_Studio');scene.collection.children.link(studiocol)

graphite=mat('V5 | satin graphite nylon',(.055,.065,.08),.05,.50)
edge=mat('Watch | polished chamfer',(.31,.35,.4),.92,.18)
rubber=mat('Watch | black FKM',(.009,.014,.019),0,.49)
rear_mat=mat('Watch | rear engineering polymer',(.019,.027,.038),.07,.4)
steel=mat('Watch | hardware steel',(.52,.57,.63),.9,.23)
brass=mat('Watch | brass standoffs',(.64,.40,.1),.82,.28)
markmat=mat('Watch | laser markings',(.37,.44,.50),.4,.5)
accent=mat('Watch | subtle teal accent',(.015,.31,.29),.7,.27)
black=mat('Watch | gasket',(.005,.008,.012),0,.65)

def clone_hardware(rootname,newname,z=0,flip=False):
    source=bpy.data.objects[rootname]
    mapping={}
    for orig in [source]+list(source.children_recursive):
        obj=orig.copy()
        if orig.data:obj.data=orig.data.copy()
        obj.animation_data_clear();hardwarecol.objects.link(obj);obj.name='WatchHW | '+orig.name
        mapping[orig]=obj
    for orig,obj in mapping.items():
        obj.parent=mapping.get(orig.parent)
    rt=mapping[source];rt.name=newname;rt.location=(0,0,z);rt.rotation_euler=(0,math.pi if flip else 0,0)
    rt['assembly_orientation_note']='Main header faces rear; inferred from user standoffs higher than header.'
    return rt,mapping

core,coremap=clone_hardware('CORE_PCB | official XY','Watch hardware | main board',0,True)
display,displaymap=clone_hardware('DISPLAY_PCB | official XY','Watch hardware | screen',P['display_pcb_center_z_mm'])
# Correct the source preview USB body's generic height override.
for orig,o in coremap.items():
    if orig.name.startswith('core_pcb USB1'):
        o.scale.z=4;o.location.z=P['usb_z_mm'];o['body_height_is_estimate']=True
    elif orig.name=='USB-C polymer tongue':o.location.z=P['usb_z_mm']

def rr(w,h,r,n=96):
    pts=[]
    for x,y,a in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
        pts.extend((x+r*math.cos(math.radians(a+j*90/n)),y+r*math.sin(math.radians(a+j*90/n))) for j in range(n+1))
    return pts

def ring(name,outer,inner,z0,z1,material):
    a=rr(*outer);b=rr(*inner);n=len(a)
    v=[(x,y,z) for z,pts in [(z0,a),(z1,a),(z0,b),(z1,b)] for x,y in pts]
    f=[]
    for i in range(n):
        j=(i+1)%n
        f.extend([(i,j,j+n,i+n),(2*n+j,2*n+i,3*n+i,3*n+j),(n+i,n+j,3*n+j,3*n+i),(j,i,2*n+i,2*n+j)])
    return mesh(name,v,f,material)


def smooth_outer_sections(sections):
    # One C2 quintic shoulder replaces multiple Hermite spans. Preserve the
    # full band-interface envelope through z=-1, and keep V4 electronics fixed.
    z0, z1 = sections[0][0], sections[-1][0]
    def ease(t):
        return t*t*t*(10+t*(-15+6*t))
    def blend(a,b,t):
        s=ease(max(0,min(1,t)))
        return tuple(x+(y-x)*s for x,y in zip(a,b))
    count=math.ceil((z1-z0)/.12)
    out=[]
    for i in range(count+1):
        z=z0+(z1-z0)*i/count
        if z<z0+1.2:
            dims=blend((W-.3,62.0,R-.25),(W,62.8,R),(z-z0)/1.2)
        elif z<=-1:
            dims=(W,62.8,R)
        else:
            dims=blend((W,62.8,R),(W-.9,H-.9,R-.45),(z+1)/(z1+1))
        out.append((z,*dims))
    return out

def refined_front_sections(top):
    # Continuous convex taper, matching the midcase at the adhesive seam.
    z0,z1=top+.15,top+1.35
    result=[]
    for i in range(17):
        t=i/16;u=t*t*t*(10+t*(-15+6*t))
        result.append((z0+(z1-z0)*t,W-.9-.6*u,H-.9-.6*u,R-.45-.25*u))
    return result

def loft_ring(name,sections,inside,material):
    if 'main body' in name:sections=smooth_outer_sections(sections)
    n=len(rr(*inside));k=len(sections)
    v=[(x,y,z) for z,w,h,r in sections for x,y in rr(w,h,r)]
    v.extend((x,y,z) for z in [sections[0][0],sections[-1][0]] for x,y in rr(*inside))
    f=[]
    for q in range(k-1):
        for i in range(n):j=(i+1)%n;f.append((q*n+i,q*n+j,(q+1)*n+j,(q+1)*n+i))
    for i in range(n):
        j=(i+1)%n;lo=k*n;hi=(k+1)*n;top=(k-1)*n
        f.extend([(lo+j,lo+i,hi+i,hi+j),(j,i,lo+i,lo+j),(top+i,top+j,hi+j,hi+i)])
    return mesh(name,v,f,material)

def boolean(obj,tool,op='DIFFERENCE'):
    bpy.context.view_layer.update();bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new('Manufactured geometry','BOOLEAN');enum(mod,'operation',op);mod.object=tool
    bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(tool,do_unlink=True)

def cyl_x(name,r,length,xyz,m=None,n=48):
    o=cylinder(name,r,length,xyz,m,n=n);o.rotation_euler.y=math.pi/2;return o

def apply_mods(o):
    bpy.context.view_layer.objects.active=o
    for mod in list(o.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)

def pin_slot(name,w,h,depth,xyz,axis='Z',material=None,r=None):
    o=rounded(name,w,h,depth,r or min(w,h)/2-.01,0,material,None)
    if axis=='X':o.rotation_euler.y=math.pi/2
    o.location=xyz
    return o

L=P['copper_standoff_length_mm'];boardhalf=.5705856
backtop=-boardhalf-L-.15;backbottom=backtop-2.4
bottom=backtop+.1;top=P['display_pcb_center_z_mm']+.83
W,H,R=P['case_width_mm'],P['case_length_mm'],P['case_corner_radius_mm']
inside=(P['cavity_width_mm'],P['cavity_length_mm'],P['cavity_corner_radius_mm'])
body=loft_ring('CASE | main body with Apple slide rails',[(bottom,W-1,61.4,R-.5),(bottom+.75,W,62.8,R),(-1.0,W,62.8,R),(2.0,W,55.0,R),(top,W-1,H-1,R-.5)],inside,graphite)
body['part']='Main enclosure';body['prototype_only']=True;body['revision']='V5';body['surface']='C2 quintic outer shoulders; functional interfaces retained'



AP=json.loads((ROOT/'apple_profile.json').read_text(encoding='utf8'))
NOMINAL=AP['profile_nominal'];track_y=23.5;track_z=-3.0;latch_y=25.515
def profile_prism(name,points,span,sy,material=None):
    n=len(points);v=[(x,sy*(track_y+u),track_z+z) for x in (-span/2,span/2) for u,z in points]
    f=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name,v,f,material);bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free();return o
def cut_track(target,sy,clearance):
    boolean(target,profile_prism('Profile tool',AP['profile_clearance_'+str(clearance)],54,sy))
    boolean(target,box('Band neck exit',(54,7,2.75),(0,sy*29.3,track_z),None,r=0))
    pocket=rounded('Latch pocket',5.55,2.3,1.3,1.1,-4.94,None,None);pocket.location.y=sy*latch_y;apply_mods(pocket);boolean(target,pocket)
    boolean(target,box('Release stem roomy guide',(5.4,2.8,6),(0,sy*latch_y,-6.9),None,r=0))
    # Recess above the integrated rear flexures, so the return arms can rise.
    boolean(target,box('Release arm movement recess',(27,5.2,2.1),(0,sy*latch_y,-7.0),None,r=0))
for sy in (-1,1):
    wall=box('Release chamber isolation rib',(28,1.3,1.2),(0,sy*21.85,-6.05),graphite,r=0)
    boolean(body,wall,'UNION')
    cut_track(body,sy,P['slide_radial_clearance_mm'])
body['interface_note']='Apple large profile unchanged in scale. Test actual purchased band; large general clearances do not apply to band lock.'

# Main-board component face points down: USB on +X, buttons on -X.



buttonz=-1.670586;usby=P['usb_y_mm'];usbz=-P['usb_z_mm']
key_y=(P['button_1_y_mm'],P['button_2_y_mm']);panel_y=sum(key_y)/2
# Rear-access pocket hides the complete large button carrier behind the shell.
pocket=pin_slot('Concealed carrier pocket',17.0,29.6,4.4,(-19.9,panel_y,.8),'X',None,r=1.2)
apply_mods(pocket);boolean(body,pocket)
for i,yy in enumerate(key_y):
    if i==0:tool=cyl_x('Round key opening',3.4,9,(-22,yy,buttonz+.5),None,160)
    else:tool=pin_slot('Pill key opening',4.8,7.6,9,(-22,yy,buttonz+.5),'X',None,r=2.0)
    apply_mods(tool);boolean(body,tool)
# Internal rails hold the carrier. Rear cover captures its bottom edge.
for sy in (-1,1):
    rail=box('Hidden carrier rail root',(2.8,1.8,11.8),(-19.4,panel_y+sy*15.5,-.3),graphite,r=0)
    boolean(body,rail,'UNION')
    # Inward retaining lips are supplied by removable part 05.

usbcut=pin_slot('USB access opening',4.5,10.2,12,(W/2,usby,usbz),'X',r=1.0)
boolean(body,usbcut)
bevel(body,.11,3)

# Front frame, matching the existing glass instead of replacing the screen.
window=(P['screen_window_width_mm'],P['screen_window_length_mm'],P['screen_window_corner_radius_mm'])
bezel=loft_ring('CASE | front bezel',refined_front_sections(top),window,graphite)
# Raised capture lip overlaps only the existing glass's black perimeter, above
# its surface, so the front retains the stack when the rear screws are tightened.
lip=ring('Front glass retaining lip',(W-1.5,H-1.5,R-.7),(34.5,40.9,7.65),top+1.25,top+2.45,graphite)
boolean(bezel,lip,'UNION')
bevel(bezel,.12,3)
trim=ring('CASE | polished front edge',(W-.7,H-.7,R-.35),(W-1.25,H-1.25,R-.62),top+.22,top+.38,edge)
bevel(trim,.04,2)
seal=ring('CASE | screen gasket',(36.05,42.45,8.4),(35.18,41.58,8.0),top+.25,top+.75,black)
seal['note']='Illustrative gasket. No water-resistance rating or seal validation.'

back=rounded('CASE | removable rear cover',W-.3,62.0,backtop-backbottom,R-.25,(backtop+backbottom)/2,rear_mat,None)
apply_mods(back)
rim=ring('CASE | rear seam gasket',(W-1.1,H-1.1,R-.6),(W-2,H-2,R-1.05),backtop-.03,backtop+.16,black)
mounts=[]
params=json.loads((SRC/'hardware_parameters.json').read_text(encoding='utf8'))
for c in next(b for b in params if b['name']=='core_pcb')['components']:
    if c['ref'] not in ('M1','M2','M3','M4'):continue
    x,y=-c['x'],c['y'];mounts.append((x,y))
    boolean(back,cylinder('Rear M2 clearance bore',1.1,4,(x,y,(backtop+backbottom)/2),None))
    boolean(back,cylinder('Rear screw head seat',1.9,.8,(x,y,backbottom+.32),None))
    st=cylinder('HARDWARE | '+c['ref']+' 6 mm brass standoff',P['copper_standoff_across_flats_mm']/math.sqrt(3),L,(x,y,-boardhalf-L/2),brass,n=6)
    boolean(st,cylinder('M2 thread envelope',.85,L+1,(x,y,-boardhalf-L/2),None))
    bevel(st,.08,2);st['nominal_body_length_mm']=L;st['thread']='M2 placeholder; actual screw size to verify'
    screw=cylinder('HARDWARE | rear M2 screw',1.65,.55,(x,y,backbottom+.30),steel,n=40)
    for ang in (0,math.pi/2):
        tool=box('Screw cross recess',(2.1,.4,.3),(x,y,backbottom+.09),None,r=0);tool.rotation_euler.z=ang;boolean(screw,tool)
    cylinder('HARDWARE | M2 screw shank',.9,2.4,(x,y,backbottom+1.6),steel,n=32)
bevel(back,.08,3)




for orig,o in list(coremap.items()):
    if orig.name in ('SW1 actuator','SW2 actuator'):bpy.data.objects.remove(o,do_unlink=True)
    elif orig.name.startswith(('core_pcb SW1 |','core_pcb SW2 |')):
        o.location.x-=.3;o.location.z=1.670586;o.scale.y=2/2.6;o.scale.z=2.2/2.6
panel=box('V5 PRINT 04 | concealed dual-key carrier',(2.0,28,12),(-20.3,panel_y,0),graphite,r=.35);apply_mods(panel)
for idx,yy in enumerate(key_y,1):
    boolean(panel,box('Hidden flexure window',(8,7.7,8.6),(-21.5,yy,-.30),None,r=0))
    leaf=box('Concealed nylon key leaf',(1.2,4.2,9.6),(-20.5,yy,1.0),graphite,r=.08)
    apply_mods(leaf);boolean(panel,leaf,'UNION')
    if idx==1:cap=cyl_x('Integral rounded key',2.8,4.7,(-22.85,yy,buttonz+.5),graphite,160)
    else:cap=pin_slot('Integral pill key',3.6,6.4,4.7,(-22.85,yy,buttonz+.5),'X',graphite,r=1.6)
    apply_mods(cap);boolean(panel,cap,'UNION')
    boss=box('Concealed contact boss',(1.35,3.8,3.0),(-19.925,yy,buttonz),graphite,r=.18)
    apply_mods(boss);boolean(panel,boss,'UNION')
    pad=box('PURCHASED | cut silicone contact pad '+str(idx),(.8,3.2,2.6),(-18.85,yy,buttonz),rubber,r=.12)
    pad['note']='Cut stock sheet; tune rest gap with 0.5/0.8/1.0 mm sheet thickness.'
    saved=col;col=hardwarecol
    cyl_x('V3 hardware | switch actuator '+str(idx),1.05,.6,(-17.79518,yy,buttonz),black,48)
    col=saved
# Invisible compression pads seat the large carrier against the internal rails.
for sy in (-1,1):
    pad=box('PURCHASED | carrier anti-rattle foam',(.8,3,8),(-21.7,panel_y+sy*11.7,0),rubber,r=.15)
    pad['note']='Adhesive-backed soft foam; select thickness to remove play, not a printed part.'
    box('PURCHASED | carrier bottom locating pad',(1.6,3,.7),(-20.3,panel_y+sy*11.7,-6.37),rubber,r=.1)
bevel(panel,.07,2)
panel['construction']='Single large PA12/PA11 carrier with two integral buttons; installed laterally from inside before electronics, captured by removable retainer and rear cover.'
panel['external_screws']=False
panel['material']='PA12/PA11; not generic brittle resin. Return and fatigue require prototype testing.'
panel['guide_clearance_per_side_mm']=.6
panel['flexure_thickness_mm']=1.2
panel['nominal_button_protrusion_mm']=.7
panel['pad_adjustment']='Use stock silicone contact pads and anti-rattle foam. Do not print microscopic soft tips.'
# Release buttons become part of the large rear cover. Side slots keep them free
# while two long nylon arms guide and return each pad.
apply_mods(back)
for sy in (-1,1):
    yy=sy*latch_y
    boolean(back,box('Rear release open window',(24,6.0,6),(0,yy,-8.0),None,r=0))
    paddle=box('Integral release paddle',(8.8,4.2,2.0),(0,yy,-8.1),rear_mat,r=.3);apply_mods(paddle)
    for sx in (-1,1):
        arm=box('Release nylon return arm',(9.0,2.2,1.2),(sx*8.3,yy,-7.65),rear_mat,r=.1);apply_mods(arm);boolean(paddle,arm,'UNION')
    stem=box('Large printable release stem',(4.0,1.4,2.0),(0,yy,-6.15),rear_mat,r=.12);apply_mods(stem);boolean(paddle,stem,'UNION')
    boolean(back,paddle,'UNION')
bevel(back,.06,2)
back.name='V5 PRINT 03 | rear cover with release paddles'
back['integrated_release_flexure_thickness_mm']=1.2
back['release_paddle_mm']=[8.8,4.2,2.0]
back['release_stem_clearance_mm']=[.7,.7]
back['release_stroke_estimate_mm']=.7
back['material']='PA12/PA11 nylon; fatigue, band lock and return not physically validated.'

# Removable fifth part: insert the key carrier laterally before electronics;
# slide this U-shaped retainer from the rear, then capture it with the cover.
retainer=box('V5 PRINT 05 | removable key retainer',(1.5,28.8,1.4),(-18.35,panel_y,-6.4),graphite,r=.10)
apply_mods(retainer)
for side in (-1,1):
    rail=box('Removable retaining finger',(1.5,2.2,11.8),(-18.35,panel_y+side*13.3,-.3),graphite,r=.10)
    apply_mods(rail);boolean(retainer,rail,'UNION')
bevel(retainer,.06,3);apply_mods(retainer)
retainer['installation']='After lateral insertion of key carrier, slide from rear; rear cover captures crossbar.'
retainer['material']='Unfilled PA12; qualification required.'
retainer['minimum_nominal_section_mm']=1.4
cut=box('Retainer crossbar rear-cover seat',(1.9,29.2,1.2),(-18.35,panel_y,-6.7),None,r=.08)
apply_mods(cut);boolean(back,cut)

# Purely illustrative deflection, fixed roots remain fixed. Not an FEA result.
apply_mods(panel);apply_mods(back)

panel.shape_key_add(name='Rest')
for idx,yy in enumerate(key_y,1):
    k=panel.shape_key_add(name='Key '+str(idx)+' demonstration')
    for i,v in enumerate(panel.data.vertices):
        p=panel.matrix_world@v.co
        leaf=abs(p.y-yy)<2.15 and -4.9<p.z<4.0 and -21.2<p.x<-19.8
        cap=abs(p.y-yy)<3.25 and p.x<-20.3 and abs(p.z-buttonz)<3.7
        boss=abs(p.y-yy)<2.0 and -20.7<p.x<-19.1 and abs(p.z-buttonz)<1.6
        if leaf or cap or boss:
            w=min(1,max(0,(4.0-p.z)/(4.0-buttonz)))**2 if leaf else 1
            k.data[i].co.x+=.5*w
    for fr,val in [(1,0),(10 if idx==1 else 55,0),(20 if idx==1 else 65,1),(35 if idx==1 else 80,0),(100,0)]:
        k.value=val;k.keyframe_insert(data_path='value',frame=fr)
back.shape_key_add(name='Rest')
for sy in (-1,1):
    k=back.shape_key_add(name='Release '+str(sy)+' demonstration')
    for i,v in enumerate(back.data.vertices):
        p=back.matrix_world@v.co
        if abs(p.y-sy*latch_y)<2.5 and abs(p.x)<12.4:
            weight=1 if abs(p.x)<4.4 else max(0,1-(abs(p.x)-4.4)/8.0)**2
            k.data[i].co.z+=.7*weight
    k.value=0

# The brass standoffs are retained by the rear screws. Removable front bezel uses
# bonded/clip design allowance, not unverified detailed snap geometry.
bezel['attachment_note']='Front frame requires qualified adhesive bonding; nominal bond gap 0.15 mm. No validated retention rating. Raised lip captures glass black edge; measure actual glass before production.'
back['attachment_note']='Four M2 placeholder screws into underside brass pillars; verify actual threads.'
body['assembly_height_mm']=top+2.45-backbottom


# Preview of purchased large-family Apple-style band heads; no fabricated
# replacement male interface needs to be purchased or fitted to the user's band.
col=strapcol
bandheads=[]
for sy in (-1,1):
    head=profile_prism('PURCHASED PREVIEW | large Apple slide head '+str(sy),NOMINAL,34.92,sy,steel)
    bevel(head,.045,2);bandheads.append(head)
    latch=rounded('PURCHASED PREVIEW | spring latch '+str(sy),5.21,1.93,.38,.94,-4.73,steel,None);latch.location.y=sy*latch_y
    latch['source']='Apple ADG: spring latch 5.21 x 1.93; 0.38 +/-0.13 protrusion'
    # Full preview bands; connector neck passes through the profile opening.
    neck=box('PURCHASED PREVIEW | neck '+str(sy),(24,4,2.5),(0,sy*29.2,track_z),rubber,r=.5)
    length=78 if sy>0 else 123
    verts=[];segments=70
    for i in range(segments+1):
        t=length*i/segments;half=12-.7*t/length
        if t>length-9:half=2+(half-2)*math.sqrt(max(0,1-((t-length+9)/9)**2))
        yy=sy*(30+t);zz=track_z-.3-.8*t/length
        verts.extend([(-half,yy,zz-1.55),(half,yy,zz-1.55),(-half,yy,zz+1.55),(half,yy,zz+1.55)])
    faces=[(0,2,3,1)]
    for i in range(segments):
        a=i*4;b=a+4;faces.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
    faces.append((4*segments,4*segments+1,4*segments+3,4*segments+2))
    band=mesh('PURCHASED PREVIEW | Apple sport band '+str(sy),verts,faces,rubber)
    if sy<0:
        for dy in range(62,145,8):boolean(band,cylinder('Purchased strap hole',1.9,7,(0,-dy,track_z),None,n=32))
    else:
        cylinder('PURCHASED PREVIEW | strap pin',2.2,.9,(0,89,track_z+1.6),steel,n=40)
    bevel(band,.24,3)
    head['compatibility']='Large family, 44/45/46/49 mm; old 42 mm. Not new small 42 mm.'


col=bpy.data.collections.new('REFINEDV5_05_Interface_test_coupons');scene.collection.children.link(col)
coupons=[]
for clearance in (.10,.16,.22):
    q=box('FIT TEST | Apple slide clearance '+str(clearance),(40,8.2,7.7),(0,25.5,-2.95),graphite,r=.5);apply_mods(q)
    cut_track(q,1,clearance);bevel(q,.08,2);q['radial_clearance_mm']=clearance;coupons.append(q)
col.hide_render=True;col.hide_viewport=True

# Studio hero: tight product crop, purchased bands intentionally extend beyond it.
col=studiocol
floor_mat=mat('Watch | studio floor',(.10,.13,.17),.08,.52)
floor=box('Watch studio floor',(1800,1800,.6),(0,0,backbottom-1),floor_mat,r=0)
camdata=bpy.data.cameras.new('Watch hero camera');cam=bpy.data.objects.new('Watch hero camera',camdata);col.objects.link(cam)
cam.location=(-74,-108,126);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();enum(camdata,'type','ORTHO');camdata.ortho_scale=98;camdata.clip_end=3000
scene.camera=cam
for name,loc,energy,size in [('Key',(-45,-45,100),160000,70),('Edge',(65,25,85),230000,55),('Soft fill',(-60,70,45),125000,80)]:
    ld=bpy.data.lights.new('Watch '+name,'AREA');ld.energy=energy;ld.size=size
    ob=bpy.data.objects.new('Watch '+name,ld);col.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
world=bpy.data.worlds.new('Watch studio');scene.world=world;world.use_nodes=True
bg=next(n for n in world.node_tree.nodes if n.type=='BACKGROUND');bg.inputs['Color'].default_value=(.16,.19,.23,1);bg.inputs['Strength'].default_value=.45
scene.render.resolution_x=1600;scene.render.resolution_y=1500;scene.render.resolution_percentage=100
enum(scene.render.image_settings,'file_format','PNG');scene.render.filepath=str(ROOT/'refined_v5_hero.png')
scene.frame_start=1;scene.frame_end=100;scene.frame_set(1)
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            sp=a.spaces.active;sp.region_3d.view_distance=95;sp.region_3d.view_location=(0,0,1);sp.region_3d.view_rotation=cam.rotation_euler.to_quaternion();sp.clip_end=5000
            enum(sp.shading,'type','MATERIAL');sp.overlay.show_floor=False

# Export only dimensional enclosure parts and coupon; retain mm units in STL.
def export_stl(obj,path):
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();me.calc_loop_triangles()
    with open(path,'wb') as f:
        f.write(b'VelaRide V5 engineering sample; mm; physical fit not validated'.ljust(80,b' '));f.write(struct.pack('<I',len(me.loop_triangles)))
        for tri in me.loop_triangles:
            vv=[obj.matrix_world@me.vertices[i].co for i in tri.vertices];normal=(vv[1]-vv[0]).cross(vv[2]-vv[0]).normalized()
            f.write(struct.pack('<12fH',*normal,*vv[0],*vv[1],*vv[2],0))
    ev.to_mesh_clear()

for ob in (body,bezel,back,panel,retainer):
    for poly in ob.data.polygons:
        poly.use_smooth=True
    adjacency={}
    for poly in ob.data.polygons:
        for ek in poly.edge_keys:adjacency.setdefault(tuple(sorted(ek)),[]).append(poly.normal.copy())
    for ed in ob.data.edges:
        ns=adjacency.get(tuple(sorted(ed.vertices)),[])
        ed.use_edge_sharp=len(ns)!=2 or ns[0].dot(ns[1])<math.cos(math.radians(30))
validation={'parameters':P,'body_height_including_glass_mm':round(top+2.45-backbottom,3),'parts':[],'fit_verified':False}
export_parts=[(body,'01_Main_case_V5_PA12_Q1_mm.stl'),(bezel,'02_Front_frame_V5_PA12_Q1_mm.stl'),(back,'03_Rear_cover_V5_NYLON_Q1_mm.stl'),(panel,'04_Key_carrier_V5_NYLON_Q1_mm.stl'),(retainer,'05_Key_retainer_V5_PA12_Q1_mm.stl')]
for ob in (trim,seal,rim):ob.hide_render=True;ob.hide_set(True)
for o,filename in export_parts:
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();bm=bmesh.new();bm.from_mesh(me)
    item={'name':o.name,'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'stl':filename}
    bm.free();ev.to_mesh_clear();validation['parts'].append(item)
    export_stl(o,ROOT/filename)
(ROOT/'case_verification.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
note=bpy.data.texts.new('V5_MANUFACTURING_NOTES.txt');note.write('Five main printed parts; removable internal key retainer. Larger PA12/PA11 nylon flexures; no tiny sliding pistons or 0.28 mm stops. Use cut stock silicone pads to tune key contact. Band interface still requires a real-band test. Animation is illustrative, not fatigue or force validation. Purchased bands, screws, nuts and pads are not exported. See README.txt.')
bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_refined_v5.blend'))
print(json.dumps(validation))
