"""Package the checked files without implying production qualification."""
from pathlib import Path
import json, shutil, hashlib, zipfile, html

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_refined_v5')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V5_Engineering_Package')
report=json.loads((ROOT/'verification_v5.json').read_text(encoding='utf-8'))
params=json.loads((ROOT/'case_parameters.json').read_text(encoding='utf-8'))
labels=['主壳','屏幕前框','后盖及表带释放机构','内藏双按键板','可拆内压架']
materials=['未填充 PA12','未填充 PA12','未填充韧性 PA11 优先，PA12 替代须先试验','未填充韧性 PA11 优先，PA12 替代须先试验','未填充 PA12']
for p,name,material in zip(report['parts'],labels,materials):
    p.update(name_zh=name,quantity=1,material_request=material)
    path=OUT/p['file']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==p['sha256']
    assert p['sampled_under_1mm']==0 and p['serialized_bad_edges']==0 and p['serialized_zero_area_faces']==0 and p['nonadjacent_self_overlap_candidates']==0
    shutil.copy2(path,ROOT/path.name)
assert not any(report['surface_intersections'].values())
assert not any(report['carrier_installation_stage_1_rear_entry_x_plus_6mm'].values())
assert not any(report['carrier_installation_stage_2_lateral_seating'].values())
assert not any(any(v.values()) for v in report['retainer_installation_from_rear'].values())
assert not report['hardware_body_surface_intersections'] and not report['hardware_retainer_surface_intersections']
(OUT/'REFERENCE/self_overlap_check.json').write_text(json.dumps([{'file':Path(p['file']).name,'sha256':p['sha256'],'nonadjacent_triangle_overlap_candidates':p['nonadjacent_self_overlap_candidates']} for p in report['parts']],indent=2),encoding='utf-8')
(OUT/'02_零件清单与检查结果.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'SOURCE').mkdir(exist_ok=True)
shutil.copy2(ROOT/'velaride_refined_v5.blend',OUT/'SOURCE/velaride_refined_v5.blend')
shutil.copy2(ROOT/'case_parameters.json',OUT/'SOURCE/case_parameters.json')
shutil.copy2(ROOT.parent/'../exports/VelaRide_V4_Thickness_Review/REFERENCE/V4_case_only.png',OUT/'REFERENCE/V4_case_only_comparison.png')

readme='''VelaRide V5 — 五件尼龙工程样机包
日期：2026-10-11。单位：毫米。每件 1 个，共 5 件。
状态：用于厂家可制造性复检与工程样机试装；尚未完成实物装配、寿命和产品定型。

本包整体替代 V4 外壳方案，不要混用 V4 后盖或省略 05 内压架。
只打印 STL_5_PARTS 中的五个文件。SOURCE 是可编辑模型；REFERENCE 是展示和检查证据。
表带、玻璃、电子板、螺丝、铜柱、硅胶垫、胶粘剂均不属于打印件。

V5 实际修改
1. 主壳肩部使用单段 C2 五次过渡，消除多段截面形成的高光波纹；主尺寸仍为 49×62.8 mm。
2. 主壳下缘与后盖外轮廓对齐；前框改为连续收口，前框名义粘接间隙 0.15 mm。
3. 修正按面朝向突然切换平滑/平面的显示方式，保留锐边的同时连续显示曲面。
4. 发现旧四件结构的按键板直线后装路径会受阻。改为独立 05 内压架，按键板先进入内腔再横向就位。
5. 后盖增加内压架横梁定位槽；压架与按键板名义间隙 0.2 mm，槽侧边与槽底留约 0.2 mm。
6. 清理最多 0.002 mm 范围的布尔/倒角数值碎面，复查实际导出的 STL。

数字检查结果
五件均为单一连通封闭网格；无非流形边、零面积面；非相邻三角面自相交候选为零。
实际 STL 的壁厚射线抽检：01—04 约 1.20 mm，05 约 1.40 mm；未采到小于 1 mm 的区域。
五件在静止位置的表面相交计数均为零；已有电子件模型未与主壳、内压架表面相交。
按键 12 个动画姿态、释放机构 5 个姿态通过表面避让抽检。动画仅演示位移，不是力学/疲劳分析。
按键板入腔 49 个位置、横向就位 25 个位置、内压架后装 41 个位置通过抽样表面避让检查。
这些结果不是连续碰撞证明、完整公差分析、全表面最小壁厚保证或生产合格证明。

必须继续确认的实物项目
屏幕模块整体厚度及玻璃边框；电池、线束及连接器空间；铜柱和螺钉实际螺纹。
用户已确认两块板间距为 5 mm，模型按相向 PCB 板面净距建模；使用 EDA 板厚计算屏幕板中心 Z=6.0705973 mm。
原屏幕板中心为 6 mm，净距只有约 4.9294 mm，本版已作相应修正。铜柱仍沿用 6 mm 长度，螺纹尚待实物确认。
苹果表带须用实际采购件验证滑入、锁止和释放；现有滑槽剖面未整体缩放。
前框仍为粘接固定方案，需选定适用尼龙及表面处理的胶粘剂并验证拉脱与环境老化。
后盖/按键弹性件须验证回弹、手感、疲劳、打印方向和材料批次；防水、跌落、耐汗及皮肤接触性能未验证。
先完成工程样机复测，再据实测修改生产版。
'''
(OUT/'00_先读_V5修改与状态.txt').write_text(readme,encoding='utf-8')

vendor='''你好，这是 VelaRide V5 的 5 件外壳及按键机构模型，请先做工艺复检并报价工程样机。
单位 mm，每件 1 个；只打印 STL_5_PARTS 的 5 件，不含表带、电子件和现成五金。

01 主壳、02 前框、05 内压架：希望采用未填充 PA12，SLS/MJF 由你们说明设备和材料牌号。
03 后盖、04 按键板：局部为反复弯曲的弹性机构，优先评估未填充韧性 PA11；如使用 PA12 请提供牌号并先试件验证。
不要直接改为普通人偶树脂、金属、玻纤/碳纤填充尼龙或整件 TPU。
目标是细腻哑光深灰/黑色；请说明清粉、喷砂、染色的顺序和尺寸影响。

请明确回复：
1. 五件分别采用的工艺、材料牌号、建议摆放方向、尺寸公差及后处理。
2. 用你们的壁厚软件按最低 1.0 mm 复检；如有红区，请返回零件名、位置、截图和测量数值。
3. 0.2 mm 名义装配间隙能否稳定加工；前框 0.15 mm 名义胶缝是否适合你们的实际公差和胶粘工艺。
4. 表带滑槽、释放间隙、按键孔和细槽能否充分清粉，后处理是否改变锁止尺寸。
5. 弹性臂名义厚度 1.2 mm，禁止擅自加厚、灌胶或磨薄。若你们认为需要调整，请先反馈位置和理由。
6. 本批为工程样机，试装前不批量生产；不要把 05 内压架误认为支撑而删除。

用户确认两块 PCB 间距为 5 mm，本模型解释为相向板面净距并已说明该基准。屏幕玻璃/电池/铜柱实测和前框粘接方案尚待落实。
本说明供用户自行转发，尚未向任何商家发送。
'''
(OUT/'01_可转发厂家_加工要求.txt').write_text(vendor,encoding='utf-8')

assembly='''V5 装配顺序与首件验证

爆炸图颜色：绿色=04 按键板；橙色=05 内压架。颜色只用于说明，不是强制打印颜色。
坐标：有按键的一侧为 -X；屏幕面为 +Z；后盖方向为 -Z。最终装配位置可在 Blender 的 V5 场景查看。

1. 暂不装电子板、后盖和内压架。清粉后检查按键孔、导向槽及表带槽。
2. 04 按键板相对最终位置向壳体中心偏移 6 mm（+X），从后方进入，恢复到最终 Z 高度。
3. 再沿 -X 横向移动 6 mm，使两个帽头穿入对应侧孔。不要在最终 X 位置强行从后方直推。
4. 05 内压架从后方沿 +Z 装入；两根长指朝向屏幕面、横梁靠后盖。压架应位于按键板内侧。
5. 先临时定位压架，再试装电子板、屏幕、铜柱、硅胶接触垫及线束。该整机步骤尚未做实物/完整路径验证。
6. 后盖的内侧长槽套住压架横梁，再使用与实际铜柱匹配的螺钉固定。不可用未确认螺纹的螺钉强拧。
7. 校验屏幕和前框位置；完成试装、拆装和电气检查后，才按已确认的工艺粘接前框。

首件记录（由实际测试填写，不代表已通过）
- 电池及线路完整放入，连接器无受压、无线束夹伤。
- 前框、后盖无翘曲；实测四角接缝并记录，不以效果图代替测量。
- 按键静止时不误触；分别按下、同时按下后能回位，无卡滞。记录操作力、有效行程及测试条件。
- 初步重复按键和释放操作，记录次数、力/行程漂移及裂纹；寿命目标需产品方确认后制定正式试验。
- 实际表带可完整锁止，反向施力不会自行滑出，按释放件后可拆。抗拉载荷与循环数另行规定。
- 验证尼龙胶接的剥离/拉脱及环境耐受。未验证前不能标注防水等级或产品寿命。
- 厂家提供尺寸/材料/后处理记录；量产公差和验收标准需基于首件测量冻结。
'''
(OUT/'03_装配顺序与首件验证.txt').write_text(assembly,encoding='utf-8')

sources='''材料与工艺参考（访问日期 2026-10-11）
PA11 候选用于反复弯曲件，参考 Formlabs 自有打印服务的材料说明：
https://now.formlabs.com/resources/nylon-11-sls
SLS 配合间隙与可制造性须结合设备和材料，参考：
https://formlabs.com/eu/white-papers/fuse-series-sls-design-guide/
上述是材料/工艺选型参考，不是所选商家的材料性能、公差或疲劳认证。
'''
(OUT/'04_材料工艺参考.txt').write_text(sources,encoding='utf-8')

rows=''.join('<tr><td>'+html.escape(p['name_zh'])+'</td><td>'+html.escape(' × '.join(f'{x:.2f}' for x in p['dimensions_mm']))+'</td><td>'+f"{p['sampled_minimum_mm']:.2f}"+'</td><td>'+html.escape(p['material_request'])+'</td></tr>' for p in report['parts'])
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>VelaRide V5 · 工程样机复检</title><style>
*{box-sizing:border-box}body{margin:0;background:#eef2f5;color:#172b3a;font:16px/1.7 'Microsoft YaHei',sans-serif}main{max-width:1120px;margin:auto;padding:48px 28px}h1{font-size:38px;margin:0}h2{margin-top:36px}small,.muted{color:#526779}.tag{display:inline-block;background:#dbede8;color:#1b6253;padding:4px 14px;border-radius:20px}.hero{width:100%;border-radius:20px;margin:24px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.grid img{width:100%;border-radius:12px}figure{margin:0;background:white;padding:14px;border-radius:16px}table{width:100%;border-collapse:collapse;background:white}th,td{text-align:left;padding:12px;border-bottom:1px solid #dce4e9}th{background:#dfe8ee}a{color:#176f74}.note{padding:18px 24px;background:#fff3dc;border-left:4px solid #c58a2d}.card{background:white;padding:22px;border-radius:16px}li{margin-bottom:8px}@media(max-width:700px){.grid{grid-template-columns:1fr}main{padding:24px 16px}table{font-size:13px}th,td{padding:8px}}@media print{main{padding:0}h2{break-after:avoid}figure,.card,table{break-inside:avoid}}
</style><main><span class="tag">V5 · 五件结构 · mm</span><h1>把外观与装配一起修好</h1><p class="muted">2026-10-11｜连续曲面、对齐接缝、可拆内压架｜工程样机阶段</p>
<img class="hero" src="REFERENCE/V5_case_only.png" alt="V5外观预览">
<h2>这次改变了什么</h2><div class="card"><ol><li>侧壁改为连续肩部过渡，减少原来的高光波纹；前框收口和后盖外缘重新对齐。</li><li>修正旧结构按键板直推安装受阻的问题：先入腔、再横向就位，最后装独立内压架。</li><li>五个实际 STL 全部通过封闭性、连通性、零面积面及非相邻面自相交检查。</li></ol></div>
<h2>V4 / V5 外观对照</h2><div class="grid"><figure><img src="REFERENCE/V4_case_only_comparison.png" alt="V4"><figcaption>V4：分段截面与肩部波纹</figcaption></figure><figure><img src="REFERENCE/V5_case_only.png" alt="V5"><figcaption>V5：连续过渡与更平顺的高光</figcaption></figure></div>
<h2>五件结构</h2><figure><img class="hero" src="REFERENCE/V5_exploded.png" alt="五件爆炸图"><figcaption>绿色：04 内藏双按键板；橙色：05 可拆内压架。显示颜色用于识别零件。</figcaption></figure>
<table><thead><tr><th>零件（各1件）</th><th>外形尺寸 mm</th><th>最小抽检厚度 mm</th><th>材质请求</th></tr></thead><tbody>'''+rows+'''</tbody></table>
<h2>装配顺序</h2><div class="card"><p>电子件安装前：按键板向内偏移 6 mm 从后方进入 → 横向推入侧孔 → 从后方装内压架 → 试装电子件 → 后盖定位压架并固定 → 核实屏幕后粘接前框。</p><p>入腔、横移及内压架安装分别抽检 49、25、41 个位置，未发现所测零件表面碰撞；不能强行沿旧路径直推按键板。</p><a href="03_装配顺序与首件验证.txt">完整装配与首件验证说明</a></div>
<h2>背面</h2><img class="hero" src="REFERENCE/V5_rear.png" alt="V5背面">
<div class="note"><strong>板间净距已按确认的 5 mm 更新；当前还不是已定型的生产版。</strong><p>屏幕玻璃、电池与线束空间、铜柱螺纹尚须实测；胶接、按键疲劳、表带锁止和环境性能须样机验证。模型检查不是实物合格证明。</p></div>
<h2>交付文件</h2><ul><li><a href="01_可转发厂家_加工要求.txt">可转发厂家的加工要求</a></li><li><a href="02_零件清单与检查结果.json">零件清单、尺寸和检查结果</a></li><li><a href="SOURCE/velaride_refined_v5.blend">可编辑 Blender 源文件</a></li><li><a href="00_先读_V5修改与状态.txt">全部修改与验证范围</a></li></ul>
<p class="muted">材质选型参考：<a href="https://now.formlabs.com/resources/nylon-11-sls">Formlabs PA11 材料说明</a>、<a href="https://formlabs.com/eu/white-papers/fuse-series-sls-design-guide/">SLS 设计指南</a>。商家的实际牌号和加工公差仍需确认。</p></main></html>'''
(OUT/'V5_修改与装配图.html').write_text(page,encoding='utf-8')
manifest={'revision':'V5','production_release':False,'files':[]}
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='package_manifest.json':
        manifest['files'].append({'path':path.relative_to(OUT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(OUT/'package_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.lower().endswith('.stl')])==5
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(manifest['files'])+1},ensure_ascii=False))
