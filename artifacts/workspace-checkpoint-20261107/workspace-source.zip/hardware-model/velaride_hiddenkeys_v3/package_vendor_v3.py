"""Package the four V3 print parts and a vendor-facing fabrication brief."""
import collections,hashlib,html,json,shutil,struct,zipfile
from pathlib import Path

ROOT=Path('D:/desktop/VelaRide_AI')
SRC=ROOT/'exports/VelaRide_HiddenKeys_V3_4parts'
MODEL=ROOT/'hardware-model/velaride_hiddenkeys_v3'
OUT=ROOT/'exports/VelaRide_V3_Vendor_Package'
(OUT/'STL_4_PARTS').mkdir(parents=True,exist_ok=True)
(OUT/'REFERENCE_IMAGES').mkdir(exist_ok=True)
verification=json.loads((MODEL/'case_verification.json').read_text(encoding='utf8'))
specs=[
 ('01','主壳','01_main_case_PA12_Q1_mm.stl','01_Main_case_PA12_Q1_mm.stl','未填充PA12','硬质、尺寸稳定、耐磕碰；滑槽耐磨','46.0 × 62.8 × 13.48'),
 ('02','屏幕前框','02_front_frame_PA12_Q1_mm.stl','02_Front_frame_PA12_Q1_mm.stl','未填充PA12','硬质、平整、不易翘曲；边缘完整','45.31 × 48.31 × 2.50'),
 ('03','后盖＋一体表带释放片','03_back_with_releases_PA12_Q1_mm.stl','03_Rear_cover_TOUGH_NYLON_Q1_mm.stl','未填充PA11优先；PA12替代另评估','主体稳定；局部弹性臂可反复小幅弯曲并回弹','45.70 × 62.00 × 3.97'),
 ('04','内藏双按键连接板','04_hidden_key_carrier_PA12_Q1_mm.stl','04_Button_carrier_TOUGH_NYLON_Q1_mm.stl','未填充PA11优先；PA12替代另评估','有韧性的硬塑料；按钮弹性臂局部弯曲，固定框不软塌','4.45 × 28.00 × 12.00'),
]
checks=[]
for pid,name,src,dest,material,properties,dims in specs:
    b=(SRC/src).read_bytes();n=struct.unpack_from('<I',b,80)[0]
    assert len(b)==84+50*n
    edges=collections.Counter()
    for i in range(n):
        r=struct.unpack_from('<12fH',b,84+50*i);v=[tuple(r[k:k+3]) for k in (3,6,9)]
        assert len(set(v))==3,(pid,'collapsed triangle')
        for a,c in ((v[0],v[1]),(v[1],v[2]),(v[2],v[0])):edges[tuple(sorted((a,c)))]+=1
    assert all(count==2 for count in edges.values()),pid
    (OUT/'STL_4_PARTS'/dest).write_bytes(b)
    checks.append(dict(id=pid,name=name,file='STL_4_PARTS/'+dest,quantity=1,units='mm',material=material,
        properties=properties,bounding_box_xyz_mm=dims,triangles=n,closed_edge_incidence=True,
        sha256=hashlib.sha256(b).hexdigest()))
assert len(list((OUT/'STL_4_PARTS').glob('*.stl')))==4

brief='''VelaRide V3 内藏按键外壳 — 商家询价 / 首轮试装要求

【只加工本包4个STL，每个1件；单位mm。】
本版替代此前13件版和外露侧板V2。请不要混用旧文件。
表带由客户自行购买！不打印表带，不采购表带；主板、屏幕、铜柱、螺丝也不计入打印报价。
后盖上的表带释放片属于壳体的一部分，不是表带。

一、零件和软硬要求
01 主壳：1件，未填充PA12，硬质、尺寸稳定、耐磕碰，滑槽内表面要干净。
02 前框：1件，未填充PA12，硬质、平整，不翘曲，边缘完整。
03 后盖＋表带释放片：1件，优先未填充PA11，要求局部反复小幅弯曲、松手回弹；主体仍是稳定的硬塑料。
04 双按键连接板：1件，优先未填充PA11，固定框不能软塌，细臂要有韧性、能小幅弯曲回弹。
03、04不是TPU软胶件，不要整件改成软胶。03、04如只能做PA12，请先说明牌号、方向和弹性臂成型能力。
请同时给“全套PA12”的替代报价，但不要在未确认时自行换料。
不使用玻纤/碳纤填充牌号替代；普通硬脆树脂或仅强调防静电的树脂不直接视作等效材料。

二、工艺与外观
优先工业尼龙粉末打印（SLS/MJF，按具体材料选择），小批量首轮打样。
目标为细腻哑光黑。打印、清粉/去支撑、喷砂、染黑和运费请分项报价。
不要厚喷漆覆盖滑槽、按键孔、导轨或弹性臂。
表面平滑处理如会改变尺寸或弹性臂厚度，请提前说明，并按处理后的最终尺寸判断精度。
弹性臂附近避免粗暴去支撑或过度喷砂，孔槽内需清粉干净。

三、精度目标（询价目标，需商家确认，不是保证功能的制造验收结论）
一般外形/装配尺寸：优先±0.15mm；如果常规能力是±0.20mm，请明确说明以便评估。
上述是成品尺寸偏差，不是层厚、像素大小或光斑大小。
主壳的苹果表带滑槽、中央锁止位置：局部目标±0.05mm，优先按实际购买表带试装和局部修配确认。
若只能统一保证±0.15mm，主壳可以作为试样报价，但不能直接承诺表带顺畅插入、可靠锁止。
该标准滑扣配合没有整体放大，不能因为普通按键间隙变大就忽略滑槽精度。
不要擅自放大滑槽、锁孔、螺钉孔，也不要统一缩放STL。

四、需要重点评估的细节
03、04有约1.2mm厚的尼龙弹性臂；后盖释放顶头最窄约1.4mm。请确认可稳定成型。
每个STL是一件连通整体，开缝和弹性臂必须保留，不可自动封缝或填实。
04按键与侧面开口名义单侧间隙约0.6mm；该值是设计间隙，不是打印公差。
原主板轻触开关行程很短，装配后需用现成硅胶垫片调整接触距离，不能仅凭打印尺寸保证按键手感。
文件尺寸为逐件XYZ外包尺寸；所有文件数值单位mm，已单件居中落地，打印朝向由工艺人员评估。

五、现成物料（客户另备，不在打印报价内）
苹果大号滑扣表带；原主板和屏幕；原有铜柱及后盖螺丝。
裁切硅胶接触垫片：可选0.5/0.8/1.0mm厚，用来试装调整按键接触距离。
薄泡棉定位/消隙垫：按实际装配选择厚度，不是3D打印软头。
如前框需要粘接，用合适的薄双面胶/胶接工艺另做装配处理。

六、报价请回复
四件分别单价及一套总价；实际材料牌号、工艺、后处理、运费、交期。
实际可保证的尺寸精度、最小可靠壁厚，以及03/04弹性臂是否适合该材料与成型方向。
无法制作或建议改动的部位请先指出，不要静默修改。

当前已做网格封闭性及指定姿态的几何避让检查，但未完成实物安装、回弹疲劳或表带锁止抗拉试验。
这是首轮试装件询价，不是已验证的量产成品图纸。
'''
(OUT/'00_发给商家_加工要求.txt').write_text(brief,encoding='utf-8-sig')
message='''你好，麻烦按附件最新版V3的4个STL报价，每件1个，单位毫米。

只做外壳和壳内按键机构，表带我自己买，不需要打印或采购表带。

01主壳、02前框：硬质未填充PA12尼龙，要求尺寸稳定、平整、耐磕碰。
03后盖带释放片、04按键连接板：优先未填充PA11；固定部分要稳定，约1.2mm厚的局部弹性臂需要能弯曲回弹，不是整件软胶。也请给全套PA12替代价并评估回弹结构。

普通尺寸精度希望成品±0.15mm；苹果表带滑槽和锁止位置需单独评估，局部目标±0.05mm或按实际表带试装修配。若只保证±0.15mm，请明确注明滑槽需要先试样。

外观哑光黑，喷砂/染色另列。不要厚喷漆堵住孔槽，不要自动填平弹性臂开缝，不要擅自缩放模型。
这是第一轮试装，请先确认薄臂能否稳定制作，再告诉我材料牌号、价格、加工精度和交期，谢谢。
'''
(OUT/'01_可直接复制转发.txt').write_text(message,encoding='utf-8-sig')

rows=''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in [pid,name,1,dims,material,prop])+'</tr>' for pid,name,src,dest,material,prop,dims in specs)
doc='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>VelaRide V3 四件打印要求</title>
<style>body{font:15px/1.65 "Microsoft YaHei",sans-serif;color:#1d2b36;max-width:1120px;margin:36px auto;padding:0 18px}h1{font-size:26px}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{border:1px solid #cdd5dd;padding:10px;text-align:left}th{background:#263b4b;color:white}.notice{background:#e9f3ef;padding:15px;border-left:5px solid #178568}.limits{background:#fff6df;padding:15px}img{max-width:100%}small{color:#516573}@media print{body{font-size:11px;margin:12mm}tr{break-inside:avoid}img{max-height:100mm}}</style>
<h1>VelaRide V3 · 商家报价与打样要求</h1><div class="notice"><b>只做4件，每件1个，单位mm；表带客户自购，不在打印范围内。</b><br>这是内藏式按键版本，不要混用旧13件版或外露侧板版本。</div>
<table><thead><tr><th>编号</th><th>部件</th><th>数量</th><th>外包XYZ/mm</th><th>建议材料</th><th>软硬/性能要求</th></tr></thead><tbody>'''+rows+'''</tbody></table>
<p><b>加工：</b>工业SLS/MJF尼龙打印；哑光黑，打印、清粉/喷砂、染色分别报价。03、04是有韧性的硬塑料，依靠局部结构弯曲，不是TPU软胶件。</p>
<p><b>普通尺寸：</b>成品目标±0.15mm，供应商如只能保证±0.20mm请明确说明。层厚不能代替尺寸精度。</p>
<p><b>苹果滑槽：</b>局部目标±0.05mm，或依据实际购买的表带试装/修配确认。只保证±0.15mm时不能承诺滑扣一次装好。</p>
<p><b>关键细节：</b>约1.2mm弹性臂、约1.4mm最窄释放顶头；开缝须完整保留。按键开口的0.6mm单侧间隙是设计值，不是整件的公差要求。</p>
<div class="limits"><b>首轮试装：</b>必须评估回弹、装配及锁止；当前没有通过实物疲劳/抗拉测试。需改厚度、开孔或材料时先反馈，不要直接自动修模生产。</div>
<p><b>客户另备：</b>主板、屏幕、表带、铜柱、螺丝、薄硅胶接触垫及泡棉消隙垫，不包含在这4个STL里。</p>
<p><small>材料选择参考：<a href="https://formlabs.com/blog/nylon-11-sls/">Formlabs Nylon 11应用说明</a>；<a href="https://formlabs.com/white-papers/fuse-series-sls-design-guide/">SLS设计指南</a>。所列工艺目标必须由实际加工商确认。</small></p>
<img src="REFERENCE_IMAGES/V3_case_only.png" alt="V3外壳，无自购表带"><p>外观参考；图中电子屏幕及五金均非打印件。</p></html>'''
(OUT/'02_四件规格一览.html').write_text(doc,encoding='utf8')
for src,dest in [('hiddenkeys_v3_case_only.png','V3_case_only.png'),('hiddenkeys_v3_rear.png','V3_rear.png')]:
    shutil.copy2(MODEL/src,OUT/'REFERENCE_IMAGES'/dest)
manifest={'revision':'V3 hidden keys, vendor package','parts':checks,'stl_count':4,'quantity_total':4,'bands_included':False,
    'geometry_changed':False,'material_notes':'03/04 prefer PA11 for ductility, PA12 alternative subject to prototype evaluation; geometry not revalidated for any specific material lot.',
    'tolerances':'General +/-0.15mm quotation target; Apple slot separately +/-0.05mm target or fit-and-adjust. Not a demonstrated manufacturing capability.',
    'physical_fit_tested':False}
(OUT/'03_文件校验与版本.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
zpath=OUT.with_suffix('.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    assert sum(n.endswith('.stl') for n in z.namelist())==4
    for p in checks:assert hashlib.sha256(z.read(p['file'])).hexdigest()==p['sha256']
print(json.dumps({'zip':str(zpath),'bytes':zpath.stat().st_size,'stl_count':4,'units':'mm','each_quantity':1,'no_band':True}))
