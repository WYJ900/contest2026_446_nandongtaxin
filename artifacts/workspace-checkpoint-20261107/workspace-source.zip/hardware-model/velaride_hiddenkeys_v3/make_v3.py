from pathlib import Path
import sys,json,shutil
ROOT=Path(__file__).resolve().parent
V2=ROOT.parent/'velaride_easyprint_v2'
sys.path.insert(0,str(V2))
from sections import TRACK,PANEL as OLD_PANEL

HOLES=r'''
buttonz=-1.670586;usby=P['usb_y_mm'];usbz=-P['usb_z_mm']
key_y=(P['button_1_y_mm'],P['button_2_y_mm']);panel_y=sum(key_y)/2
# Rear-access pocket hides the complete large button carrier behind the shell.
pocket=pin_slot('Concealed carrier pocket',13.5,29.6,4.4,(-19.9,panel_y,-.15),'X',None,r=1.2)
apply_mods(pocket);boolean(body,pocket)
for i,yy in enumerate(key_y):
    if i==0:tool=cyl_x('Round key opening',3.4,9,(-22,yy,buttonz),None,64)
    else:tool=pin_slot('Pill key opening',4.8,7.6,9,(-22,yy,buttonz),'X',None,r=2.0)
    apply_mods(tool);boolean(body,tool)
# Internal rails hold the carrier. Rear cover captures its bottom edge.
for sy in (-1,1):
    rail=box('Hidden carrier rail root',(2.8,1.8,11.8),(-19.4,panel_y+sy*15.5,-.3),graphite,r=0)
    boolean(body,rail,'UNION')
    lip=box('Hidden carrier retaining rail',(1.2,3.5,11.8),(-18.7,panel_y+sy*13.75,-.3),graphite,r=.12)
    apply_mods(lip);boolean(body,lip,'UNION')
'''

NEW_SIDE=r'''
for orig,o in list(coremap.items()):
    if orig.name in ('SW1 actuator','SW2 actuator'):bpy.data.objects.remove(o,do_unlink=True)
    elif orig.name.startswith(('core_pcb SW1 |','core_pcb SW2 |')):
        o.location.x-=.3;o.location.z=1.670586;o.scale.y=2/2.6;o.scale.z=2.2/2.6
panel=box('V3 PRINT 04 | concealed dual-key carrier',(2.0,28,12),(-20.3,panel_y,0),graphite,r=.35);apply_mods(panel)
for idx,yy in enumerate(key_y,1):
    boolean(panel,box('Hidden flexure window',(8,7.7,9.5),(-21.5,yy,-.75),None,r=0))
    leaf=box('Concealed nylon key leaf',(1.2,4.2,10.5),(-20.5,yy,.55),graphite,r=.08)
    apply_mods(leaf);boolean(panel,leaf,'UNION')
    if idx==1:cap=cyl_x('Integral rounded key',2.8,3.2,(-22.1,yy,buttonz),graphite,64)
    else:cap=pin_slot('Integral pill key',3.6,6.4,3.2,(-22.1,yy,buttonz),'X',graphite,r=1.6)
    apply_mods(cap);boolean(panel,cap,'UNION')
    boss=box('Concealed contact boss',(1.35,3.8,3.0),(-19.925,yy,buttonz),graphite,r=.18)
    apply_mods(boss);boolean(panel,boss,'UNION')
    pad=box('PURCHASED | cut silicone contact pad '+str(idx),(.8,3.2,2.6),(-18.85,yy,buttonz),rubber,r=.12)
    pad['note']='Cut stock sheet; tune rest gap with 0.5/0.8/1.0 mm sheet thickness.'
    saved=col;col=hardwarecol
    cyl_x('V3 hardware | switch actuator '+str(idx),1.05,.6,(-17.79518,yy,buttonz),black,48)
    col=saved
# Invisible compression pads seat the large carrier against the internal rails.
for sy in (-1,1):
    pad=box('PURCHASED | carrier anti-rattle foam',(.8,3,8),(-21.7,panel_y+sy*11.7,0),rubber,r=.15)
    pad['note']='Adhesive-backed soft foam; select thickness to remove play, not a printed part.'
    box('PURCHASED | carrier bottom locating pad',(1.6,3,.7),(-20.3,panel_y+sy*11.7,-6.37),rubber,r=.1)
bevel(panel,.07,2)
panel['construction']='Single large PA12/PA11 carrier with two integral buttons; installed from rear, captured by internal rails and rear cover.'
panel['external_screws']=False
panel['material']='PA12/PA11; not generic brittle resin. Return and fatigue require prototype testing.'
panel['guide_clearance_per_side_mm']=.6
panel['flexure_thickness_mm']=1.2
panel['nominal_button_protrusion_mm']=.7
panel['pad_adjustment']='Use stock silicone contact pads and anti-rattle foam. Do not print microscopic soft tips.'
'''

rest=OLD_PANEL[OLD_PANEL.index('# Release buttons become'):]
rest=rest.replace("V2 PRINT 03", "V3 PRINT 03")
start=rest.index("panel.shape_key_add(name='Rest')")
end=rest.index("back.shape_key_add(name='Rest')",start)
rest=rest[:start]+r'''
panel.shape_key_add(name='Rest')
for idx,yy in enumerate(key_y,1):
    k=panel.shape_key_add(name='Key '+str(idx)+' demonstration')
    for i,v in enumerate(panel.data.vertices):
        p=panel.matrix_world@v.co
        leaf=abs(p.y-yy)<2.15 and -4.9<p.z<4.0 and -21.2<p.x<-19.8
        cap=abs(p.y-yy)<3.25 and p.x<-20.3 and abs(p.z-buttonz)<3.0
        boss=abs(p.y-yy)<2.0 and -20.7<p.x<-19.1 and abs(p.z-buttonz)<1.6
        if leaf or cap or boss:
            w=min(1,max(0,(4.0-p.z)/(4.0-buttonz)))**2 if leaf else 1
            k.data[i].co.x+=.5*w
    for fr,val in [(1,0),(10 if idx==1 else 55,0),(20 if idx==1 else 65,1),(35 if idx==1 else 80,0),(100,0)]:
        k.value=val;k.keyframe_insert(data_path='value',frame=fr)
''' +rest[end:]

s=(V2/'build_v2.py').read_text(encoding='utf8')
s=s.replace('/velaride_easyprint_v2\'','/velaride_hiddenkeys_v3\'').replace('VelaRide | EasyPrint V2 four parts','VelaRide | Hidden keys V3').replace('EASYV2_','HIDDENV3_')
def section(a,b,new):
 global s
 i=s.index(a);j=s.index(b,i);s=s[:i]+new+'\n'+s[j:]
section('buttonz=-1.670586;','usbcut=',HOLES)
section('# Correct original tactile switch axis','# The brass standoffs',NEW_SIDE+rest)
s=s.replace('V2 PRINT 04','V3 PRINT 04').replace('V2 PRINT 03','V3 PRINT 03')
s=s.replace('04_dual_key_panel_PA12_Q1_mm.stl','04_hidden_key_carrier_PA12_Q1_mm.stl')
s=s.replace('easyprint_v2_hero.png','hiddenkeys_v3_hero.png').replace('velaride_easyprint_v2.blend','velaride_hiddenkeys_v3.blend')
s=s.replace("'V2 | matte nylon'","'V3 | satin graphite nylon'")
(ROOT/'build_v3.py').write_text(s,encoding='utf8')
p=json.loads((V2/'case_parameters.json').read_text(encoding='utf8'))
p.update(design_revision='Hidden keys V3',external_sideplate=False,external_side_screws=0,print_part_count=4,button_protrusion_mm=.7,button_clearance_per_side_mm=.6,side_panel_frame_thickness_mm=2.0)
p.pop('button_nominal_stop_stroke_mm',None)
(ROOT/'case_parameters.json').write_text(json.dumps(p,indent=2),encoding='utf8')
shutil.copy2(V2/'apple_profile.json',ROOT/'apple_profile.json')
verify=(V2/'verify_finish_v2.py').read_text(encoding='utf8')
verify=verify.replace('velaride_easyprint_v2','velaride_hiddenkeys_v3').replace('VelaRide | EasyPrint V2 four parts','VelaRide | Hidden keys V3').replace('VelaRide_EasyPrint_V2_4parts','VelaRide_HiddenKeys_V3_4parts').replace('V2 PRINT','V3 PRINT').replace('EASYV2_','HIDDENV3_').replace('easyprint_v2_','hiddenkeys_v3_')
# Internal carrier intentionally contacts retaining rails; test it 0.01 mm away.
verify=verify.replace('px-.01','px-.01')
verify=verify.replace("'nominal_per_side':.7,'two_size_errors_of_0p15':.55,'with_additional_relative_position_error_0p30':.25", "'nominal_per_side':.6,'two_size_errors_of_0p15':.45,'with_additional_relative_position_error_0p30':.15")
(ROOT/'verify_finish_v3.py').write_text(verify,encoding='utf8')
print('Built V3 scripts')
