import bpy,json
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_watch_case')
hero=bpy.data.scenes['VelaRide | Watch Enclosure']
bpy.context.window.scene=hero
hero.render.filepath=str(ROOT/'watch_case_hero.png')
bpy.ops.render.render(write_still=True)

name='VelaRide | Exploded construction'
old=bpy.data.scenes.get(name)
if old:
    for c in list(old.collection.children):
        for o in list(c.objects):bpy.data.objects.remove(o,do_unlink=True)
        bpy.data.collections.remove(c)
    bpy.data.scenes.remove(old)
ex=bpy.data.scenes.new(name)
ex.unit_settings.system=hero.unit_settings.system;ex.unit_settings.scale_length=.001
ex.world=hero.world;ex.render.engine=hero.render.engine
ex.render.resolution_x=1800;ex.render.resolution_y=1400;ex.render.resolution_percentage=100
ex.render.image_settings.file_format=hero.render.image_settings.file_format
coll=bpy.data.collections.new('Exploded construction');ex.collection.children.link(coll)
mapping={}
for cname in ['WATCH_01_Enclosure','WATCH_02_Existing_hardware','WATCH_04_Studio']:
    for orig in bpy.data.collections[cname].objects:
        o=orig.copy();o.animation_data_clear();coll.objects.link(o);mapping[orig]=o;o.name='EX | '+orig.name
for orig,o in mapping.items():o.parent=mapping.get(orig.parent)
for orig,o in mapping.items():
    if o.parent:continue
    n=orig.name
    if n=='Watch hero camera':
        o.data=orig.data.copy();ex.camera=o
        o.location=(-78,-135,125);o.rotation_euler=(Vector((0,0,17))-o.location).to_track_quat('-Z','Y').to_euler();o.data.ortho_scale=155
    elif n=='Watch hardware | screen':o.location+=Vector((25,0,23))
    elif n=='Watch hardware | main board':o.location+=Vector((25,0,3))
    elif n in ['CASE | front bezel','CASE | polished front edge','CASE | screen gasket']:o.location+=Vector((25,0,39))
    elif n.startswith('HARDWARE |') and 'standoff' in n:o.location+=Vector((25,0,3))
    elif n in ['CASE | removable rear cover','CASE | rear seam gasket'] or n.startswith('HARDWARE |'):
        o.location+=Vector((25,0,-8))
    elif n.startswith('CASE |') or n.startswith('CONTROL |'):o.location+=Vector((-33,0,4))
    elif n=='Watch studio floor':o.location.z=-20
bpy.context.window.scene=ex
ex.render.filepath=str(ROOT/'watch_case_exploded.png')
bpy.ops.render.render(write_still=True)

# A close-up of the actual receiving holes is saved separately from the hero.
bpy.context.window.scene=hero
cam=hero.camera;pos=cam.location.copy();rot=cam.rotation_euler.copy();scale=cam.data.ortho_scale
strap=bpy.data.collections['WATCH_03_Purchased_strap_preview'];strap.hide_render=True
cam.location=(42,64,35);cam.rotation_euler=(Vector((0,24,-2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=48
hero.render.filepath=str(ROOT/'22mm_quick_release_interface.png')
bpy.ops.render.render(write_still=True)
cam.location=pos;cam.rotation_euler=rot;cam.data.ortho_scale=scale;strap.hide_render=False
hero.render.filepath=str(ROOT/'watch_case_hero.png')
bpy.context.window.scene=hero
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_watch_case.blend'))
print('Saved hero, exploded view, interface close-up and editable scenes.')
