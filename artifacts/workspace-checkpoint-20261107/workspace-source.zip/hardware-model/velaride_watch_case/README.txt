VelaRide 商业手表外观的黄山派外壳 — 初版可试装设计

本次目标是给现有实物做外壳。原始裸板模型文件保留，外壳另存。

打开 velaride_watch_case.blend：
  VelaRide | Watch Enclosure 是佩戴外观场景。
  VelaRide | Exploded construction 是结构分解场景。
  原始裸板场景也保留，便于追溯尺寸。

设计与尺寸（mm）
  壳体不含表耳：42.6 × 49.0，包含前框约 16.70 厚。
  独立主壳、前框、后盖；左侧双按键、右侧 USB-C 开口及可拆防尘塞。
  前框上唇压住现有屏幕的黑色边缘；前框与主壳的固定采用胶接试装方案。
  后盖四处 M2 螺钉位置对应主板安装孔，连接底部铜柱。
  排针面向后盖，屏幕在上方。这个朝向根据“铜柱略高于排针”推断。
  铜柱暂选 M2、柱体长 6 mm、六角对边 4 mm。螺纹/对边需实物复核。
  屏幕 PCB 与主板中心面间距暂取 6 mm，可在 case_parameters.json 修改。
  单位：1 Blender 单位 = 1 mm；STL 数值单位为毫米。

排针标称依据
  官方工程 CN3：XUNDA XDZ127-2-15-S-1.0-G1，LCSC C19268856。
  制造商机械图：PA=4.00，PB=1.50，总高 L=5.50 mm。
  与用户“铜柱略高于排针”的描述结合，选 6 mm 为初版基准。
  PDF 已保存在 references/header_XDZ127.pdf。
  https://atta.szlcsc.com/upload/public/pdf/source/20231121/132ADD8FE50D9D5F7A5EBF788BB0A2C5.pdf

购买表带的明确规格
  22 mm 直头、快拆生耳、两片式表带。
  生耳杆身约 1.8 mm，端针 0.8 mm；表带头部厚度不超过 5.5 mm。
  搜索词：22mm 直头 快拆生耳 FKM/硅胶表带 0.8mm端针。
  不按 Apple Watch 滑轨、Garmin QuickFit 或专用弧形端头接口设计。
  选择时核对上述连接规格，不能仅凭“22 mm”名称判断兼容。

可直接查看的现售参考
  StrapHabit Waffle FKM Rubber Quick Release Watch Straps，选 22 mm。
  厂商标注：20/22 mm 宽，80/130 mm 长，3.5–5.5 mm 厚，0.8 mm 快拆端针。
  https://straphabit.com/collections/22mm-watch-straps/products/waffle-rubber-quick-release-watch-straps
  上述表带规格用来定义接口包络；渲染中的纹理和扣具是简化展示。
  未购买或实测该表带，没有承诺到货免调整。

生耳规格交叉参考
  Masar 1.78/1.8 mm 快拆生耳，0.8 mm 端针，22 mm 版本：
  https://masar-shop.com/en/products/quick-release-watch-spring-bar-1-8mm-double-lever-stainless-steel

外壳表耳接口
  净间距：22.10 mm。
  孔径：1.00 mm；盲孔有效建模深度约 1.35 mm（名义 1.30 加末端余量）。
  两组生耳轴线：Y=±28.20，Z=-2.50；轴线沿 X。
  外侧保留约 2.15 mm 实体，表带从两耳之间安装，底面可操作快拆拨杆。
  先用 22mm_lug_fit_coupon.stl 试装购买的表带，孔位若有打印收缩可少量修整。
  此试装件复制主壳表耳净距、孔径和孔深，不必先打印整个外壳。

文件
  watch_case_hero.png                  手表外观预览
  watch_case_exploded.png              主壳、屏幕、主板、铜柱与后盖分解
  22mm_quick_release_interface.png      表耳接口近景
  velaride_watch_case.blend            完整可编辑模型
  case_body_PROTOTYPE.stl              主壳及一体表耳
  front_bezel_PROTOTYPE.stl            前框
  rear_cover_PROTOTYPE.stl             后盖
  22mm_lug_fit_coupon.stl              表带接口试装件
  case_parameters.json                可调尺寸及假设
  case_verification.json              网格与部分空间检查
  build_watch_case.py                  建模与 STL 导出脚本
  render_case_views.py                 多视图渲染脚本

已检查及尚待确认
  三个壳体零件及表耳试装件的网格均封闭，无边界边/非流形边。
  当前简化硬件网格与主壳、前框、后盖未发现表面相交。
  生耳孔已用几何射线检查确认存在，尺寸记录在 verification 文件。
  上述检查不能替代实物装配：屏幕堆叠间距、铜柱实际螺纹和整机高度仍未实测。
  电池及额外接线未提供尺寸，尚未计入容积；不得把本版视为完整量产结构。
  按键帽、塞子和胶接/垫片细节是概念设计，未完成卡扣、密封和耐久验证。
  图中金属质感是外观表达，未指定量产壳体材料或防水等级。

重建
  先打开 ../huangshan_pi/huangshan_pi_v1_2.blend。
  调整 case_parameters.json 后，在 Blender 中运行 build_watch_case.py。
  运行 render_case_views.py 可重新生成配图及分解场景。
  脚本内 ROOT 使用本工作区绝对路径，移动目录后需修改。

来源查阅日期：2026-10-10。
