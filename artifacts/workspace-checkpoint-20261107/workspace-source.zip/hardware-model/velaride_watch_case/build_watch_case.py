"""VelaRide enclosure concept with dimensional 22 mm quick-release interfaces.
Requires the source Huangshan .blend. Saves a NEW file; original is preserved.
Screen-board spacing remains an estimate. Do not infer production fit from renders.
"""
import bpy, bmesh, math, json, ast, sys, struct
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_watch_case')
SRC=ROOT.parent/'huangshan_pi'
P=json.loads((ROOT/'case_parameters.json').read_text(encoding='utf8'))
sys.path.insert(0,str(SRC))
from extract_hardware import path_points
# Reuse only geometry helper definitions; do not run the source scene builder.
tree=ast.parse((SRC/'build_blender.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'geometry_helpers','exec'))

scene_name='VelaRide | Watch Enclosure'
existing=bpy.data.scenes.get(scene_name)
if existing:
    for c in list(existing.collection.children):
        if c.name.startswith('WATCH_'):
            for o in list(c.all_objects):bpy.data.objects.remove(o,do_unlink=True)
            bpy.data.collections.remove(c)
    bpy.data.scenes.remove(existing)
scene=bpy.data.scenes.new(scene_name)
bpy.context.window.scene=scene
enum(scene.unit_settings,'system','METRIC');scene.unit_settings.scale_length=.001
scene.unit_settings.length_unit='MILLIMETERS'
col=bpy.data.collections.new('WATCH_01_Enclosure');scene.collection.children.link(col)
hardwarecol=bpy.data.collections.new('WATCH_02_Existing_hardware');scene.collection.children.link(hardwarecol)
strapcol=bpy.data.collections.new('WATCH_03_Purchased_strap_preview');scene.collection.children.link(strapcol)
studiocol=bpy.data.collections.new('WATCH_04_Studio');scene.collection.children.link(studiocol)

graphite=mat('Watch | satin graphite',(.095,.111,.14),.84,.25)
edge=mat('Watch | polished chamfer',(.31,.35,.4),.92,.18)
rubber=mat('Watch | black FKM',(.009,.014,.019),0,.49)
rear_mat=mat('Watch | rear engineering polymer',(.019,.027,.038),.07,.4)
steel=mat('Watch | hardware steel',(.52,.57,.63),.9,.23)
brass=mat('Watch | brass standoffs',(.64,.40,.1),.82,.28)
markmat=mat('Watch | laser markings',(.37,.44,.50),.4,.5)
accent=mat('Watch | subtle teal accent',(.015,.31,.29),.7,.27)
black=mat('Watch | gasket',(.005,.008,.012),0,.65)

def clone_hardware(rootname,newname,z=0,flip=False):
    source=bpy.data.objects[rootname]
    mapping={}
    for orig in [source]+list(source.children_recursive):
        obj=orig.copy()
        if orig.data:obj.data=orig.data.copy()
        obj.animation_data_clear();hardwarecol.objects.link(obj);obj.name='WatchHW | '+orig.name
        mapping[orig]=obj
    for orig,obj in mapping.items():
        obj.parent=mapping.get(orig.parent)
    rt=mapping[source];rt.name=newname;rt.location=(0,0,z);rt.rotation_euler=(0,math.pi if flip else 0,0)
    rt['assembly_orientation_note']='Main header faces rear; inferred from user standoffs higher than header.'
    return rt,mapping

core,coremap=clone_hardware('CORE_PCB | official XY','Watch hardware | main board',0,True)
display,displaymap=clone_hardware('DISPLAY_PCB | official XY','Watch hardware | screen',P['display_pcb_center_z_mm'])
# Correct the source preview USB body's generic height override.
for orig,o in coremap.items():
    if orig.name.startswith('core_pcb USB1'):
        o.scale.z=4;o.location.z=P['usb_z_mm'];o['body_height_is_estimate']=True
    elif orig.name=='USB-C polymer tongue':o.location.z=P['usb_z_mm']

def rr(w,h,r,n=20):
    pts=[]
    for x,y,a in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
        pts.extend((x+r*math.cos(math.radians(a+j*90/n)),y+r*math.sin(math.radians(a+j*90/n))) for j in range(n+1))
    return pts

def ring(name,outer,inner,z0,z1,material):
    a=rr(*outer);b=rr(*inner);n=len(a)
    v=[(x,y,z) for z,pts in [(z0,a),(z1,a),(z0,b),(z1,b)] for x,y in pts]
    f=[]
    for i in range(n):
        j=(i+1)%n
        f.extend([(i,j,j+n,i+n),(2*n+j,2*n+i,3*n+i,3*n+j),(n+i,n+j,3*n+j,3*n+i),(j,i,2*n+i,2*n+j)])
    return mesh(name,v,f,material)

def loft_ring(name,sections,inside,material):
    n=len(rr(*inside));k=len(sections)
    v=[(x,y,z) for z,w,h,r in sections for x,y in rr(w,h,r)]
    v.extend((x,y,z) for z in [sections[0][0],sections[-1][0]] for x,y in rr(*inside))
    f=[]
    for q in range(k-1):
        for i in range(n):j=(i+1)%n;f.append((q*n+i,q*n+j,(q+1)*n+j,(q+1)*n+i))
    for i in range(n):
        j=(i+1)%n;lo=k*n;hi=(k+1)*n;top=(k-1)*n
        f.extend([(lo+j,lo+i,hi+i,hi+j),(j,i,lo+i,lo+j),(top+i,top+j,hi+j,hi+i)])
    return mesh(name,v,f,material)

def boolean(obj,tool,op='DIFFERENCE'):
    bpy.context.view_layer.update();bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new('Manufactured geometry','BOOLEAN');enum(mod,'operation',op);mod.object=tool
    bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(tool,do_unlink=True)

def cyl_x(name,r,length,xyz,m=None,n=48):
    o=cylinder(name,r,length,xyz,m,n=n);o.rotation_euler.y=math.pi/2;return o

def apply_mods(o):
    bpy.context.view_layer.objects.active=o
    for mod in list(o.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)

def pin_slot(name,w,h,depth,xyz,axis='Z',material=None,r=None):
    o=rounded(name,w,h,depth,r or min(w,h)/2-.01,0,material,None)
    if axis=='X':o.rotation_euler.y=math.pi/2
    o.location=xyz
    return o

L=P['copper_standoff_length_mm'];boardhalf=.5705856
backtop=-boardhalf-L-.15;backbottom=backtop-1.65
bottom=backtop+.1;top=P['display_pcb_center_z_mm']+.83
W,H,R=P['case_width_mm'],P['case_length_mm'],P['case_corner_radius_mm']
inside=(P['cavity_width_mm'],P['cavity_length_mm'],P['cavity_corner_radius_mm'])
body=loft_ring('CASE | main body with 22 mm lugs',[(bottom,W-1,H-1,R-.5),(bottom+.75,W,H,R),(top-.9,W,H,R),(top,W-1,H-1,R-.5)],inside,graphite)
body['part']='Main enclosure';body['prototype_only']=True

# Four integrated lugs. 22.1 mm net clear width for a nominal 22 mm straight strap.
gap=P['lug_clear_width_mm'];axisY=P['lug_axis_y_mm'];axisZ=P['lug_axis_z_mm']
for sy in (-1,1):
    for sx in (-1,1):
        lug=box('Lug union',(3.5,9,5.8),(sx*(gap/2+1.75),sy*25.7,axisZ),graphite,r=.8)
        apply_mods(lug);boolean(body,lug,'UNION')
        # blind receiving socket, starts at the inner face, leaves outside wall intact
        hole=cyl_x('Springbar tip bore',P['lug_hole_diameter_mm']/2,P['lug_hole_depth_mm']+.15,(sx*(gap/2+P['lug_hole_depth_mm']/2-.025),sy*axisY,axisZ))
        boolean(body,hole)
body['lug_clear_width_mm']=gap;body['springbar_bore_diameter_mm']=P['lug_hole_diameter_mm'];body['springbar_bore_depth_mm']=P['lug_hole_depth_mm']

# Main-board component face points down: USB on +X, buttons on -X.
buttonz=-P['button_z_mm'];usby=P['usb_y_mm'];usbz=-P['usb_z_mm']
for y in (P['button_1_y_mm'],P['button_2_y_mm']):
    boolean(body,cyl_x('Button guide bore',1.0,7,(-W/2,y,buttonz)))
usbcut=pin_slot('USB access opening',4.5,10.2,8,(W/2,usby,usbz),'X',r=1.0)
boolean(body,usbcut)
bevel(body,.11,3)

# Front frame, matching the existing glass instead of replacing the screen.
window=(P['screen_window_width_mm'],P['screen_window_length_mm'],P['screen_window_corner_radius_mm'])
bezel=loft_ring('CASE | front bezel',[(top-.05,W-.9,H-.9,R-.45),(top+.5,W-.65,H-.65,R-.3),(top+1.35,W-1.5,H-1.5,R-.7)],window,graphite)
# Raised capture lip overlaps only the existing glass's black perimeter, above
# its surface, so the front retains the stack when the rear screws are tightened.
lip=ring('Front glass retaining lip',(W-1.5,H-1.5,R-.7),(34.5,40.9,7.65),top+1.25,top+1.5,graphite)
boolean(bezel,lip,'UNION')
bevel(bezel,.12,3)
trim=ring('CASE | polished front edge',(W-.7,H-.7,R-.35),(W-1.25,H-1.25,R-.62),top+.22,top+.38,edge)
bevel(trim,.04,2)
seal=ring('CASE | screen gasket',(36.05,42.45,8.4),(35.18,41.58,8.0),top+.25,top+.75,black)
seal['note']='Illustrative gasket. No water-resistance rating or seal validation.'

back=rounded('CASE | removable rear cover',W-.3,H-.3,backtop-backbottom,R-.25,(backtop+backbottom)/2,rear_mat,None)
apply_mods(back)
rim=ring('CASE | rear seam gasket',(W-1.1,H-1.1,R-.6),(W-2,H-2,R-1.05),backtop-.03,backtop+.16,black)
mounts=[]
params=json.loads((SRC/'hardware_parameters.json').read_text(encoding='utf8'))
for c in next(b for b in params if b['name']=='core_pcb')['components']:
    if c['ref'] not in ('M1','M2','M3','M4'):continue
    x,y=-c['x'],c['y'];mounts.append((x,y))
    boolean(back,cylinder('Rear M2 clearance bore',1.1,4,(x,y,(backtop+backbottom)/2),None))
    boolean(back,cylinder('Rear screw head seat',1.9,.8,(x,y,backbottom+.32),None))
    st=cylinder('HARDWARE | '+c['ref']+' 6 mm brass standoff',P['copper_standoff_across_flats_mm']/math.sqrt(3),L,(x,y,-boardhalf-L/2),brass,n=6)
    boolean(st,cylinder('M2 thread envelope',.85,L+1,(x,y,-boardhalf-L/2),None))
    bevel(st,.08,2);st['nominal_body_length_mm']=L;st['thread']='M2 placeholder; actual screw size to verify'
    screw=cylinder('HARDWARE | rear M2 screw',1.65,.55,(x,y,backbottom+.30),steel,n=40)
    for ang in (0,math.pi/2):
        tool=box('Screw cross recess',(2.1,.4,.3),(x,y,backbottom+.09),None,r=0);tool.rotation_euler.z=ang;boolean(screw,tool)
    cylinder('HARDWARE | M2 screw shank',.9,2.4,(x,y,backbottom+1.6),steel,n=32)
bevel(back,.08,3)

# A tactile round push-button and a low-profile secondary button, with stems.
yy=P['button_1_y_mm']
crown=cyl_x('CONTROL | round push button',2.55,1.35,(-W/2-.65,yy,buttonz),graphite,64);bevel(crown,.18,3)
cyl_x('CONTROL | push-button stem',.75,4,(-W/2+1.0,yy,buttonz),steel,32)
cyl_x('CONTROL | inset accent face',1.82,.08,(-W/2-1.36,yy,buttonz),accent,64)
for i in range(24):
    a=i*2*math.pi/24
    ridge=box('CONTROL | edge knurl '+str(i),(.62,.16,.22),(-W/2-.68,yy+2.5*math.cos(a),buttonz+2.5*math.sin(a)),edge,r=.035)
    ridge.rotation_euler.x=a
button=pin_slot('CONTROL | secondary pill',2.65,6.4,1.15,(-W/2-.48,P['button_2_y_mm'],buttonz),'X',graphite,r=1.2)
cyl_x('CONTROL | secondary stem',.75,3,(-W/2+.8,P['button_2_y_mm'],buttonz),steel,32)
cover=pin_slot('CONTROL | removable USB dust cover',5.0,11.0,.65,(W/2+.13,usby,usbz),'X',rubber,r=1.1)
cover['note']='Concept plug; removable to expose PCB USB-C. Retention to prototype.'

# The brass standoffs are retained by the rear screws. Removable front bezel uses
# bonded/clip design allowance, not unverified detailed snap geometry.
bezel['attachment_note']='Prototype: front frame bonded to midcase. Raised lip captures glass black edge; gasket to tune after measurement.'
back['attachment_note']='Four M2 placeholder screws into underside brass pillars; verify actual threads.'
body['assembly_height_mm']=top+1.5-backbottom

# Purchased strap preview is independent from exported enclosure parts.
col=strapcol
def strap_z(t,length):return axisZ-1.8*(min(t/length,1)**1.5)
def make_strap(name,sign,length):
    n=90;verts=[]
    for i in range(n+1):
        t=i*length/n
        half=11-1.0*(t/length)
        if t>length-8:half=2+(half-2)*math.sqrt(max(0,1-((t-(length-8))/8)**2))
        y=sign*(axisY-1.8+t);z=strap_z(t,length)
        th=2.75-min(t/length*2,1)
        verts.extend([(-half,y,z-th),(half,y,z-th),(-half,y,z+th),(half,y,z+th)])
    faces=[(0,2,3,1)]
    for i in range(n):
        a=i*4;b=a+4;faces.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
    faces.append((4*n,4*n+1,4*n+3,4*n+2))
    o=mesh(name,verts,faces,rubber);o['purchased_component_preview']=True
    # Straight springbar passage, plus underside thumb-lever access.
    boolean(o,cyl_x('Strap springbar tube',.97,23,(0,sign*axisY,axisZ)))
    lever=box('Quick release lever pocket',(5,3.2,3.0),(6,sign*axisY,axisZ-2.1),None,r=0)
    boolean(o,lever)
    if sign<0:
        for t in range(32,int(length)-11,7):
            hole=pin_slot('Strap adjustment slot',3.1,5,5,(0,sign*(axisY-1.8+t),strap_z(t,length)),r=1.4)
            boolean(o,hole)
    bevel(o,.28,3)
    # Fine transverse texture, kept away from the lug interface.
    for t in range(9,int(length)-8,3):
        z=strap_z(t,length)+2.77-min(t/length*2,1);y=sign*(axisY-1.8+t)
        for x in (-6.5,6.5):box('Strap preview texture',(4.9,.13,.045),(x,y,z),rubber,r=.02)
    return o
strap1=make_strap('PURCHASED PREVIEW | 22 mm strap buckle half',1,80)
strap2=make_strap('PURCHASED PREVIEW | 22 mm strap long half',-1,130)
for sy in (-1,1):
    bar=cyl_x('PURCHASED PREVIEW | 22 mm quick-release springbar',.9,21.7,(0,sy*axisY,axisZ),steel,32)
    for sx in (-1,1):cyl_x('PURCHASED PREVIEW | 0.8 mm springbar tip',.4,1.25,(sx*11.48,sy*axisY,axisZ),steel,24)
    cylinder('PURCHASED PREVIEW | release thumb pin',.42,1.3,(6,sy*axisY,axisZ-2.4),steel,n=24)
# Two movable keepers, through openings around the strap (not part of the case).
for y in (38,47):
    keeper=box('PURCHASED PREVIEW | strap keeper',(24.3,5.2,7.5),(0,y,axisZ),rubber,r=.65);apply_mods(keeper)
    boolean(keeper,box('Keeper passage',(22.4,8,5.8),(0,y,axisZ),None,r=0));bevel(keeper,.15,3)
buckle=ring('PURCHASED PREVIEW | pin buckle',(24,12,2.6),(19.7,8,1.2),-4.2,-2.5,graphite);buckle.location.y=101
bevel(buckle,.25,3)
box('PURCHASED PREVIEW | buckle tang',(1.5,10.8,1.1),(0,100,-2.05),steel,r=.4)

# Small strap-fit coupon exports with the same lug geometry, allowing cheap fit QA.
col=bpy.data.collections.new('WATCH_05_Interface_test_coupon');scene.collection.children.link(col)
coupon=box('FIT TEST | 22 mm quick-release lug coupon',(30,4,5.8),(0,22.9,axisZ),graphite,r=0)
for sx in (-1,1):
    tab=box('Coupon tab',(3.5,9,5.8),(sx*(gap/2+1.75),25.7,axisZ),graphite,r=.7);apply_mods(tab);boolean(coupon,tab,'UNION')
    boolean(coupon,cyl_x('Coupon springbar bore',.5,1.45,(sx*(gap/2+.625),axisY,axisZ)))
bevel(coupon,.1,2);col.hide_render=True;col.hide_viewport=True

# Studio hero: tight product crop, purchased bands intentionally extend beyond it.
col=studiocol
floor_mat=mat('Watch | studio floor',(.10,.13,.17),.08,.52)
floor=box('Watch studio floor',(1800,1800,.6),(0,0,backbottom-1),floor_mat,r=0)
camdata=bpy.data.cameras.new('Watch hero camera');cam=bpy.data.objects.new('Watch hero camera',camdata);col.objects.link(cam)
cam.location=(-74,-108,126);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();enum(camdata,'type','ORTHO');camdata.ortho_scale=90;camdata.clip_end=3000
scene.camera=cam
for name,loc,energy,size in [('Key',(-45,-45,100),160000,70),('Edge',(65,25,85),230000,55),('Soft fill',(-60,70,45),125000,80)]:
    ld=bpy.data.lights.new('Watch '+name,'AREA');ld.energy=energy;ld.size=size
    ob=bpy.data.objects.new('Watch '+name,ld);col.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
world=bpy.data.worlds.new('Watch studio');scene.world=world;world.use_nodes=True
bg=next(n for n in world.node_tree.nodes if n.type=='BACKGROUND');bg.inputs['Color'].default_value=(.16,.19,.23,1);bg.inputs['Strength'].default_value=.45
scene.render.resolution_x=1600;scene.render.resolution_y=1500;scene.render.resolution_percentage=100
enum(scene.render.image_settings,'file_format','PNG');scene.render.filepath=str(ROOT/'watch_case_hero.png')
scene.frame_start=1;scene.frame_end=1
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            sp=a.spaces.active;sp.region_3d.view_distance=95;sp.region_3d.view_location=(0,0,1);sp.region_3d.view_rotation=cam.rotation_euler.to_quaternion();sp.clip_end=5000
            enum(sp.shading,'type','MATERIAL');sp.overlay.show_floor=False

# Export only dimensional enclosure parts and coupon; retain mm units in STL.
def export_stl(obj,path):
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();me.calc_loop_triangles()
    with open(path,'wb') as f:
        f.write(b'VelaRide prototype; units mm; fit NOT verified'.ljust(80,b' '));f.write(struct.pack('<I',len(me.loop_triangles)))
        for tri in me.loop_triangles:
            vv=[obj.matrix_world@me.vertices[i].co for i in tri.vertices];normal=(vv[1]-vv[0]).cross(vv[2]-vv[0]).normalized()
            f.write(struct.pack('<12fH',*normal,*vv[0],*vv[1],*vv[2],0))
    ev.to_mesh_clear()

for ob in (body,bezel,trim,back):
    for poly in ob.data.polygons:
        if abs(poly.normal.z)<.8:poly.use_smooth=True
validation={'parameters':P,'body_height_including_glass_mm':round(top+1.5-backbottom,3),'parts':[],'fit_verified':False}
for o,filename in [(body,'case_body_PROTOTYPE.stl'),(bezel,'front_bezel_PROTOTYPE.stl'),(back,'rear_cover_PROTOTYPE.stl'),(coupon,'22mm_lug_fit_coupon.stl')]:
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();bm=bmesh.new();bm.from_mesh(me)
    item={'name':o.name,'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'stl':filename}
    bm.free();ev.to_mesh_clear();validation['parts'].append(item)
    export_stl(o,ROOT/filename)
(ROOT/'case_verification.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
note=bpy.data.texts.new('WATCH_CASE_README.txt');note.write(json.dumps(validation,indent=2)+'\n22 mm straight quick-release strap; 1.8 mm shaft; 0.8 mm tips.\nMain header faces rear. Copper pillar length selected at 6 mm based on 5.50 mm header.\nDo not order tooling from this file. Prototype with actual board, strap and measured screen spacing.\n')
bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_watch_case.blend'))
print(json.dumps(validation))
