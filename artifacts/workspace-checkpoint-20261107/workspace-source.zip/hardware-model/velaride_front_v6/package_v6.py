"""Deliver the same-screen front revision with honest comparison metrics."""
from pathlib import Path
import json,shutil,hashlib,zipfile,html
from html.parser import HTMLParser

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_front_v6')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V6_Engineering_Package')
report=json.loads((ROOT/'verification_v6.json').read_text(encoding='utf-8'))
metrics=json.loads((ROOT/'front_comparison_metrics.json').read_text(encoding='utf-8'))
params=json.loads((ROOT/'case_parameters.json').read_text(encoding='utf-8'))
labels=['主壳','贴合式黑色前框','后盖及表带释放机构','内藏双按键板','可拆内压架']
for p,label in zip(report['parts'],labels):
    p['name_zh']=label;p['quantity']=1
    assert hashlib.sha256((OUT/p['file']).read_bytes()).hexdigest()==p['sha256']
    for k in ('sampled_under_1mm','serialized_bad_edges','serialized_zero_area_faces','nonadjacent_self_overlap_candidates'):assert p[k]==0,(p['file'],k)
    assert p['components']==1
    shutil.copy2(OUT/p['file'],ROOT/Path(p['file']).name)
assert not any(report['surface_intersections'].values())
assert not any(any(v.values()) for v in report['key_motion_surface_intersections'].values())
assert not any(report['release_motion_surface_intersections'].values())
assert not any(report['carrier_installation_stage_1_rear_entry_x_plus_6mm'].values())
assert not any(report['carrier_installation_stage_2_lateral_seating'].values())
assert not any(any(v.values()) for v in report['retainer_installation_from_rear'].values())
assert not report['hardware_body_surface_intersections'] and not report['hardware_retainer_surface_intersections']
(OUT/'SOURCE').mkdir(exist_ok=True)
shutil.copy2(ROOT/'velaride_front_v6.blend',OUT/'SOURCE/velaride_front_v6.blend')
shutil.copy2(ROOT/'case_parameters.json',OUT/'SOURCE/case_parameters.json')
(OUT/'02_五件清单与检查.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

notes='''VelaRide V6 — 保留现有屏幕的正面优化方案
2026-10-11；单位 mm；五个独立打印件，每件 1 个。V5 原文件保留。
本版是工程方案与试装模型，不是已通过胶接、寿命、密封及整机资格验证的生产版。

已确认约束
保留黄山派 ZC-A1D85W-010 屏幕，1.85 英寸、390×450；不缩放屏幕、电子板或 UI。
沿用用户确认的两板间距 5 mm，并按相向 PCB 板面净距建模。
电子件位置、表带接口剖面和可拆按键内压架的装配思路保留。

V6 修改
主壳包络从 49×62.8 收为 48×60.8 mm；重调转角，保留按键内腔和表带滑槽附近的结构厚度。
按钮外端相应缩短，名义外露仍约 0.7 mm。
前框从 2.30 mm 降为 1.40 mm；屏幕玻璃顶面相对前框的凹入高度由约 1.28 降为 0.38 mm。
可见开口从 34.5×40.9 mm 改为 35.6×42.0 mm，展示更多原有玻璃边缘；这不增加发光面积。
黑色前框与 OLED 黑底统一视觉色调。渲染中的光泽、色差和接缝不等于加工实物的保证值。

固定方式的变化必须注意
降低前框时取消了原有上压式玻璃防脱唇。V6 改为屏幕模块胶接固定的待验证方案。
已有玻璃的外形 35.1×41.5 mm、厚度及圆角仍为估计值，须用实物确认。
模型中的黑色屏幕边胶只是几何占位，不是指定或已验证的胶粘剂。
厂家需要确定适用于尼龙/玻璃的胶、表面处理、胶层控制及强度/老化验证；不能把这个模型当作已具备机械防脱保证。
若胶接方案不可行，需要恢复防脱结构并重新评估正面高度，不能直接省略屏幕固定。

真实屏占比口径
现有模型发光区约 30.775×35.510 mm；由标称 1.85 英寸和 390:450、方形像素假设推导。
圆角半径 6.2 mm 为估计。因此面积数据是模型比较值，不能替代屏幕厂商机械图。
按“同一模型发光区 / 主壳 XY 包络矩形”计算，约由 34.44% 提升到 36.32%，增加 1.87 个百分点，相对约 5.4%。
这不是“屏幕大了 5.4%”，也不是与 Apple 官方屏占比直接可比的认证口径；分母不包含侧按键和表带。
REFERENCE 中绿色图只标出同一发光区，V5/V6 完全等大，防止把黑色装饰边当作新增像素。

检查结果
五件实际导出的 STL 均为单一连通封闭网格，无非流形边、零面积面，未检出非相邻三角面自相交候选。
壁厚法向射线抽检的最小值约为 1.20、1.40、1.20、1.20、1.40 mm；均未采到小于 1 mm。
静止件、按键演示姿态、后盖释放演示姿态、按键板两阶段入壳和内压架后装通过抽样表面避让检查。
该检查不等于完整连续碰撞、公差堆叠、疲劳、抗拉或实物装配证明。
模型正上方光路对 V5/V6 发光区均未发现前框遮挡；V6 在所测斜向光路上减少遮挡。这不是 OLED 光学视角测试。

仍需补齐：电池和线束空间、铜柱螺纹、真实玻璃尺寸、屏幕模块胶接与前框胶接工艺，以及首件装配和耐久验证。
全部五件使用 V6，不与旧壳/旧后盖混配。图中的表带、屏幕、铜柱、胶层均不打印。
'''
(OUT/'00_先读_正面方案与固定方式.txt').write_text(notes,encoding='utf-8')
vendor='''V6 五件尼龙工程样机 — 厂家复检要点
各件数量 1，单位 mm，仅打印 STL_5_PARTS 的 5 件。
01 主壳、02 前框、05 内压架：未填充 PA12 候选。
03 后盖和 04 按键板：含弹性机构，未填充韧性 PA11 优先；采用 PA12 须先验证回弹与疲劳。
不得直接用普通人偶树脂、金属或整件 TPU 替换。
本版屏幕固定改为待验证胶接方案，必须先确认实际屏幕玻璃尺寸及胶接方法；不靠上压唇固定。
前框目标黑色细腻表面，光泽尽量与玻璃黑边协调；涂层不能改变按键孔、滑槽或胶接面的有效尺寸。
请返回材料牌号、打印工艺、摆放方向、尺寸公差及后处理方案。
请对五件按 1.0 mm 最低壁厚重新扫描，反馈不足位置和截图；局部 1.2 mm 弹性臂不能擅自加厚或磨薄。
评估 0.2 mm 内压架配合间隙、约 0.25 mm 玻璃边胶间隙以及 0.15 mm 前框胶缝与实际工艺是否匹配。
表带滑槽按客户实际采购件试装。外壳缩小后五件必须作为一套使用。
尚未发送给任何厂家。本文件供用户自行转发做工艺复检，不代表已批准批量生产。
'''
(OUT/'01_可转发厂家_复检要求.txt').write_text(vendor,encoding='utf-8')
assembly='''V6 装配顺序
1. 暂不装电子板、前框、后盖和内压架。
2. 按键板相对最终位置向内（+X）偏移 6 mm，从后方进入内腔；达到最终高度后横向推向侧孔就位。
3. 从后方安装 05 可拆内压架，再试装电子件、接触垫和线束。不要在最终 X 位置把按键板直接向上硬推。
4. 后盖内侧长槽定位内压架横梁，采用与实际铜柱匹配的螺钉固定。
5. 试配玻璃和前框，确认胶接表面、点胶量、固化与可维修性后实施胶接。屏幕模块的固定必须单独验证。
6. 首件验证静止不误触、按键回弹、表带锁止/释放、接缝和胶接强度。
详细数字检查范围见 REFERENCE/verification_v6.json；电子件完整装配路径、电池及线束仍须实物验证。
'''
(OUT/'03_装配顺序.txt').write_text(assembly,encoding='utf-8')

page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>VelaRide V6 · 同屏幕正面对比</title><style>
*{box-sizing:border-box}body{margin:0;background:#eef1f4;color:#172b39;font:16px/1.7 'Microsoft YaHei',sans-serif}main{max-width:1160px;margin:auto;padding:42px 24px}h1{font-size:36px;margin:6px 0}h2{margin-top:36px}p{max-width:900px}.muted{color:#536a78}.tag{display:inline-block;background:#d2e8e0;padding:4px 14px;border-radius:20px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}figure{margin:0;background:white;padding:12px;border-radius:16px}figure img{width:100%;border-radius:10px}figcaption{padding:10px 8px}button{font:inherit;border:1px solid #56726d;background:white;color:#164b42;padding:8px 18px;border-radius:8px;cursor:pointer}button.active{background:#164b42;color:white}.controls{display:flex;gap:10px;margin:20px 0;flex-wrap:wrap}table{width:100%;background:white;border-collapse:collapse}th,td{padding:12px;text-align:left;border-bottom:1px solid #dce4e9}th{background:#dfe8ed}.note{background:#fff3de;padding:18px 24px;border-left:4px solid #b78023}.hero{width:100%;border-radius:16px}a{color:#096d6b}li{margin-bottom:8px}@media(max-width:700px){.grid{grid-template-columns:1fr}main{padding:24px 14px}h1{font-size:28px}th,td{padding:8px;font-size:14px}}
</style><main><span class="tag">保留现有 1.85 英寸屏幕 · V6</span><h1>让正面更像一整块黑色屏幕</h1><p class="muted">同一屏幕、同一界面、同一正交视角、同一物理比例。减少宽灰框与屏幕下沉感，同时压缩主壳轮廓。</p>
<div class="controls"><button id="normal" class="active" onclick="show(false)">外观对比</button><button id="active" onclick="show(true)">标出实际模型发光区</button></div>
<div class="grid"><figure><img id="v5" src="REFERENCE/V5_top.png" alt="V5 同比例俯视"><figcaption><strong>V5</strong> · 宽灰框、屏幕下沉约 1.28 mm</figcaption></figure><figure><img id="v6" src="REFERENCE/V6_top.png" alt="V6 同比例俯视"><figcaption><strong>V6</strong> · 一体黑色正面、下沉约 0.38 mm</figcaption></figure></div>
<p id="caption">两张图均使用 74 mm 正交视野，界面文字未放大。</p>
<h2>改善了多少</h2><table><tr><th>比较项目</th><th>V5</th><th>V6</th></tr><tr><td>主壳 XY 包络</td><td>49 × 62.8 mm</td><td>48 × 60.8 mm</td></tr><tr><td>屏幕型号 / 分辨率</td><td>1.85″ / 390×450</td><td>相同，不换屏</td></tr><tr><td>模型发光区包络</td><td>约 30.78 × 35.51 mm</td><td>完全相同</td></tr><tr><td>发光区面积 / 主壳包络矩形*</td><td>34.44%</td><td>36.32%</td></tr><tr><td>玻璃低于前框</td><td>1.28 mm</td><td>0.38 mm</td></tr><tr><td>前框可见开口</td><td>34.5 × 40.9 mm</td><td>35.6 × 42.0 mm</td></tr></table>
<p class="muted">* 这是本模型统一口径下的比较，约提升 1.87 个百分点、相对约 5.4%。发光区由标称对角线与分辨率推导，圆角估计；分母不含按键和表带。不代表发光面积变大，也不是 Apple 官方口径。</p>
<h2>斜视效果</h2><img class="hero" src="REFERENCE/V6_case_only.png" alt="V6 斜视效果">
<h2>学习苹果正面的哪些部分</h2><p>参考<a href="https://support.apple.com/en-la/125093">苹果官方产品图</a>：黑色屏幕边缘与正面形成连续视觉，外框退居边缘。V6 用黑色前框、较浅凹入和更紧凑轮廓接近这个方向，没有套用苹果内部结构，也没有虚构更大的显示面板。</p>
<div class="note"><strong>这版固定方式发生了变化。</strong><p>为了降低前框，取消原有上压玻璃唇，改为屏幕模块胶接固定的待验证方案。胶、实际玻璃尺寸及胶接强度必须先验证；不能直接当作已定型生产图。渲染中的光泽匹配也须由实际表面处理验证。</p></div>
<h2>模型检查与文件</h2><p>五件 STL 的网格及自相交检查通过；最小壁厚抽检约 1.20–1.40 mm。静止零件、按键运动和原两阶段入壳路径的抽样表面避让检查通过。实际屏幕光学性能、胶接、疲劳和装配仍须首件验证。</p><ul><li><a href="00_先读_正面方案与固定方式.txt">方案变化与适用范围</a></li><li><a href="02_五件清单与检查.json">五件检查结果</a></li><li><a href="REFERENCE/front_comparison_metrics.json">正面比例与遮挡抽检数据</a></li><li><a href="SOURCE/velaride_front_v6.blend">Blender 源文件</a></li><li><a href="01_可转发厂家_复检要求.txt">厂家复检说明</a></li></ul>
<p class="muted">屏幕规格依据：<a href="https://wiki.sifli.com/board/sf32lb52x/SF32LB52-%E9%BB%84%E5%B1%B1%E6%B4%BE.html">SiFli 黄山派官方指南</a>。访问日期：2026-10-11。</p>
</main><script>function show(active){document.getElementById('v5').src='REFERENCE/V5_'+(active?'active_area':'top')+'.png';document.getElementById('v6').src='REFERENCE/V6_'+(active?'active_area':'top')+'.png';document.getElementById('normal').classList.toggle('active',!active);document.getElementById('active').classList.toggle('active',active);document.getElementById('caption').textContent=active?'绿色只标示原有模型发光区域：两版大小相同。黑色外框不是新增像素。':'两张图均使用 74 mm 正交视野，界面文字未放大。';}</script></html>'''
(OUT/'V5_V6_同屏幕正面对比.html').write_text(page,encoding='utf-8')
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        self.links.extend(v for k,v in attrs if k in ('src','href') and not v.startswith(('http:','https:','#')))
parser=Links();parser.feed(page)
assert all((OUT/v).exists() for v in parser.links)
for rev in ('V5','V6'):assert (OUT/f'REFERENCE/{rev}_active_area.png').exists()
manifest={'revision':'V6','same_existing_screen':True,'production_release':False,'files':[]}
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='package_manifest.json':manifest['files'].append({'path':path.relative_to(OUT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(OUT/'package_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None and len([n for n in z.namelist() if n.endswith('.stl')])==5
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'links_checked':len(parser.links)},ensure_ascii=False))
