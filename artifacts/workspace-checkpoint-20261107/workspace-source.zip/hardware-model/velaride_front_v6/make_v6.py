"""V6 front study: same screen and board stack, reduced footprint, flush bezel."""
from pathlib import Path
import json, shutil

ROOT=Path(__file__).resolve().parent
V5=ROOT.parent/'velaride_refined_v5'
source=(V5/'build_v5.py').read_text(encoding='utf-8')
for old,new in [('velaride_refined_v5','velaride_front_v6'),('VelaRide | Refined V5','VelaRide | Front V6'),('REFINEDV5_','FRONTV6_'),('V5 PRINT','V6 PRINT'),('refined_v5_','front_v6_'),('_V5_','_V6_'),('V5 | satin graphite nylon','V6 | graphite nylon'),("'V5'","'V6'"),('V5_MANUFACTURING_NOTES','V6_MANUFACTURING_NOTES')]:
    source=source.replace(old,new)
source=source.replace('62.0','60.0').replace('62.8','60.8').replace('61.4','59.4')
# Keep corner stock around the hidden key-carrier pocket while shortening the
# top face. The lower shell keeps its V5 corner radius and band interface.
source=source.replace('(W-.9,H-.9,R-.45),(z+1)/(z1+1))','(W-.9,H-.9,R-3.2),(z+1)/(z1+1))')
# Shorten the outer key stems to retain 0.7 mm protrusion after narrowing.
source=source.replace('2.8,4.7,(-22.85,yy,buttonz+.5)','2.8,4.2,(-22.6,yy,buttonz+.5)')
source=source.replace('3.6,6.4,4.7,(-22.85,yy,buttonz+.5)','3.6,6.4,4.2,(-22.6,yy,buttonz+.5)')

start=source.index('def refined_front_sections(top):')
end=source.index('\ndef loft_ring(',start)
source=source[:start]+'''def refined_front_sections(top):
    # A 1.4-mm-deep ring: no thin overhanging flange above the existing glass.
    # A small rolled shoulder removes the broad horizontal frame highlight.
    out=[]
    for i in range(25):
        t=i/24;u=t*t*t*(10+t*(-15+6*t))
        out.append((top+.15+1.40*t,W-.9-.6*u,H-.9-.6*u,R-3.2-.30*u))
    return out
''' +source[end:]
old="""lip=ring('Front glass retaining lip',(W-1.5,H-1.5,R-.7),(34.5,40.9,7.65),top+1.25,top+2.45,graphite)
boolean(bezel,lip,'UNION')"""
assert old in source
source=source.replace(old,"# V6 removes the overhanging lip. Screen-module adhesive retention must be qualified.")
source=source.replace("bevel(bezel,.12,3)","bevel(bezel,.08,3)")
source=source.replace("body['assembly_height_mm']=top+2.45-backbottom","body['assembly_height_mm']=top+1.55-backbottom")
source=source.replace("round(top+2.45-backbottom,3)","round(top+1.55-backbottom,3)")
old="bezel['attachment_note']='Front frame requires qualified adhesive bonding; nominal bond gap 0.15 mm. No validated retention rating. Raised lip captures glass black edge; measure actual glass before production.'"
assert old in source
source=source.replace(old,"""bezel['attachment_note']='V6 near-flush front: no overhanging glass retention lip. Both frame bonding and screen-module retention require qualified adhesive and real-part validation. Screen aperture is not active display area.'
bezel['screen_glass_radial_clearance_nominal_mm']=.25
bezel['existing_screen_not_scaled']=True
frontblack=mat('V6 | black front ceramic-look polymer',(.002,.004,.006),.05,.19)
bezel.data.materials.clear();bezel.data.materials.append(frontblack)
screenblack=mat('V6 | uniform OLED black background',(.002,.004,.006),.05,.19)
for screenpart in hardwarecol.objects:
    if screenpart.type=='MESH' and screenpart.name.startswith(('WatchHW | AMOLED active area','WatchHW | AMOLED cover glass')):
        screenpart.data.materials.clear();screenpart.data.materials.append(screenblack)
edge_bond=ring('PURCHASED | V6 screen edge adhesive',(35.6,42.0,8.15),(35.1,41.5,8.1),top+.15,P['display_pcb_center_z_mm']+2.000012,black)
edge_bond['not_a_printed_part']=True
edge_bond['status']='Illustrative edge-bond envelope, adhesive and actual glass dimensions require qualification.'
""")
source=source.replace("mat('V6 | graphite nylon',(.055,.065,.08),.05,.50)","mat('V6 | graphite nylon',(.022,.029,.036),.05,.48)")
source=source.replace("See README.txt.","See V6 front study notes. V6 requires qualified adhesive retention for the screen module; original glass and active area are unchanged.")
(ROOT/'build_v6.py').write_text(source,encoding='utf-8')
p=json.loads((V5/'case_parameters.json').read_text(encoding='utf-8'))
p.update(design_revision='Front V6 same-screen engineering study',case_width_mm=48.0,case_length_mm=47.4,case_corner_radius_mm=10.2,overall_case_length_mm=60.8,
         front_glass_retaining_lip=False,front_bezel_height_mm=1.4,
         screen_glass_radial_clearance_nominal_mm=.25,
         screen_module_retention='Adhesive design and process pending qualification; former overhanging lip removed',
         unchanged_screen_model='ZC-A1D85W-010',active_area_scaled=False,
         prototype_only=True,production_release=False)
(ROOT/'case_parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(V5/'apple_profile.json',ROOT/'apple_profile.json')
check=(V5/'check_export_v5.py').read_text(encoding='utf-8')
for old,new in [('velaride_refined_v5','velaride_front_v6'),('VelaRide | Refined V5','VelaRide | Front V6'),('REFINEDV5_','FRONTV6_'),('V5','V6'),('v5','v6')]:check=check.replace(old,new)
(ROOT/'check_export_v6.py').write_text(check,encoding='utf-8')
print('Generated isolated V6 build and check scripts')
