"""Create equal-scale comparisons and distinguish screen size from case size."""
import bpy,json,math,shutil
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_front_v6')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V6_Engineering_Package')
(OUT/'REFERENCE').mkdir(exist_ok=True)

def bounds(obj):
    pts=[obj.matrix_world@Vector(c) for c in obj.bound_box]
    return ([min(p[i] for p in pts) for i in range(3)],[max(p[i] for p in pts) for i in range(3)])

metrics={}
for revision,name in [('V5','VelaRide | Refined V5'),('V6','VelaRide | Front V6')]:
    s=bpy.data.scenes[name];bpy.context.window.scene=s;s.frame_set(1)
    body=next(o for o in s.objects if o.name.startswith('CASE | main body'))
    frame=next(o for o in s.objects if o.name.startswith('CASE | front bezel'))
    glass=next(o for o in s.objects if o.name.startswith('WatchHW | AMOLED cover glass'))
    active=next(o for o in s.objects if o.name.startswith('WatchHW | AMOLED active area'))
    lo,hi=bounds(active);glo,ghi=bounds(glass);flo,fhi=bounds(frame)
    aw,ah=hi[0]-lo[0],hi[1]-lo[1]
    radius=6.2
    area=aw*ah-(4-math.pi)*radius**2
    # Sample the existing modeled active area, never the larger glass aperture.
    points=[]
    for ix in range(math.ceil(aw/.5)):
        x=lo[0]+(ix+.5)*.5
        if x>hi[0]:continue
        for iy in range(math.ceil(ah/.5)):
            y=lo[1]+(iy+.5)*.5
            if y>hi[1]:continue
            qx=max(abs(x)-(aw/2-radius),0);qy=max(abs(y)-(ah/2-radius),0)
            if qx*qx+qy*qy<=radius*radius:points.append(Vector((x,y,hi[2]+.001)))
    trees=[]
    for obj in [body,frame]:
        ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh()
        trees.append(BVHTree.FromPolygons([obj.matrix_world@v.co for v in m.vertices],[list(p.vertices) for p in m.polygons]))
        ev.to_mesh_clear()
    visibility={}
    for label,angle,axis in [('top',0,0),('x45',45,0),('x60',60,0),('x75',75,0),('y60',60,1),('y75',75,1)]:
        d=Vector((0,0,math.cos(math.radians(angle))));d[axis]=math.sin(math.radians(angle))
        blocked=sum(any(tree.ray_cast(p,d,50)[0] is not None for tree in trees) for p in points)
        visibility[label]={'sample_count':len(points),'blocked_samples':blocked,'unblocked_fraction':round(1-blocked/len(points),6)}
    metrics[revision]={'body_bbox_mm':[round(v,5) for v in body.dimensions],
        'modeled_active_bbox_mm':[round(aw,5),round(ah,5)],
        'modeled_active_rounded_area_mm2':round(area,3),
        'active_area_to_body_bbox_ratio':round(area/(body.dimensions.x*body.dimensions.y),6),
        'glass_to_front_rim_recess_mm':round(fhi[2]-ghi[2],6),
        'oblique_geometric_visibility':visibility}
    cam=s.camera
    saved=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale,s.render.resolution_x,s.render.resolution_y,s.render.resolution_percentage,s.render.filepath)
    cam.location=(0,0,150);cam.rotation_euler=(0,0,0);cam.data.ortho_scale=74
    s.render.resolution_x=1400;s.render.resolution_y=1400;s.render.resolution_percentage=100
    s.render.filepath=str(OUT/'REFERENCE'/f'{revision}_top.png');bpy.ops.render.render(write_still=True)
    # Diagnostic view: mask only the modeled active area in teal, with UI off.
    prior_mats=list(active.data.materials)
    mat=bpy.data.materials.new(revision+' active-area diagnostic');mat.use_nodes=True
    node=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
    node.inputs['Base Color'].default_value=(.01,.55,.4,1);node.inputs['Roughness'].default_value=.8
    active.data.materials.clear();active.data.materials.append(mat)
    ui=[o for o in s.objects if 'Demo UI' in o.name];vis=[o.hide_render for o in ui]
    for obj in ui:obj.hide_render=True
    s.render.filepath=str(OUT/'REFERENCE'/f'{revision}_active_area.png');bpy.ops.render.render(write_still=True)
    active.data.materials.clear()
    for material in prior_mats:active.data.materials.append(material)
    for obj,state in zip(ui,vis):obj.hide_render=state
    cam.location,cam.rotation_euler,cam.data.ortho_scale,s.render.resolution_x,s.render.resolution_y,s.render.resolution_percentage,s.render.filepath=saved

assert metrics['V5']['modeled_active_bbox_mm']==metrics['V6']['modeled_active_bbox_mm']
metrics['scope']='Same 1.85-inch 390x450 module. Active size derived from advertised diagonal and square pixels, corner radius and cover-glass size estimated. Area denominator is main-shell XY bounding rectangle, excludes keys and straps; this is NOT an Apple-comparable certified screen/body-area measurement. Oblique rays check only modeled body/frame occlusion, not optical OLED viewing performance.'
metrics['ratio_relative_gain']=round(metrics['V6']['active_area_to_body_bbox_ratio']/metrics['V5']['active_area_to_body_bbox_ratio']-1,6)
(ROOT/'front_comparison_metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'REFERENCE/front_comparison_metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')

s=bpy.data.scenes['VelaRide | Front V6'];bpy.context.window.scene=s
strap=next(c for c in s.collection.children if c.name.startswith('FRONTV6_03'))
strap.hide_render=True
s.render.resolution_x=1600;s.render.resolution_y=1500;s.render.resolution_percentage=85
s.render.filepath=str(OUT/'REFERENCE/V6_case_only.png');bpy.ops.render.render(write_still=True)
strap.hide_render=False;s.render.filepath=str(OUT/'REFERENCE/V6_hero.png');bpy.ops.render.render(write_still=True)
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        space=area.spaces.active
        # User specifically asked to inspect the watch from above.
        space.region_3d.view_rotation=(1,0,0,0);space.region_3d.view_location=(0,0,0);space.region_3d.view_distance=95
        allowed=[e.identifier for e in space.region_3d.bl_rna.properties['view_perspective'].enum_items]
        if 'ORTHO' in allowed:space.region_3d.view_perspective=allowed[allowed.index('ORTHO')]
        space.overlay.show_overlays=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_front_v6.blend'))
print(json.dumps(metrics,ensure_ascii=False))
