"""Run in Blender; export and independently re-read manufacturing meshes."""
import bpy, bmesh, json, struct, hashlib, collections, math
from pathlib import Path
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_front_v6')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V6_Engineering_Package')
(OUT/'STL_5_PARTS').mkdir(parents=True,exist_ok=True)
(OUT/'REFERENCE').mkdir(exist_ok=True)
s=bpy.data.scenes['VelaRide | Front V6'];bpy.context.window.scene=s;s.frame_set(1)
parts=[next(o for o in s.objects if o.name.startswith(prefix)) for prefix in
       ('CASE | main body','CASE | front bezel','V6 PRINT 03','V6 PRINT 04','V6 PRINT 05')]
names=['01_Main_case_V6_PA12_Q1_mm.stl','02_Front_frame_V6_PA12_Q1_mm.stl',
       '03_Rear_cover_V6_NYLON_Q1_mm.stl','04_Key_carrier_V6_NYLON_Q1_mm.stl','05_Key_retainer_V6_PA12_Q1_mm.stl']

def evaluated(o):
    e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
    v=[o.matrix_world@p.co for p in m.vertices]
    p=[list(f.vertices) for f in m.polygons]
    e.to_mesh_clear()
    return v,p

def tree(o,translation=None):
    v,p=evaluated(o)
    if translation is not None:v=[x+translation for x in v]
    return BVHTree.FromPolygons(v,p)

report={'revision':'V6','physical_fit_verified':False,'production_release':False,
        'thickness_method':'Exported float32 STL triangle centroids, inward ray offset .0005 mm; minimum face area .002 mm2; opposing normal dot < -.85; max ray 12 mm. Not an exhaustive minimum-thickness proof.',
        'parts':[]}
for o,filename in zip(parts,names):
    e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
    bm=bmesh.new();bm.from_mesh(m)
    e.to_mesh_clear()
    m=bpy.data.meshes.new('V6 temporary export mesh')
    # Weld numerical bevel/boolean slivers, at most two micrometres.
    weld_mm=.002 if o.name.startswith('V6 PRINT 03') else (.0001 if o.name.startswith('V6 PRINT 04') else .001)
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=weld_mm)
    bmesh.ops.triangulate(bm,faces=list(bm.faces))
    if o.name.startswith('V6 PRINT 05'):
        bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.0001)
        bmesh.ops.triangulate(bm,faces=list(bm.faces))
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    boundary=sum(x.is_boundary for x in bm.edges);nonmanifold=sum(not x.is_manifold for x in bm.edges)
    unseen=set(bm.verts);components=0
    while unseen:
        stack=[unseen.pop()];components+=1
        while stack:
            v=stack.pop()
            for edge in v.link_edges:
                w=edge.other_vert(v)
                if w in unseen:unseen.remove(w);stack.append(w)
    assert not boundary and not nonmanifold and components==1,(o.name,boundary,nonmanifold,components)
    bm.to_mesh(m);bm.free();m.calc_loop_triangles()
    v=[o.matrix_world@p.co for p in m.vertices]
    lo=Vector([min(p[i] for p in v) for i in range(3)])
    hi=Vector([max(p[i] for p in v) for i in range(3)])
    offset=Vector(((lo.x+hi.x)/2,(lo.y+hi.y)/2,lo.z))
    records=[];collapsed=0
    for tri in m.loop_triangles:
        xyz=[v[i]-offset for i in tri.vertices]
        normal=(xyz[1]-xyz[0]).cross(xyz[2]-xyz[0]).normalized()
        raw=struct.pack('<12fH',*normal,*xyz[0],*xyz[1],*xyz[2],0)
        serialized=struct.unpack('<12fH',raw)
        points=[tuple(serialized[k:k+3]) for k in (3,6,9)]
        if len(set(points))<3:
            collapsed+=1;continue
        records.append(raw)
    data=b'VelaRide V6 | mm | engineering sample | fit not validated'.ljust(80,b' ')+struct.pack('<I',len(records))+b''.join(records)
    path=OUT/'STL_5_PARTS'/filename;path.write_bytes(data)
    bpy.data.meshes.remove(m)
    # Check the actual serialized coordinates, not only Blender's mesh.
    vv=[];ff=[];ids={};edges=collections.Counter();zero_area=0
    for raw in struct.iter_unpack('<12fH',path.read_bytes()[84:]):
        xyz=[tuple(raw[k:k+3]) for k in (3,6,9)]
        face=[]
        for point in xyz:
            if point not in ids:ids[point]=len(vv);vv.append(Vector(point))
            face.append(ids[point])
        ff.append(face)
        for a,b in zip(face,face[1:]+face[:1]):edges[tuple(sorted((a,b)))]+=1
        if (vv[face[1]]-vv[face[0]]).cross(vv[face[2]]-vv[face[0]]).length==0:zero_area+=1
    bad=sum(c!=2 for c in edges.values())
    assert not bad and not zero_area,(filename,bad,zero_area)
    bvh=BVHTree.FromPolygons(vv,ff,all_triangles=True)
    self_hits=[(a,b) for a,b in bvh.overlap(bvh) if a<b and not set(ff[a]).intersection(ff[b])]
    assert not self_hits,(filename,'nonadjacent self-overlap',len(self_hits))
    thickness=[]
    for f in ff:
        a,b,c=[vv[i] for i in f];cross=(b-a).cross(c-a)
        if cross.length/2<.002:continue
        normal=cross.normalized();center=(a+b+c)/3
        hit,n,index,dist=bvh.ray_cast(center-normal*.0005,-normal,12)
        if hit is not None and .002<dist<12 and n.dot(normal)<-.85:thickness.append(dist+.0005)
    report['parts'].append({'file':'STL_5_PARTS/'+filename,'object':o.name,
        'dimensions_mm':[round(x,5) for x in hi-lo], 'triangles':len(ff),
        'boundary_edges':boundary,'nonmanifold_edges':nonmanifold,'components':components,'nonadjacent_self_overlap_candidates':len(self_hits),
        'serialized_bad_edges':bad,'serialized_zero_area_faces':zero_area,'float32_collapsed_triangles_omitted':collapsed,'numerical_weld_tolerance_mm':weld_mm,
        'sha256':hashlib.sha256(data).hexdigest(),'probe_count':len(thickness),
        'sampled_minimum_mm':round(min(thickness),5),'sampled_under_1mm':sum(t<.9999 for t in thickness),
        'assembly_translation_mm':list(offset)})

body,bezel,back,panel,retainer=parts
bt=tree(body)
report['surface_intersections']={}
for i in range(len(parts)):
    for j in range(i+1,len(parts)):
        report['surface_intersections'][str(i+1)+'_'+str(j+1)]=len(tree(parts[i]).overlap(tree(parts[j])))
report['key_motion_surface_intersections']={}
for frame in (1,10,15,20,27,35,55,60,65,72,80,100):
    s.frame_set(frame)
    report['key_motion_surface_intersections'][str(frame)]={'body':len(bt.overlap(tree(panel))),'retainer':len(tree(retainer).overlap(tree(panel)))}
s.frame_set(1)
report['release_motion_surface_intersections']={}
for t in (0,.25,.5,.75,1):
    for key in back.data.shape_keys.key_blocks:
        if key.name!='Rest':key.value=t
    bpy.context.view_layer.update()
    report['release_motion_surface_intersections'][str(t)]=len(bt.overlap(tree(back)))
for key in back.data.shape_keys.key_blocks:key.value=0
bpy.context.view_layer.update()
hw=next(c for c in s.collection.children if c.name.startswith('FRONTV6_02'))
report['hardware_body_surface_intersections']=[o.name for o in hw.objects if o.type=='MESH' and bt.overlap(tree(o))]
report['hardware_retainer_surface_intersections']=[o.name for o in hw.objects if o.type=='MESH' and tree(retainer).overlap(tree(o))]
report['carrier_straight_rear_insertion_surface_intersections']={str(d):len(bt.overlap(tree(panel,Vector((-.01,0,-d))))) for d in (0,.5,1,2,4,6,10,16,24)}
report['carrier_installation_stage_1_rear_entry_x_plus_6mm']={str(round(d,2)):len(bt.overlap(tree(panel,Vector((6,0,-d))))) for d in [i*.5 for i in range(49)]}
report['carrier_installation_stage_2_lateral_seating']={str(round(x,2)):len(bt.overlap(tree(panel,Vector((x,0,0))))) for x in [i*.25 for i in range(25)]}
pt=tree(panel)
report['retainer_installation_from_rear']={str(round(d,2)):{'body':len(bt.overlap(tree(retainer,Vector((0,0,-d))))),'panel':len(pt.overlap(tree(retainer,Vector((0,0,-d)))))} for d in [i*.5 for i in range(41)]}
report['collision_check_scope']='Triangle surface intersection only; does not prove absence of full containment. Motion shape keys are illustrative, not mechanical simulation. Straight rear insertion tested without hardware; alternate tilted paths not covered.'
(ROOT/'verification_v6.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'REFERENCE'/'verification_v6.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
