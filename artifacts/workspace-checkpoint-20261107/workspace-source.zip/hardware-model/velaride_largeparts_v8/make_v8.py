"""Create V8 as four larger printed parts with explicit mechanical retention."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parent
V7=ROOT.parent/'velaride_rolled_v7'
src=(V7/'build_v7.py').read_text(encoding='utf-8')
for old,new in [('velaride_rolled_v7','velaride_largeparts_v8'),('VelaRide | Rolled V7','VelaRide | Large parts V8'),('ROLLEDV7_','LARGEV8_'),('rolled_v7_','largeparts_v8_'),('V7','V8')]:src=src.replace(old,new)

# A 1.2-mm screen stop and a 0.2-mm stock cushion replace the adhesive-only hold.
src=src.replace('z0,z1=top-1.35,top+1.55','z0,z1=top-1.35,top+2.57')
src=src.replace('w=38.4+(W-.9-38.4)*math.cos(theta)','w=36.3+(W-.9-36.3)*math.cos(theta)')
src=src.replace('h=44.8+(H-.9-44.8)*math.cos(theta)','h=42.7+(H-.9-42.7)*math.cos(theta)')
src=src.replace('(9.55-(R-3.2))*math.sin(theta)','(8.7-(R-3.2))*math.sin(theta)')
src=src.replace("(W-.9-38.4)/2","(W-.9-36.3)/2")
src=src.replace("bevel(bezel,.045,3)","""lip=ring('V8 integral screen safety stop',(36.3,42.7,8.7),(33.5,39.9,7.3),top+1.37,top+2.57,graphite)
boolean(bezel,lip,'UNION')
bevel(bezel,.045,3)""")

# Existing rear-to-board fasteners get explicit M2x4 shank envelopes.
src=src.replace("1.9,.8,(x,y,backbottom+.32)","1.9,.9,(x,y,backbottom+.35)")
src=src.replace("1.65,.55,(x,y,backbottom+.30)","1.65,.70,(x,y,backbottom+.45)")
src=src.replace(".9,2.4,(x,y,backbottom+1.6)","1.0,4.0,(x,y,backbottom+2.8)")
start=src.index('# Removable fifth part:')
end=src.index('# Purely illustrative deflection',start)
src=src[:start]+"exec(compile((ROOT/'structure_v8.py').read_text(encoding='utf-8'),'structure_v8.py','exec'),globals())\n\n"+src[end:]
src=src.replace("back.name='V8 PRINT 03 | rear cover with release paddles'","back.name='V8 PRINT 02 | rear cover with integrated rails'")
src=src.replace("panel=box('V8 PRINT 04 | concealed dual-key carrier'","panel=box('V8 PRINT 03 | integrated dual key panel'")

start=src.index("edge_bond=ring('PURCHASED | V8 screen edge adhesive'")
end=src.index("back['attachment_note']",start)
src=src[:start]+"""cushion=ring('PURCHASED | V8 cut sheet screen cushion',(35.0,41.4,8.05),(33.5,39.9,7.3),top+1.17,top+1.37,black)
cushion['not_a_printed_part']=True
cushion['nominal_sheet_thickness_mm']=.2
cushion['status']='Soft stock sheet under integral stop; real glass and preload to validate.'
apply_mods(body);apply_mods(bezel)
bridge=ring('V8 integral front/body join',(W-.9,H-.9,R-3.2),(44.2,43.6,7.2),top-1.60,top-1.25,graphite)
boolean(body,bridge,'UNION')
boolean(body,bezel,'UNION')
body['screen_retention']='Integral front stop + stock cushion + full 5mm board spacer + screw-locked rear. No separate bonded front frame.'
body['new_shell_fasteners']='Four M2x6 screws into captured M2 hex nuts; nut AF4.0 H1.6, pocket AF4.2; hardware choice subject to supplier confirmation.'
body['print_part_count']=4

"""+src[end:]
src=src.replace("back['attachment_note']='Four M2 placeholder screws into underside brass pillars; verify actual threads.'","back['attachment_note']='Four outer M2x6 shell screws; four inner M2x4 standoff screws. Board top M2x4 heads accessible before fitting spacer/display.'")
src=src.replace('top+1.55-backbottom','top+2.57-backbottom')
src=src.replace('for ob in (body,bezel,back,panel,retainer):','for ob in (body,back,panel,spacer):')
start=src.index('export_parts=[');end=src.index('\nfor ob in (trim,seal,rim)',start)
src=src[:start]+"export_parts=[(body,'01_One_piece_shell_V8_PA12_Q1_mm.stl'),(back,'02_Rear_cover_with_rails_V8_NYLON_Q1_mm.stl'),(panel,'03_Dual_key_panel_V8_NYLON_Q1_mm.stl'),(spacer,'04_Board_spacer_frame_V8_PA12_Q1_mm.stl')]"+src[end:]
src=src.replace('Five main printed parts; removable internal key retainer.','Four large printed parts; integral shell, rear with rails, key panel, board spacer.')
src=src.replace('V8 requires qualified adhesive retention for the screen module; original glass and active area are unchanged.','Integral screen stop and screw-locked rear provide a mechanical retention proposal. Real glass, preload, fastener pullout and fatigue remain unvalidated.')
(ROOT/'build_v8.py').write_text(src,encoding='utf-8')
p=json.loads((V7/'case_parameters.json').read_text(encoding='utf-8'))
p.update(design_revision='Large parts V8 mechanical retention sample',print_part_count=4,
    front_glass_retaining_lip=True,screen_stop_overlap_each_side_mm=.8,
    screen_stop_nominal_thickness_mm=1.2,front_visible_aperture_mm=[33.5,39.9],
    front_top_outline_mm=[36.3,42.7],front_flat_land_nominal_mm=1.4,
    front_separate_printed_part=False,front_bond_gap_nominal_mm=0,
    removable_key_retainer=False,key_retainer_integrated_in_rear=True,
    board_spacer_is_one_large_frame=True,board_spacer_height_mm=5.0,
    shell_screw_size='M2x6 candidate',shell_nut_af_mm=4.0,shell_nut_height_mm=1.6,
    shell_nut_pocket_af_mm=4.2,shell_nut_pocket_height_mm=1.85,
    shell_screw_centres_mm=[[x,y] for x in (-19.8,19.8) for y in (-20.6,20.6)],
    board_screw_size='M2x4 candidate, upper and lower',screen_cushion_nominal_mm=.2,
    extra_height_from_v7_mm=1.02,overall_height_unchanged_from_v6=False,
    screen_module_retention='Integral stop + full spacer + rear support; adhesive not primary retention. Physical qualification pending.',
    fastener_reference='https://www.hardwarespecialty.com/Product/900882')
(ROOT/'case_parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(V7/'apple_profile.json',ROOT/'apple_profile.json')
print('Generated V8 four-large-part mechanical retention design.')
