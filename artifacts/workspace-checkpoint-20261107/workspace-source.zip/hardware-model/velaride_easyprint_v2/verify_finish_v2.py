import bpy,bmesh,json,struct,zipfile,collections
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_easyprint_v2')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_EasyPrint_V2_4parts');OUT.mkdir(parents=True,exist_ok=True)
s=bpy.data.scenes['VelaRide | EasyPrint V2 four parts'];bpy.context.window.scene=s;s.frame_set(1)
data=json.loads((ROOT/'case_verification.json').read_text())
body=next(o for o in s.objects if o.name.startswith('CASE | main body'))
back=next(o for o in s.objects if o.name.startswith('V2 PRINT 03'))
panel=next(o for o in s.objects if o.name.startswith('V2 PRINT 04'))
def bt(o):
    e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
    result=BVHTree.FromPolygons([o.matrix_world@v.co for v in m.vertices],[list(p.vertices) for p in m.polygons]);e.to_mesh_clear();return result
b=bt(body)
data['motion_checks']={}
px=panel.location.x
for frame in (1,20,65):
    s.frame_set(frame);panel.location.x=px-.01;bpy.context.view_layer.update()
    data['motion_checks']['key_panel_frame_'+str(frame)+'_excluding_mount_contact']=len(b.overlap(bt(panel)))
panel.location.x=px;s.frame_set(1)
data['motion_checks']['rear_at_rest']=len(b.overlap(bt(back)))
for k in back.data.shape_keys.key_blocks:
    if k.name!='Rest':k.value=1
bpy.context.view_layer.update()
data['motion_checks']['rear_release_at_0p7mm']=len(b.overlap(bt(back)))
for k in back.data.shape_keys.key_blocks:k.value=0
bpy.context.view_layer.update()
hw=next(c for c in s.collection.children if c.name.startswith('EASYV2_02'))
data['hardware_body_intersections']=[o.name for o in hw.objects if o.type=='MESH' and b.overlap(bt(o))]
data['clearance_stack_example_mm']={'nominal_per_side':.7,'two_size_errors_of_0p15':.55,'with_additional_relative_position_error_0p30':.25,'note':'Illustrative conservative dimensional stack for new contact-boss passage; not applicable to Apple band profile.'}

for p in data['parts']:
    o=s.objects[p['name']];e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
    bm=bmesh.new();bm.from_mesh(m);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    todo=set(bm.verts);components=0
    while todo:
        components+=1;stack=[todo.pop()]
        while stack:
            v=stack.pop()
            for edge in v.link_edges:
                w=edge.other_vert(v)
                if w in todo:todo.remove(w);stack.append(w)
    assert components==1,(p['name'],components)
    assert all(edge.is_manifold for edge in bm.edges),p['name']
    bm.to_mesh(m);bm.free();m.calc_loop_triangles()
    verts=[o.matrix_world@v.co for v in m.vertices]
    lo=Vector([min(v[a] for v in verts) for a in range(3)]);hi=Vector([max(v[a] for v in verts) for a in range(3)])
    offset=Vector(((lo.x+hi.x)/2,(lo.y+hi.y)/2,lo.z));verts=[v-offset for v in verts]
    records=[];edges=collections.Counter()
    for tri in m.loop_triangles:
        vv=[verts[i] for i in tri.vertices];nn=(vv[1]-vv[0]).cross(vv[2]-vv[0]).normalized()
        raw=struct.pack('<12fH',*nn,*vv[0],*vv[1],*vv[2],0);r=struct.unpack('<12fH',raw);pts=[tuple(r[k:k+3]) for k in (3,6,9)]
        if len(set(pts))<3:continue
        records.append(raw)
        for a,c in ((pts[0],pts[1]),(pts[1],pts[2]),(pts[2],pts[0])):edges[tuple(sorted((a,c)))]+=1
    bad=sum(count!=2 for count in edges.values());assert bad==0,(p['name'],bad)
    path=OUT/p['stl'];path.write_bytes(b'VelaRide EasyPrint V2 PA12 Q1 millimetres prototype'.ljust(80,b' ')+struct.pack('<I',len(records))+b''.join(records))
    p.update(connected_components=components,dimensions_mm=[round(v,3) for v in hi-lo],stl_triangles=len(records),serialized_nonmanifold_edges=bad,quantity=1)
    e.to_mesh_clear()
(ROOT/'case_verification.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
with zipfile.ZipFile(OUT.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in data['parts']:z.write(OUT/p['stl'],p['stl'])
with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:assert z.testzip() is None and len(z.namelist())==4

strap=next(c for c in s.collection.children if c.name.startswith('EASYV2_03'))
strap.hide_render=True
s.render.filepath=str(ROOT/'easyprint_v2_case_only.png');bpy.ops.render.render(write_still=True)
cam=s.camera;original=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale)
# Rear view makes the large integrated releases visible.
floor=next(o for o in s.objects if o.name.startswith('Watch studio floor'));floor.hide_render=True
cam.location=(-65,-90,-105);cam.rotation_euler=(Vector((0,0,-3))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=85
s.render.filepath=str(ROOT/'easyprint_v2_rear.png');bpy.ops.render.render(write_still=True)
floor.hide_render=False;cam.location=original[0];cam.rotation_euler=original[1];cam.data.ortho_scale=original[2]
strap.hide_render=False;s.render.filepath=str(ROOT/'easyprint_v2_hero.png');bpy.ops.render.render(write_still=True)
s.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_easyprint_v2.blend'))
print(json.dumps({'motion':data['motion_checks'],'hardware':data['hardware_body_intersections'],'parts':[(p['stl'],p['dimensions_mm']) for p in data['parts']],'zip':str(OUT.with_suffix('.zip'))}))
