TRACK=r'''
AP=json.loads((ROOT/'apple_profile.json').read_text(encoding='utf8'))
NOMINAL=AP['profile_nominal'];track_y=23.5;track_z=-3.0;latch_y=25.515
def profile_prism(name,points,span,sy,material=None):
    n=len(points);v=[(x,sy*(track_y+u),track_z+z) for x in (-span/2,span/2) for u,z in points]
    f=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name,v,f,material);bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free();return o
def cut_track(target,sy,clearance):
    boolean(target,profile_prism('Profile tool',AP['profile_clearance_'+str(clearance)],54,sy))
    boolean(target,box('Band neck exit',(54,7,2.75),(0,sy*29.3,track_z),None,r=0))
    pocket=rounded('Latch pocket',5.55,2.3,1.3,1.1,-4.94,None,None);pocket.location.y=sy*latch_y;apply_mods(pocket);boolean(target,pocket)
    boolean(target,box('Release stem roomy guide',(5.4,2.8,6),(0,sy*latch_y,-6.9),None,r=0))
    # Recess above the integrated rear flexures, so the return arms can rise.
    boolean(target,box('Release arm movement recess',(27,5.2,2.1),(0,sy*latch_y,-7.0),None,r=0))
for sy in (-1,1):
    wall=box('Release chamber isolation rib',(28,1.3,1.2),(0,sy*21.85,-6.05),graphite,r=0)
    boolean(body,wall,'UNION')
    cut_track(body,sy,P['slide_radial_clearance_mm'])
body['interface_note']='Apple large profile unchanged in scale. Test actual purchased band; large general clearances do not apply to band lock.'
'''

HOLES=r'''
buttonz=-1.670586;usby=P['usb_y_mm'];usbz=-P['usb_z_mm']
key_y=(P['button_1_y_mm'],P['button_2_y_mm']);panel_y=sum(key_y)/2
for yy in key_y:
    boolean(body,box('Large contact boss passage',(10,5.2,4.8),(-22,yy,buttonz),None,r=0))
    for sy in (-1,1):
        boolean(body,box('Fixed stop seating pocket',(1.6,2.6,2.1),(-22.9,yy+sy*3.5,.6),None,r=0))
# Large side panel screws; clearance holes, no resin-printed threads.
for yy in (panel_y-12,panel_y+12):
    for zz in (-5.4,5.6):
        boolean(body,cyl_x('Side panel M2 clearance',1.4,8,(-22,yy,zz)))
        tool=cyl_x('M2 nut access pocket',2.75,2.3,(-19.8,yy,zz),None,n=6);boolean(body,tool)
'''

PANEL=r'''
# Correct original tactile switch axis; no microscopic sliding piston system.
for orig,o in list(coremap.items()):
    if orig.name in ('SW1 actuator','SW2 actuator'):bpy.data.objects.remove(o,do_unlink=True)
    elif orig.name.startswith(('core_pcb SW1 |','core_pcb SW2 |')):
        o.location.x-=.3;o.location.z=1.670586;o.scale.y=2/2.6;o.scale.z=2.2/2.6
panel=box('V2 PRINT 04 | integrated dual-key panel',(2.4,30,19),(-24.2,panel_y,-.15),graphite,r=.6);apply_mods(panel)
for idx,yy in enumerate(key_y,1):
    boolean(panel,box('Open flexure window',(7,7.6,14.5),(-24.2,yy,-.65),None,r=0))
    leaf=box('Continuous nylon key leaf',(1.2,4.8,14.2),(-24.4,yy,.5),graphite,r=.1);apply_mods(leaf);boolean(panel,leaf,'UNION')
    cap=box('Integral finger pad',(2.4,6,6.2),(-25.6,yy,buttonz),graphite,r=.7);apply_mods(cap);boolean(panel,cap,'UNION')
    boss=box('Integral broad contact boss',(4.8,3.8,3.4),(-21.65,yy,buttonz),graphite,r=.25);apply_mods(boss);boolean(panel,boss,'UNION')
    # Fixed stops flank each finger pad, clear of the contact boss.
    for sy in (-1,1):
        stop=box('Integral overtravel shoulder',(1.0,2.0,1.5),(-23.15,yy+sy*3.5,.6),graphite,r=.08);apply_mods(stop);boolean(panel,stop,'UNION')
    # Stock soft pad is cut from sheet, not a separate printed micro-part.
    pad=box('PURCHASED | silicone contact pad '+str(idx),(.8,3.2,2.8),(-18.85,yy,buttonz),rubber,r=.18)
    pad['purchase_note']='Cut from stock silicone sheet; 0.5/0.8/1.0 mm options, tune assembled rest gap 0.2-0.4 mm.'
    colsave=col;col=hardwarecol
    cyl_x('V2 hardware | switch actuator '+str(idx),1.05,.6,(-17.79518,yy,buttonz),black,48)
    col=colsave
for yy in (panel_y-12,panel_y+12):
    for zz in (-5.4,5.6):
        boolean(panel,cyl_x('Panel M2 through hole',1.4,5,(-24.2,yy,zz)))
        screw=cyl_x('PURCHASED | side panel M2 screw head',1.7,1.1,(-25.85,yy,zz),steel,32)
        cyl_x('PURCHASED | side panel screw shank',.95,5.5,(-22.65,yy,zz),steel,24)
bevel(panel,.07,2)
panel['material']='Unfilled PA12 or PA11 nylon. Do not substitute ordinary rigid/brittle ESD resin without fatigue qualification.'
panel['flexure_thickness_mm']=1.2;panel['free_flexure_length_mm']=14.2
panel['contact_boss_side_clearance_mm']=.7;panel['nominal_stop_stroke_mm']=.75
panel['pad_adjustment']='Stock sheet pads set rest gap; no 0.03 mm precision stack required.'

# Release buttons become part of the large rear cover. Side slots keep them free
# while two long nylon arms guide and return each pad.
apply_mods(back)
for sy in (-1,1):
    yy=sy*latch_y
    boolean(back,box('Rear release open window',(24,6.0,6),(0,yy,-8.0),None,r=0))
    paddle=box('Integral release paddle',(8.8,4.2,2.0),(0,yy,-8.1),rear_mat,r=.3);apply_mods(paddle)
    for sx in (-1,1):
        arm=box('Release nylon return arm',(9.0,2.2,1.2),(sx*8.3,yy,-7.65),rear_mat,r=.1);apply_mods(arm);boolean(paddle,arm,'UNION')
    stem=box('Large printable release stem',(4.0,1.4,2.0),(0,yy,-6.15),rear_mat,r=.12);apply_mods(stem);boolean(paddle,stem,'UNION')
    boolean(back,paddle,'UNION')
bevel(back,.06,2)
back.name='V2 PRINT 03 | rear cover with release paddles'
back['integrated_release_flexure_thickness_mm']=1.2
back['release_paddle_mm']=[8.8,4.2,2.0]
back['release_stem_clearance_mm']=[.7,.7]
back['release_stroke_estimate_mm']=.7
back['material']='PA12/PA11 nylon; fatigue, band lock and return not physically validated.'

# Purely illustrative deflection, fixed roots remain fixed. Not an FEA result.
apply_mods(panel);apply_mods(back)
panel.shape_key_add(name='Rest')
for idx,yy in enumerate(key_y,1):
    k=panel.shape_key_add(name='Key '+str(idx)+' demonstration')
    for i,v in enumerate(panel.data.vertices):
        p=panel.matrix_world@v.co
        is_leaf=abs(p.y-yy)<2.5 and p.x<-23.7 and -7.1<p.z<6.61
        is_cap=abs(p.y-yy)<3.1 and p.x<-24.3 and abs(p.z-buttonz)<3.2
        is_boss=abs(p.y-yy)<2.0 and -24.1<p.x<-19.1 and abs(p.z-buttonz)<1.8
        if is_leaf or is_cap or is_boss:
            weight=min(1,max(0,(6.6-p.z)/(6.6-buttonz)))**2 if is_leaf else 1
            k.data[i].co.x+=.6*weight
    for fr,val in [(1,0),(10 if idx==1 else 55,0),(20 if idx==1 else 65,1),(35 if idx==1 else 80,0),(100,0)]:
        k.value=val;k.keyframe_insert(data_path='value',frame=fr)
back.shape_key_add(name='Rest')
for sy in (-1,1):
    k=back.shape_key_add(name='Release '+str(sy)+' demonstration')
    for i,v in enumerate(back.data.vertices):
        p=back.matrix_world@v.co
        if abs(p.y-sy*latch_y)<2.5 and abs(p.x)<12.4:
            weight=1 if abs(p.x)<4.4 else max(0,1-(abs(p.x)-4.4)/8.0)**2
            k.data[i].co.z+=.7*weight
    k.value=0
'''
