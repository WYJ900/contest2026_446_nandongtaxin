from pathlib import Path
import json,shutil,sys
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'velaride_apple_slide'
sys.path.insert(0,str(OLD))
from variant_sections import STRAP,COUPONS
from sections import TRACK,HOLES,PANEL
p=json.loads((OLD/'case_parameters.json').read_text(encoding='utf8'))
p.update(case_width_mm=46.0,overall_case_length_mm=62.8,slide_radial_clearance_mm=.12,
    print_part_count=4,flexure_thickness_mm=1.2,side_panel_frame_thickness_mm=2.4,
    boss_side_clearance_mm=.7,rest_gap_target_mm=[.2,.4],button_pad_stock_thickness_mm=[.5,.8,1.0],
    recommended_material='PA12 or PA11 unfilled nylon',design_revision='EasyPrint V2',
    button_nominal_stop_stroke_mm=.75)
for k in ['button_hard_travel_mm','button_rest_gap_mm']:p.pop(k,None)
(ROOT/'case_parameters.json').write_text(json.dumps(p,indent=2),encoding='utf8')
shutil.copy2(OLD/'apple_profile.json',ROOT/'apple_profile.json')
s=(OLD/'build_apple_slide.py').read_text(encoding='utf8')
s=s.replace('/velaride_apple_slide\'','/velaride_easyprint_v2\'').replace('VelaRide | Apple slide and working keys','VelaRide | EasyPrint V2 four parts').replace('APPLE_','EASYV2_')
def section(a,b,new):
 global s
 i=s.index(a);j=s.index(b,i);s=s[:i]+new+'\n'+s[j:]
section('# Official Apple R3 cross-section','# Main-board component face',TRACK)
section('buttonz=-P[','usbcut=',HOLES)
section('# Correct original switch geometry','# The brass standoffs',PANEL)
s=s.replace('backbottom=backtop-1.65','backbottom=backtop-2.4')
s=s.replace('[(bottom,W-1,57.4,R-.5),(bottom+.75,W,58.8,R),(-1.0,W,58.8,R),(2.0,W,54.0,R),(top,W-1,H-1,R-.5)]','[(bottom,W-1,61.4,R-.5),(bottom+.75,W,62.8,R),(-1.0,W,62.8,R),(2.0,W,55.0,R),(top,W-1,H-1,R-.5)]')
s=s.replace("W-.3,H-.3,backtop-backbottom","W-.3,62.0,backtop-backbottom")
s=s.replace('top+1.25,top+1.5','top+1.25,top+2.45')
s=s.replace("body['assembly_height_mm']=top+1.5-backbottom","body['assembly_height_mm']=top+2.45-backbottom")
s=s.replace("frame_end=180","frame_end=100")
s=s.replace("camdata.ortho_scale=90","camdata.ortho_scale=98")
s=s.replace("'Watch | satin graphite',(.095,.111,.14),.84,.25","'V2 | matte nylon',(.055,.065,.08),.15,.42")
s=s.replace("for ob in (body,bezel,trim,back):","for ob in (body,bezel,back,panel):")
a=s.index("validation={'parameters':P");b=s.index("for o,filename in export_parts:",a)
s=s[:a]+"""validation={'parameters':P,'body_height_including_glass_mm':round(top+2.45-backbottom,3),'parts':[],'fit_verified':False}
export_parts=[(body,'01_main_case_PA12_Q1_mm.stl'),(bezel,'02_front_frame_PA12_Q1_mm.stl'),(back,'03_back_with_releases_PA12_Q1_mm.stl'),(panel,'04_dual_key_panel_PA12_Q1_mm.stl')]
for ob in (trim,seal,rim):ob.hide_render=True;ob.hide_set(True)
"""+s[b:]
s=s.replace("'apple_slide_hero.png'","'easyprint_v2_hero.png'").replace('velaride_apple_slide.blend','velaride_easyprint_v2.blend')
a=s.index("note=bpy.data.texts.new(");b=s.index('bpy.ops.object.select_all',a)
s=s[:a]+"note=bpy.data.texts.new('EASYPRINT_V2_NOTES.txt');note.write('Four main printed parts. Larger PA12/PA11 nylon flexures; no tiny sliding pistons or 0.28 mm stops. Use cut stock silicone pads to tune key contact. Band interface still requires a real-band test. Animation is illustrative, not fatigue or force validation. Purchased bands, screws, nuts and pads are not exported. See README.txt.')\n"+s[b:]
(ROOT/'build_v2.py').write_text(s,encoding='utf8')
print('Generated V2 builder')
