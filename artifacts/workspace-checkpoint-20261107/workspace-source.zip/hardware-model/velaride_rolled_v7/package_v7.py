"""Package V7 with equal-scale shape comparisons and verified print meshes."""
from pathlib import Path
import json,shutil,hashlib,zipfile
from html.parser import HTMLParser

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_rolled_v7')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V7_Engineering_Package')
report=json.loads((ROOT/'verification_v7.json').read_text(encoding='utf-8'))
metrics=json.loads((ROOT/'rolled_comparison_metrics.json').read_text(encoding='utf-8'))
labels=['主壳','窄平边圆弧前框','后盖及表带释放机构','内藏双按键板','可拆内压架']
for p,label in zip(report['parts'],labels):
    p.update(name_zh=label,quantity=1)
    assert hashlib.sha256((OUT/p['file']).read_bytes()).hexdigest()==p['sha256']
    for k in ('sampled_under_1mm','serialized_bad_edges','serialized_zero_area_faces','nonadjacent_self_overlap_candidates'):assert p[k]==0,(p['file'],k)
    assert p['components']==1 and p['sampled_minimum_mm']>=1.199
    shutil.copy2(OUT/p['file'],ROOT/Path(p['file']).name)
assert not any(report['surface_intersections'].values())
assert not any(any(v.values()) for v in report['key_motion_surface_intersections'].values())
assert not any(report['release_motion_surface_intersections'].values())
for k in ('hardware_body_surface_intersections','hardware_front_surface_intersections','hardware_retainer_surface_intersections'):assert not report[k],k
for k in ('carrier_installation_stage_1_rear_entry_x_plus_6mm','carrier_installation_stage_2_lateral_seating'):assert not any(report[k].values())
assert not any(any(v.values()) for v in report['retainer_installation_from_rear'].values())
(OUT/'SOURCE').mkdir(exist_ok=True)
shutil.copy2(ROOT/'velaride_rolled_v7.blend',OUT/'SOURCE/velaride_rolled_v7.blend')
shutil.copy2(ROOT/'case_parameters.json',OUT/'SOURCE/case_parameters.json')
(OUT/'02_五件清单与检查.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

notes='''VelaRide V7 — 窄平边、圆弧下收版
2026-10-11；单位 mm；5 件，各 1 个；V5/V6 源文件保持不变。

这次修改针对左右边框的实体截面，不是只换颜色。
01. 玻璃旁顶面平边：由 V6 的每侧约 5.45 mm 收窄到名义 1.40 mm。
02. 顶部外轮廓：38.4×44.8 mm，屏幕开口仍为 35.6×42.0 mm。
03. 左右外侧通过约 4.35 mm 水平距离、2.90 mm 高度的连续圆弧落向侧壁。
04. 主壳与前框接合面下移 1.50 mm；前框最高点和整机高度不增加。
05. 前框内腔四角补足材料，并将主壳内部导轨根部顶部降低 0.40 mm，避开弧面内腔。
06. 保留原屏幕、发光区、界面大小和两块 PCB 的 5 mm 净距；主壳包络仍为 48×60.8 mm。

尺寸口径
1.40 mm 指玻璃旁的水平顶面，不是“发光区域到整机外缘的全部黑边”。
原屏幕玻璃自带黑边仍在，向侧面下落的弧面也仍占据投影面积。
V7 的改变是让原先宽而平的边框成为窄顶边与圆润侧沿，不能把它解读为发光面积变大。

本次复核
实际导出的五件 STL 均为单一连通封闭实体；无非流形边、零面积三角面，未检出非相邻三角面自相交候选。
最小法向壁厚抽检：主壳约 1.20 mm，圆弧前框约 1.216 mm，后盖约 1.20 mm，按键板约 1.20 mm，内压架约 1.40 mm。
五件静止位置未检出表面相交；现有电子件与主壳、前框、内压架未检出表面相交。
按键 12 个演示姿态、后盖释放 5 个姿态、按键板两阶段入壳和内压架后装抽样检查通过。
这些是模型级抽检，不是连续碰撞证明、完整公差分析、力学/疲劳仿真或实物质量认证。

加工与装配
五件必须整套使用 V7；主壳和前框接合面已改变，不能混用 V6 主壳或前框。
沿用 V6 的屏幕模块胶接待验证方案。不存在已验证的上压式玻璃防脱唇。
图中的边胶为示意包络，实际玻璃尺寸、胶种、表面处理、点胶量和胶接强度必须由首件验证。
01/02/05 候选未填充 PA12；03/04 含弹性机构，优先评估未填充韧性 PA11，PA12 替代须验证回弹及疲劳。
只有 STL_5_PARTS 内的 5 件打印；屏幕、表带、电子板、铜柱、螺钉、接触垫和胶层均不打印。
电池/线束空间、铜柱螺纹、胶接及整机耐久仍未完成实物验证；本包属于工程打样方案。
'''
(OUT/'00_先读_V7形状修改与状态.txt').write_text(notes,encoding='utf-8')

vendor='''VelaRide V7 五件尼龙工程样机，请先复检并报价。
单位 mm，各 1 件，不与 V6 混配；特别注意 01 主壳与 02 圆弧前框的接合面已变更。
01/02/05 采用未填充 PA12 候选；03/04 弹性机构优先评估未填充韧性 PA11，PA12 替代需先验证。
请勿直接替换普通人偶树脂、金属或整件 TPU。
02 的窄平边名义 1.4 mm，圆弧下收面属于零件本体，不是支撑，不能删除或打磨成平面。
请用贵司壁厚检查软件按最低 1.0 mm 重新扫描五件；红区需返回零件名、位置及测量值。
请明确打印设备/工艺、材料牌号、摆放方向、尺寸公差和后处理；喷砂、染色、涂层不得堵塞滑槽、按键孔或改变胶接界面。
屏幕模块和前框仍需确定胶接工艺及验证；渲染中的玻璃黑边与尼龙表面光泽匹配并非实物保证。
表带接口须使用客户实际采购件进行锁止、释放和抗拉试验；不要整体缩放模型补偿配合。
本包是工程样机版本，实际装配、胶接及耐久通过前不作为定型批产图。
本说明供用户自行转发，尚未向厂家发送。
'''
(OUT/'01_可转发厂家_复检要求.txt').write_text(vendor,encoding='utf-8')
assembly='''V7 装配顺序
1. 先不装前框、后盖、内压架和电子板。
2. 按键板相对最终位置向内（+X）偏移 6 mm，从后方进入；到最终高度后沿 -X 横向推入两个侧孔。
3. 将 05 内压架从后方装入，再试配电子件、接触垫、线束和屏幕模块。
4. 后盖内侧长槽定位内压架横梁，采用已确认与铜柱匹配的螺钉固定。
5. 试装圆弧前框，确认胶接间隙与点胶方式；只有屏幕模块和前框的胶接工艺明确后才实施粘接。
6. 检验屏幕固定、按键静止不误触/按压回弹、表带锁止/释放、接缝和胶接强度。
屏幕玻璃、电池、线束、铜柱螺纹及完整电子件装配路径仍需实物确认。
'''
(OUT/'03_装配顺序.txt').write_text(assembly,encoding='utf-8')

page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>V7 窄平边与圆弧下收</title><style>
*{box-sizing:border-box}body{margin:0;background:#eef2f4;color:#19303d;font:16px/1.7 'Microsoft YaHei',sans-serif}main{max-width:1160px;margin:auto;padding:40px 24px}h1{font-size:36px;margin:8px 0}h2{margin-top:34px}.tag{background:#d4e8df;padding:4px 14px;border-radius:20px;display:inline-block}.muted{color:#587080}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}figure{margin:0;background:white;padding:12px;border-radius:14px}img{width:100%;border-radius:10px}figcaption{padding:8px}.note{padding:18px;background:#fff1d8;border-left:4px solid #b78131}.buttons{display:flex;gap:10px;margin:18px 0}button{font:inherit;padding:8px 20px;background:white;border:1px solid #276454;border-radius:8px;cursor:pointer}.selected{background:#276454;color:white}a{color:#17695c}table{width:100%;border-collapse:collapse;background:white}th,td{padding:12px;text-align:left;border-bottom:1px solid #dde5e9}th{background:#dfe9ed}@media(max-width:720px){main{padding:24px 14px}.grid{grid-template-columns:1fr}h1{font-size:28px}th,td{padding:8px;font-size:14px}}
</style><main><span class="tag">V7 · 窄顶边、圆弧下收</span><h1>把左右宽平边，真正改成圆润侧沿</h1><p class="muted">相同屏幕、相同整体高度。顶部紧贴玻璃的平边收窄，外侧连续向下圆弧过渡。</p>
<div class="buttons"><button id="hero" class="selected" onclick="setView('hero')">斜视</button><button id="top" onclick="setView('top')">俯视</button><button id="profile" onclick="setView('profile')">轮廓侧视</button></div>
<div class="grid"><figure><img id="before" src="REFERENCE/V6_hero.png" alt="V6 宽平边"><figcaption><strong>V6</strong>：每侧约 5.45 mm 顶部平边</figcaption></figure><figure><img id="after" src="REFERENCE/V7_hero.png" alt="V7 窄平边圆弧"><figcaption><strong>V7</strong>：名义 1.4 mm 窄顶边，外侧弧面下落</figcaption></figure></div>
<h2>具体改了截面</h2><table><tr><th>位置</th><th>V6</th><th>V7</th></tr><tr><td>玻璃旁顶部平边 / 每侧</td><td>约 5.45 mm</td><td>名义 1.40 mm</td></tr><tr><td>顶部外轮廓宽</td><td>46.5 mm</td><td>38.4 mm</td></tr><tr><td>外側过渡</td><td>宽平面、小倒角</td><td>约 4.35 mm 横向圆弧过渡</td></tr><tr><td>最高点与屏幕位置</td><td>原高度</td><td>保持相同</td></tr><tr><td>主壳正面包络</td><td>48 × 60.8 mm</td><td>保持相同</td></tr></table>
<p class="muted">1.4 mm 指顶部水平窄边，不能理解为整机所有可见黑边只有 1.4 mm。原屏幕黑边和下落弧面仍在，实际发光区保持不变。</p>
<h2>从侧面看圆弧最清楚</h2><figure><img src="REFERENCE/V7_profile.png" alt="V7 圆弧侧面"><figcaption>接合面下移，内部四角补足厚度；没有把整机叠高。</figcaption></figure>
<h2>结构复核</h2><p>前框最小法向壁厚抽检约 <strong>1.216 mm</strong>；五件均通过封闭性、连通性、零面积面及自相交候选检查。主壳/前框/现有电子件与按键运动、装配路径的抽样表面避让检查通过。</p>
<div class="note"><strong>仍为工程打样方案。</strong><p>沿用 V6 的待验证胶接固定方案；需要确认实际玻璃尺寸、胶种及胶接强度。模型检查不能替代首件装配与耐久测试。</p></div>
<h2>文件</h2><ul><li><a href="SOURCE/velaride_rolled_v7.blend">V7 Blender 源文件</a></li><li><a href="00_先读_V7形状修改与状态.txt">修改细节与验证范围</a></li><li><a href="02_五件清单与检查.json">五件尺寸和检查数据</a></li><li><a href="01_可转发厂家_复检要求.txt">厂家复检说明</a></li><li><a href="03_装配顺序.txt">装配顺序</a></li></ul></main>
<script>function setView(v){document.getElementById('before').src='REFERENCE/V6_'+v+'.png';document.getElementById('after').src='REFERENCE/V7_'+v+'.png';for(const id of ['hero','top','profile'])document.getElementById(id).classList.toggle('selected',id===v)}</script></html>'''
(OUT/'V6_V7_窄边圆弧对比.html').write_text(page,encoding='utf-8')
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        self.links.extend(v for k,v in attrs if k in ('src','href') and not v.startswith(('http:','https:','#')))
p=Links();p.feed(page)
assert all((OUT/x).exists() for x in p.links)
for rev in ('V6','V7'):
    for view in ('top','hero','profile'):assert (OUT/f'REFERENCE/{rev}_{view}.png').exists()
manifest={'revision':'V7','production_release':False,'files':[]}
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='package_manifest.json':manifest['files'].append({'path':path.relative_to(OUT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
(OUT/'package_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None and len([n for n in z.namelist() if n.endswith('.stl')])==5
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'links_checked':len(p.links)},ensure_ascii=False))
