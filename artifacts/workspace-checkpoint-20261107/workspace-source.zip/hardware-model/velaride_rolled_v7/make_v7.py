"""V7: narrow top land and a geometrically rolled-down front perimeter."""
from pathlib import Path
import json,shutil

ROOT=Path(__file__).resolve().parent
V6=ROOT.parent/'velaride_front_v6'
source=(V6/'build_v6.py').read_text(encoding='utf-8')
for old,new in [('velaride_front_v6','velaride_rolled_v7'),('VelaRide | Front V6','VelaRide | Rolled V7'),('FRONTV6_','ROLLEDV7_'),('V6 PRINT','V7 PRINT'),('front_v6_','rolled_v7_'),('V6','V7')]:
    source=source.replace(old,new)

start=source.index('def refined_front_sections(top):')
end=source.index('\ndef loft_ring(',start)
source=source[:start]+'''def rolled_front(name,top,material):
    # The visible horizontal land is just 1.4 mm around the glass aperture.
    # The rest of the front perimeter becomes a curved descending shoulder.
    z0,z1=top-1.35,top+1.55
    outer=[]
    for i in range(65):
        theta=(math.pi/2)*i/64
        w=38.4+(W-.9-38.4)*math.cos(theta)
        h=44.8+(H-.9-44.8)*math.cos(theta)
        r=(R-3.2)+(9.55-(R-3.2))*math.sin(theta)
        outer.append((z0+(z1-z0)*math.sin(theta),w,h,r))
    # Broad lower cavity clears the existing carrier, PCB and guide roots.
    # Upper throat clears the original glass, rather than a scaled screen.
    inner=[]
    for i in range(49):
        z=z0+(z1-z0)*i/48
        t=max(0,min(1,(z-6.10)/.95));u=t*t*t*(10+t*(-15+6*t))
        inner.append((z,44.2+(35.6-44.2)*u,43.6+(42.0-43.6)*u,7.2+(8.15-7.2)*u))
    n=len(rr(*outer[0][1:]));no=len(outer);ni=len(inner)
    verts=[(x,y,z) for z,w,h,r in outer+inner for x,y in rr(w,h,r)]
    faces=[]
    for k in range(no-1):
        for i in range(n):
            j=(i+1)%n;faces.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
    base=no*n
    for k in range(ni-1):
        for i in range(n):
            j=(i+1)%n;faces.append((base+k*n+j,base+k*n+i,base+(k+1)*n+i,base+(k+1)*n+j))
    for i in range(n):
        j=(i+1)%n
        faces.append((j,i,base+i,base+j))
        faces.append(((no-1)*n+i,(no-1)*n+j,base+(ni-1)*n+j,base+(ni-1)*n+i))
    obj=mesh(name,verts,faces,material)
    obj['top_flat_land_mm']=1.4
    obj['outer_roll_horizontal_each_side_mm']=(W-.9-38.4)/2
    obj['screen_not_scaled']=True
    return obj
''' +source[end:]
old="(2.0,W,55.0,R),(top,W-1,H-1,R-.5)],inside,graphite)"
assert old in source
source=source.replace(old,"(2.0,W,55.0,R),(top-1.5,W-1,H-1,R-.5)],inside,graphite)")
source=source.replace("(2.8,1.8,11.8),(-19.4,panel_y+sy*15.5,-.3)","(2.8,1.8,11.4),(-19.4,panel_y+sy*15.5,-.5)")
old="bezel=loft_ring('CASE | front bezel',refined_front_sections(top),window,graphite)"
assert old in source
source=source.replace(old,"bezel=rolled_front('CASE | front bezel',top,graphite)")
source=source.replace("bevel(bezel,.08,3)","bevel(bezel,.045,3)")
source=source.replace("V7 near-flush front: no overhanging glass retention lip.","V7 rolled narrow rim: no overhanging glass retention lip.")
source=source.replace('1.4-mm-deep ring','rolled annular shell')
(ROOT/'build_v7.py').write_text(source,encoding='utf-8')
p=json.loads((V6/'case_parameters.json').read_text(encoding='utf-8'))
p.update(design_revision='Rolled V7 narrow top rim',front_bezel_height_mm=2.9,
         front_flat_land_nominal_mm=1.4,front_top_outline_mm=[38.4,44.8],
         front_base_outline_mm=[47.1,46.5],front_side_roll_horizontal_mm=4.35,
         front_roll_drop_mm=2.9,front_joint_lowered_mm=1.5,
         overall_height_unchanged_from_v6=True)
(ROOT/'case_parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(V6/'apple_profile.json',ROOT/'apple_profile.json')
check=(V6/'check_export_v6.py').read_text(encoding='utf-8')
for old,new in [('velaride_front_v6','velaride_rolled_v7'),('VelaRide | Front V6','VelaRide | Rolled V7'),('FRONTV6_','ROLLEDV7_'),('V6','V7'),('v6','v7')]:check=check.replace(old,new)
check=check.replace("'retainer':len(tree(retainer).overlap(tree(panel)))", "'retainer':len(tree(retainer).overlap(tree(panel))),'front':len(tree(bezel).overlap(tree(panel)))")
mark="report['hardware_body_surface_intersections']="
check=check.replace(mark,"report['hardware_front_surface_intersections']=[o.name for o in hw.objects if o.type=='MESH' and tree(bezel).overlap(tree(o))]\n"+mark)
(ROOT/'check_export_v7.py').write_text(check,encoding='utf-8')
print('Generated V7: 1.4 mm top land, 4.35 mm rolled side shoulder.')
