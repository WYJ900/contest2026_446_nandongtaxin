"""Render matched V6/V7 views of the real rolled geometry."""
import bpy,json
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_rolled_v7')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V7_Engineering_Package')
(OUT/'REFERENCE').mkdir(exist_ok=True)
metrics={}
for rev,name in [('V6','VelaRide | Front V6'),('V7','VelaRide | Rolled V7')]:
    s=bpy.data.scenes[name];bpy.context.window.scene=s;s.frame_set(1)
    cam=s.camera;floor=next(o for o in s.objects if o.name.startswith('Watch studio floor'))
    strap=next(c for c in s.collection.children if c.name.endswith('_03_Purchased_strap_preview'))
    saved=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale,s.render.resolution_x,s.render.resolution_y,s.render.resolution_percentage,s.render.filepath,strap.hide_render,floor.hide_render)
    active=next(o for o in s.objects if o.name.startswith('WatchHW | AMOLED active area'))
    body=next(o for o in s.objects if o.name.startswith('CASE | main body'))
    frame=next(o for o in s.objects if o.name.startswith('CASE | front bezel'))
    metrics[rev]={'screen_active_dimensions_mm':[round(v,5) for v in active.dimensions],
        'body_xy_mm':[round(v,5) for v in body.dimensions[:2]],
        'top_flat_side_land_nominal_mm':5.45 if rev=='V6' else 1.4,
        'top_rim_outer_width_nominal_mm':46.5 if rev=='V6' else 38.4,
        'front_top_z_mm':max((frame.matrix_world@Vector(c)).z for c in frame.bound_box)}
    s.render.resolution_percentage=100;s.render.resolution_x=1400;s.render.resolution_y=1400
    cam.location=(0,0,150);cam.rotation_euler=(0,0,0);cam.data.ortho_scale=74;strap.hide_render=False
    s.render.filepath=str(OUT/'REFERENCE'/f'{rev}_top.png');bpy.ops.render.render(write_still=True)
    strap.hide_render=True
    cam.location=(-74,-108,126);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=85
    s.render.resolution_x=1400;s.render.resolution_y=1300
    s.render.filepath=str(OUT/'REFERENCE'/f'{rev}_hero.png');bpy.ops.render.render(write_still=True)
    floor.hide_render=True
    cam.location=(0,-160,0);cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=62
    s.render.resolution_x=1600;s.render.resolution_y=700
    s.render.filepath=str(OUT/'REFERENCE'/f'{rev}_profile.png');bpy.ops.render.render(write_still=True)
    cam.location,cam.rotation_euler,cam.data.ortho_scale,s.render.resolution_x,s.render.resolution_y,s.render.resolution_percentage,s.render.filepath,strap.hide_render,floor.hide_render=saved
assert metrics['V6']['screen_active_dimensions_mm']==metrics['V7']['screen_active_dimensions_mm']
assert abs(metrics['V6']['front_top_z_mm']-metrics['V7']['front_top_z_mm'])<.001
metrics['scope']='Top horizontal land is not the entire projected black border. The original glass black margin and the descending shoulder remain. Screen, board gap and overall front height are unchanged. Dimensions are nominal geometry; printing and adhesive retention need qualification.'
(ROOT/'rolled_comparison_metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'REFERENCE/rolled_comparison_metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
s=bpy.data.scenes['VelaRide | Rolled V7'];bpy.context.window.scene=s
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        sp=area.spaces.active;sp.region_3d.view_rotation=s.camera.rotation_euler.to_quaternion()
        sp.region_3d.view_location=(0,0,0);sp.region_3d.view_distance=86;sp.overlay.show_overlays=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_rolled_v7.blend'))
print(json.dumps(metrics,ensure_ascii=False))
