import collections,html,json,math,shutil,struct,zipfile,hashlib
from pathlib import Path

SRC=Path(__file__).resolve().parent
ROOT=SRC.parents[1]/'exports'
OUT=ROOT/'VelaRide_Case_Quote_20261010_v1'
data=json.loads((OUT/'package_manifest.json').read_text(encoding='utf8'))
parts=data['parts']

# Float32 STL serialization can collapse extremely short tessellation edges.
# Remove only triangles with coincident stored vertices; this changes no surface
# extent or fit dimensions and restores their neighbouring edge incidence.
for p in parts:
    path=OUT/p['file'];buf=path.read_bytes();n=struct.unpack_from('<I',buf,80)[0]
    good=[];removed=0
    for i in range(n):
        raw=buf[84+50*i:134+50*i];r=struct.unpack('<12fH',raw)
        vv=[tuple(r[k:k+3]) for k in (3,6,9)]
        if len(set(vv))<3:removed+=1
        else:good.append(raw)
    if removed:
        path.write_bytes(buf[:80]+struct.pack('<I',len(good))+b''.join(good))
    p['zero_area_float32_triangles_removed']=p.get('zero_area_float32_triangles_removed',0)+removed
    p['triangle_count']=len(good);p['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
data['serialization_cleanup']='Removed triangles whose stored float32 vertices coincide; no dimensions or design changes.'
(OUT/'package_manifest.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')

brief='''VelaRide 手表外壳 — 3D 打印询价包
版本：QUOTE-20261010-v1　单位：毫米（mm）

【报价范围】只打印外壳、侧边按键及壳体上的表带释放机构。
表带由客户自行购买！本包没有表带 STL，不需要打印、采购或报价表带。
主板、屏幕、电池、螺丝、铜柱和胶水也不在本次打印报价范围。
“表带释放组件”是固定在壳体上的按钮，不是表带本体。

一、请分别报三项价格
1. 完整主体：01_PA12_MAIN + 02_TPU_MAIN，共13件，全部按文件名Q1各打印1件。
   其中PA12硬质件9件，TPU 95A软质件4件。
2. 首轮小件试装：C01+C02+C03+A04+A05+A06+B01+B03，共8件。
   用于先测试滑扣及一套侧键。与完整主体方案为分阶段/备选报价，不自动相加。
3. 可选附件：04_ACCESSORIES_OPTIONAL，共5件，请单独报价，不并入主体总价。
   极薄装饰片和垫圈可以建议薄片/胶垫替代工艺，不强制3D打印。

二、材料与外观
硬质主体：优先按未填充PA12尼龙、MJF工艺报价，SLS可另报替代方案。
外观目标：细腻哑光黑；请把打印、清粉/喷砂、染黑费用分别列出。
首次试装件与正式件如使用不同后处理，请注明可能的尺寸变化。
软质件：先按TPU 95A评估；如设备/材料不适合这些微小软零件，请给出可行替代方案。
滑槽及按键导向面不做厚喷漆；无需镜面电镀、金属喷镀或整机装配。

三、尺寸与文件使用
所有STL均为二进制STL，数值单位是mm。STL格式本身不保存可靠的单位信息，请按毫米导入。
每个文件已单独移到XY中心、最低点Z=0，没有缩放或修改设计尺寸。
当前位置不是强制打印朝向，请由工艺人员评估摆放和后处理。
文件名Q1表示1件，不要因为有两颗按键再把每个文件数量翻倍。
逐件外包尺寸、实体体积及数量见01_零件清单.html / 01_零件清单.txt。
主壳本体约42.6×58.8mm；装好前框/屏幕/后盖后厚度约16.7mm。

四、请在报价前回复的可制造性问题
这是机械试装样机，当前没有通过实物装配、回弹、拉力或寿命试验。
侧键限位片约0.28mm厚、TPU释放件含约0.5mm薄臂、软接触头约1.4mm直径，
这些零件可能超出常规PA12/TPU服务的稳定成型能力；请明确哪些做不了或需要改图。
侧键总行程0.24mm、静态间隙0.03mm；请勿把图纸尺寸当作贵司必然能达到的公差。
滑扣采用苹果大号家族轮廓，必须用客户购买的实际表带试装并确认锁住、能释放。
三种滑扣试装件是0.10/0.16/0.22mm径向配合余量，不是承诺的打印精度。
如需加厚、放大孔、改间隙、缩放或修复网格，请先说明变更；不要静默修改后直接生产。
当前用途是询价和可制造性评估，不是已验证成品的生产放行图纸。

五、现成件（不计入打印报价）
苹果大号滑扣表带：客户自购；支持44/45/46/49mm家族，旧款42mm命名需核对。
铜柱：4个，暂定M2、柱体6mm，以客户现有实物为准。
后盖螺丝：4个，暂定M2；表带释放组件螺丝：4个，暂定M1.4。长度待装配确认。
主板、屏幕、线路和电池：客户自备；电池尺寸尚未纳入完整装配验证。

六、请提供
各方案含税/运费价格、加工工艺、材料牌号、后处理、交期、最小起订量；
可承诺的尺寸精度；无法稳定成型的零件及建议调整；是否包含清粉、去支撑和小孔修整。

包内预览图已移除购买的表带。图片仅说明装配与外观，最终报价按清单分项。
'''
(OUT/'00_先读_只报外壳不含表带.txt').write_text(brief,encoding='utf-8-sig')

forward='''你好，麻烦帮我评估并报价这个手表外壳的3D打印。

注意：表带我自己买，不需要打印或采购表带；屏幕、主板、螺丝、铜柱也不包含。
主要打印外壳、侧键和壳体上的表带释放机构。

请分别报价：
① 整套主体13件：PA12硬质件9件＋TPU 95A软质件4件；
② 首轮试装小件8件；
③ 可选装饰/垫圈/防尘塞另报。

硬质壳优先MJF PA12，哑光黑，喷砂/染黑单独报价，SLS可提供替代价。
全部STL按毫米导入，每个Q1文件数量为1。

这是试装模型，有0.28mm薄限位片、微小TPU软头和弹性薄臂，请先判断哪些能稳定制作。
如果有做不了的尺寸或需要改图，请告诉我，不要自行缩放或改厚度。
请附工艺、材料牌号、尺寸精度、后处理、运费和交期，谢谢。
'''
(OUT/'02_可直接转发给打印店.txt').write_text(forward,encoding='utf-8-sig')

groups={'01_PA12_MAIN':'A 主体硬质件：9件，计入整套主体报价',
 '02_TPU_MAIN':'B 主体软质件：4件，计入整套主体报价',
 '03_FIT_TEST_OPTION':'C 滑槽试装件：3件，首轮试装另报',
 '04_ACCESSORIES_OPTIONAL':'D 可选附件：5件，不计入主体基础报价'}
notes={
 'A01':'有横向滑槽及锁止孔，需彻底清粉；装配未实测。',
 'A05':'约0.28mm薄片，请先评估最小可靠厚度。','A08':'约0.28mm薄片，请先评估最小可靠厚度。',
 'B01':'微小软头，请确认成型精度及清理可行性。','B02':'微小软头，请确认成型精度及清理可行性。',
 'B03':'这是壳体释放键，不是表带；含薄弹性臂。','B04':'这是壳体释放键，不是表带；含薄弹性臂。',
 'D01':'极薄装饰件，可取消或改薄片工艺。','D02':'约0.08mm，仅作装饰薄片形状参考。',
 'D03':'密封尚未验证，可报硅胶/胶垫替代。','D04':'密封尚未验证，可报硅胶/胶垫替代。',
 'D05':'可选防尘塞，保持可拆卸。'}
rows=[];plain=['零件清单：只含壳体侧打印件，表带客户自购；STL单位mm；各文件Q1。','']
for group,title in groups.items():
    rows.append('<tr class="group"><th colspan="7">'+html.escape(title)+'</th></tr>');plain.append(title)
    for p in parts:
        if p['group']!=group:continue
        dim=' × '.join(f'{v:.3f}' for v in p['dimensions_mm']);note=notes.get(p['id'],'')
        rows.append('<tr>'+''.join('<td>'+v+'</td>' for v in [p['id'],html.escape(p['name']),str(p['quantity']),html.escape(p['material']),dim,f"{p['volume_cm3']:.4f}",html.escape(note)])+'</tr>')
        plain.append(f"{p['id']}  {p['name']}  数量1  {p['material']}\n  尺寸XYZ(mm)：{dim}；实体体积(cm³)：{p['volume_cm3']:.6f}\n  文件：{p['file']}"+(f'\n  备注：{note}' if note else ''))
    plain.append('')
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>VelaRide 外壳打印报价清单</title>
<style>body{font:14px/1.5 "Microsoft YaHei",Arial,sans-serif;color:#18212d;margin:32px;max-width:1280px}h1{font-size:25px}p{margin:8px 0}.notice{background:#eaf5ef;border-left:5px solid #168258;padding:14px}.warning{background:#fff5dd;padding:12px}table{width:100%;border-collapse:collapse;margin-top:20px}td,th{border:1px solid #ccd4dd;padding:8px;text-align:left}thead{background:#263748;color:white}.group{background:#e9eef3}td:first-child{font-weight:bold;white-space:nowrap}small{color:#526173}.images{display:flex;gap:12px}.images img{width:48%;object-fit:contain} @media print{body{margin:12mm;font-size:10px}thead{display:table-header-group}tr{break-inside:avoid}.images{page-break-before:always}}</style>
<h1>VelaRide · 外壳打印报价清单</h1><p>QUOTE-20261010-v1 ｜ 苹果大号滑扣接口试装版 ｜ 单位：mm</p>
<div class="notice"><b>表带由客户自行购买，本包不含表带打印文件。</b><br>只报外壳、侧键和壳体上的表带释放机构。电子件、铜柱、螺丝不计入打印报价。</div>
<p><b>方案①：A+B共13件。</b> 方案②：C01–C03+A04–A06+B01+B03共8件，单独试装。D组附件另报。</p>
<p>建议PA12硬质件按MJF/可替代SLS报价；TPU 95A软质件单独评估。喷砂、染黑、运费和交期请分列。</p>
<div class="warning">当前是机械试装模型。0.28mm限位片、微小软头及薄弹性臂需要供应商先评估；不能加工时请提出替代方案。可封闭网格不等于已验证可打印或可装配。</div>
<table><thead><tr><th>编号</th><th>零件</th><th>数量</th><th>材料/工艺方向</th><th>外包XYZ / mm</th><th>体积 / cm³</th><th>备注</th></tr></thead><tbody>'''+''.join(rows)+'''</tbody></table>
<p><small>尺寸为逐件归零后的XYZ包围盒，不代表指定打印朝向。体积为模型实体体积，不含支撑、粉末损耗、计费包络或后处理。不得仅按体积推断最终价格。</small></p>
<div class="images"><img src="05_REFERENCE_IMAGES/case_only_preview.png" alt="仅外壳的装配预览"><img src="05_REFERENCE_IMAGES/slide_slot_detail.png" alt="壳体上的表带接收滑槽"></div>
<p>预览图不含自购表带。装配状态与零件数量以清单为准。</p></html>'''
(OUT/'01_零件清单.html').write_text(page,encoding='utf8')
(OUT/'01_零件清单.txt').write_text('\n'.join(plain),encoding='utf-8-sig')
shutil.copy2(SRC/'apple_slide_slot.png',OUT/'05_REFERENCE_IMAGES/slide_slot_detail.png')
shutil.copy2(SRC/'apple_slide_release_underside.png',OUT/'05_REFERENCE_IMAGES/release_buttons_underside.png')

# Re-read the actual binary STLs independently, checking closed edge incidence,
# stored bounds, and count, after zero-area float32 triangles were removed.
checks=[]
for p in parts:
    path=OUT/p['file'];buf=path.read_bytes();count=struct.unpack_from('<I',buf,80)[0]
    assert len(buf)==84+50*count,(p['id'],'STL length mismatch')
    edges=collections.Counter();lo=[math.inf]*3;hi=[-math.inf]*3
    for i in range(count):
        r=struct.unpack_from('<12fH',buf,84+i*50);vv=[tuple(r[k:k+3]) for k in (3,6,9)]
        for v in vv:
            for a in range(3):lo[a]=min(lo[a],v[a]);hi[a]=max(hi[a],v[a])
        for a,b in ((vv[0],vv[1]),(vv[1],vv[2]),(vv[2],vv[0])):edges[tuple(sorted((a,b)))]+=1
    bad=sum(n!=2 for n in edges.values())
    assert bad==0,(p['id'],'nonclosed serialized STL',bad)
    assert abs(lo[2])<.0001 and max(abs(hi[a]-lo[a]-p['dimensions_mm'][a]) for a in range(3))<.0002,p['id']
    assert hashlib.sha256(buf).hexdigest()==p['sha256']
    checks.append({'id':p['id'],'triangles':count,'edges_not_shared_by_two_faces':bad,'units':'mm','quantity':1})
assert len(list(OUT.rglob('*.stl')))==21
(OUT/'03_文件校验.json').write_text(json.dumps({'stl_count':21,'main_quantity':13,'band_files':0,'passed':True,'checks':checks},ensure_ascii=False,indent=2),encoding='utf8')

archive=ROOT/(OUT.name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert sum(n.endswith('.stl') for n in z.namelist())==21
print(json.dumps({'zip':str(archive),'zip_bytes':archive.stat().st_size,'stl_count':21,'main_parts':13,'purchased_band_included':False,'all_binary_stls_checked':True}))
