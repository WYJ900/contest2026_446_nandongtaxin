"""Sections used to generate the self-contained Apple-slide case builder."""
TRACK = r'''
# Official Apple R3 cross-section, female clearance is a prototype variable.
AP=json.loads((ROOT/'apple_profile.json').read_text(encoding='utf8'))
PROFILE=AP['profile_clearance_'+str(P['slide_radial_clearance_mm'])]
NOMINAL=AP['profile_nominal']
track_y=23.5;track_z=-3.0;latch_y=track_y+2.015

def profile_prism(name,points,span,sy,material=None):
    n=len(points)
    v=[(x,sy*(track_y+u),track_z+z) for x in (-span/2,span/2) for u,z in points]
    f=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name,v,f,material)
    bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
    return o

def cut_track(target,sy,clearance):
    boolean(target,profile_prism('Official profile female tool',AP['profile_clearance_'+str(clearance)],48,sy))
    # Neck exit to the outside; undercut is provided by the official bulb profile.
    boolean(target,box('Band neck mouth',(48,5,2.75),(0,sy*(track_y+5.8),track_z),None,r=0))
    # Central latch engages the band-owned spring catch, on the wrist-facing side.
    pocket=rounded('Latch receiving pocket',5.55,2.3,1.2,1.1,0,None,None)
    pocket.location=(0,sy*latch_y,-4.94);apply_mods(pocket);boolean(target,pocket)
    boolean(target,box('Release plunger guide',(5.2,2.0,4.8),(0,sy*latch_y,-6.3),None,r=0))
    for xx in (-9,9):boolean(target,cylinder('Release cassette pilot',.6,2.2,(xx,sy*latch_y,-6.25),None,n=24))

for sy in (-1,1):
    cut_track(body,sy,P['slide_radial_clearance_mm'])
body['interface']='Large Apple Watch 44/45/46/49 mm family; legacy 42 mm only'
body['profile_source']='Apple official R3 DWG, converted and sampled at 0.002 mm'
body['latch_source']='Apple ADG 2026-09-21 page 218; 34.92 mm male width; 3.21 mm profile height'
release_parts=[]
for sy in (-1,1):
    # Fixed TPU cassette rail and moving pad, joined by two long flexible arms.
    pad=box('RELEASE | TPU button '+str(sy),(7.6,3.4,.6),(0,sy*latch_y,-7.82),rubber,r=.12);apply_mods(pad)
    stem=box('Release stem',(4.95,1.72,2.29),(0,sy*latch_y,-6.38),rubber,r=.07);apply_mods(stem);boolean(pad,stem,'UNION')
    for sx in (-1,1):
        anchor=box('Release fixed anchor',(3.3,4.5,.7),(sx*9,sy*latch_y,-6.97),rubber,r=.1);apply_mods(anchor)
        # Folded/sloping TPU arm, stores return energy while the centre rises.
        arm=box('Release elastic arm',(5.3,.95,.5),(sx*5.8,sy*latch_y,-7.47),rubber,r=.1)
        arm.rotation_euler.y=-sx*.115;apply_mods(arm);boolean(anchor,arm,'UNION');boolean(pad,anchor,'UNION')
        boolean(pad,cylinder('Cassette M1.4 clearance',.76,3,(sx*9,sy*latch_y,-7.5),None,n=24))
        screw=cylinder('HARDWARE | release cassette M1.4 screw',1.2,.5,(sx*9,sy*latch_y,-7.62),steel,n=32)
        cylinder('HARDWARE | release cassette screw shank',.68,1.9,(sx*9,sy*latch_y,-6.65),steel,n=24)
    pad['material']='TPU 95A prototype flexure';pad['release_stroke_mm']=.72
    pad['operation']='Press from wrist side to lift the band-owned catch; durability not physically tested.'
    release_parts.append(pad)
'''

BUTTON_HOLES = r'''
buttonz=-P['button_axis_above_pcb_mm']-.5705856
usby=P['usb_y_mm'];usbz=-P['usb_z_mm']
for yy in (P['button_1_y_mm'],P['button_2_y_mm']):
    boolean(body,box('Keyed plunger guide',(8,1.9,1.6),(-W/2,yy,buttonz),None,r=0))
    boolean(body,cyl_x('Internal flange chamber',2.075,1.5,(-19.90,yy,buttonz)))
'''

BUTTONS = r'''
# Correct original switch geometry from the GT-TC191A drawing: 1.1 mm axis
# above PCB, 0.15 +/-0.05 mm switch travel. Previous caps were only illustrative.
for orig,o in list(coremap.items()):
    if orig.name in ('SW1 actuator','SW2 actuator'):bpy.data.objects.remove(o,do_unlink=True)
    if orig.name.startswith(('core_pcb SW1 |','core_pcb SW2 |')):
        o.location.x-=.3;o.location.z=.5705856+1.1;o.scale.y=2/2.6;o.scale.z=2.2/2.6

button_parts=[];button_roots=[];switch_actuators=[]
for idx,yy in enumerate((P['button_1_y_mm'],P['button_2_y_mm']),1):
    motion=root('MOTION | side key '+str(idx));button_roots.append(motion)
    # Rigid pusher is inserted from the inside. Cap attaches after insertion.
    rod=box('BUTTON | keyed pusher '+str(idx),(3.60,1.6,1.3),(-20.60,yy,buttonz),graphite,r=.05);apply_mods(rod)
    flange=cyl_x('Pusher captive flange',1.85,.55,(-20.375,yy,buttonz),graphite)
    boolean(rod,flange,'UNION');rod.parent=motion
    # Hard inward stop: .24 mm from rest; outward flange shoulder prevents loss.
    ret=cyl_x('BUTTON | bonded retaining stop '+str(idx),2.02,.28,(-19.72,yy,buttonz),graphite)
    boolean(ret,box('Stop keyed passage',(2,1.9,1.6),(-19.72,yy,buttonz),None,r=0))
    ret['retention']='Bonded press-fit insert; install after inserting pusher.'
    if idx==1:cap=cyl_x('BUTTON | round cap',2.55,1.3,(-22.35,yy,buttonz),graphite,64)
    else:cap=pin_slot('BUTTON | pill cap',2.65,6.4,1.3,(-22.35,yy,buttonz),'X',graphite,r=1.2)
    apply_mods(cap)
    boolean(cap,box('Keyed cap socket',(1.2,1.72,1.42),(-21.98,yy,buttonz),None,r=0));bevel(cap,.08,2);cap.parent=motion
    # Soft contact tip accommodates small stack errors and limits switch overload.
    tip_end=-18.09518-P['button_rest_gap_mm']
    tip=cyl_x('BUTTON | TPU contact tip '+str(idx),.71,tip_end-(-18.84),((tip_end-18.84)/2,yy,buttonz),rubber,32);tip.parent=motion
    tip['note']='TPU 95A compliant contact; adjust length after switch fit test.'
    button_parts.extend([rod,ret,cap,tip])
    colsave=col;col=hardwarecol
    sw=cyl_x('WatchHW | actual switch actuator '+str(idx),1.05,.6,(-17.79518,yy,buttonz),black,48);switch_actuators.append(sw)
    col=colsave
    motion['hard_travel_mm']=.24;motion['switch_travel_mm']=.15;motion['rest_gap_mm']=P['button_rest_gap_mm']
    motion['return']='Original tactile switch spring plus compliant TPU tip; friction/preload require physical fit tuning.'
    for frame,travel in [(1,0),(10 if idx==1 else 55,0),(20 if idx==1 else 65,.24),(30 if idx==1 else 75,.24),(40 if idx==1 else 85,0),(180,0)]:
        motion.location.x=travel;motion.keyframe_insert(data_path='location',frame=frame)
        sw.location.x=-17.79518+(.15 if travel else 0);sw.keyframe_insert(data_path='location',frame=frame)
    if idx==1:
        accentcap=cyl_x('BUTTON | cap teal inset',1.82,.08,(-23.035,yy,buttonz),accent,48);accentcap.parent=motion
'''

STRAP = r'''
# Preview of purchased large-family Apple-style band heads; no fabricated
# replacement male interface needs to be purchased or fitted to the user's band.
col=strapcol
bandheads=[]
for sy in (-1,1):
    head=profile_prism('PURCHASED PREVIEW | large Apple slide head '+str(sy),NOMINAL,34.92,sy,steel)
    bevel(head,.045,2);bandheads.append(head)
    latch=rounded('PURCHASED PREVIEW | spring latch '+str(sy),5.21,1.93,.38,.94,-4.73,steel,None);latch.location.y=sy*latch_y
    latch['source']='Apple ADG: spring latch 5.21 x 1.93; 0.38 +/-0.13 protrusion'
    # Full preview bands; connector neck passes through the profile opening.
    neck=box('PURCHASED PREVIEW | neck '+str(sy),(24,4,2.5),(0,sy*29.2,track_z),rubber,r=.5)
    length=78 if sy>0 else 123
    verts=[];segments=70
    for i in range(segments+1):
        t=length*i/segments;half=12-.7*t/length
        if t>length-9:half=2+(half-2)*math.sqrt(max(0,1-((t-length+9)/9)**2))
        yy=sy*(30+t);zz=track_z-.3-.8*t/length
        verts.extend([(-half,yy,zz-1.55),(half,yy,zz-1.55),(-half,yy,zz+1.55),(half,yy,zz+1.55)])
    faces=[(0,2,3,1)]
    for i in range(segments):
        a=i*4;b=a+4;faces.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
    faces.append((4*segments,4*segments+1,4*segments+3,4*segments+2))
    band=mesh('PURCHASED PREVIEW | Apple sport band '+str(sy),verts,faces,rubber)
    if sy<0:
        for dy in range(62,145,8):boolean(band,cylinder('Purchased strap hole',1.9,7,(0,-dy,track_z),None,n=32))
    else:
        cylinder('PURCHASED PREVIEW | strap pin',2.2,.9,(0,89,track_z+1.6),steel,n=40)
    bevel(band,.24,3)
    head['compatibility']='Large family, 44/45/46/49 mm; old 42 mm. Not new small 42 mm.'
'''

COUPONS = r'''
col=bpy.data.collections.new('APPLE_05_Interface_test_coupons');scene.collection.children.link(col)
coupons=[]
for clearance in (.10,.16,.22):
    q=box('FIT TEST | Apple slide clearance '+str(clearance),(40,8.2,7.7),(0,25.5,-2.95),graphite,r=.5);apply_mods(q)
    cut_track(q,1,clearance);bevel(q,.08,2);q['radial_clearance_mm']=clearance;coupons.append(q)
col.hide_render=True;col.hide_viewport=True
'''
