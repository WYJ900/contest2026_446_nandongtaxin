from pathlib import Path
import json
from variant_sections import TRACK,BUTTON_HOLES,BUTTONS,STRAP,COUPONS
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'velaride_watch_case'
p=json.loads((BASE/'case_parameters.json').read_text())
for k in list(p):
    if k.startswith(('strap_','lug_','springbar_')):del p[k]
p.update(style='graphite Apple-compatible slide interface',slide_family='44/45/46/49 mm large, legacy 42 mm',slide_radial_clearance_mm=.12,
    button_axis_above_pcb_mm=1.1,button_switch_travel_mm=.15,button_switch_travel_tolerance_mm=.05,button_hard_travel_mm=.24,button_rest_gap_mm=.03,overall_case_length_mm=58.8)
(ROOT/'case_parameters.json').write_text(json.dumps(p,indent=2),encoding='utf8')
s=(BASE/'build_watch_case.py').read_text(encoding='utf8')
s=s.replace("/velaride_watch_case')","/velaride_apple_slide')")
s=s.replace("scene_name='VelaRide | Watch Enclosure'","scene_name='VelaRide | Apple slide and working keys'")
s=s.replace('WATCH_','APPLE_').replace('22 mm lugs','Apple slide rails')
s=s.replace("[(bottom,W-1,H-1,R-.5),(bottom+.75,W,H,R),(top-.9,W,H,R),(top,W-1,H-1,R-.5)]", "[(bottom,W-1,57.4,R-.5),(bottom+.75,W,58.8,R),(-1.0,W,58.8,R),(2.0,W,54.0,R),(top,W-1,H-1,R-.5)]",1)
def replace_section(text,start,end,new):
    a=text.index(start);b=text.index(end,a)
    return text[:a]+new+'\n'+text[b:]
s=replace_section(s,'# Four integrated lugs.','# Main-board component face',TRACK)
s=replace_section(s,'buttonz=-P[','usbcut=',BUTTON_HOLES)
s=replace_section(s,'# A tactile round','# The brass standoffs',BUTTONS+"\ncover=pin_slot('CONTROL | removable USB dust cover',5.0,11.0,.65,(W/2+.13,usby,usbz),'X',rubber,r=1.1)\n")
s=replace_section(s,'# Purchased strap preview','# Small strap-fit coupon',STRAP)
s=replace_section(s,'# Small strap-fit coupon','# Studio hero',COUPONS)
s=s.replace('scene.frame_start=1;scene.frame_end=1','scene.frame_start=1;scene.frame_end=180;scene.frame_set(1)')
s=s.replace('for ob in (body,bezel,trim,back):','for ob in (body,bezel,trim,back):')
start="for o,filename in [(body,'case_body_PROTOTYPE.stl'),(bezel,'front_bezel_PROTOTYPE.stl'),(back,'rear_cover_PROTOTYPE.stl'),(coupon,'22mm_lug_fit_coupon.stl')]:"
assert start in s
s=s.replace(start,"export_parts=[(body,'case_body_apple_slide_PROTOTYPE.stl'),(bezel,'front_bezel_PROTOTYPE.stl'),(back,'rear_cover_PROTOTYPE.stl')]\nexport_parts += [(o,'slide_coupon_'+str(o['radial_clearance_mm']).replace('.','p')+'.stl') for o in coupons]\nexport_parts += [(o,'side_key_part_'+str(i)+'.stl') for i,o in enumerate(button_parts)]\nexport_parts += [(o,'TPU_release_cassette_'+str(i)+'.stl') for i,o in enumerate(release_parts)]\nfor o,filename in export_parts:")
s=s.replace('watch_case_hero.png','apple_slide_hero.png').replace('velaride_watch_case.blend','velaride_apple_slide.blend')
s=s.replace("+ '\\n22 mm straight quick-release strap; 1.8 mm shaft; 0.8 mm tips.","+ '\\nApple-compatible large sliding band interface.")
# Replace the embedded note fully, because the original describes obsolete lugs.
a=s.index("note=bpy.data.texts.new(");b=s.index("bpy.ops.object.select_all",a)
s=s[:a]+"note=bpy.data.texts.new('APPLE_SLIDE_NOTES.txt');note.write('Apple large-family slide: official R3 cross-section, prototype clearance 0.12 mm. Band-owned latch engages central pocket. TPU underside release cassette pushes latch in. Side keys have keyed plungers, captive flanges, bonded stops, compliant tips; original tactile switches provide return. Frame 1 rest, 20 key1, 65 key2. Animation is prescribed motion, not proof of physical performance. Fit/load/cycle tests still required. See README.txt and case_parameters.json.')\n"+s[b:]
(ROOT/'build_apple_slide.py').write_text(s,encoding='utf8')
print('Generated',ROOT/'build_apple_slide.py')
