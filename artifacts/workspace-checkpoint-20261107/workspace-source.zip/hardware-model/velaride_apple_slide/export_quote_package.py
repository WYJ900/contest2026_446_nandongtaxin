"""Export only enclosure-side parts for a vendor quotation; excludes bought bands."""
import bpy,bmesh,json,struct,hashlib
from pathlib import Path
from mathutils import Vector

BASE=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_apple_slide')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_Case_Quote_20261010_v1')
OUT.mkdir(parents=True,exist_ok=True)
scene=bpy.data.scenes['VelaRide | Apple slide and working keys']
oldscene=bpy.context.window.scene;oldframe=scene.frame_current
bpy.context.window.scene=scene;scene.frame_set(1)

# ID, source object, descriptive file stem, Chinese name, material, group.
specs=[
('A01','CASE | main body with Apple slide rails','main_case','主壳（含苹果大号滑扣接收槽）','PA12','01_PA12_MAIN'),
('A02','CASE | front bezel','front_bezel','屏幕前框','PA12','01_PA12_MAIN'),
('A03','CASE | removable rear cover','rear_cover','可拆后盖','PA12','01_PA12_MAIN'),
('A04','BUTTON | keyed pusher 1','key1_pusher','侧键1顶杆及一体防脱法兰','PA12','01_PA12_MAIN'),
('A05','BUTTON | bonded retaining stop 1','key1_stop','侧键1内侧限位片','PA12','01_PA12_MAIN'),
('A06','BUTTON | round cap','key1_round_cap','侧键1圆键帽','PA12','01_PA12_MAIN'),
('A07','BUTTON | keyed pusher 2','key2_pusher','侧键2顶杆及一体防脱法兰','PA12','01_PA12_MAIN'),
('A08','BUTTON | bonded retaining stop 2','key2_stop','侧键2内侧限位片','PA12','01_PA12_MAIN'),
('A09','BUTTON | pill cap','key2_pill_cap','侧键2长圆键帽','PA12','01_PA12_MAIN'),
('B01','BUTTON | TPU contact tip 1','key1_soft_tip','侧键1软接触头','TPU 95A','02_TPU_MAIN'),
('B02','BUTTON | TPU contact tip 2','key2_soft_tip','侧键2软接触头','TPU 95A','02_TPU_MAIN'),
('B03','RELEASE | TPU button -1','lower_band_release','壳体下端表带释放组件','TPU 95A','02_TPU_MAIN'),
('B04','RELEASE | TPU button 1','upper_band_release','壳体上端表带释放组件','TPU 95A','02_TPU_MAIN'),
('C01','FIT TEST | Apple slide clearance 0.1','slot_test_c010','滑扣试装件（径向余量0.10 mm）','PA12','03_FIT_TEST_OPTION'),
('C02','FIT TEST | Apple slide clearance 0.16','slot_test_c016','滑扣试装件（径向余量0.16 mm）','PA12','03_FIT_TEST_OPTION'),
('C03','FIT TEST | Apple slide clearance 0.22','slot_test_c022','滑扣试装件（径向余量0.22 mm）','PA12','03_FIT_TEST_OPTION'),
('D01','CASE | polished front edge','decorative_edge','装饰边（极薄，可不做）','外观薄片/PA12可制造性评估','04_ACCESSORIES_OPTIONAL'),
('D02','BUTTON | cap teal inset','button_decorative_disc','圆键装饰面片（极薄，可不做）','装饰贴片/薄片','04_ACCESSORIES_OPTIONAL'),
('D03','CASE | screen gasket','screen_gasket','屏幕垫圈（软垫参考）','TPU/硅胶片替代评估','04_ACCESSORIES_OPTIONAL'),
('D04','CASE | rear seam gasket','rear_gasket','后盖垫圈（软垫参考）','TPU/硅胶片替代评估','04_ACCESSORIES_OPTIONAL'),
('D05','CONTROL | removable USB dust cover','usb_dust_cover','USB防尘塞（可选）','TPU 95A','04_ACCESSORIES_OPTIONAL'),
]

def find_obj(base):
    found=[o for o in scene.objects if o.name==base or (o.name.startswith(base+'.') and o.name[len(base)+1:].isdigit())]
    assert len(found)==1,(base,[o.name for o in found])
    return found[0]

records=[]
for pid,base,stem,name,material,group in specs:
    o=find_obj(base)
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh()
    bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    boundary=sum(e.is_boundary for e in bm.edges);nonmanifold=sum(not e.is_manifold for e in bm.edges)
    assert not boundary and not nonmanifold,(pid,boundary,nonmanifold)
    bm.to_mesh(me);bm.free();me.calc_loop_triangles()
    verts=[o.matrix_world@v.co for v in me.vertices]
    lo=Vector(tuple(min(v[a] for v in verts) for a in range(3)))
    hi=Vector(tuple(max(v[a] for v in verts) for a in range(3)))
    offset=Vector(((lo.x+hi.x)/2,(lo.y+hi.y)/2,lo.z))
    verts=[v-offset for v in verts]
    dest=OUT/group/(pid+'_'+stem+'_Q1_mm.stl');dest.parent.mkdir(exist_ok=True)
    volume=0.0
    with dest.open('wb') as f:
        header=(pid+' VelaRide enclosure ONLY; 1 unit=1mm; prototype quotation').encode('ascii')
        f.write(header[:80].ljust(80,b' '));f.write(struct.pack('<I',len(me.loop_triangles)))
        for t in me.loop_triangles:
            a,b,c=[verts[i] for i in t.vertices];normal=(b-a).cross(c-a).normalized()
            f.write(struct.pack('<12fH',*normal,*a,*b,*c,0));volume+=a.dot(b.cross(c))/6
    records.append(dict(id=pid,name=name,quantity=1,material=material,group=group,
        file=dest.relative_to(OUT).as_posix(),source_object=o.name,
        dimensions_mm=[round(v,4) for v in hi-lo],volume_cm3=round(abs(volume)/1000,6),
        triangle_count=len(me.loop_triangles),boundary_edges=boundary,nonmanifold_edges=nonmanifold,
        translation_to_quote_origin_mm=[round(v,6) for v in -offset],
        sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
    ev.to_mesh_clear()

manifest={'project':'VelaRide Apple-large sliding-band ENCLOSURE ONLY','revision':'QUOTE-20261010-v1',
 'units':'mm','purchased_watch_band_included':False,'electronics_or_hardware_included':False,
 'prototype_fit_verified':False,'geometry_changes':'Only normals recalculated and each separate part translated to XY centre / Z minimum 0; no scaling or redesign.',
 'main_quantity':13,'fit_test_quantity_optional':3,'accessory_quantity_optional':5,'parts':records}
(OUT/'package_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')

# Quote preview deliberately excludes all purchased watch bands.
views=OUT/'05_REFERENCE_IMAGES';views.mkdir(exist_ok=True)
strap=next(c for c in scene.collection.children if c.name.startswith('APPLE_03'))
hidden=strap.hide_render;oldpath=scene.render.filepath
try:
    strap.hide_render=True;scene.render.filepath=str(views/'case_only_preview.png')
    bpy.ops.render.render(write_still=True)
finally:
    strap.hide_render=hidden;scene.render.filepath=oldpath;scene.frame_set(oldframe);bpy.context.window.scene=oldscene
print(json.dumps({'output':str(OUT),'stl_files':len(records),'main_parts':13,'optional_parts':8,'band_exported':False}))
