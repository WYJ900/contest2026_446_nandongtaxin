import bpy,bmesh,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_apple_slide')
s=bpy.data.scenes['VelaRide | Apple slide and working keys'];bpy.context.window.scene=s
body=next(o for o in s.objects if o.name=='CASE | main body with Apple slide rails')
hwcol=next(c for c in s.collection.children if c.name.startswith('APPLE_02'))
strapcol=next(c for c in s.collection.children if c.name.startswith('APPLE_03'))
def tree(o):
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh()
    v=[o.matrix_world@q.co for q in me.vertices];pol=[list(q.vertices) for q in me.polygons]
    out=BVHTree.FromPolygons(v,pol);ev.to_mesh_clear();return out
s.frame_set(1);bpy.context.view_layer.update();bt=tree(body)
report=json.loads((ROOT/'case_verification.json').read_text())
report['overall_case_length_mm']=58.8
report['frame_length_mm']=49.0
report['hardware_case_surface_intersections']=[o.name for o in hwcol.objects if o.type=='MESH' and bt.overlap(tree(o))]
report['rigid_key_surface_intersections']={}
for frame in (1,20,40,65,85):
    s.frame_set(frame);bpy.context.view_layer.update()
    hits=[]
    for o in s.objects:
        if o.name.startswith(('BUTTON | keyed pusher','BUTTON | round cap','BUTTON | pill cap')) and bt.overlap(tree(o)):hits.append(o.name)
    report['rigid_key_surface_intersections'][str(frame)]=hits
report['switch_nominal_travel_mm']=.15
report['switch_datasheet_tolerance_mm']=.05
report['key_stop_travel_mm']=.24
report['outward_stop_contacts_at_rest']='Flange is designed to touch the chamber shoulder. Coplanar contact can be counted as a surface overlap.'
report['rigid_key_interior_path_checks']={}
for i in (1,2):
    s.frame_set(1);rt=bpy.data.objects['MOTION | side key '+str(i)]
    rr=[]
    for dx in (.002,.06,.12,.18,.238):
        rt.location.x=dx;bpy.context.view_layer.update()
        rr.append({'stroke_mm':dx,'body_surface_overlap':bool(bt.overlap(tree(bpy.data.objects['BUTTON | keyed pusher '+str(i)])))})
    report['rigid_key_interior_path_checks'][str(i)]=rr
s.frame_set(1)
report['original_switch_return_not_simulated']=True
report['band_slide_paths']={}
s.frame_set(1)
for head in [o for o in strapcol.objects if o.name.startswith('PURCHASED PREVIEW | large Apple slide head')]:
    orig=head.location.copy();hits=[]
    for dx in (-25,-15,0,15,25):
        head.location.x=dx;bpy.context.view_layer.update()
        if bt.overlap(tree(head)):hits.append(dx)
    report['band_slide_paths'][head.name]={'checked_x_offsets_mm':[-25,-15,0,15,25],'surface_intersection_offsets_mm':hits}
    head.location=orig
bpy.context.view_layer.update()
(ROOT/'case_verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')

s.render.filepath=str(ROOT/'apple_slide_hero.png');bpy.ops.render.render(write_still=True)
cam=s.camera;oldloc=cam.location.copy();oldrot=cam.rotation_euler.copy();oldscale=cam.data.ortho_scale
strapcol.hide_render=True
cam.location=(-48,-62,16);cam.rotation_euler=(Vector((0,-25,-3))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=49
s.render.filepath=str(ROOT/'apple_slide_slot.png');bpy.ops.render.render(write_still=True)

# Underside: release button and four rear screws, with the floor hidden.
floor=next(o for o in s.objects if o.name.startswith('Watch studio floor'));floor.hide_render=True
cam.location=(-48,-76,-86);cam.rotation_euler=(Vector((0,-8,-4))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=73
s.render.filepath=str(ROOT/'apple_slide_release_underside.png');bpy.ops.render.render(write_still=True)
floor.hide_render=False;strapcol.hide_render=False
cam.location=oldloc;cam.rotation_euler=oldrot;cam.data.ortho_scale=oldscale
s.frame_set(1);s.render.filepath=str(ROOT/'apple_slide_hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_apple_slide.blend'))
print(json.dumps({k:v for k,v in report.items() if k in ['hardware_case_surface_intersections','rigid_key_surface_intersections','band_slide_paths']}))
