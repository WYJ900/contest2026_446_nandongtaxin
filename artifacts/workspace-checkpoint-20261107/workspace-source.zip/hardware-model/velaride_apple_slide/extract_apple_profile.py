"""Convert the official R3 DWG/DXF spline chain to millimetre XY profiles."""
import ezdxf,json,math
from pathlib import Path
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parent
doc=ezdxf.readfile(ROOT/'references/apple_lug_R3.dxf')
byid={e.dxf.handle:e for e in doc.modelspace()}
# Exclude 7B/7E, alternate duplicate long-arc representations present in the file.
chain=[('76',False),('73',False),('7D',False),('7F',False),('7A',False),('77',False),('7C',False),('79',True),('75',True),('78',True)]
points=[]
for hid,rev in chain:
    pp=[(v.x,v.y) for v in byid[hid].flattening(.002,segments=12)]
    if rev:pp.reverse()
    if points:assert math.dist(points[-1],pp[0])<.001,(hid,points[-1],pp[0])
    points.extend(pp if not points else pp[1:])
assert math.dist(points[0],points[-1])<.001
inside=max(x for x,z in points);zmid=(max(z for x,z in points)+min(z for x,z in points))/2
# u increases from the rounded inner nose toward the band/outside of the watch.
poly=Polygon([(inside-x,z-zmid) for x,z in points]).simplify(.001,preserve_topology=True)
assert poly.is_valid
out={'source':'Apple Watch Lug Profile R3.dwg','source_url':'https://developer.apple.com/accessories/apple-watch-lug-profile.zip','units':'mm','profile_nominal':list(poly.exterior.coords)[:-1], 'bounds':poly.bounds,'profile_height_mm':poly.bounds[3]-poly.bounds[1], 'slot_clearances_mm':[.10,.12,.16,.22]}
for c in out['slot_clearances_mm']:
    out['profile_clearance_'+str(c)]=list(poly.buffer(c,resolution=5).simplify(.003,preserve_topology=True).exterior.coords)[:-1]
(ROOT/'apple_profile.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print('Profile points',len(out['profile_nominal']),'bounds',poly.bounds,'height',out['profile_height_mm'])
