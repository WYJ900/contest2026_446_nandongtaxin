import ezdxf,json
from pathlib import Path
P=Path(__file__).resolve().parent/'references/apple_lug_R3.dxf'
d=ezdxf.readfile(P)
print('UNITS',d.units)
for e in d.modelspace():
    print(e.dxftype(),str(e.dxf.all_existing_dxf_attribs())[:1500])
    if e.dxftype()=='SPLINE':print('knots',list(e.knots),'control',list(e.control_points),'fit',list(e.fit_points))
    if e.dxftype()=='LWPOLYLINE':print('points',list(e.get_points()))
