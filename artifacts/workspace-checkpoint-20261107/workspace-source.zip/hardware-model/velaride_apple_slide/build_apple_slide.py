"""VelaRide enclosure concept with dimensional 22 mm quick-release interfaces.
Requires the source Huangshan .blend. Saves a NEW file; original is preserved.
Screen-board spacing remains an estimate. Do not infer production fit from renders.
"""
import bpy, bmesh, math, json, ast, sys, struct
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_apple_slide')
SRC=ROOT.parent/'huangshan_pi'
P=json.loads((ROOT/'case_parameters.json').read_text(encoding='utf8'))
sys.path.insert(0,str(SRC))
from extract_hardware import path_points
# Reuse only geometry helper definitions; do not run the source scene builder.
tree=ast.parse((SRC/'build_blender.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'geometry_helpers','exec'))

scene_name='VelaRide | Apple slide and working keys'
existing=bpy.data.scenes.get(scene_name)
if existing:
    for c in list(existing.collection.children):
        if c.name.startswith('APPLE_'):
            for o in list(c.all_objects):bpy.data.objects.remove(o,do_unlink=True)
            bpy.data.collections.remove(c)
    bpy.data.scenes.remove(existing)
scene=bpy.data.scenes.new(scene_name)
bpy.context.window.scene=scene
enum(scene.unit_settings,'system','METRIC');scene.unit_settings.scale_length=.001
scene.unit_settings.length_unit='MILLIMETERS'
col=bpy.data.collections.new('APPLE_01_Enclosure');scene.collection.children.link(col)
hardwarecol=bpy.data.collections.new('APPLE_02_Existing_hardware');scene.collection.children.link(hardwarecol)
strapcol=bpy.data.collections.new('APPLE_03_Purchased_strap_preview');scene.collection.children.link(strapcol)
studiocol=bpy.data.collections.new('APPLE_04_Studio');scene.collection.children.link(studiocol)

graphite=mat('Watch | satin graphite',(.095,.111,.14),.84,.25)
edge=mat('Watch | polished chamfer',(.31,.35,.4),.92,.18)
rubber=mat('Watch | black FKM',(.009,.014,.019),0,.49)
rear_mat=mat('Watch | rear engineering polymer',(.019,.027,.038),.07,.4)
steel=mat('Watch | hardware steel',(.52,.57,.63),.9,.23)
brass=mat('Watch | brass standoffs',(.64,.40,.1),.82,.28)
markmat=mat('Watch | laser markings',(.37,.44,.50),.4,.5)
accent=mat('Watch | subtle teal accent',(.015,.31,.29),.7,.27)
black=mat('Watch | gasket',(.005,.008,.012),0,.65)

def clone_hardware(rootname,newname,z=0,flip=False):
    source=bpy.data.objects[rootname]
    mapping={}
    for orig in [source]+list(source.children_recursive):
        obj=orig.copy()
        if orig.data:obj.data=orig.data.copy()
        obj.animation_data_clear();hardwarecol.objects.link(obj);obj.name='WatchHW | '+orig.name
        mapping[orig]=obj
    for orig,obj in mapping.items():
        obj.parent=mapping.get(orig.parent)
    rt=mapping[source];rt.name=newname;rt.location=(0,0,z);rt.rotation_euler=(0,math.pi if flip else 0,0)
    rt['assembly_orientation_note']='Main header faces rear; inferred from user standoffs higher than header.'
    return rt,mapping

core,coremap=clone_hardware('CORE_PCB | official XY','Watch hardware | main board',0,True)
display,displaymap=clone_hardware('DISPLAY_PCB | official XY','Watch hardware | screen',P['display_pcb_center_z_mm'])
# Correct the source preview USB body's generic height override.
for orig,o in coremap.items():
    if orig.name.startswith('core_pcb USB1'):
        o.scale.z=4;o.location.z=P['usb_z_mm'];o['body_height_is_estimate']=True
    elif orig.name=='USB-C polymer tongue':o.location.z=P['usb_z_mm']

def rr(w,h,r,n=20):
    pts=[]
    for x,y,a in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
        pts.extend((x+r*math.cos(math.radians(a+j*90/n)),y+r*math.sin(math.radians(a+j*90/n))) for j in range(n+1))
    return pts

def ring(name,outer,inner,z0,z1,material):
    a=rr(*outer);b=rr(*inner);n=len(a)
    v=[(x,y,z) for z,pts in [(z0,a),(z1,a),(z0,b),(z1,b)] for x,y in pts]
    f=[]
    for i in range(n):
        j=(i+1)%n
        f.extend([(i,j,j+n,i+n),(2*n+j,2*n+i,3*n+i,3*n+j),(n+i,n+j,3*n+j,3*n+i),(j,i,2*n+i,2*n+j)])
    return mesh(name,v,f,material)

def loft_ring(name,sections,inside,material):
    n=len(rr(*inside));k=len(sections)
    v=[(x,y,z) for z,w,h,r in sections for x,y in rr(w,h,r)]
    v.extend((x,y,z) for z in [sections[0][0],sections[-1][0]] for x,y in rr(*inside))
    f=[]
    for q in range(k-1):
        for i in range(n):j=(i+1)%n;f.append((q*n+i,q*n+j,(q+1)*n+j,(q+1)*n+i))
    for i in range(n):
        j=(i+1)%n;lo=k*n;hi=(k+1)*n;top=(k-1)*n
        f.extend([(lo+j,lo+i,hi+i,hi+j),(j,i,lo+i,lo+j),(top+i,top+j,hi+j,hi+i)])
    return mesh(name,v,f,material)

def boolean(obj,tool,op='DIFFERENCE'):
    bpy.context.view_layer.update();bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new('Manufactured geometry','BOOLEAN');enum(mod,'operation',op);mod.object=tool
    bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(tool,do_unlink=True)

def cyl_x(name,r,length,xyz,m=None,n=48):
    o=cylinder(name,r,length,xyz,m,n=n);o.rotation_euler.y=math.pi/2;return o

def apply_mods(o):
    bpy.context.view_layer.objects.active=o
    for mod in list(o.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)

def pin_slot(name,w,h,depth,xyz,axis='Z',material=None,r=None):
    o=rounded(name,w,h,depth,r or min(w,h)/2-.01,0,material,None)
    if axis=='X':o.rotation_euler.y=math.pi/2
    o.location=xyz
    return o

L=P['copper_standoff_length_mm'];boardhalf=.5705856
backtop=-boardhalf-L-.15;backbottom=backtop-1.65
bottom=backtop+.1;top=P['display_pcb_center_z_mm']+.83
W,H,R=P['case_width_mm'],P['case_length_mm'],P['case_corner_radius_mm']
inside=(P['cavity_width_mm'],P['cavity_length_mm'],P['cavity_corner_radius_mm'])
body=loft_ring('CASE | main body with Apple slide rails',[(bottom,W-1,57.4,R-.5),(bottom+.75,W,58.8,R),(-1.0,W,58.8,R),(2.0,W,54.0,R),(top,W-1,H-1,R-.5)],inside,graphite)
body['part']='Main enclosure';body['prototype_only']=True


# Official Apple R3 cross-section, female clearance is a prototype variable.
AP=json.loads((ROOT/'apple_profile.json').read_text(encoding='utf8'))
PROFILE=AP['profile_clearance_'+str(P['slide_radial_clearance_mm'])]
NOMINAL=AP['profile_nominal']
track_y=23.5;track_z=-3.0;latch_y=track_y+2.015

def profile_prism(name,points,span,sy,material=None):
    n=len(points)
    v=[(x,sy*(track_y+u),track_z+z) for x in (-span/2,span/2) for u,z in points]
    f=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name,v,f,material)
    bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
    return o

def cut_track(target,sy,clearance):
    boolean(target,profile_prism('Official profile female tool',AP['profile_clearance_'+str(clearance)],48,sy))
    # Neck exit to the outside; undercut is provided by the official bulb profile.
    boolean(target,box('Band neck mouth',(48,5,2.75),(0,sy*(track_y+5.8),track_z),None,r=0))
    # Central latch engages the band-owned spring catch, on the wrist-facing side.
    pocket=rounded('Latch receiving pocket',5.55,2.3,1.2,1.1,0,None,None)
    pocket.location=(0,sy*latch_y,-4.94);apply_mods(pocket);boolean(target,pocket)
    boolean(target,box('Release plunger guide',(5.2,2.0,4.8),(0,sy*latch_y,-6.3),None,r=0))
    for xx in (-9,9):boolean(target,cylinder('Release cassette pilot',.6,2.2,(xx,sy*latch_y,-6.25),None,n=24))

for sy in (-1,1):
    cut_track(body,sy,P['slide_radial_clearance_mm'])
body['interface']='Large Apple Watch 44/45/46/49 mm family; legacy 42 mm only'
body['profile_source']='Apple official R3 DWG, converted and sampled at 0.002 mm'
body['latch_source']='Apple ADG 2026-09-21 page 218; 34.92 mm male width; 3.21 mm profile height'
release_parts=[]
for sy in (-1,1):
    # Fixed TPU cassette rail and moving pad, joined by two long flexible arms.
    pad=box('RELEASE | TPU button '+str(sy),(7.6,3.4,.6),(0,sy*latch_y,-7.82),rubber,r=.12);apply_mods(pad)
    stem=box('Release stem',(4.95,1.72,2.29),(0,sy*latch_y,-6.38),rubber,r=.07);apply_mods(stem);boolean(pad,stem,'UNION')
    for sx in (-1,1):
        anchor=box('Release fixed anchor',(3.3,4.5,.7),(sx*9,sy*latch_y,-6.97),rubber,r=.1);apply_mods(anchor)
        # Folded/sloping TPU arm, stores return energy while the centre rises.
        arm=box('Release elastic arm',(5.3,.95,.5),(sx*5.8,sy*latch_y,-7.47),rubber,r=.1)
        arm.rotation_euler.y=-sx*.115;apply_mods(arm);boolean(anchor,arm,'UNION');boolean(pad,anchor,'UNION')
        boolean(pad,cylinder('Cassette M1.4 clearance',.76,3,(sx*9,sy*latch_y,-7.5),None,n=24))
        screw=cylinder('HARDWARE | release cassette M1.4 screw',1.2,.5,(sx*9,sy*latch_y,-7.62),steel,n=32)
        cylinder('HARDWARE | release cassette screw shank',.68,1.9,(sx*9,sy*latch_y,-6.65),steel,n=24)
    pad['material']='TPU 95A prototype flexure';pad['release_stroke_mm']=.72
    pad['operation']='Press from wrist side to lift the band-owned catch; durability not physically tested.'
    release_parts.append(pad)

# Main-board component face points down: USB on +X, buttons on -X.

buttonz=-P['button_axis_above_pcb_mm']-.5705856
usby=P['usb_y_mm'];usbz=-P['usb_z_mm']
for yy in (P['button_1_y_mm'],P['button_2_y_mm']):
    boolean(body,box('Keyed plunger guide',(8,1.9,1.6),(-W/2,yy,buttonz),None,r=0))
    boolean(body,cyl_x('Internal flange chamber',2.075,1.5,(-19.90,yy,buttonz)))

usbcut=pin_slot('USB access opening',4.5,10.2,8,(W/2,usby,usbz),'X',r=1.0)
boolean(body,usbcut)
bevel(body,.11,3)

# Front frame, matching the existing glass instead of replacing the screen.
window=(P['screen_window_width_mm'],P['screen_window_length_mm'],P['screen_window_corner_radius_mm'])
bezel=loft_ring('CASE | front bezel',[(top-.05,W-.9,H-.9,R-.45),(top+.5,W-.65,H-.65,R-.3),(top+1.35,W-1.5,H-1.5,R-.7)],window,graphite)
# Raised capture lip overlaps only the existing glass's black perimeter, above
# its surface, so the front retains the stack when the rear screws are tightened.
lip=ring('Front glass retaining lip',(W-1.5,H-1.5,R-.7),(34.5,40.9,7.65),top+1.25,top+1.5,graphite)
boolean(bezel,lip,'UNION')
bevel(bezel,.12,3)
trim=ring('CASE | polished front edge',(W-.7,H-.7,R-.35),(W-1.25,H-1.25,R-.62),top+.22,top+.38,edge)
bevel(trim,.04,2)
seal=ring('CASE | screen gasket',(36.05,42.45,8.4),(35.18,41.58,8.0),top+.25,top+.75,black)
seal['note']='Illustrative gasket. No water-resistance rating or seal validation.'

back=rounded('CASE | removable rear cover',W-.3,H-.3,backtop-backbottom,R-.25,(backtop+backbottom)/2,rear_mat,None)
apply_mods(back)
rim=ring('CASE | rear seam gasket',(W-1.1,H-1.1,R-.6),(W-2,H-2,R-1.05),backtop-.03,backtop+.16,black)
mounts=[]
params=json.loads((SRC/'hardware_parameters.json').read_text(encoding='utf8'))
for c in next(b for b in params if b['name']=='core_pcb')['components']:
    if c['ref'] not in ('M1','M2','M3','M4'):continue
    x,y=-c['x'],c['y'];mounts.append((x,y))
    boolean(back,cylinder('Rear M2 clearance bore',1.1,4,(x,y,(backtop+backbottom)/2),None))
    boolean(back,cylinder('Rear screw head seat',1.9,.8,(x,y,backbottom+.32),None))
    st=cylinder('HARDWARE | '+c['ref']+' 6 mm brass standoff',P['copper_standoff_across_flats_mm']/math.sqrt(3),L,(x,y,-boardhalf-L/2),brass,n=6)
    boolean(st,cylinder('M2 thread envelope',.85,L+1,(x,y,-boardhalf-L/2),None))
    bevel(st,.08,2);st['nominal_body_length_mm']=L;st['thread']='M2 placeholder; actual screw size to verify'
    screw=cylinder('HARDWARE | rear M2 screw',1.65,.55,(x,y,backbottom+.30),steel,n=40)
    for ang in (0,math.pi/2):
        tool=box('Screw cross recess',(2.1,.4,.3),(x,y,backbottom+.09),None,r=0);tool.rotation_euler.z=ang;boolean(screw,tool)
    cylinder('HARDWARE | M2 screw shank',.9,2.4,(x,y,backbottom+1.6),steel,n=32)
bevel(back,.08,3)


# Correct original switch geometry from the GT-TC191A drawing: 1.1 mm axis
# above PCB, 0.15 +/-0.05 mm switch travel. Previous caps were only illustrative.
for orig,o in list(coremap.items()):
    if orig.name in ('SW1 actuator','SW2 actuator'):bpy.data.objects.remove(o,do_unlink=True)
    if orig.name.startswith(('core_pcb SW1 |','core_pcb SW2 |')):
        o.location.x-=.3;o.location.z=.5705856+1.1;o.scale.y=2/2.6;o.scale.z=2.2/2.6

button_parts=[];button_roots=[];switch_actuators=[]
for idx,yy in enumerate((P['button_1_y_mm'],P['button_2_y_mm']),1):
    motion=root('MOTION | side key '+str(idx));button_roots.append(motion)
    # Rigid pusher is inserted from the inside. Cap attaches after insertion.
    rod=box('BUTTON | keyed pusher '+str(idx),(3.60,1.6,1.3),(-20.60,yy,buttonz),graphite,r=.05);apply_mods(rod)
    flange=cyl_x('Pusher captive flange',1.85,.55,(-20.375,yy,buttonz),graphite)
    boolean(rod,flange,'UNION');rod.parent=motion
    # Hard inward stop: .24 mm from rest; outward flange shoulder prevents loss.
    ret=cyl_x('BUTTON | bonded retaining stop '+str(idx),2.02,.28,(-19.72,yy,buttonz),graphite)
    boolean(ret,box('Stop keyed passage',(2,1.9,1.6),(-19.72,yy,buttonz),None,r=0))
    ret['retention']='Bonded press-fit insert; install after inserting pusher.'
    if idx==1:cap=cyl_x('BUTTON | round cap',2.55,1.3,(-22.35,yy,buttonz),graphite,64)
    else:cap=pin_slot('BUTTON | pill cap',2.65,6.4,1.3,(-22.35,yy,buttonz),'X',graphite,r=1.2)
    apply_mods(cap)
    boolean(cap,box('Keyed cap socket',(1.2,1.72,1.42),(-21.98,yy,buttonz),None,r=0));bevel(cap,.08,2);cap.parent=motion
    # Soft contact tip accommodates small stack errors and limits switch overload.
    tip_end=-18.09518-P['button_rest_gap_mm']
    tip=cyl_x('BUTTON | TPU contact tip '+str(idx),.71,tip_end-(-18.84),((tip_end-18.84)/2,yy,buttonz),rubber,32);tip.parent=motion
    tip['note']='TPU 95A compliant contact; adjust length after switch fit test.'
    button_parts.extend([rod,ret,cap,tip])
    colsave=col;col=hardwarecol
    sw=cyl_x('WatchHW | actual switch actuator '+str(idx),1.05,.6,(-17.79518,yy,buttonz),black,48);switch_actuators.append(sw)
    col=colsave
    motion['hard_travel_mm']=.24;motion['switch_travel_mm']=.15;motion['rest_gap_mm']=P['button_rest_gap_mm']
    motion['return']='Original tactile switch spring plus compliant TPU tip; friction/preload require physical fit tuning.'
    for frame,travel in [(1,0),(10 if idx==1 else 55,0),(20 if idx==1 else 65,.24),(30 if idx==1 else 75,.24),(40 if idx==1 else 85,0),(180,0)]:
        motion.location.x=travel;motion.keyframe_insert(data_path='location',frame=frame)
        sw.location.x=-17.79518+(.15 if travel else 0);sw.keyframe_insert(data_path='location',frame=frame)
    if idx==1:
        accentcap=cyl_x('BUTTON | cap teal inset',1.82,.08,(-23.035,yy,buttonz),accent,48);accentcap.parent=motion

cover=pin_slot('CONTROL | removable USB dust cover',5.0,11.0,.65,(W/2+.13,usby,usbz),'X',rubber,r=1.1)

# The brass standoffs are retained by the rear screws. Removable front bezel uses
# bonded/clip design allowance, not unverified detailed snap geometry.
bezel['attachment_note']='Prototype: front frame bonded to midcase. Raised lip captures glass black edge; gasket to tune after measurement.'
back['attachment_note']='Four M2 placeholder screws into underside brass pillars; verify actual threads.'
body['assembly_height_mm']=top+1.5-backbottom


# Preview of purchased large-family Apple-style band heads; no fabricated
# replacement male interface needs to be purchased or fitted to the user's band.
col=strapcol
bandheads=[]
for sy in (-1,1):
    head=profile_prism('PURCHASED PREVIEW | large Apple slide head '+str(sy),NOMINAL,34.92,sy,steel)
    bevel(head,.045,2);bandheads.append(head)
    latch=rounded('PURCHASED PREVIEW | spring latch '+str(sy),5.21,1.93,.38,.94,-4.73,steel,None);latch.location.y=sy*latch_y
    latch['source']='Apple ADG: spring latch 5.21 x 1.93; 0.38 +/-0.13 protrusion'
    # Full preview bands; connector neck passes through the profile opening.
    neck=box('PURCHASED PREVIEW | neck '+str(sy),(24,4,2.5),(0,sy*29.2,track_z),rubber,r=.5)
    length=78 if sy>0 else 123
    verts=[];segments=70
    for i in range(segments+1):
        t=length*i/segments;half=12-.7*t/length
        if t>length-9:half=2+(half-2)*math.sqrt(max(0,1-((t-length+9)/9)**2))
        yy=sy*(30+t);zz=track_z-.3-.8*t/length
        verts.extend([(-half,yy,zz-1.55),(half,yy,zz-1.55),(-half,yy,zz+1.55),(half,yy,zz+1.55)])
    faces=[(0,2,3,1)]
    for i in range(segments):
        a=i*4;b=a+4;faces.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
    faces.append((4*segments,4*segments+1,4*segments+3,4*segments+2))
    band=mesh('PURCHASED PREVIEW | Apple sport band '+str(sy),verts,faces,rubber)
    if sy<0:
        for dy in range(62,145,8):boolean(band,cylinder('Purchased strap hole',1.9,7,(0,-dy,track_z),None,n=32))
    else:
        cylinder('PURCHASED PREVIEW | strap pin',2.2,.9,(0,89,track_z+1.6),steel,n=40)
    bevel(band,.24,3)
    head['compatibility']='Large family, 44/45/46/49 mm; old 42 mm. Not new small 42 mm.'


col=bpy.data.collections.new('APPLE_05_Interface_test_coupons');scene.collection.children.link(col)
coupons=[]
for clearance in (.10,.16,.22):
    q=box('FIT TEST | Apple slide clearance '+str(clearance),(40,8.2,7.7),(0,25.5,-2.95),graphite,r=.5);apply_mods(q)
    cut_track(q,1,clearance);bevel(q,.08,2);q['radial_clearance_mm']=clearance;coupons.append(q)
col.hide_render=True;col.hide_viewport=True

# Studio hero: tight product crop, purchased bands intentionally extend beyond it.
col=studiocol
floor_mat=mat('Watch | studio floor',(.10,.13,.17),.08,.52)
floor=box('Watch studio floor',(1800,1800,.6),(0,0,backbottom-1),floor_mat,r=0)
camdata=bpy.data.cameras.new('Watch hero camera');cam=bpy.data.objects.new('Watch hero camera',camdata);col.objects.link(cam)
cam.location=(-74,-108,126);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();enum(camdata,'type','ORTHO');camdata.ortho_scale=90;camdata.clip_end=3000
scene.camera=cam
for name,loc,energy,size in [('Key',(-45,-45,100),160000,70),('Edge',(65,25,85),230000,55),('Soft fill',(-60,70,45),125000,80)]:
    ld=bpy.data.lights.new('Watch '+name,'AREA');ld.energy=energy;ld.size=size
    ob=bpy.data.objects.new('Watch '+name,ld);col.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
world=bpy.data.worlds.new('Watch studio');scene.world=world;world.use_nodes=True
bg=next(n for n in world.node_tree.nodes if n.type=='BACKGROUND');bg.inputs['Color'].default_value=(.16,.19,.23,1);bg.inputs['Strength'].default_value=.45
scene.render.resolution_x=1600;scene.render.resolution_y=1500;scene.render.resolution_percentage=100
enum(scene.render.image_settings,'file_format','PNG');scene.render.filepath=str(ROOT/'apple_slide_hero.png')
scene.frame_start=1;scene.frame_end=180;scene.frame_set(1)
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            sp=a.spaces.active;sp.region_3d.view_distance=95;sp.region_3d.view_location=(0,0,1);sp.region_3d.view_rotation=cam.rotation_euler.to_quaternion();sp.clip_end=5000
            enum(sp.shading,'type','MATERIAL');sp.overlay.show_floor=False

# Export only dimensional enclosure parts and coupon; retain mm units in STL.
def export_stl(obj,path):
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();me.calc_loop_triangles()
    with open(path,'wb') as f:
        f.write(b'VelaRide prototype; units mm; fit NOT verified'.ljust(80,b' '));f.write(struct.pack('<I',len(me.loop_triangles)))
        for tri in me.loop_triangles:
            vv=[obj.matrix_world@me.vertices[i].co for i in tri.vertices];normal=(vv[1]-vv[0]).cross(vv[2]-vv[0]).normalized()
            f.write(struct.pack('<12fH',*normal,*vv[0],*vv[1],*vv[2],0))
    ev.to_mesh_clear()

for ob in (body,bezel,trim,back):
    for poly in ob.data.polygons:
        if abs(poly.normal.z)<.8:poly.use_smooth=True
validation={'parameters':P,'body_height_including_glass_mm':round(top+1.5-backbottom,3),'parts':[],'fit_verified':False}
export_parts=[(body,'case_body_apple_slide_PROTOTYPE.stl'),(bezel,'front_bezel_PROTOTYPE.stl'),(back,'rear_cover_PROTOTYPE.stl')]
export_parts += [(o,'slide_coupon_'+str(o['radial_clearance_mm']).replace('.','p')+'.stl') for o in coupons]
export_parts += [(o,'side_key_part_'+str(i)+'.stl') for i,o in enumerate(button_parts)]
export_parts += [(o,'TPU_release_cassette_'+str(i)+'.stl') for i,o in enumerate(release_parts)]
for o,filename in export_parts:
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();bm=bmesh.new();bm.from_mesh(me)
    item={'name':o.name,'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'stl':filename}
    bm.free();ev.to_mesh_clear();validation['parts'].append(item)
    export_stl(o,ROOT/filename)
(ROOT/'case_verification.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
note=bpy.data.texts.new('APPLE_SLIDE_NOTES.txt');note.write('Apple large-family slide: official R3 cross-section, prototype clearance 0.12 mm. Band-owned latch engages central pocket. TPU underside release cassette pushes latch in. Side keys have keyed plungers, captive flanges, bonded stops, compliant tips; original tactile switches provide return. Frame 1 rest, 20 key1, 65 key2. Animation is prescribed motion, not proof of physical performance. Fit/load/cycle tests still required. See README.txt and case_parameters.json.')
bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_apple_slide.blend'))
print(json.dumps(validation))
