import bpy,bmesh,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_wallfix_v4')
s=bpy.context.scene;s.frame_set(1)
results=[]
for obj in [o for o in s.objects if o.type=='MESH' and (o.name.startswith('CASE | main body') or o.name.startswith('CASE | front bezel') or 'PRINT 03' in o.name or 'PRINT 04' in o.name)]:
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();bm=bmesh.new();bm.from_mesh(me)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
    vs=[obj.matrix_world@v.co for v in me.vertices];polys=[list(p.vertices) for p in me.polygons]
    bvh=BVHTree.FromPolygons(vs,polys,all_triangles=True,epsilon=0)
    samples=[]
    for poly in me.polygons:
        a,b,c=[vs[i] for i in poly.vertices];cross=(b-a).cross(c-a);area=cross.length/2
        if area<.002:continue
        n=cross.normalized();p=(a+b+c)/3
        pos,normal,idx,dist=bvh.ray_cast(p-n*.0005,-n,12)
        if pos is not None and .002<dist<12 and normal.dot(n)<-.85:
            samples.append({'mm':round(dist+.0005,5),'at':[round(v,4) for v in p],'to':[round(v,4) for v in pos],'area':round(area,5),'normal':[round(v,4) for v in n]})
    samples.sort(key=lambda q:q['mm'])
    item={'name':obj.name,'opposed_surface_probe_count':len(samples),'under_1mm':sum(t['mm']<1 for t in samples),'minimum_sampled_mm':samples[0]['mm'] if samples else None,'lowest':samples[:40],'thin_samples':[q for q in samples if q['mm']<1]}
    results.append(item);ev.to_mesh_clear()
name='thickness_'+('V4' if 'V4' in s.name else 'V3')+'.json'
(ROOT/name).write_text(json.dumps(results,indent=2),encoding='utf8')
print(json.dumps([{'name':r['name'],'under_1mm':r['under_1mm'],'min':r['minimum_sampled_mm'],'lowest':r['lowest'][:5]} for r in results]))
