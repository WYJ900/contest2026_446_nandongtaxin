from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parent
V3=ROOT.parent/'velaride_hiddenkeys_v3'
source=(V3/'build_v3.py').read_text(encoding='utf8')
source=source.replace('/velaride_hiddenkeys_v3\'','/velaride_wallfix_v4\'').replace('VelaRide | Hidden keys V3','VelaRide | Wall corrected V4').replace('HIDDENV3_','WALLV4_').replace('V3 PRINT','V4 PRINT')

# Upgrade geometry generation, not just viewport shading.
old="tree=ast.parse((SRC/'build_blender.py').read_text(encoding='utf8'))"
new="""helper_source=(SRC/'build_blender.py').read_text(encoding='utf8')
helper_source=helper_source.replace('mod.segments=segments','mod.segments=max(8,segments)')
helper_source=helper_source.replace('j*90/16','j*90/96').replace('range(17)','range(97)')
helper_source=helper_source.replace('def cylinder(name,r,depth,loc,material,parent=None,n=40):','def cylinder(name,r,depth,loc,material,parent=None,n=160):\\n    n=max(n,160) if n>=24 else n')
tree=ast.parse(helper_source)"""
assert old in source;source=source.replace(old,new)
source=source.replace('def rr(w,h,r,n=20):','def rr(w,h,r,n=96):')

smooth=r'''
def smooth_outer_sections(sections):
    # Shape-preserving cubic Hermite interpolation; extrema and section ends
    # remain at their specified dimensions. Sample each span at <=0.25 mm.
    zs=[q[0] for q in sections];hs=[zs[i+1]-zs[i] for i in range(len(zs)-1)]
    values=[[q[j] for q in sections] for j in (1,2,3)]
    slopes=[]
    for vals in values:
        ds=[(vals[i+1]-vals[i])/hs[i] for i in range(len(hs))]
        m=[0.0]*len(zs)
        for i in range(1,len(zs)-1):
            if ds[i-1]*ds[i]>0:
                w1=2*hs[i]+hs[i-1];w2=hs[i]+2*hs[i-1]
                m[i]=(w1+w2)/(w1/ds[i-1]+w2/ds[i])
        # Horizontal tangents at the two mating planes create rounded shoulders.
        m[0]=0;m[-1]=0;slopes.append(m)
    out=[]
    for i,h in enumerate(hs):
        count=max(4,math.ceil(h/.25))
        for k in range(count):
            t=k/count;z=zs[i]+h*t;row=[z]
            for vals,m in zip(values,slopes):
                v=(2*t**3-3*t**2+1)*vals[i]+(t**3-2*t**2+t)*h*m[i]+(-2*t**3+3*t**2)*vals[i+1]+(t**3-t**2)*h*m[i+1]
                row.append(v)
            out.append(tuple(row))
    out.append(sections[-1]);return out

'''
source=source.replace('def loft_ring(name,sections,inside,material):',smooth+"def loft_ring(name,sections,inside,material):\n    if 'main body' in name:sections=smooth_outer_sections(sections)")

# Remove the 0.23 mm roof over the carrier by opening the pocket to the front
# parting plane. The >=1.2 mm front-frame lip closes it after assembly.
old="13.5,29.6,4.4,(-19.9,panel_y,-.15)"
assert old in source;source=source.replace(old,"17.0,29.6,4.4,(-19.9,panel_y,.8)")

# Retain electronics coordinates; only the exterior cheeks grow 1.5 mm/side.
# Extend caps through those cheeks, keeping their visible protrusion unchanged.
source=source.replace("(-22,yy,buttonz),None,64","(-22,yy,buttonz+.5),None,160")
source=source.replace("(-22,yy,buttonz),'X',None","(-22,yy,buttonz+.5),'X',None")
source=source.replace("(8,7.7,9.5),(-21.5,yy,-.75)","(8,7.7,8.6),(-21.5,yy,-.30)")
source=source.replace("(1.2,4.2,10.5),(-20.5,yy,.55)","(1.2,4.2,9.6),(-20.5,yy,1.0)")
source=source.replace("2.8,3.2,(-22.1,yy,buttonz),graphite,64","2.8,4.7,(-22.85,yy,buttonz+.5),graphite,160")
source=source.replace("3.6,6.4,3.2,(-22.1,yy,buttonz),'X'","3.6,6.4,4.7,(-22.85,yy,buttonz+.5),'X'")
source=source.replace("abs(p.z-buttonz)<3.0","abs(p.z-buttonz)<3.7")
source=source.replace("(1.2,3.5,11.8),(-18.7,","(1.5,3.5,11.8),(-18.55,")
source=source.replace("'USB access opening',4.5,10.2,8,","'USB access opening',4.5,10.2,12,")

# All definitive filenames change revision; old supplier files remain intact.
source=source.replace('hiddenkeys_v3_','wallfix_v4_').replace('velaride_hiddenkeys_v3.blend','velaride_wallfix_v4.blend')
source=source.replace("'V3 | satin graphite nylon'","'V4 | satin graphite nylon'")
source=source.replace("'01_main_case_PA12_Q1_mm.stl'","'01_Main_case_V4_PA12_Q1_mm.stl'")
source=source.replace("'02_front_frame_PA12_Q1_mm.stl'","'02_Front_frame_V4_PA12_Q1_mm.stl'")
source=source.replace("'03_back_with_releases_PA12_Q1_mm.stl'","'03_Rear_cover_V4_NYLON_Q1_mm.stl'")
source=source.replace("'04_hidden_key_carrier_PA12_Q1_mm.stl'","'04_Key_carrier_V4_NYLON_Q1_mm.stl'")
(ROOT/'build_v4.py').write_text(source,encoding='utf8')
p=json.loads((V3/'case_parameters.json').read_text(encoding='utf8'))
p.update(design_revision='Wall corrected V4',case_width_mm=49.0,cavity_length_mm=43.6,minimum_structural_wall_requirement_mm=1.0,
    carrier_bottom_rail_nominal_mm=1.4,flexure_nominal_mm=1.2,outer_cheek_added_per_side_mm=1.5,
    carrier_pocket_open_to_parting_plane=True,round_corner_segments=96,outer_axial_max_step_mm=.25,
    exposed_button_center_z_shift_mm=.5)
(ROOT/'case_parameters.json').write_text(json.dumps(p,indent=2),encoding='utf8')
shutil.copy2(V3/'apple_profile.json',ROOT/'apple_profile.json')
verify=(V3/'verify_finish_v3.py').read_text(encoding='utf8')
verify=verify.replace('velaride_hiddenkeys_v3','velaride_wallfix_v4').replace('VelaRide | Hidden keys V3','VelaRide | Wall corrected V4').replace('VelaRide_HiddenKeys_V3_4parts','VelaRide_WallFix_V4_4parts').replace('V3 PRINT','V4 PRINT').replace('HIDDENV3_','WALLV4_').replace('hiddenkeys_v3_','wallfix_v4_')
(ROOT/'verify_finish_v4.py').write_text(verify,encoding='utf8')
print('V4 build script generated')
