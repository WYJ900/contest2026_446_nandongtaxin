import json,hashlib,shutil,struct,zipfile,html
from pathlib import Path

ROOT=Path('D:/desktop/VelaRide_AI')
MODEL=ROOT/'hardware-model/velaride_wallfix_v4'
STLS=ROOT/'exports/VelaRide_WallFix_V4_4parts'
OUT=ROOT/'exports/VelaRide_V4_Thickness_Review'
(OUT/'STL_4_PARTS').mkdir(parents=True,exist_ok=True)
(OUT/'REFERENCE').mkdir(exist_ok=True)
report=json.loads((MODEL/'case_verification.json').read_text(encoding='utf8'))
audit=json.loads((MODEL/'thickness_V4.json').read_text(encoding='utf8'))
before=json.loads((MODEL/'thickness_V3.json').read_text(encoding='utf8'))
assert len(report['parts'])==4 and len(audit)==4
assert all(p['under_1mm']==0 for p in audit)
assert all(p['boundary_edges']==0 and p['nonmanifold_edges']==0 and p['serialized_nonmanifold_edges']==0 for p in report['parts'])
assert all(v==0 for v in report['motion_checks'].values())
assert not report['hardware_body_intersections']
manifest=[]
names=['主壳','屏幕前框','后盖及表带释放片','内藏双按键连接板']
for i,p in enumerate(report['parts']):
    src=STLS/p['stl'];b=src.read_bytes();n=struct.unpack_from('<I',b,80)[0]
    assert len(b)==84+50*n and n==p['stl_triangles']
    shutil.copy2(src,OUT/'STL_4_PARTS'/src.name)
    manifest.append(dict(name=names[i],file='STL_4_PARTS/'+src.name,quantity=1,units='mm',dimensions_xyz_mm=p['dimensions_mm'],
        triangles=n,sha256=hashlib.sha256(b).hexdigest(),sampled_minimum_mm=audit[i]['minimum_sampled_mm'],
        sampled_under_1mm=audit[i]['under_1mm'],probe_count=audit[i]['opposed_surface_probe_count']))
notes='''VelaRide V4：薄壁修正与曲面细化版 — 请商家重新复检

本包整体替代V3。四个STL全部换成V4，不要混用旧主壳、前框或后盖。
每件1个，单位mm。仅外壳及按键机构；表带、电子件和现成五金均不打印。

已修改
1. 主壳宽度由46.0增加至49.0mm，每侧外壁增加1.5mm，覆盖按键内腔附近薄壁。
2. 取消按键内腔上方原约0.23mm的薄顶片，将该处开至前框分型面，装配后由厚前框覆盖。
3. 主腔长度44.5改为43.6mm，加强表带滑槽后方的隔墙；未缩放主板或屏幕。
4. 按键连接板底边由约0.5改为名义1.4mm，按钮外观中心上移0.5mm，内部开关接触位置保持。
5. 弹性臂名义厚度保留1.2mm，以免简单加厚后按键过硬；侧向导向筋加厚。
6. 主壳外轮廓改为连续曲率过渡的分段三次插值，轴向采样间隔不大于0.25mm。
   圆角每90度由20段提高到96段，圆孔/按钮圆周至少160段，倒角细分提高。
   这是实际导出网格的几何细化，不只是渲染中的平滑着色。

本地检查结果
四件网格均封闭、单一连通实体；STL重读边连接检查通过。
指定按压/释放姿态的表面避让检查通过；未发现硬件与主壳表面相交。
相向表面法向射线抽检：四件的最小采样厚度均约1.20mm，未采到小于1.00mm的区域。
主壳18235个有效探针、前框6024个、后盖5063个、连接板2154个。

请注意检查范围
上述为本地几何抽检，不是对所有位置的数学证明，也不是加工后最小厚度保证。
本地方法在面积至少0.002mm²的三角面中心沿内法线检测相向表面，使用法向夹角过滤；
尖角、倒角、极小面及斜向最短距离的解释可能与贵司软件不同。
请用贵司原先的壁厚检查软件，对V4按最小1mm要求重新扫描，确认原红色区域是否消除。
若仍有不足处，请返回零件文件名、截图和对应位置/测量厚度，继续据此修正。

尺寸与材质
01 主壳：49.0×62.8×13.48mm，硬质未填充PA12优先。
02 前框：约48.35×48.35×2.50mm，硬质未填充PA12优先。
03 后盖：约48.70×62.00×3.97mm，韧性未填充PA11优先，PA12替代需试装评估。
04 连接板：约5.95×28.00×12.00mm，韧性未填充PA11优先，局部需能弯曲回弹。
03/04不是整件软胶，不要用普通硬脆树脂直接替换。
表面目标为细腻哑光；清粉、喷砂和染色不可堵塞滑槽或磨薄弹性臂。

苹果大号表带滑扣剖面不整体放大，仍需用客户实际购买表带试装锁止、释放。
目前仍为机械试装版：未完成实际装配路径、回弹疲劳、表带抗拉及防水验证。
可编辑源文件位于本地 velaride_wallfix_v4.blend，报价/打印使用本包毫米STL。
'''
(OUT/'00_V4修改与复检说明.txt').write_text(notes,encoding='utf-8-sig')
msg='''你好，这是针对你们反馈“模型曲面粗糙、红色区域不足1mm”的V4修正版，请整体替换之前V3四个文件。

已加厚主壳按键侧壁，取消内腔顶部薄片，补强按键连接板底边，并重新细化实际STL曲面。
本地相向表面壁厚抽检四件最薄采样值均约1.2mm，没有采到小于1mm的位置；网格封闭性检查通过。

麻烦用你们原先的检查软件再跑一次“最小1mm壁厚”和曲面质量复检，特别看原截图红色区域。
如果仍有薄壁，请标出对应文件名、位置和测得厚度，不要直接加厚/缩放后生产。

四件各1个，单位毫米。表带我自己买，不用打印表带；电子件、铜柱和螺丝也不包含。
谢谢。
'''
(OUT/'01_直接转发商家.txt').write_text(msg,encoding='utf-8-sig')
summary={'revision':'V4 wall correction and high-resolution geometry','date_packaged':'2026-10-11','quantity_total':4,
 'units':'mm','purchased_band_included':False,'minimum_requirement_mm':1.0,
 'physical_fit_verified':False,'thickness_method':'Face-centroid inward ray with opposing-normal filter; sampling only, not exhaustive minimum wall certification.',
 'parts':manifest}
(OUT/'02_文件与检查结果.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
shutil.copy2(MODEL/'wallfix_v4_case_only.png',OUT/'REFERENCE/V4_case_only.png')
shutil.copy2(MODEL/'wallfix_v4_rear.png',OUT/'REFERENCE/V4_rear.png')
shutil.copy2(MODEL/'thickness_V4.json',OUT/'REFERENCE/thickness_probe_details.json')
shutil.copy2(MODEL/'case_verification.json',OUT/'REFERENCE/geometry_and_motion_checks.json')
rows=''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in [names[i],round(before[i]['minimum_sampled_mm'],3),round(audit[i]['minimum_sampled_mm'],3),audit[i]['under_1mm'],p['triangles']])+'</tr>' for i,p in enumerate(manifest))
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>V4 薄壁修正复检</title><style>body{font:15px/1.6 "Microsoft YaHei",sans-serif;max-width:1080px;margin:32px auto;padding:0 18px;color:#233340}table{width:100%;border-collapse:collapse;margin:20px 0}th,td{border:1px solid #bdc9d2;padding:10px;text-align:left}th{background:#263e50;color:white}.note{background:#eef5f0;padding:15px}.warn{background:#fff4df;padding:14px}img{max-width:100%}</style>
<h1>V4 薄壁修正与曲面细化</h1><div class="note">四件全部替换V3；每件1个，单位mm；表带客户自购。</div>
<p>加厚主壳侧壁；取消内腔顶部薄片；连接板底边由约0.5mm增加至名义1.4mm；重建外形连续过渡并提高圆角、圆孔和倒角网格细分。</p>
<table><tr><th>零件</th><th>V3抽检最小/mm</th><th>V4抽检最小/mm</th><th>V4小于1mm样本</th><th>STL三角面数</th></tr>'''+rows+'''</table>
<div class="warn">表中结果来自有限的相向表面射线抽检，不是完整最小壁厚证明。请商家使用原检查软件按1mm要求重新复检，并确认实际加工可行性。</div>
<p>主壳宽度增加至49mm，主板/屏幕/表带接口没有整体缩放。仍保留尼龙弹性按键与释放片，实际回弹、疲劳和锁止强度需打样确认。</p>
<img src="REFERENCE/V4_case_only.png" alt="V4外观"><p>STL实际已细化；效果图不代表制造表面粗糙度。</p></html>'''
(OUT/'03_V4复检概览.html').write_text(page,encoding='utf8')
(MODEL/'README.txt').write_text(notes,encoding='utf-8-sig')
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.endswith('.stl')])==4
    for p in manifest:assert hashlib.sha256(z.read(p['file'])).hexdigest()==p['sha256']
print(json.dumps({'review_zip':str(archive),'bytes':archive.stat().st_size,'stl_count':4,'each_quantity':1,'review_sampled_minimum_mm':[q['minimum_sampled_mm'] for q in audit]}))
