"""Clean numerical CSG slivers without global remeshing of fit interfaces."""
old=bpy.data.scenes['VelaRide | Large parts V8']
for num,obj in zip(('02','03','04'),(back,panel,spacer)):
    source=next(o for o in old.objects if o.name.startswith('V8 PRINT '+num))
    obj.modifiers.clear()
    obj.data=source.data.copy()
    if obj.data.shape_keys:obj.shape_key_clear()
for obj in (body,back,panel,spacer):
    apply_mods(obj)
    # Preserve the original deformation demonstrations by removing keys from the
    # new V9 sample only. Production meshes represent the rest position.
    if obj.data.shape_keys:obj.shape_key_clear()
    bm=bmesh.new();bm.from_mesh(obj.data)
    if obj==body:
        bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.001)
        bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.00001)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(obj.data);bm.free();obj.data.update()
    obj['revision']='V9'
    obj['physical_fit_verified']=False
print('V9 closed-shell construction complete')
