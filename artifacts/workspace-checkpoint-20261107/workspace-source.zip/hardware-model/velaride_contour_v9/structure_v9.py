"""Executed inside build_v8.py, using the common dimensioned geometry helpers."""
# Integrate the former 1.5-mm-wide loose U-retainer into the large rear cover.
apply_mods(back)
for side in (-1,1):
    z0=backtop-.12;z1=5.6
    rail=box('V9 integrated rear key support',(1.5,3.0,z1-z0),(-18.35,panel_y+side*12.9,(z0+z1)/2),rear_mat,r=.10)
    apply_mods(rail);boolean(back,rail,'UNION')
back['integrated_key_rails']=True
back['loose_small_retainer_removed']=True

# Four larger bosses transfer rear-cover force directly into the main shell.
# Standard nuts load against 2+ mm of nylon below each side-access pocket.
apply_mods(body)
shell_centres=[(x,y) for x in (-19.8,19.8) for y in (-20.6,20.6)]
saved_col=col
for idx,(x,y) in enumerate(shell_centres,1):
    z0=backtop;z1=-1.6
    boss=cylinder('V9 integral shell screw boss',3.7,z1-z0,(x,y,(z0+z1)/2),graphite,n=96)
    bevel(boss,.08,3);apply_mods(boss);boolean(body,boss,'UNION')
    boolean(body,cylinder('V9 M2 shell bore',1.1,7,(x,y,-5),None,n=64))
    angle=math.atan2(y,x)
    pocket=cylinder('V9 captive M2 hex pocket',4.2/math.sqrt(3),1.85,(x,y,-3.725),None,n=6)
    pocket.rotation_euler.z=angle;boolean(body,pocket)
    slot=box('V9 nut side loading corridor',(6.0,4.3,1.85),(x-3*math.cos(angle),y-3*math.sin(angle),-3.725),None,r=0)
    slot.rotation_euler.z=angle;boolean(body,slot)
    boolean(back,cylinder('V9 shell rear clearance',1.1,5,(x,y,backbottom+1),None,n=64))
    boolean(back,cylinder('V9 shell screw recessed head',1.9,.9,(x,y,backbottom+.35),None,n=96))
    col=hardwarecol
    nut=cylinder('HARDWARE V9 | shell M2 nut '+str(idx),4/math.sqrt(3),1.6,(x,y,-3.8),steel,n=6)
    nut.rotation_euler.z=angle;boolean(nut,cylinder('V9 nut thread envelope',.85,3,(x,y,-3.8),None,n=48))
    nut['specification']='M2 DIN934 nominal AF4 H1.6; purchased, not printed'
    head=cylinder('HARDWARE V9 | outer M2x6 head '+str(idx),1.65,.7,(x,y,backbottom+.45),steel,n=64)
    cylinder('HARDWARE V9 | outer M2x6 shank '+str(idx),1,6,(x,y,backbottom+3.8),steel,n=48)
    head['nominal_length_mm']=6;head['head_envelope_requires_supplier_check']=True
    col=saved_col

# Full-size one-piece inter-board frame; replaces four loose printed spacers.
zcore=boardhalf;zdisplay=P['display_pcb_center_z_mm']-.5000117
spacer=ring('V9 PRINT 04 | full board spacer frame',(35.0,41.3,8.3),(31.0,37.3,6.3),zcore+1.75,zcore+3.25,graphite)
for idx,(x,y) in enumerate(mounts,1):
    post=cylinder('V9 integrated board spacing post',3.3,zdisplay-zcore,(x,y,(zcore+zdisplay)/2),graphite,n=96)
    boolean(spacer,post,'UNION')
    boolean(spacer,cylinder('V9 board screw head access',2.1,7,(x,y,(zcore+zdisplay)/2),None,n=96))
    col=hardwarecol
    cylinder('HARDWARE V9 | board upper M2x4 head '+str(idx),1.65,.7,(x,y,zcore+.35),steel,n=64)
    cylinder('HARDWARE V9 | board upper M2x4 shank '+str(idx),1,4,(x,y,zcore-2),steel,n=48)
    col=saved_col
bevel(spacer,.06,3);apply_mods(spacer)
spacer['nominal_face_to_face_board_spacing_mm']=5.0
spacer['installation']='One large frame between PCB faces. Bores clear the four upper board screw heads.'
spacer['needs_real_board_contact_and_component_clearance_check']=True
