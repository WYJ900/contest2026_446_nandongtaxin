import bpy,bmesh,math,ast,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_contour_v9')
SRC=ROOT.parent/'huangshan_pi'
for path in [SRC/'build_blender.py',ROOT/'build_v9.py']:
    tree=ast.parse(path.read_text(encoding='utf8'))
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(path),'exec'))
s=bpy.data.scenes['VelaRide | Continuous contour V9'];bpy.context.window.scene=s;s.frame_set(1)
col=next(c for c in s.collection.children if c.name.startswith('CONTOURV9_01'))
hw=next(c for c in s.collection.children if c.name.startswith('CONTOURV9_02'))
body=next(o for o in s.objects if o.name.startswith('CASE | main body'))
back=next(o for o in s.objects if o.name.startswith('V9 PRINT 02'))
panel=next(o for o in s.objects if o.name.startswith('V9 PRINT 03'))
old=next(o for o in s.objects if o.name.startswith('V9 PRINT 04'))
graphite=body.data.materials[0]
if not body.get('v9_pocket_roof_cleaned'):
    tool=box('V9 pocket roof relief',(4.4,29.6,2.0),(-19.9,2.511686,5.1),None,r=0)
    boolean(body,tool)
    body['v9_pocket_roof_cleaned']=True

def tree_for(o):
    e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
    t=BVHTree.FromPolygons([o.matrix_world@v.co for v in m.vertices],[list(f.vertices) for f in m.polygons]);e.to_mesh_clear();return t

# Full-height support pads must avoid all modeled components on both boards.
obstacles=[o for o in hw.objects if o.type=='MESH' and 'exact outline' not in o.name]
obstacles += [body,back,panel]
trees=[(o.name,tree_for(o)) for o in obstacles]
safe=[]
for x in range(-8,9,2):
    for y in (-18.6,18.6):
        q=box('support clearance probe',(2.4,2.0,4.998),(x,y,3.0705856),None,r=0)
        t=tree_for(q);hits=[name for name,tr in trees if t.overlap(tr)]
        bpy.data.objects.remove(q,do_unlink=True)
        if not hits:safe.append((x,y))
print('SAFE SUPPORT CENTRES',safe)
chosen=[]
for x in (-6,6):
    for y in (-18.6,18.6):
        assert (x,y) in safe,('No safe support candidate',x,y)
        chosen.append((x,y))
spacer=ring('V9 PRINT 04 | component-clear board spacer',(34.0,39.8,8.0),(30.8,36.6,6.4),2.3205856,3.8205856,graphite)
for x,y in chosen:
    post=box('V9 full-height board contact pad',(2.4,2.0,5.0),(x,y,3.0705856),graphite,r=0)
    boolean(spacer,post,'UNION')
spacer['contact_pad_centres_mm']=json.dumps(chosen)
spacer['nominal_face_to_face_board_spacing_mm']=5.0
spacer['contact_pad_size_mm']=[2.4,2.0]
spacer['contact_status']='Clear of modeled components; real PCB copper/contact locations and tolerances must be checked.'
bpy.data.objects.remove(old,do_unlink=True)
# Move screw head previews down by 0.15 mm to match the actual counterbore seat.
# This also moves the corresponding shank: purchased length remains 6 mm.
for o in hw.objects:
    if o.name.startswith(('HARDWARE V9 | outer M2x6 head','HARDWARE V9 | outer M2x6 shank')) and not o.get('v9_seated'):
        o.location.z-=.15;o['v9_seated']=True
for o in (body,spacer):
    bm=bmesh.new();bm.from_mesh(o.data)
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.0001)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
    for f in o.data.polygons:f.use_smooth=abs(f.normal.z)<.9999
    o['physical_fit_verified']=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_contour_v9.blend'))
(ROOT/'support_positions.json').write_text(json.dumps(chosen),encoding='utf8')
