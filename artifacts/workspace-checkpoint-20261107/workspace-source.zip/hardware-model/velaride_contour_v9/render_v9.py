"""Render actual Blender geometry for review, not an illustration of hypothetical fit."""
import bpy, math
from pathlib import Path
from mathutils import Vector
ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/velaride_contour_v9')
OUT=Path('D:/desktop/VelaRide_AI/exports/VelaRide_V9_Engineering_Package')/'REFERENCE'
OUT.mkdir(parents=True,exist_ok=True)
s=bpy.data.scenes['VelaRide | Continuous contour V9'];bpy.context.window.scene=s
s.frame_set(1)
cam=s.camera
def enum(obj,prop,value):
    assert value in [i.identifier for i in obj.bl_rna.properties[prop].enum_items]
    setattr(obj,prop,value)
# Engine initialized by the source blend; use that renderer.
s.render.resolution_x=1400;s.render.resolution_y=1400;s.render.resolution_percentage=100
enum(s.render.image_settings,'file_format','PNG')
for ob in s.objects:
    if ob.type=='MESH' and ('CASE | main body' in ob.name or ob.name.startswith('V9 PRINT')):
        # Flat mechanical walls should stay planar; smoothly shade only curved faces.
        for p in ob.data.polygons:p.use_smooth=abs(p.normal.z)<.9999
def point(loc,target=(0,0,0)):
    cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
views=[('V9_hero.png',(-74,-108,126),94),('V9_top.png',(0,0,160),88),('V9_side.png',(-140,-36,36),90)]
for filename,loc,scale in views:
    point(loc);cam.data.ortho_scale=scale;s.render.filepath=str(OUT/filename)
    bpy.ops.render.render(write_still=True)
# Hardware fit view: only the four printable components, separated vertically.
show=[o for o in s.objects if o.name.startswith(('CASE | main body','V9 PRINT'))]
saved={o:o.hide_render for o in s.objects}
locations={o:o.location.copy() for o in show}
for o in s.objects:
    if o.type not in ('CAMERA','LIGHT') and o not in show:o.hide_render=True
for o in show:
    o.hide_render=False
    if o.name.startswith('CASE | main body'):o.location.x-=32;o.location.y+=30
    if o.name.startswith('V9 PRINT 02'):o.location.x+=32;o.location.y+=30
    if o.name.startswith('V9 PRINT 03'):o.location.x-=10;o.location.y-=37
    if o.name.startswith('V9 PRINT 04'):o.location.x+=32;o.location.y-=37
point((0,-105,190),(0,0,0));cam.data.ortho_scale=146
s.render.filepath=str(OUT/'V9_four_parts.png');bpy.ops.render.render(write_still=True)
for o,v in saved.items():o.hide_render=v
for o,v in locations.items():o.location=v
point((-74,-108,126));cam.data.ortho_scale=94
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            sp=a.spaces.active;sp.region_3d.view_distance=94;sp.region_3d.view_location=(0,0,0);sp.region_3d.view_rotation=cam.rotation_euler.to_quaternion()
            enum(sp.shading,'type','MATERIAL');sp.overlay.show_overlays=False
s.render.filepath=str(OUT/'V9_hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'velaride_contour_v9.blend'))
print('V9 renders saved')
