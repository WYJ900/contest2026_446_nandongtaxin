"""Derive a new enclosure from V8, retaining the supplied hardware coordinates."""
from pathlib import Path
import json, shutil

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'velaride_largeparts_v8'
s = (OLD/'build_v8.py').read_text(encoding='utf8')
for a,b in [('velaride_largeparts_v8','velaride_contour_v9'),('VelaRide | Large parts V8','VelaRide | Continuous contour V9'),('LARGEV8_','CONTOURV9_'),('largeparts_v8_','contour_v9_'),('V8','V9')]:
    s=s.replace(a,b)
# One outer/inner loft replaces the coplanar lip + bridge + bezel unions.
i=s.index("body=loft_ring(")
j=s.index("body['part']",i)
s=s[:i]+"exec(compile((ROOT/'continuous_shell.py').read_text(encoding='utf8'),'continuous_shell.py','exec'),globals())\n"+s[j:]
i=s.index("bezel=rolled_front(")
j=s.index("trim=ring(",i)
s=s[:i]+s[j:]
i=s.index("bezel['attachment_note']")
j=s.index("screenblack=mat(",i)
s=s[:i]+s[j:]
i=s.index('apply_mods(body);apply_mods(bezel)')
j=s.index("body['screen_retention']",i)
s=s[:i]+"apply_mods(body)\n"+s[j:]
s=s.replace("mod.object=tool", "mod.object=tool;enum(mod,'solver','EXACT')")
s=s.replace('structure_v8.py','structure_v9.py')
# The bevel was applied before the bosses in V8. Use only the final clean-up.
s=s.replace('bevel(body,.11,3)', '# Final edges are finished after all CSG operations.')
s=s.replace("17.0,29.6,4.4,(-19.9,panel_y,.8)", "13.1,29.6,4.4,(-19.9,panel_y,-1.15)")
s=s.replace("graphite=mat('V9 | graphite nylon',(.022,.029,.036),.05,.48)","graphite=mat('V9 | satin graphite nylon',(.065,.078,.089),.12,.32)")
s=s.replace("rubber=mat('Watch | black FKM',(.009,.014,.019),0,.49)","rubber=mat('V9 | mineral green purchased band',(.12,.19,.17),0,.52)")
s=s.replace("rear_mat=mat('Watch | rear engineering polymer',(.019,.027,.038),.07,.4)","rear_mat=mat('V9 | dark rear nylon',(.026,.033,.039),.05,.43)")
s=s.replace("scene.render.resolution_x=1600;scene.render.resolution_y=1500", "scene.render.resolution_x=1500;scene.render.resolution_y=1500")
s=s.replace("for ob in (body,back,panel,spacer):", "exec(compile((ROOT/'finish_geometry.py').read_text(encoding='utf8'),'finish_geometry.py','exec'),globals())\nfor ob in (body,back,panel,spacer):")
s=s.replace("'velaride_contour_v9.blend'", "'velaride_contour_v9.blend'")
s=s.replace('VelaRide V5 engineering sample;', 'VelaRide V9 engineering sample;')
(ROOT/'build_v9.py').write_text(s,encoding='utf8')
(ROOT/'structure_v9.py').write_text((OLD/'structure_v8.py').read_text(encoding='utf8').replace('V8','V9'),encoding='utf8')
shutil.copy2(OLD/'apple_profile.json',ROOT/'apple_profile.json')
p=json.loads((OLD/'case_parameters.json').read_text(encoding='utf8'))
p.update(design_revision='Continuous contour V9',outer_shoulder_interpolation='Single continuous Bezier shoulder, integral front lip',production_release=False,physical_fit_verified=False)
p['front_bezel_height_mm']=None
p['front_roll_drop_mm']=None
p['front_side_roll_horizontal_mm']=None
p['front_separate_printed_part']=False
p['minimum_structural_wall_requirement_mm']=1.0
p['design_status']='Nylon prototype; estimated glass and component heights; battery/cable envelope missing'
(ROOT/'case_parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf8')
print(ROOT/'build_v9.py')
