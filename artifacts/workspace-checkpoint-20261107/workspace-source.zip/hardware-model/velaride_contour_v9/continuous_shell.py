"""One closed shell; millimetres. Continuous outer shoulders and stepped inner stop."""
zmax=top+2.57

def bezier(t,p):
    u=1-t
    return u*u*u*p[0]+3*u*u*t*p[1]+3*u*t*t*p[2]+t*t*t*p[3]

def bezier_at_z(z,zp,vp):
    lo,hi=0.0,1.0
    for _ in range(45):
        t=(lo+hi)/2
        if bezier(t,zp)<z:lo=t
        else:hi=t
    return bezier((lo+hi)/2,vp)

outer=[]
for i in range(51):
    z=bottom+(-1-bottom)*i/50
    t=min(1,max(0,(z-bottom)/1.2));u=t*t*t*(10+t*(-15+6*t))
    outer.append((z,W-.3+.3*u,60+.8*u,R-.25+.25*u))
for i in range(1,121):
    # Dense sampling near the horizontal top tangent.
    t=i/120;z=-1+(zmax+1)*math.sin(t*math.pi/2)
    w=bezier_at_z(z,[-1,7.8,zmax,zmax],[48,48,46,36.3])
    h=bezier_at_z(z,[-1,1.7,zmax,zmax],[60.8,60.8,49.0,42.7])
    r=10.2+(8.7-10.2)*t*t*(3-2*t)
    outer.append((z,w,h,r))

inner=[(bottom,39,43.6,7.8),(4.9,39,43.6,7.8),(5.4,44.2,43.6,7.2),(6.10,44.2,43.6,7.2)]
for i in range(1,41):
    t=i/40;u=t*t*t*(10+t*(-15+6*t))
    inner.append((6.10+.95*t,44.2+(35.6-44.2)*u,43.6+(42.0-43.6)*u,7.2+(8.15-7.2)*u))
inner += [(top+1.37,35.6,42.0,8.15),(top+1.37,33.5,39.9,7.3),(zmax,33.5,39.9,7.3)]
n=len(rr(*outer[0][1:]));no=len(outer);ni=len(inner)
verts=[(x,y,z) for z,w,h,r in outer+inner for x,y in rr(w,h,r)]
faces=[]
for k in range(no-1):
    for i in range(n):
        j=(i+1)%n;faces.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
base=no*n
for k in range(ni-1):
    for i in range(n):
        j=(i+1)%n;faces.append((base+k*n+j,base+k*n+i,base+(k+1)*n+i,base+(k+1)*n+j))
for i in range(n):
    j=(i+1)%n
    faces.extend([(j,i,base+i,base+j),((no-1)*n+i,(no-1)*n+j,base+(ni-1)*n+j,base+(ni-1)*n+i)])
body=mesh('CASE | main body with Apple slide rails',verts,faces,graphite)
bm=bmesh.new();bm.from_mesh(body.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(body.data);bm.free()
body['construction']='Single closed loft; integral glass stop; no coplanar front unions'
