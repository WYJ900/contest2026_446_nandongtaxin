"""Collect the reviewed geometry and its actual verification into a vendor review package."""
from pathlib import Path
import json,shutil,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'exports'/'VelaRide_V9_Engineering_Package'
SRC=OUT/'SOURCE';SRC.mkdir(parents=True,exist_ok=True)
report=json.loads((ROOT/'verification_v9.json').read_text(encoding='utf8'))
assert len(report['parts'])==4
for p in report['parts']:
    assert all(p[k]==0 for k in ['nonmanifold_edges','boundary_edges','serialized_bad_edges','serialized_zero_area_faces','nonadjacent_self_overlap_candidates','sampled_under_1mm'])
assert not any(report['part_surface_intersections'].values())
params=json.loads((ROOT/'case_parameters.json').read_text(encoding='utf8'))
params.update(board_spacer_contact_centres_mm=json.loads((ROOT/'support_positions.json').read_text()),
    board_spacer_contact_pad_mm=[2.4,2.0],outer_axial_max_step_mm=None,
    front_base_outline_mm=None,front_joint_lowered_mm=None,
    case_length_mm=60.8,source_legacy_case_length_parameter_mm=47.4,
    outer_shell_dimensions_mm=[48.0,60.8,18.59118],
    shell_screw_preview_seating_correction_mm=-.15,
    key_pocket_roof_relief_top_z_mm=6.1,
    validation_file='../REFERENCE/verification_v9.json')
(ROOT/'case_parameters_final.json').write_text(json.dumps(params,ensure_ascii=False,indent=2),encoding='utf8')
for name in ['velaride_contour_v9.blend','case_parameters_final.json','build_v9.py','continuous_shell.py','finish_geometry.py','structure_v9.py','refine_fit_v9.py','check_export_v9.py','render_v9.py','apple_profile.json','support_positions.json']:
    shutil.copy2(ROOT/name,SRC/name)
notes='''VelaRide V9｜连续圆弧四件版｜2026-10-11

用途：外观审查、加工评估和尼龙首件打样。不是已验证可批量生产的成品。
源自 exports 的 V7 工程资料，以及工作区当前 V8 四件版。
V7/V8 文件均保留；必须整套使用 V9，不能混用旧版主壳或支撑架。

本次修改
1. 主壳上半部重建为连续圆弧，取消原上下两层肩部的视觉台阶。
2. 主壳、正面框和玻璃止挡改为单个封闭壳体，修复 V8 主壳破面。
3. 清理按键槽顶端的薄片，使当前法向壁厚抽检最低值约 1.16 mm。
4. 板间支撑架改为四个避开已建模器件的支撑点，仍保持 5 mm 板间净距。
5. 保留 PCB 位置、USB 位置、双按键、6 mm 铜柱和原表带滑槽轮廓。
6. 石墨灰壳体、灰绿色表带为效果图方案；表带为外购示意，不打印。

整体尺寸与屏幕
外壳约 48.0 × 60.8 × 18.591 mm，不含外突按键及表带。
屏幕玻璃模型约 35.1 × 41.5 mm；正面止挡开口 33.5 × 39.9 mm。
玻璃周围顶面边宽约 1.4 mm，不等于发光区到整机外缘的黑边。
屏幕和电路板未缩放，未以渲染方式伪造更大的显示面积。
圆形件为现有按键帽，不是已增加旋转编码器功能的数码表冠。

打印清单（STL_4_PARTS，单位 mm，各 1 件）
01 一体主壳：未填充 PA12 候选。
02 后盖及一体释放弹臂：未填充 PA11 候选。
03 双按键板及弹臂：未填充 PA11 候选。
04 板间支撑架：未填充 PA12 候选。
整套 4 件。所有 STL 独立居中、底部落在 Z=0；装配坐标偏移记录在检查 JSON。
不能把所有 STL 原点重合后打印成一个总成，也不要统一缩放补偿。

实测/模型证据边界
PCB 板框和元件 XY 来自本地官方 EDA 工程提取模型。
玻璃外形和厚度、部分元件高度仍为原模型的估算，不是已确认的供应商机械图。
电池、排线弯折区和线束尚未建模。实际装配和整机厚度必须带实物复核。
四件导出 STL 均为单连通封闭网格，无破边、非流形边、零面积面；未检出非邻接自相交候选。
四件静止位置间未检出表面交叉；已建模器件无外壳干涉。
支撑架与两块 PCB 板面存在名义接触，浮点误差在约 0.000002 mm；属于预期支撑面。
该检测不覆盖完整包容、连续装配路径、公差叠加、力学、疲劳或防水性能。
壁厚为法向射线抽检，不是穷尽的最小壁厚证明。详细数量、算法和散列见检查 JSON。

效果图
REFERENCE/V9_hero.png：正面斜视。
REFERENCE/V9_top.png：正视。
REFERENCE/V9_side.png：侧视。
REFERENCE/V9_four_parts.png：四件拆分示意，移位仅为展示。
全部从本次 Blender 几何直接渲染；颜色、表面光泽和表带均为视觉预览。

材料路线
本版按尼龙功能样评估。树脂可另做外观样，但普通脆性树脂不能直接替代弹臂材料。
金属方案需要重新设计弹臂、绝缘及天线附近结构；本套不能直接换材质下单。
TPU 暂用于软垫/表带方向，不能直接替代四个承力件。
不承诺任何商家的工艺精度或具体材料牌号。最终以厂家工艺评审和首件实测为准。

参考来源
Apple Watch Series 7 的圆角及边缘连续设计：
https://www.apple.com/newsroom/2021/09/apple-reveals-apple-watch-series-7-featuring-the-largest-most-advanced-display/
Formlabs SLS 设计指南（PA11 延展性高于其 PA12 的材料说明，仅作选材参考）：
https://formlabs.com/white-papers/fuse-series-sls-design-guide/
硬件来源及估算项：hardware-model/huangshan_pi/README.txt 与原始 EDA。

源码重建说明
这些脚本记录本工作区的修改流程；build_v9.py 依赖同级 huangshan_pi 资料和 V8 源场景。
在本工作区依次运行 build_v9.py → refine_fit_v9.py → check_export_v9.py → render_v9.py。
单独转发的压缩包不是完整自包含的脚本重建环境；Blender 成品文件和四件 STL 可独立打开。
SOURCE/case_parameters_final.json 为交付参数。build_v9.py 的初始参数读取位于原工作区。
'''
(OUT/'00_先读_设计与验证范围.txt').write_text(notes,encoding='utf8')
vendor='''厂家评估稿｜VelaRide V9 四件尼龙手表壳

请先做可制造性评估及一套首件报价，不按量产文件直接生产。
只加工 STL_4_PARTS 中 4 个文件，各 1 件，全部单位 mm，保持原始尺寸。
主壳、支撑架考虑未填充 PA12；带弹臂的后盖和按键板考虑未填充 PA11。
请反馈实际工艺（SLS/MJF 等）、材料牌号、层厚、尺寸公差、喷砂/染色方案。
若只能提供 PA12，请先评估按键和表带释放弹臂的回弹及寿命；不直接用普通树脂替换。

关键要求
1. 滑槽采用原方案名义 0.12 mm 径向间隙；请先用实际外购表带试配。
   此间隙没有针对贵司工艺验证，必要时先加工局部试片，未经沟通不要全局缩放。
2. 窄槽、螺母腔、弹臂缝隙和 USB 开口必须清粉并检查通畅。
3. M2 螺钉、螺母、6 mm 铜柱均为外购件；实际头型、长度、牙型和扳手空间待确认。
4. 先核对真实玻璃机械图及表面压紧量，再确定 0.2 mm 软垫和止挡结构。
5. 5 mm 板间支撑架的四处接触面需与真实 PCB 核对，避开焊点/测试点和裸铜。
6. 电池和 FPC/线束未纳入本模型，必须装实物检查后再定版。
7. 不进行任意抽壳、自动减薄、按比例缩小、网格粗化或薄壁自动填充。

建议首件顺序
确认材料与工艺 → 核对真实玻璃/PCB/电池/表带 → 局部滑槽试配 → 四件样品 → 清粉去毛刺 → 无电池试装 → 按键/表带保持力和回弹测试 → 整机装配。
本文件未授权下单或付款；供用户自行联系厂家评估。
'''
(OUT/'01_可转发厂家_评估要求.txt').write_text(vendor,encoding='utf8')
manifest={'revision':'V9','production_release':False,'files':[]}
for f in sorted(OUT.rglob('*')):
    if f.is_file() and f.name!='package_manifest.json':manifest['files'].append({'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(OUT/'package_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
with zipfile.ZipFile(OUT.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(OUT.rglob('*')):
        if f.is_file():z.write(f,f.relative_to(OUT.parent))
print(OUT.with_suffix('.zip'))
