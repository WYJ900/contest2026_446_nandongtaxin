from pathlib import Path
root=Path(__file__).resolve().parent
s=(root.parent/'velaride_rolled_v7'/'check_export_v7.py').read_text(encoding='utf8')
s=s[:s.index('body,bezel,back,panel,retainer=parts')]
s=s.replace('velaride_rolled_v7','velaride_contour_v9').replace('VelaRide | Rolled V7','VelaRide | Continuous contour V9').replace('V7','V9').replace('STL_5_PARTS','STL_4_PARTS')
i=s.index('parts=[');j=s.index('\ndef evaluated',i)
s=s[:i]+'''parts=[next(o for o in s.objects if o.name.startswith(prefix)) for prefix in
       ('CASE | main body','V9 PRINT 02','V9 PRINT 03','V9 PRINT 04')]
names=['01_Continuous_shell_V9_PA12_Q1_mm.stl','02_Rear_cover_V9_PA11_Q1_mm.stl',
       '03_Dual_key_panel_V9_PA11_Q1_mm.stl','04_Board_spacer_V9_PA12_Q1_mm.stl']
'''+s[j:]
s=s.replace(".002 if o.name.startswith('V9 PRINT 03') else (.0001 if o.name.startswith('V9 PRINT 04') else .001)",".002 if o.name.startswith('V9 PRINT 02') else (.0001 if o.name.startswith(('V9 PRINT 03','V9 PRINT 04')) else .001)")
s+= '''
report['part_surface_intersections']={}
trees=[tree(o) for o in parts]
for i in range(4):
    for j in range(i+1,4):
        hits=trees[i].overlap(trees[j])
        report['part_surface_intersections'][str(i+1)+'_'+str(j+1)]=len(hits)
hw=next(c for c in s.collection.children if c.name.startswith('CONTOURV9_02'))
report['hardware_surface_intersections']={}
for i,bt in enumerate(trees):
    report['hardware_surface_intersections'][str(i+1)]=[o.name for o in hw.objects if o.type=='MESH' and bt.overlap(tree(o))]
report['collision_scope']='Triangle-surface overlap at rest, including nominal contact. Does not prove full-containment absence or an assembly path.'
report['glass_dimensions_estimated']=True
report['battery_and_wiring_not_modeled']=True
(ROOT/'verification_v9.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'REFERENCE'/'verification_v9.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
'''
(root/'check_export_v9.py').write_text(s,encoding='utf8')
