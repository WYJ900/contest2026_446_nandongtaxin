"""Extract official EasyEDA Pro board geometry; coordinates in the file are mils."""
import collections
import json
import math
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
SCALE = 0.0254

def records(data):
    return [r for s in data.decode('utf-8').splitlines() if s.strip() for r in [json.loads(s)] if r]

def path_points(path):
    if not path or isinstance(path[0], str):
        return []
    pts = [(path[0], path[1])]
    i = 2
    mode = 'L'
    while i < len(path):
        if isinstance(path[i], str):
            mode = path[i]
            i += 1
        if mode == 'L':
            pts.append((path[i], path[i+1]))
            i += 2
        elif mode == 'ARC':
            angle, x, y = path[i:i+3]
            i += 3
            x0, y0 = pts[-1]
            dx, dy = x-x0, y-y0
            theta = math.radians(angle)
            if abs(theta) < 1e-8 or math.hypot(dx,dy)<1e-5:
                pts.append((x,y))
                continue
            # Signed included angle, positive counterclockwise in EDA XY.
            factor = 0.5 / math.tan(theta/2)
            cx, cy = (x+x0)/2-dy*factor, (y+y0)/2+dx*factor
            a0 = math.atan2(y0-cy, x0-cx)
            rad = math.hypot(x0-cx,y0-cy)
            n = max(3, math.ceil(abs(angle)/3))
            pts.extend((cx+rad*math.cos(a0+theta*j/n),cy+rad*math.sin(a0+theta*j/n)) for j in range(1,n+1))
        else:
            raise ValueError(mode)
    return pts

def extract():
    z = zipfile.ZipFile(ROOT/'references/huangshan_v1_2.epro')
    project = json.loads(z.read('project.json'))
    footprints = {}
    for n in z.namelist():
        if n.endswith('.efoo'):
            footprints[Path(n).stem] = records(z.read(n))
    boards=[]
    for n in z.namelist():
        if not n.endswith('.epcb'):
            continue
        rr=records(z.read(n))
        starts=[i for i,r in enumerate(rr) if r[0]=='DOCTYPE']+[len(rr)]
        for a,b in zip(starts,starts[1:]):
            seg=rr[a:b]
            if seg[0][1]=='FOOTPRINT':
                footprints[seg[1][1]['uuid']]=seg
            elif seg[0][1]=='PCB':
                boardrows=seg
        rr=boardrows
        outline=next(r for r in rr if r[0]=='POLY' and r[4]==11)
        points=path_points(outline[6])
        xmin,xmax=min(p[0] for p in points),max(p[0] for p in points)
        ymin,ymax=min(p[1] for p in points),max(p[1] for p in points)
        ox,oy=(xmin+xmax)/2,(ymin+ymax)/2
        attrs=collections.defaultdict(dict)
        for r in rr:
            if r[0]=='ATTR':
                attrs[r[3]][r[7]]=r[8]
        components=[]
        for c in rr:
            if c[0]!='COMPONENT':continue
            a=attrs[c[1]]
            dev=project['devices'].get(a.get('Device'),{})
            da=dev.get('attributes',{})
            fp=a.get('Footprint') or da.get('Footprint')
            fr=footprints.get(fp,[])
            tr=da.get('3D Model Transform','')
            tr=[float(v) for v in tr.split(',')] if tr else []
            compshape=[]
            for r in fr:
                if r[0]=='POLY' and r[4]==48:
                    compshape.extend(path_points(r[6]))
            bounds=None
            if compshape:
                bounds=[min(p[0] for p in compshape),min(p[1] for p in compshape),max(p[0] for p in compshape),max(p[1] for p in compshape)]
                bounds=[v*SCALE for v in bounds]
            components.append(dict(ref=a.get('Designator',c[1]),part=dev.get('title',''),footprint=fp,
                x=(c[4]-ox)*SCALE,y=(c[5]-oy)*SCALE,rotation=c[6],side=c[3],bounds=bounds,
                model_transform_mil=tr,model_title=da.get('3D Model Title',''),
                height=da.get('Height Above Board',''),pads=[r for r in fr if r[0]=='PAD'],
                fills=[r for r in fr if r[0]=='FILL'],silk=[r for r in fr if r[0]=='POLY' and r[4]==3]))
        board=dict(name='display_pcb' if len(components)<30 else 'core_pcb',source=n,
            width=(xmax-xmin)*SCALE,length=(ymax-ymin)*SCALE,
            thickness=sum(r[3] for r in rr if r[0]=='LAYER_PHYS')*SCALE,
            center_mil=[ox,oy],outline=[[(x-ox)*SCALE,(y-oy)*SCALE] for x,y in points],
            components=components,tracks=[r for r in rr if r[0]=='LINE' and r[4] in (1,2)],
            cutouts=[r[7][0] for r in rr if r[0]=='FILL' and r[4]==12 and r[7][0][0]=='R'],
            vias=[r for r in rr if r[0]=='VIA'],strings=[r for r in rr if r[0]=='STRING' and r[3] in (3,4)])
        boards.append(board)
    (ROOT/'hardware_parameters.json').write_text(json.dumps(boards,indent=2,ensure_ascii=False),encoding='utf8')
    for b in boards:
        print(b['name'], 'size mm',round(b['width'],4),round(b['length'],4),'stackup mm',round(b['thickness'],4),'components',len(b['components']))
        print('mounting',[(c['ref'],round(c['x'],4),round(c['y'],4)) for c in b['components'] if c['ref'] in ('M1','M2','M3','M4')])

if __name__=='__main__':extract()
