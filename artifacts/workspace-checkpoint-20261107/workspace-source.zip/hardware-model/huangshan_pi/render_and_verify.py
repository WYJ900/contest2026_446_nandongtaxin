import bpy
import bmesh
import json
import hashlib
from pathlib import Path
from mathutils import Vector

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/huangshan_pi')
s=bpy.context.scene
cam=s.camera
report={'source_sha256':hashlib.sha256((ROOT/'references/huangshan_v1_2.epro').read_bytes()).hexdigest(),'boards':[]}
for o in bpy.data.objects:
    if 'exact outline' not in o.name:continue
    bm=bmesh.new();bm.from_mesh(o.data)
    item={'name':o.name,'dimensions_mm':list(o.dimensions),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'mounting_holes':{k:o[k] for k in o.keys() if 'hole_diameter' in k}}
    bm.free()
    assert item['boundary_edges']==0 and item['nonmanifold_edges']==0,item
    assert abs(o.dimensions.x-o['width_mm'])<.001
    assert abs(o.dimensions.y-o['length_mm'])<.001
    report['boards'].append(item)
report['physical_assembly_fit_verified']=False
report['geometry_note']='Board XY from official EDA; component bodies simplified; glass and assembly spacing estimated.'
(ROOT/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')

s.frame_set(1)
s.render.filepath=str(ROOT/'huangshan_overview.png')
bpy.ops.render.render(write_still=True)
original_loc=cam.location.copy();original_rot=cam.rotation_euler.copy();original_scale=cam.data.ortho_scale
s.frame_set(60)
cam.location=(68,-108,85);cam.rotation_euler=(Vector((0,0,10))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=75
s.render.filepath=str(ROOT/'huangshan_exploded.png')
bpy.ops.render.render(write_still=True)
s.frame_set(1)
cam.location=original_loc;cam.rotation_euler=original_rot;cam.data.ortho_scale=original_scale
s.render.filepath=str(ROOT/'huangshan_overview.png')
# Save the friendly overview, without a render window obscuring the model.
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'huangshan_pi_v1_2.blend'))
print(json.dumps(report))
