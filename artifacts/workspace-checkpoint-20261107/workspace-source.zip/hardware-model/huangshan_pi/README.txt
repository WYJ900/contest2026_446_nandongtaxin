黄山派 SF32LB52 V1.2 — Blender 参数化可视化模型

已通过本机 Blender 5.2.1 LTS + MCP 创建。

文件
  huangshan_pi_v1_2.blend   可编辑模型、材质、灯光、相机和三种布局
  huangshan_overview.png    核心板及屏幕概览
  huangshan_exploded.png    分层展示
  hardware_parameters.json 从官方 EDA 工程提取的参数
  verification.json        板框尺寸与网格封闭性检查结果
  extract_hardware.py      原始 EDA 参数提取程序（Python 标准库）
  build_blender.py          Blender 建模脚本
  render_and_verify.py      渲染与校验脚本
  references/              原始官方工程和参考图

查看
  打开 .blend 后即可看到核心板与显示屏。
  时间轴第 1 帧：部件并排展示。
  时间轴第 60 帧：分层展示（间距为展示用估算值）。
  时间轴第 120 帧：装配示意（间距为估算值，未校核实物装配）。
  模型单位：1 Blender 单位 = 1 mm；单位比例 0.001。
  原有启动场景对象保留在原集合内并隐藏。

几何依据
  核心板与显示转接板板框外包尺寸：35.1104 × 41.4767 mm。
  主板厚度：约 1.1412 mm，来自工程层叠厚度求和，包含阻焊层。
  显示转接板厚度：约 1.0000 mm，来自工程层叠厚度求和。
  核心板四个安装孔直径：2.5 mm。
  显示转接板安装孔开口：2.6 mm，来自封装多层开孔图元。
  还原板框曲线、板上开槽、器件 XY 位置/角度/所在面、焊盘和封装丝印。
  提取器件记录：主板 156 项，显示板 15 项，包含孔位和测试点。
  原始内部坐标按 mil × 0.0254 转换为毫米；曲线采样最大角步长 3°。

精度范围
  封装实体使用工程中形状层/3D 外包参数作简化建模。
  大部分器件高度、连接器内部细节、模组内芯片与天线细节为展示性简化。
  玻璃外形、厚度、圆角及屏幕与板之间距离为估算，不属于官方机械尺寸。
  显示有效区域由 1.85 英寸、390×450 和方形像素假设推算。
  VelaRide 界面为演示画面，不是实际固件截图。
  未建电池、喇叭、外壳、螺丝及 FPC 连接排线。
  此版本适合展示与布局讨论，不能作为已验证的开模或打印装配依据。

来源（检索/下载日期 2026-10-10）
  思澈官方黄山派使用指南及“黄山派设计图纸”下载入口：
  https://wiki.sifli.com/board/sf32lb52x/SF32LB52-%E9%BB%84%E5%B1%B1%E6%B4%BE.html
  原始工程：
  https://downloads.sifli.com/hardware/files/documentation/ProPrj_%E7%AB%8B%E5%88%9B%C2%B7%E9%BB%84%E5%B1%B1%E6%B4%BESF32LB52%E5%BC%80%E5%8F%91%E6%9D%BFV1.2%28202504250924%29.epro
  立创官方硬件参数：
  https://wiki.lckfb.com/zh-hans/hspi-sf32lb52/hardware/board.html
  参考图取自思澈官方指南的 SVG 嵌入图片；该参考图标注 V1.1，
  只用于核对外观，主板坐标和器件信息以 V1.2 EDA 工程为准。
  原始工程及参考图权利归各自权利人；这里保留用于本模型的来源核对。

重建
  先运行 extract_hardware.py，再在 Blender 中运行 build_blender.py。
  build_blender.py 与 render_and_verify.py 的 ROOT 是本项目绝对路径，
  迁移目录后需修改 ROOT。
