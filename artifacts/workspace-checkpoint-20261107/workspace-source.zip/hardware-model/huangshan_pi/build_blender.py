"""Run in Blender. Rebuilds only the named Huangshan model collection.
XY and board outlines are extracted from the official V1.2 EDA project.
Generic component heights, display glass and assembly spacing are visualization estimates.
"""
import bpy
import math
import json
import sys
from pathlib import Path
from mathutils import Vector, Quaternion

ROOT=Path('D:/desktop/VelaRide_AI/hardware-model/huangshan_pi')
sys.path.insert(0,str(ROOT))
from extract_hardware import path_points
BOARDS=json.loads((ROOT/'hardware_parameters.json').read_text(encoding='utf8'))
S=.0254

def enum(obj,prop,wanted):
    items=obj.bl_rna.properties[prop].enum_items
    allowed=[i.identifier for i in items]
    if wanted in allowed:setattr(obj,prop,wanted)
    else:raise ValueError((prop,wanted,allowed))

scene=bpy.context.scene
scene.name='Huangshan Pi | components and assembly'
old=bpy.data.collections.get('HUANGSHAN_V1_2')
if old:
    for o in list(old.all_objects):bpy.data.objects.remove(o,do_unlink=True)
    bpy.data.collections.remove(old)
col=bpy.data.collections.new('HUANGSHAN_V1_2')
scene.collection.children.link(col)
# Preserve the original startup objects in their original collection.
for c in scene.collection.children:
    if c!=col:c.hide_render=True;c.hide_viewport=True
enum(scene.unit_settings,'system','METRIC')
scene.unit_settings.scale_length=.001
scene.unit_settings.length_unit='MILLIMETERS'  # Runtime enum verified on Blender 5.2.

def link(o,parent=None):
    for c in list(o.users_collection):c.objects.unlink(o)
    col.objects.link(o)
    if parent:o.parent=parent
    return o

def mat(name,color,metal=0,rough=.4,emit=0):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes=True
    n=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
    n.inputs['Base Color'].default_value=(*color,1)
    n.inputs['Metallic'].default_value=metal
    n.inputs['Roughness'].default_value=rough
    if emit:
        n.inputs['Emission Color'].default_value=(*color,1)
        n.inputs['Emission Strength'].default_value=emit
    m.diffuse_color=(*color,1)
    return m

pcb=mat('PCB | black solder mask',(.019,.026,.031),.05,.46)
blue=mat('SiFli module | blue solder mask',(.015,.25,.40),.15,.37)
gold=mat('ENIG | gold',(.73,.47,.095),.8,.26)
silver=mat('Connector steel',(.56,.61,.65),.83,.28)
solder=mat('Solder',(.47,.51,.53),.78,.3)
black=mat('IC epoxy',(.018,.022,.026),.05,.47)
cream=mat('Connector polymer',(.77,.77,.68),0,.35)
ceramic=mat('MLCC ceramic',(.39,.29,.16),0,.42)
white=mat('Silkscreen',(.78,.85,.87),0,.55)
trackmat=mat('Covered copper traces',(.031,.043,.049),.08,.49)
glass=mat('AMOLED glass',(.007,.013,.019),.2,.16)
screenmat=mat('AMOLED black pixels',(.002,.005,.009),0,.27)
cyan=mat('OLED cyan',(.015,.8,.72),.05,.28,1.1)
screenwhite=mat('OLED white',(.8,.91,.96),0,.3,.8)
amber=mat('OLED amber',(.96,.38,.07),0,.3,.9)

def mesh(name,verts,faces,material,parent=None):
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
    o=bpy.data.objects.new(name,me);col.objects.link(o)
    if parent:o.parent=parent
    if material:me.materials.append(material)
    return o

def bevel(o,w=.1,segments=3):
    types=[i.identifier for i in bpy.types.Modifier.bl_rna.properties['type'].enum_items]
    if 'BEVEL' in types:
        mod=o.modifiers.new('Edge highlights','BEVEL');mod.width=w;mod.segments=segments
    return o

def box(name,size,loc,material,parent=None,r=.05):
    x,y,z=[s/2 for s in size]
    v=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
    o=mesh(name,v,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],material,parent)
    o.location=loc
    if r:bevel(o,min(r,min(size)/4),3)
    return o

def cylinder(name,r,depth,loc,material,parent=None,n=40):
    verts=[(r*math.cos(i*2*math.pi/n),r*math.sin(i*2*math.pi/n),z) for z in (-depth/2,depth/2) for i in range(n)]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name,verts,faces,material,parent);o.location=loc
    return o

def extrude(name,points,depth,z,material,parent=None):
    pp=[]
    for p in points:
        if not pp or math.dist(p,pp[-1])>1e-5:pp.append(p)
    if math.dist(pp[0],pp[-1])<1e-5:pp.pop()
    n=len(pp);v=[(x,y,h) for h in (z-depth/2,z+depth/2) for x,y in pp]
    return mesh(name,v,[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],material,parent)

def rounded(name,w,h,d,r,z,material,parent):
    pts=[]
    for x,y,a in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
        pts.extend((x+r*math.cos(math.radians(a+j*90/16)),y+r*math.sin(math.radians(a+j*90/16))) for j in range(17))
    return bevel(extrude(name,pts,d,z,material,parent),min(.12,d/4),3)

def text(name,body,loc,size,material,parent=None):
    cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.size=size;cu.extrude=0
    o=bpy.data.objects.new(name,cu);col.objects.link(o);o.location=loc
    if parent:o.parent=parent
    cu.materials.append(material);return o

def lines(name,paths,r,material,parent=None):
    if not paths:return None
    cu=bpy.data.curves.new(name,'CURVE');enum(cu,'dimensions','3D');cu.bevel_depth=r;cu.bevel_resolution=1
    for points in paths:
        if len(points)<2:continue
        sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
        for v,p in zip(sp.points,points):v.co=(*p,1)
    o=bpy.data.objects.new(name,cu);col.objects.link(o);cu.materials.append(material)
    if parent:o.parent=parent
    return o

class Batch:
    def __init__(self):self.v=[];self.f=[]
    def addbox(self,c,size,angle=0):
        x,y,z=[v/2 for v in size];co,si=math.cos(angle),math.sin(angle)
        v=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
        k=len(self.v);self.v.extend((c[0]+co*a-si*b,c[1]+si*a+co*b,c[2]+d) for a,b,d in v)
        self.f.extend(tuple(k+i for i in f) for f in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])
    def finish(self,name,m,parent):
        if self.v:return mesh(name,self.v,self.f,m,parent)

def root(name):
    o=bpy.data.objects.new(name,None);col.objects.link(o);return o

def transform(c,x,y):
    # EDA bottom footprints mirror local X before board rotation.
    if c['side']==2:x=-x
    a=math.radians(c['rotation'])
    return c['x']+x*math.cos(a)-y*math.sin(a),c['y']+x*math.sin(a)+y*math.cos(a)

def difference(obj,cutter):
    bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new('Machined opening','BOOLEAN');enum(mod,'operation','DIFFERENCE');mod.object=cutter
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter,do_unlink=True)

roots={}
for b in BOARDS:
    name=b['name'];rt=root(name.upper()+' | official XY');roots[name]=rt
    rt['source']=b['source'];rt['xy_units']='mm; extracted from official EDA, mil * 0.0254'
    rt['height_note']='PCB stackup extracted. Most component heights are simplified estimates.'
    t=b['thickness'];board=extrude(name+' | exact outline',b['outline'],t,0,pcb,rt)
    board['width_mm']=b['width'];board['length_mm']=b['length'];board['stackup_mm']=t
    for cut in b.get('cutouts',[]):
        _,x,y,w,h,angle,rad=cut
        ox,oy=b['center_mil']
        tool=rounded('EDA board cutout',w*S,h*S,t+2,min(rad*S,w*S/2-.001,h*S/2-.001),0,None,rt) if rad else box('EDA board cutout',(w*S,h*S,t+2),(0,0,0),None,rt,0)
        tool.location=((x+w/2-ox)*S,(y-h/2-oy)*S,0)
        tool.rotation_euler.z=math.radians(angle)
        difference(board,tool)
    pads=Batch();contacts=Batch();silkpaths=[]
    for c in b['components']:
        ref=c['ref'];side=1 if c['side']==1 else -1;z=side*(t/2+.04)
        ismount=ref in ('M1','M2','M3','M4')
        if ismount:
            hole=next((p[9][1]*S/2 for p in c['pads'] if p[9]),None)
            if hole is None:
                hole=next((f[7][0][3]*S for f in c['fills'] if f[4]==12 and f[7][0][0]=='CIRCLE'),1.3)
            difference(board,cylinder('Hole cutter',hole,t+2,(c['x'],c['y'],0),None,rt))
            for sg in [-1,1]:
                ring=cylinder(name+' '+ref+' plated ring',2,.025,(c['x'],c['y'],sg*(t/2+.015)),gold,rt)
                difference(ring,cylinder('Ring cutter',hole,t+3,(c['x'],c['y'],0),None,rt))
            board[ref+'_hole_diameter_mm']=round(hole*2,5)
            continue
        for p in c['pads']:
            shape=p[10]
            if not shape or shape[0] not in ('RECT','ELLIPSE','OVAL'):continue
            x,y=transform(c,p[6]*S,p[7]*S)
            pads.addbox((x,y,z),(shape[1]*S,shape[2]*S,.035),math.radians(c['rotation']+(-p[8] if side<0 else p[8])))
        for p in c['silk']:
            pts=path_points(p[6])
            if pts:silkpaths.append([(*transform(c,x*S,y*S),side*(t/2+.055)) for x,y in pts])
        if ref.startswith(('TP','MT')) or (name=='core_pcb' and ref=='U20'):continue
        bounds=c['bounds'];tr=c['model_transform_mil']
        if bounds:
            w,h=bounds[2]-bounds[0],bounds[3]-bounds[1];cx,cy=(bounds[2]+bounds[0])/2,(bounds[3]+bounds[1])/2
        elif len(tr)>=8 and tr[0]>0 and tr[1]>0:
            w,h=tr[0]*S,tr[1]*S;cx,cy=tr[6]*S,tr[7]*S
        elif c['pads']:
            pp=c['pads'];xx=[p[6]*S for p in pp];yy=[p[7]*S for p in pp]
            w,h=max(.6,max(xx)-min(xx)),max(.4,max(yy)-min(yy));cx,cy=(max(xx)+min(xx))/2,(max(yy)+min(yy))/2
        else:w,h,cx,cy=1,1,0,0
        w,h=max(.3,w),max(.3,h)
        height=.45;m=black
        if ref.startswith('C'):height=.5;m=ceramic
        if ref.startswith('R'):height=.3;m=black
        if ref.startswith('L'):height=.6;m=black
        if ref.startswith('CN'):height=3.4;m=cream
        if ref.startswith('FPC'):height=1;m=cream
        if ref.startswith('SW'):height=2.6;m=silver
        if ref.startswith('USB'):height=3.2;m=silver
        if 'TF' in c['model_title'] or 'MICRO-SD' in c['model_title'].upper():height=1.6;m=silver
        if ref.startswith('U'):height=.8
        if name=='core_pcb' and ref=='U1':height=.65;m=blue
        if name=='core_pcb' and ref=='CN3':height=2.2;m=black
        if c['height']=='1mm':height=1
        x,y=transform(c,cx,cy)
        o=box(name+' '+ref+' | '+c['part'],(w,h,height),(x,y,side*(t/2+height/2+.07)),m,rt,.06)
        o.rotation_euler.z=math.radians(c['rotation'])
        o['designator']=ref;o['part']=c['part'];o['source_xy_mm']=[c['x'],c['y']]
        o['body_height_is_estimate']=c['height']!='1mm'
        if ref.startswith(('C','R','L')):
            for dx in (-w*.4,w*.4):
                a=math.radians(c['rotation']);contacts.addbox((x+dx*math.cos(a),y+dx*math.sin(a),side*(t/2+height/2+.08)),(min(.23,w*.22),h+.015,height*.95),a)
        if name=='core_pcb' and ref=='CN3':
            for i in range(15):
                for j in (-.635,.635):contacts.addbox((c['x']+(i-7)*1.27,c['y']+j,t/2+3.4),(.36,.36,4.2))
        if ref.startswith('USB'):
            # Open-ended metal receptacle, oriented with its official footprint.
            inner=box('USB cavity',(w-.55,h+1,height-.5),(x,y,side*(t/2+height/2+.07)),None,rt,0)
            inner.rotation_euler.z=o.rotation_euler.z;difference(o,inner)
            tongue=box('USB-C polymer tongue',(w-.9,h-.7,.5),(x,y,side*(t/2+height/2+.07)),black,rt,.06);tongue.rotation_euler.z=o.rotation_euler.z
        if ref in ('CN1','CN2') and name=='core_pcb':
            a=math.radians(c['rotation']);dx,dy=math.sin(a)*h*.25,-math.cos(a)*h*.25
            cavity=box('GH connector opening',(w-.8,h*.85,height-1),(x+dx,y+dy,side*(t/2+height/2+.18)),None,rt,0)
            cavity.rotation_euler.z=a;difference(o,cavity)
            for px in (-.625,.625):
                contacts.addbox((x+px*math.cos(a),y+px*math.sin(a),side*(t/2+height/2+.05)),(.28,2,.28),a)
        if ref=='CARD1':
            for yy in (-h*.3,h*.3):
                x1,y1=transform(c,cx-w*.42,cy+yy)
                mark=box('TF cage stamped tab',(1,.35,.08),(x1,y1,side*(t/2+height+.12)),black,rt,.03);mark.rotation_euler.z=o.rotation_euler.z
        if ref.startswith('SW'):
            a=math.radians(c['rotation']);dx,dy=-math.sin(a)*h*.52,math.cos(a)*h*.52
            cap=box(ref+' actuator',(w*.65,.8,1.45),(x+dx,y+dy,side*(t/2+height/2+.07)),black,rt,.1);cap.rotation_euler.z=a
    pads.finish(name+' | footprint pads',gold,rt);contacts.finish(name+' | terminations and pins',solder,rt)
    lines(name+' | footprint silkscreen',silkpaths,.035,white,rt)
    ox,oy=b['center_mil']
    for sd in (1,2):
        sg=1 if sd==1 else -1
        tracks=[[( (r[5]-ox)*S,(r[6]-oy)*S,sg*(t/2+.01)),((r[7]-ox)*S,(r[8]-oy)*S,sg*(t/2+.01))] for r in b['tracks'] if r[4]==sd]
        lines(name+' | routed copper under mask '+str(sd),tracks,.028,trackmat,rt)
    bevel(board,.035,2)

# SiFli module details: reference-render proportions; not a die/package CAD model.
rt=roots['core_pcb'];b=next(b for b in BOARDS if b['name']=='core_pcb');t=b['thickness']
module=next(c for c in b['components'] if c['ref']=='U1')
mx=module['x'];my=module['y'];surface=t/2+.72
box('SF32LB525 | illustrative IC',(6.6,6.6,.72),(mx,my+1.1,surface+.36),black,rt,.12)
box('QSPI NOR | illustrative IC',(5.4,4.6,.7),(mx+.85,my-6.2,surface+.35),black,rt,.09)
box('48 MHz crystal',(2,3.2,.5),(mx-5.55,my+2.9,surface+.25),silver,rt,.15)
box('32 kHz crystal',(2,1.4,.4),(mx-5.4,my-4.4,surface+.2),silver,rt,.12)
text('SiFli module mark','SiFli', (mx-2.15,my+.2,surface+.735),1.3,white,rt)
text('SiFli part mark','SF32LB525', (mx-2.5,my-1.05,surface+.735),.68,white,rt)
ant=[(mx-7.5,my+12.4,surface+.025),(mx-7.5,my+16,surface+.025),(mx-5.1,my+16,surface+.025),(mx-5.1,my+13.6,surface+.025),(mx-2.6,my+13.6,surface+.025),(mx-2.6,my+16,surface+.025),(mx,my+16,surface+.025),(mx,my+13.6,surface+.025),(mx+2.6,my+13.6,surface+.025),(mx+2.6,my+16,surface+.025),(mx+5.1,my+16,surface+.025),(mx+5.1,my+11.3,surface+.025)]
lines('Module PCB antenna | illustrative trace',[ant],.24,gold,rt)
text('Board title','HUANGSHAN',(-15.4,17.6,t/2+.08),.85,white,rt)
text('Board version','V1.2', (11.1,17.6,t/2+.08),1,white,rt)
text('Board maker','SiFli',(-15.2,15.8,t/2+.08),1.1,white,rt)
text('BAT label','BAT',(-14,-16,t/2+.08),1,white,rt)
text('SPK label','SPK',(10.5,-16,t/2+.08),1,white,rt)
for label,x,y in [('KEY1',11.6,9.3),('KEY2',11.6,-.15)]:
    text(label,label,(x,y,t/2+.08),.72,white,rt)

# Glass envelope and active area are estimates. Official screen: 1.85 in, 390x450.
rt=roots['display_pcb'];d=next(b for b in BOARDS if b['name']=='display_pcb');zt=d['thickness']/2
gl=rounded('AMOLED cover glass | ESTIMATED',35.1,41.5,1.2,8.1,zt+.9,glass,rt)
gl['dimensions_are_estimated']=True;gl['screen_model']='ZC-A1D85W-010';gl['resolution']=[390,450]
aw=1.85*25.4*390/math.sqrt(390**2+450**2);ah=aw*450/390
active=rounded('AMOLED active area | diagonal-derived',aw,ah,.04,6.2,zt+1.52,screenmat,rt)
active['assumption']='Square pixels; advertised 1.85 inch diagonal. Rounded-corner radius estimated.'
ui=zt+1.553
text('Demo UI brand','VELARIDE',(-11.8,12.9,ui),1.65,cyan,rt)
text('Demo UI battery','87%',(8.2,13.3,ui),1.2,screenwhite,rt)
text('Demo UI speed','24.8',(-12.5,1.6,ui),8.6,screenwhite,rt)
text('Demo UI unit','KM/H',(-3.1,-1.3,ui),1.45,cyan,rt)
text('Demo UI distance','12.64',(-12,-8,ui),3,screenwhite,rt)
text('Demo UI elapsed','00:32', (3,-8,ui),3,screenwhite,rt)
text('Demo UI distance label','DIST / KM',(-11.8,-10.1,ui),.95,cyan,rt)
text('Demo UI time label','RIDE TIME',(3.2,-10.1,ui),.95,cyan,rt)
lines('Demo UI dividers',[[(-12,-4,ui),(12,-4,ui)],[(0,-5.6,ui),(0,-10.2,ui)]],.035,cyan,rt)
lines('Demo UI route',[[(-9,-14,ui),(-4,-14,ui),(-1,-12.5,ui),(2,-15,ui),(6,-13.5,ui),(10,-13.5,ui)]],.11,amber,rt)

# Animation provides component overview, exploded and indicative assembly views.
core=roots['core_pcb'];display=roots['display_pcb']
for frame,cp,dp in [(1,(-23,0,0),(23,0,0)),(60,(0,0,0),(0,0,20)),(120,(0,0,0),(0,0,8.5))]:
    core.location=cp;display.location=dp
    core.keyframe_insert(data_path='location',frame=frame);display.keyframe_insert(data_path='location',frame=frame)
scene.frame_start=1;scene.frame_end=120
for f,n in [(1,'COMPONENTS'),(60,'EXPLODED - spacing illustrative'),(120,'ASSEMBLED - spacing illustrative')]:scene.timeline_markers.new(n,frame=f)
scene.frame_set(1)

stage=mat('Stage',(.033,.044,.059),.05,.55)
floor=box('Studio floor',(2000,2000,.6),(0,0,-7.3),stage,None,.05)
camd=bpy.data.cameras.new('Product camera');cam=bpy.data.objects.new('Product camera',camd);col.objects.link(cam)
cam.location=(72,-107,130);target=Vector((0,0,0));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
enum(camd,'type','ORTHO');camd.ortho_scale=113;scene.camera=cam
camd.clip_start=.1;camd.clip_end=3000
for name,loc,power,size in [('Key',(0,-45,100),190000,70),('Fill',(-75,0,45),100000,65),('Rim',(35,60,80),210000,55)]:
    ld=bpy.data.lights.new(name,'AREA');ld.energy=power;ld.shape='DISK';ld.size=size
    o=bpy.data.objects.new(name,ld);col.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
world=bpy.data.worlds.new('Huangshan studio world');scene.world=world;world.use_nodes=True
bg=next(n for n in world.node_tree.nodes if n.type=='BACKGROUND');bg.inputs['Color'].default_value=(.13,.17,.22,1);bg.inputs['Strength'].default_value=.35
scene.render.resolution_x=1800;scene.render.resolution_y=1250;scene.render.resolution_percentage=100
enum(scene.render.image_settings,'file_format','PNG')
scene.render.filepath=str(ROOT/'huangshan_overview.png')
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            space=area.spaces.active;space.region_3d.view_distance=115;space.region_3d.view_location=(0,0,0)
            space.region_3d.view_rotation=cam.rotation_euler.to_quaternion()
            space.clip_start=.1;space.clip_end=5000
            enum(space.shading,'type','MATERIAL')
            space.overlay.show_floor=False
note=bpy.data.texts.get('MODEL_NOTES.txt') or bpy.data.texts.new('MODEL_NOTES.txt')
note.clear();note.write('Official source: https://wiki.sifli.com/board/sf32lb52x/SF32LB52-%E9%BB%84%E5%B1%B1%E6%B4%BE.html\nDownloaded official V1.2 EDA .epro on 2026-10-10.\nBoard outline, component origins/rotations, footprint pads and mounting holes: extracted.\nGeneric component bodies, SiFli module interior, screen glass and assembly spacing: simplified estimates.\nThe VelaRide display UI is an illustrative mockup.\n1 Blender unit = 1 mm. Frame 1 components; frame 60 exploded; frame 120 indicative assembly.\nNot a production enclosure clearance model.\n')
scene['hardware_source']='Official SiFli Huangshan Pi V1.2 EDA'
scene['physical_fit_verified']=False
bpy.ops.object.select_all(action='DESELECT')
bpy.context.view_layer.objects.active=bpy.data.objects['core_pcb | exact outline']
bpy.data.objects['core_pcb | exact outline'].select_set(True)
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'huangshan_pi_v1_2.blend'))
print('BUILT',len(col.all_objects),'objects; saved',ROOT/'huangshan_pi_v1_2.blend')
