from pathlib import Path
import sys,json,numpy as np,trimesh
from inspect_watch_mesh import ROOT
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

WORK=ROOT/'20261018_V4_工作记录'
WORK.mkdir(exist_ok=True)

def probe(m,n=18000):
    p,f=trimesh.sample.sample_surface(m,n,seed=23)
    normals=m.face_normals[f]; lengths=np.full(n,np.nan); opposing=np.zeros(n)
    for start in range(0,n,400):
        ids=np.arange(start,min(start+400,n))
        hit,ri,fi=m.ray.intersects_location(p[ids]-normals[ids]*.00005,-normals[ids],multiple_hits=False)
        lengths[ids[ri]]=np.linalg.norm(hit-p[ids[ri]],axis=1)
        opposing[ids[ri]]=-np.einsum('ij,ij->i',normals[ids[ri]],m.face_normals[fi])
    return p,normals,lengths,opposing

def audit(path,label,samples=18000):
    m=trimesh.load_mesh(path);p,n,t,o=probe(m,samples)
    np.savez(WORK/(label+'_probe.npz'),points=p,normals=n,thickness=t,opposing=o)
    good=(o>.8)&(t>.005);thin=good&(t<1.0)
    report={'label':label,'opposed_samples':int(good.sum()),'below_1mm':int(thin.sum()),'quantiles':np.nanquantile(t[good],[0,.01,.05,.1,.5]).tolist(),'lowest':[{'p':p[i].tolist(),'n':n[i].tolist(),'t':float(t[i])} for i in np.where(good)[0][np.argsort(t[good])[:20]]]}
    (WORK/(label+'_probe.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    fig,axs=plt.subplots(1,3,figsize=(15,5))
    for ax,(a,b) in zip(axs,[(0,1),(0,2),(1,2)]):
        ax.scatter(p[:,a],p[:,b],s=.15,c='lightgray');sc=ax.scatter(p[thin,a],p[thin,b],c=t[thin],s=3,vmin=0,vmax=1,cmap='plasma');ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('XYZ'[a]);ax.set_ylabel('XYZ'[b])
    fig.colorbar(sc,ax=axs);fig.suptitle(label);fig.savefig(WORK/(label+'_thin.png'),dpi=140);plt.close(fig)
    print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':
    for label,path in [('V3_main',ROOT/'20261018_局部加厚V3_厂家复审'/'01_外壳_局部加厚V3.stl'),('original_lower',ROOT/'修复版_单件STL'/'下横杆_修复.stl')]:audit(path,label)
