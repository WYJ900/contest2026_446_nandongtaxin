from inspect_watch_mesh import ROOT,stats
import numpy as np,trimesh,manifold3d as md,json
from scipy.ndimage import binary_erosion
P=ROOT/'20261018_V4_工作记录';V3=ROOT/'20261018_局部加厚V3_厂家复审'
old=trimesh.load_mesh(ROOT/'修复版_单件STL'/'外壳_修复.stl')
new=trimesh.load_mesh(P/'main_deliver.stl')
def block(mesh,points,direction,limit):
 result=np.zeros(len(points),dtype=bool)
 for start in range(0,len(points),500):
  a=points[start:start+500];hit,ri,_=mesh.ray.intersects_location(a,np.tile(direction,(len(a),1)),multiple_hits=False)
  dist=np.linalg.norm(hit-a[ri],axis=1);result[start+ri[dist<limit]]=True
 return result
report={'parts':{'main':stats(new)},'passages':{},'collisions':[]}
checks=[]
x=np.arange(-48.5,-13.4,.1);z=np.arange(-3.9,1.01,.1);X,Z=np.meshgrid(x,z)
for name,start_y,direction,limit in [('front_slot',-6,[0,1,0],11),('rear_slot',48,[0,-1,0],12)]:
 checks.append((name,np.c_[X.ravel(),np.full(X.size,start_y),Z.ravel()],direction,limit,X.shape))
for idx,(cy,cz) in enumerate([(7.485624,5.7),(37.5926,4.8)]):
 a=np.arange(-1.9,1.91,.1);Y,Z=np.meshgrid(a+cy,a+cz);checks.append((f'screw_{idx}',np.c_[np.full(Y.size,-54),Y.ravel(),Z.ravel()],[1,0,0],47,Y.shape))
for side in [0,1]:
 y=np.arange(11,34,.15);z=np.arange(-3.9,4.5,.15);Y,Z=np.meshgrid(y,z)
 checks.append((f'side_ports_{side}',np.c_[np.full(Y.size,-54 if side==0 else -8),Y.ravel(),Z.ravel()],[1 if side==0 else -1,0,0],8,Y.shape))
for name,p,d,limit,shape in checks:
 a=block(old,p,d,limit);b=block(new,p,d,limit);safe=binary_erosion((~a).reshape(shape),iterations=2).ravel()
 report['passages'][name]={'original_clear_samples':int((~a).sum()),'newly_blocked':int((~a&b).sum()),'blocked_at_least_two_grid_cells_inside':int((safe&b).sum())}
 print(name,report['passages'][name],flush=True)
def s(m):return md.Manifold(md.Mesh64(m.vertices.astype('float64'),m.faces.astype('uint64')))
so,sn=s(old),s(new)
for f in sorted(V3.glob('*.stl'))[1:]:
 m=trimesh.load_mesh(f);o=s(m);a=(so^o).volume()
 if f.name.startswith('02_'):m=trimesh.load_mesh(P/'bottom_final.stl');o=s(m)
 b=(sn^o).volume()
 item={'part':f.name,'before_mm3':a,'after_mm3':b};report['collisions'].append(item);print(item,flush=True)
# Distance from resampled surface to the intended (pre-remesh) shape.
raw=trimesh.load_mesh(P/'main_trial.stl');p,_=trimesh.sample.sample_surface(new,8000,seed=15)
ds=[]
for k in range(0,len(p),500):ds.extend(trimesh.proximity.closest_point(raw,p[k:k+500])[1])
report['remesh_surface_distance_mm']={'max':float(np.max(ds)),'p99':float(np.quantile(ds,.99)),'median':float(np.median(ds))}
(P/'fit_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('deviation',report['remesh_surface_distance_mm'],flush=True)
