"""Archive workspace-only source without overwriting the accepted release."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / 'my-contest-repo'
OUT = REPO / 'artifacts/workspace-checkpoint-20261107'
OUT.mkdir(parents=True, exist_ok=True)
inventory = json.loads((ROOT / 'backup/phone-demo-20261107/workspace-inventory.json').read_text(encoding='utf-8'))
selected = {}
omitted = []
secret = re.compile(rb'(?:sk-|tp-)[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')
blocked_names = {'.env', '.env.local', '.env.production'}
blocked_parts = {'.git', 'node_modules', '__pycache__', 'sign', '.build'}
source_suffixes = {'.c', '.h', '.py', '.sh', '.ps1', '.mjs', '.js', '.json', '.md', '.txt', '.cmake', '.ux', '.xml', '.scad'}

def add(path):
    if not path.is_file() or path.is_symlink():
        return
    relative = path.relative_to(ROOT).as_posix()
    if (any(part in blocked_parts for part in path.relative_to(ROOT).parts)
            or path.name in blocked_names or path.name.startswith('.env.')
            or path.suffix.lower() in {'.key', '.pem', '.keystore', '.jks', '.pyc'}
            or 'mickey' in path.name.lower() or path.name == 'MiSans-Demibold.ttf'):
        omitted.append({'path': relative, 'reason': 'credential, dependency, cache, or unused third-party artwork/font'})
        return
    data = path.read_bytes()
    if secret.search(data):
        raise RuntimeError(f'Secret-like content in {relative}; no file contents printed.')
    selected[relative] = data

for item in inventory:
    relative = item['repository']
    if relative in {'.claude', 'my-contest-repo'}:
        continue
    base = ROOT / relative
    if item['changed']:
        result = subprocess.run(['git', '-C', str(base), 'diff', '--binary', '--full-index', 'HEAD'],
                                capture_output=True, check=True)
        if secret.search(result.stdout):
            raise RuntimeError(f'Secret-like content in patch for {relative}')
        (OUT / 'patches').mkdir(exist_ok=True)
        (OUT / 'patches' / (relative.replace('/', '__') + '.patch')).write_bytes(result.stdout)
        for name in item['changed']:
            add(base / name)
    for name in item['untracked']:
        path = base / name
        if relative == 'build':
            if path.suffix.lower() not in source_suffixes and path.name not in {'Kconfig', 'CMakeLists.txt', 'defconfig', 'config'}:
                omitted.append({'path': path.relative_to(ROOT).as_posix(), 'reason': 'build output or binary dependency'})
                continue
        if relative == 'apps' and name.startswith('testing/drivers/nist-sts/'):
            omitted.append({'path': path.relative_to(ROOT).as_posix(), 'reason': 'nested upstream dependency'})
            continue
        add(path)

for folder in ['tools', 'project-docs', 'vela-quickapp/src']:
    for path in (ROOT / folder).rglob('*'):
        add(path)
for folder in ['hardware-model']:
    for path in (ROOT / folder).rglob('*'):
        if path.suffix.lower() in source_suffixes:
            add(path)
for path in ROOT.glob('*.py'):
    add(path)
for name in ['AGENTS.md', 'PROJECT_PLAN.md', '开发记录.md', 'build.sh', 'emulator.sh',
             'vela-quickapp/package.json', 'vela-quickapp/package-lock.json',
             'backup/phone-demo-20261107/test-commands.json',
             'backup/phone-demo-20261107/test-result.json',
             'backup/phone-demo-20261107/connect.json',
             'backup/phone-demo-20261107/scan.json',
             'backup/phone-demo-20261107/inventory_workspace.py',
             'backup/phone-demo-20261107/archive_checkpoint.py']:
    add(ROOT / name)

archive = OUT / 'workspace-source.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
    for name, data in sorted(selected.items()):
        bundle.writestr(name, data)

files = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
         for name, data in sorted(selected.items())}
manifest = {
    'created_local': datetime.now().isoformat(timespec='seconds'),
    'purpose': 'Source preservation, not a newly verified firmware baseline.',
    'accepted_release': {'firmware': 'artifacts/phone-bridge-20261106/firmware.bin',
                         'sha256': '424e7a2c41fe57dbd581e1c313bfe8793067415e0af449166700f501d3c1a734'},
    'repositories': inventory,
    'files': files,
    'explicit_omissions': omitted,
    'scope_omissions': ['Unmodified upstream repositories and toolchains',
                        'WSL filesystem/build trees (accepted source snapshots already archived separately)',
                        'Raw audio/video, private credentials/signing keys, node_modules and caches',
                        'Generated CAD meshes, vendor reference models and reference SDK checkouts',
                        'Historical root web-gateway mirror (older than repository version)'],
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8', newline='\n')
hashes = {}
for path in OUT.rglob('*'):
    if path.is_file() and path.name != 'SHA256SUMS.json':
        hashes[path.relative_to(OUT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
(OUT / 'SHA256SUMS.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8', newline='\n')
print(f'Archived {len(files)} source/support files; zip bytes={archive.stat().st_size}; patches={len(list((OUT / "patches").glob("*.patch")))}')
print(f'Explicitly omitted {len(omitted)} dependency/cache/output paths; see manifest.')
