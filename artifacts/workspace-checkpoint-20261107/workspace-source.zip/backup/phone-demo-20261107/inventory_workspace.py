from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'backup/phone-demo-20261107/workspace-inventory.json'

def git(path, *args):
    result = subprocess.run(['git', '-c', 'core.quotepath=false', '-C', str(path), *args],
                            capture_output=True, timeout=60)
    if result.returncode:
        return None
    return result.stdout.decode('utf-8', errors='replace').strip()

def inspect(relative):
    path = ROOT / relative
    if not (path / '.git').exists():
        return None
    changed = git(path, 'diff', '--name-only', 'HEAD')
    untracked = git(path, 'ls-files', '--others', '--exclude-standard')
    if not changed and not untracked:
        return None
    return {'repository': relative, 'head': git(path, 'rev-parse', 'HEAD'),
            'changed': (changed or '').splitlines(), 'untracked': (untracked or '').splitlines()}

paths = (ROOT / '.repo/project.list').read_text().splitlines()
paths.append('my-contest-repo')
with ThreadPoolExecutor(max_workers=8) as executor:
    inventory = [item for item in executor.map(inspect, paths) if item]
OUT.write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding='utf-8')
for item in inventory:
    print(item['repository'], 'modified=', len(item['changed']), 'untracked=', len(item['untracked']))
    if item['repository'] in {'apps', 'nuttx', 'vendor/sifli', 'packages/ai_agent', 'external',
                              'apps/graphics/lvgl/lvgl', 'external/zblue/zblue'}:
        print('  changed:', ', '.join(item['changed']))
print('Saved:', OUT)
