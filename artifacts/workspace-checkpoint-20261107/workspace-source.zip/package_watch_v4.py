from inspect_watch_mesh import ROOT,stats
from pathlib import Path
import trimesh,numpy as np,pymeshlab as pm,shutil,json,hashlib,zipfile
P=ROOT/'20261018_V4_工作记录';V3=ROOT/'20261018_局部加厚V3_厂家复审'
D=ROOT/'20261018_薄壁复修V4_厂家复审';D.mkdir(exist_ok=True)
files=[(P/'main_deliver.stl','01_外壳_薄壁复修V4.stl'),(P/'bottom_final.stl','02_底部外壳_配套V4.stl'),(V3/'03_上横杆_加厚V3.stl','03_上横杆_加厚版.stl'),(V3/'04_下横杆_原版.stl','04_下横杆_原版.stl'),(V3/'05_按钮其一_原版.stl','05_按钮其一_原版.stl'),(V3/'06_按钮其二_原版.stl','06_按钮其二_原版.stl')]
report={'files':[],'fit':json.loads((P/'fit_verification.json').read_text(encoding='utf-8')),'main_thickness':json.loads((P/'V4_main_deliver_probe.json').read_text(encoding='utf-8')),'bottom_thickness':json.loads((P/'V4_bottom_deliver_probe.json').read_text(encoding='utf-8'))}
for src,name in files:
 target=D/name;shutil.copy2(src,target);m=trimesh.load_mesh(target)
 ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices,face_matrix=m.faces));ms.compute_selection_by_self_intersections_per_face()
 r={'name':name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'stats':stats(m),'components':len(m.split(only_watertight=False)),'self_intersections':int(ms.current_mesh().face_selection_array().sum())}
 assert r['components']==1 and r['self_intersections']==0 and r['stats']['watertight'] and r['stats']['winding']
 assert r['stats']['boundary_edges']==r['stats']['nonmanifold_edges']==r['stats']['degenerate_faces']==r['stats']['duplicate_faces']==0
 report['files'].append(r)
old=trimesh.load_mesh(ROOT/'修复版_单件STL'/'外壳_修复.stl');new=trimesh.load_mesh(D/files[0][1]);seats=[]
for cy,cz in [(7.485624,5.7),(37.5926,4.8)]:
 for left in [True,False]:
  start=np.array([-55 if left else -7,cy+1.4,cz]);direction=np.array([1 if left else -1,0,0]);vals=[]
  for mesh in [old,new]:
   hit,_,_=mesh.ray.intersects_location([start],[direction],multiple_hits=False);vals.append(hit[0].tolist() if len(hit) else None)
  seats.append({'cy':cy,'left':left,'original_hit':vals[0],'new_hit':vals[1],'x_change_mm':None if None in vals else vals[1][0]-vals[0][0]})
report['screw_seat_probes']=seats
(D/'验证记录.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
text='''黄山派 watch 表带版：薄壁复修 V4（待厂家复审，未承诺审核通过）

只上传此目录的六个 STL；一黑一白两套时，各上传一组，每款数量 1。
主外壳与底壳必须使用本目录的 V4 配套版本，不能只换主壳而混用旧底壳。

本次变化：
1. 主壳从原版重新构建：长槽端部、内圆角附近连续补料；前后外侧增加约 0.9 mm，螺孔周围增加外凸台。取消 V3 的独立加强条方案。
2. 保留主体原坐标和内腔设计轮廓，无整体缩放。左右螺孔轴线保留，贯通孔清理到直径约 2.04 mm。
3. 螺钉头沉孔底面向外调整：前端左侧实测约 0.55 mm、右侧约 0.06 mm，后端两侧约 0.8 mm。会改变螺钉头的坐入深度和有效啮合长度；旧螺钉是否够长尚未实物验证。
4. 右侧接口下沿向下补料约 0.12 mm（设计 0.15 mm，经过避让后实际约 0.12 mm）；V4 底壳对应位置增加避让，保留接口开口。
5. 主壳底缘外侧另平滑外扩不超过 0.101 mm；不向内压缩主体内腔。底壳保留 V3 螺丝柱加粗，另做上述局部避让。
6. 上横杆沿用 V3 加厚版（厚度 4.2 mm），下横杆和两个按钮仍为原版。

导出后验证：
- 六件各为一个封闭连通体，开放边、非流形边、退化面、重复面、自相交面均为 0。
- 主壳和底壳已清理 0.003 mm 以下的极短边，主壳约 1.08 万面、底壳约 0.57 万面。
- 主壳 50000 个表面抽样点中，42919 个符合对向面测厚条件，未发现低于 1 mm，抽样最小约 1.024 mm。
- 底壳 25000 个表面抽样点中，24538 个符合测厚条件，未发现低于 1 mm，抽样最小约 1.108 mm。
- 原下横杆另做 18000 点抽样，最小约 1.299 mm，无低于 1 mm 的有效测厚点。
- 主壳与 V4 底壳、两根横杆及按钮的静态实体相交体积为 0 或数值级误差。
- 表带长槽、螺孔、按钮/接口直通通道未发现远离边缘的新增遮挡；少量边缘采样变化来自约 0.025 mm 的网格简化。

验证限制：抽样不等于所有位置的数学证明；无法代替嘉立创人工薄壁审核、实际电路板/电池/表带接头/螺钉试装，以及打印收缩和插拔运动验证。必须等厂家复审后决定生产，不能直接确认“接受风险”。

本目录是配套复审交付。旧 V3 和工作目录中的中间文件均保留，但不要用于本次替换。
'''
(D/'先读说明_必须配套使用.txt').write_text(text,encoding='utf-8-sig')
shutil.copy2(P/'V4修改预览.png',D/'V4修改预览.png')
code=D/'复现脚本';code.mkdir(exist_ok=True)
for name in ['build_watch_v4_trial.py','collapse_watch_short_edges.py','finish_watch_v4_rim.py','verify_watch_v4.py','audit_watch_v4.py','render_watch_v4.py','package_watch_v4.py','inspect_watch_mesh.py']:shutil.copy2(Path(__file__).parent/name,code/name)
(P/'不要上传_中间文件.txt').write_text('此目录含失败试验和中间文件，不得用于下单。使用同级 20261018_薄壁复修V4_厂家复审 目录。',encoding='utf-8-sig')
with zipfile.ZipFile(D.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for p in D.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(D))
print(json.dumps({'folder':str(D),'seats':seats,'files':[{k:r[k] for k in ['name','components','self_intersections']} for r in report['files']]},ensure_ascii=False),flush=True)
