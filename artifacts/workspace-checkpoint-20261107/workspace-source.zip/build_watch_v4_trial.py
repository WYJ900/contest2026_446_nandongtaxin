import numpy as np,trimesh,manifold3d as md,json
from inspect_watch_mesh import ROOT,stats
from shapely.geometry import Polygon
from shapely.ops import unary_union

OUT=ROOT/'20261018_V4_工作记录';OUT.mkdir(exist_ok=True)
SRC=ROOT/'修复版_单件STL'
names=['外壳','底部外壳','上横杆','下横杆','V0.2黄山派-按钮其一','V0.2黄山派-按钮其二']
meshes=[trimesh.load_mesh(SRC/f'{n}_修复.stl') for n in names]
def solid(m):return md.Manifold(md.Mesh64(m.vertices.astype('float64'),m.faces.astype('uint64')))
def mesh(s):
 a=s.to_mesh64();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
def box(lo,hi):return md.Manifold.cube(np.array(hi)-lo).translate(lo)
ss=[solid(m) for m in meshes];base=ss[0].simplify(.005)

# Conservative cavity keepout from the two complete original inner contours.
# Union keeps the larger outline, including the original bottom screw recesses.
polys=[]
for z in [-4.0,8.0]:
 for p in base.slice(z).to_polygons():
  q=Polygon(p)
  if not q.exterior.is_ccw:polys.append(q)
inner=unary_union(polys).buffer(.01).simplify(.003,preserve_topology=True)
inner_cs=md.CrossSection([np.array(inner.exterior.coords)[:-1]],md.FillRule.EvenOdd)
cavity=inner_cs.extrude(20).translate([0,0,-6])
# Add a continuous outer shell rather than independent reinforcing rails.
envelope=solid(meshes[0].convex_hull).minkowski_sum(md.Manifold.sphere(.9,circular_segments=24))
zones=box([-54,-5,-3.915],[-8,4,1.2])+box([-54,37,-3.915],[-8,47,1.2])
add=(envelope-cavity)^zones

cutters=[]
# Preserve each original straight-through channel, separately for each wall.
for y0,y1 in [(-6,20.7),(20.7,48)]:
 half=base^box([-55,y0,-6],[-7,y1,13])
 silhouette=half.rotate([90,0,0]).project().simplify(.003)
 void=(half.hull().rotate([90,0,0]).project()-silhouette).simplify(.01).offset(.015)
 cutter=void.extrude(y1-y0).transform([[1,0,0,0],[0,0,1,y0],[0,-1,0,0]])
 cutters.append(cutter)
for x0,x1 in []:
 half=base^box([x0,-7,-7],[x1,49,14])
 silhouette=half.transform([[0,1,0,0],[0,0,1,0],[1,0,0,0]]).project().simplify(.003)
 void=half.hull().transform([[0,1,0,0],[0,0,1,0],[1,0,0,0]]).project()-silhouette
 cutter=void.extrude(x1-x0).transform([[0,0,1,x0],[1,0,0,0],[0,1,0,0]])
 cutters.append(cutter)
for c in cutters:add=add-c

bores=[]
# Strengthen the counterbore back walls: preserve the through bore and move
# only the larger screw-head recess outward into the added outer boss.
for cy,cz in [(7.485624,5.7),(37.5926,4.8)]:
 for left in [True,False]:
  x0=-52.4 if left else -14.0
  boss=md.Manifold.cylinder(4.5,3.3,circular_segments=96).rotate([0,90,0]).translate([x0,cy,cz])
  bore=md.Manifold.cylinder(8,1.02,circular_segments=96).rotate([0,90,0]).translate([x0-1,cy,cz])
  bores.append(bore)
  seat0,seat1=((-54,-50.35) if left else (-11.55,-7)) if cy<20 else ((-54,-49.85) if left else (-12.05,-7))
  head=md.Manifold.cylinder(seat1-seat0,1.85,circular_segments=96).rotate([0,90,0]).translate([seat0,cy,cz])
  add=add+((boss^envelope)-cavity-bore-head)

# A shallow exterior pad above the left button apertures; keep their original
# through silhouettes, so reinforcement does not encroach on the openings.
half=base^box([-55,-7,-7],[-30.95,49,14])
tr=[[0,1,0,0],[0,0,1,0],[1,0,0,0]]
void=(half.hull().transform(tr).project()-half.transform(tr).project()).simplify(.005).offset(.01)
button_clear=void.extrude(26).transform([[0,0,1,-55],[1,0,0,0],[0,1,0,0]])
add=add+(box([-51.95,13,1.5],[-51.2,33,4.3])-button_clear)

v3=ROOT/'20261018_局部加厚V3_厂家复审'
back=solid(trimesh.load_mesh(v3/'02_底部外壳_局部加厚V3.stl'))
# The original right-side connector sill is nominally only 1 mm. Extend its
# underside by 0.15 mm and recess the matching cover locally, preserving the
# connector opening and the assembled exterior bottom surface.
back=back-box([-13.5,11.8,-4.33],[-9.0,23.2,2.0])
floor=base.slice(-4.05).extrude(.20).translate([0,0,-4.21265])
floor=floor^box([-13.3,12.0,-4.3],[-9.2,23.0,-3.9])
add=add+floor
mesh(back).export(OUT/'bottom_recess.stl')
bar=solid(trimesh.load_mesh(v3/'03_上横杆_加厚V3.stl'))
guard=back.minkowski_sum(md.Manifold.cube([.3,.3,.3],center=True))
for o in [bar]+ss[3:]:guard=guard+o.minkowski_sum(md.Manifold.cube([.2,.2,.2],center=True))
new=(base+(add-guard)).set_tolerance(.003).simplify(.008)
for bore in bores:new=new-bore
new=new.simplify(.005)
m=mesh(new);m.export(OUT/'main_trial.stl')
exact=max(m.split(only_watertight=False),key=lambda q:abs(q.volume))
exact.fix_normals()
(OUT/'main_exact.obj').write_text(trimesh.exchange.obj.export_obj(exact,include_normals=False,digits=12),encoding='utf-8')
import pymeshlab as pm
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=exact.vertices,face_matrix=exact.faces));ms.compute_selection_by_self_intersections_per_face()
print('EXACT',stats(exact),'SI',int(ms.current_mesh().face_selection_array().sum()),flush=True)
import pymeshfix
for label,src,tol in [('main_final',exact,.025),('bottom_final',mesh(back),.01)]:
 sm=solid(src).set_tolerance(.001).simplify(tol)
 smm=mesh(sm);smm.update_faces(smm.nondegenerate_faces());smm.update_faces(smm.unique_faces());smm.remove_unreferenced_vertices()
 before_volume=smm.volume
 fix=pymeshfix.MeshFix(smm.vertices,smm.faces);fix.repair()
 clean=trimesh.Trimesh(fix.points,fix.faces,process=True)
 clean.export(OUT/f'{label}.stl');clean=trimesh.load_mesh(OUT/f'{label}.stl')
 ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=clean.vertices,face_matrix=clean.faces));ms.compute_selection_by_self_intersections_per_face()
 print(label,stats(clean),'SI',int(ms.current_mesh().face_selection_array().sum()),'repair_volume_delta',clean.volume-before_volume,flush=True)
print(json.dumps({'stats':stats(m),'components':len(m.split(only_watertight=False)),'status':str(new.status())}),flush=True)
(OUT/'inner_keepout.json').write_text(json.dumps(list(inner.exterior.coords)),encoding='utf-8')
