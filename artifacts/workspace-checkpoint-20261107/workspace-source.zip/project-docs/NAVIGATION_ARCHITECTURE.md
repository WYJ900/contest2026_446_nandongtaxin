# VelaRide 二维手表导航架构

## 目标

- 左右切换表盘；
- 上下进入骑行、提醒、AI 复盘功能页；
- 方向锁定后同一次手势不换轴；
- 转场有效刷新至少 25Hz，目标 30Hz；
- 静止页面显示完整内容，拖动期间允许使用低细节预览。

## 选型

保留 NuttX + LVGL 9.1，不整体移植 SiFli `gui_app_fwk`。复用思澈 `watch_v9`
的表盘视觉方向与 `init/pause/resume/deinit` 生命周期思想，自行实现轻量三槽位
导航器。

三个固定 slot 分别承担当前页、目标预览页和备用页。方向锁定后才构建目标预览，
转场结束后交换 slot，非当前页不运行 timer。该方案不使用全屏快照：390×450
RGB565 单快照需要 351KB，内部 SRAM 无法容纳。（2026-10-17：快照后来改放 PSRAM；
EPIC 与 PSRAM 的关系见 [EPIC 实测交接](../my-contest-repo/docs/HANDOFF_EPIC_20261017.md)。）

## 手势规则

- 累计移动 12px 后开始判定；
- 主轴至少为副轴的 1.3 倍才锁轴；
- 左右手势只在表盘层生效；
- 上滑进入下一功能页，下滑返回上一层；
- 横向提交阈值 86px，纵向提交阈值 99px；
- 落页动画 140ms，期间动态数据和表盘更新暂停。

## 表盘路线

第一版包含代码原生数字骑行表盘和 SiFli simple 风格指针表盘。后续从
SiFli-SDK `example/multimedia/lvgl/watch_v9/src/gui_apps/clock/` 移植视觉资源：

1. `simple`：禁用 bitmap mask 漂移动画，只保留背景与三根指针；
2. `dial`：背景离线裁剪并与黑底预合成，取消运行时 zoom；
3. 当前数字骑行表盘。

资源必须离线转换为当前 LVGL 9.1 可直接引用的 variable image。背景放 XIP Flash，
禁止复制全屏背景到 SRAM/PSRAM；指针使用 EPIC 支持的透明格式。

## 许可

SiFli-SDK 和相关表盘 C 文件采用 Apache-2.0。移植时保留原 SPDX 和版权声明，
并在作品第三方许可材料中注明修改。官方 PNG 位于 Apache-2.0 仓库但无逐文件许可
元数据，正式公开发布前仍建议向上游确认素材权属。
