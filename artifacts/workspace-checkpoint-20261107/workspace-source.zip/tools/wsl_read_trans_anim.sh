#!/usr/bin/env bash
# 读思澈的自定义转场动画实现，看它用了哪些 LVGL/EPIC 手法
F=/home/wyj/sifli_hspi/lvgl/watch/src/gui_apps/utils/custom_trans_anim.c
H=/home/wyj/sifli_hspi/lvgl/watch/src/gui_apps/utils/custom_trans_anim.h

echo "=== 规模 ==="
wc -l "$F" "$H"

echo
echo "=== 头文件（对外接口）==="
cat "$H"

echo
echo "=== 用到的关键 API ==="
grep -ho 'lv_anim_[a-z_]*\|lv_obj_set_style_transform[a-z_]*\|lv_indev_[a-z_]*\|arm_2d_[a-z_]*\|EPIC[A-Za-z_]*' "$F" | sort -u
