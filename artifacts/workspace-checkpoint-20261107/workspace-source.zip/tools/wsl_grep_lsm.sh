#!/bin/bash
cd /home/wyj/velaride_history_cache
sed -n 1085,1150p nuttx/drivers/sensors/lsm6dsl.c
grep -n "static int lsm6dsl_readsensor\|static int lsm6dsl_read_sensor\|lsm6dsl_readreg8\|static int lsm6dsl_readreg" nuttx/drivers/sensors/lsm6dsl.c | head
