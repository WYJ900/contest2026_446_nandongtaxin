#!/usr/bin/env bash
# 补齐 prebuilts 工具链并修复 Windows 检出导致的 CRLF 行尾
#
# 两个问题都源自在 Windows 上 checkout 源码：
# 1. prebuilts/tools 未同步，导致 jidl_gen_cpp（快应用 IDL 生成器）找不到；
# 2. 构建期要执行的 perl/python/shell 脚本带 CRLF，Linux 内核解析 shebang 时
#    会把 "#!/usr/bin/env perl\r" 里的 \r 当成解释器名的一部分而报 not found。
set -eu

SRC=/mnt/d/desktop/VelaRide_AI
DEST=/home/wyj/velaride_ai

echo "=== 同步 prebuilts/tools（含 Linux 版 jidl_gen_cpp）==="
mkdir -p "$DEST/prebuilts"
rsync -a --exclude='.git' --exclude='darwin/' \
  "$SRC/prebuilts/tools/" "$DEST/prebuilts/tools/"
chmod +x "$DEST/prebuilts/tools/rust/bin/jidl/jidl_gen_cpp"
"$DEST/prebuilts/tools/rust/bin/jidl/jidl_gen_cpp" --help >/dev/null 2>&1 \
  && echo "    jidl_gen_cpp 可执行" || echo "    jidl_gen_cpp 调用异常（继续）"

echo "=== 修复构建期脚本的 CRLF 行尾 ==="
# 只处理带 shebang 的可执行脚本，避免动到源码和二进制
fixed=0
while IFS= read -r f; do
  if head -c 2 "$f" 2>/dev/null | grep -q '#!' && grep -qU $'\r' "$f" 2>/dev/null; then
    sed -i 's/\r$//' "$f"
    fixed=$((fixed + 1))
  fi
done < <(find "$DEST/apps" "$DEST/external" "$DEST/nuttx" "$DEST/frameworks" \
           -type f \( -name '*.pl' -o -name '*.py' -o -name '*.sh' \) 2>/dev/null)
echo "    修复 $fixed 个脚本"
