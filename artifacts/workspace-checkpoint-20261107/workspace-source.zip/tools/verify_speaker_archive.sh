#!/usr/bin/env bash
# Verify the source snapshot in a fresh tree; never flash or modify the baseline.
set -euo pipefail
WORK=/mnt/d/desktop/VelaRide_AI
SAVE=$WORK/backup/expansion-20261027
SNAPSHOT=$SAVE/speaker-source-snapshot
DST=/home/wyj/velaride_speaker_archive_check_20261027
test -f "$SNAPSHOT/manifest.json"
test ! -e "$DST"
mkdir "$DST"
tar -xzf "$SNAPSHOT/source.tar.gz" -C "$DST"
SOURCE=$DST/source
OUT=$DST/output
export PATH=/opt/arm-gnu-toolchain/bin:$HOME/.local/bin:$PATH
cd "$SOURCE/nuttx"
cmake -B "$OUT" -S "$SOURCE/nuttx" -GNinja \
  -DBOARD_CONFIG="$SOURCE/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh" \
  '-DEXTRA_FLAGS=-Wno-cpp -Wno-deprecated-declarations' > "$SAVE/07-archive-configure.log" 2>&1 ||
  { tail -50 "$SAVE/07-archive-configure.log"; exit 1; }
cmp "$SNAPSHOT/.config" "$OUT/.config"
echo 'Configuration matches frozen speaker baseline'
cmake --build "$OUT" -- -j8 > "$SAVE/08-archive-build.log" 2>&1 ||
  { tail -70 "$SAVE/08-archive-build.log"; exit 1; }
test "$(stat -c %s "$OUT/nuttx.bin")" -lt $((0x990000))
cmp "$SNAPSHOT/.config" "$OUT/.config"
cp "$OUT/nuttx.bin" "$SAVE/archive-rebuild.bin"
cp "$OUT/.config" "$SAVE/archive-rebuild.config"
sha256sum "$OUT/nuttx.bin" "$SNAPSHOT/nuttx.bin"
stat -c '%s bytes' "$OUT/nuttx.bin"
