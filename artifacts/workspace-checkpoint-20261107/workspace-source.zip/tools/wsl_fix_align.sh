#!/usr/bin/env bash
# 把 LVGL 绘制缓冲对齐恢复成板级原始值（ALIGN=4 / STRIDE_ALIGN=1）
#
# 试过抄 gemini-s1 参考板的 64/16，两种都会在启动时断言崩溃：
#   · framebuffer 地址不固定，随之前的内存分配漂移（改 MQ_MAXMSGSIZE 就从
#     0x60055b30 变成 0x60075b38，一个 16 字节对齐、一个只有 8 字节对齐），
#     设 16 或 64 都会随机触发
#       lv_display_set_buffers: buf1 == lv_draw_buf_align(buf1, cf)
#   · stride 上限 4：390×450 RGB565，stride = 780 = 2²×3×5×13 不能被 8/16 整除，
#     设 16 会让 stride×h = 352800 超过 framebuffer 的 351000 字节
#       lv_display_set_buffers: stride * h <= buf_size
#
# 对齐的收益远小于刷新周期（33→16ms），不值得冒随机崩溃的风险。
set -eu

D=/home/wyj/velaride_ai/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh/defconfig

sed -i 's/^CONFIG_LV_DRAW_BUF_ALIGN=.*$/CONFIG_LV_DRAW_BUF_ALIGN=4/' "$D"
sed -i 's/^CONFIG_LV_DRAW_BUF_STRIDE_ALIGN=.*$/CONFIG_LV_DRAW_BUF_STRIDE_ALIGN=1/' "$D"

echo "=== 当前图形与 AI 相关配置 ==="
grep -E 'LV_DEF_REFR_PERIOD|LV_CACHE_DEF_SIZE|LV_DRAW_BUF_ALIGN|LV_DRAW_BUF_STRIDE|MQ_MAXMSGSIZE|AI_AGENT_VELA=|LV_USE_FS_POSIX' "$D"
