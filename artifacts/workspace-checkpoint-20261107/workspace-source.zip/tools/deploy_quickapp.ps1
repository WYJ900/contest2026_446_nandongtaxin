﻿# 把打包好的快应用 rpk 解包进固件 romfs
#
# 设备上 /etc 是 romfs 只读、/data 是 tmpfs（断电清空），运行时装不了应用，
# 所以快应用必须在编译期解包进 vendor/.../src/etc/data/app/<包名>/，随固件烧录。
#
# 完整流程：
#   cd vela-quickapp; npm run build          # .ux -> .js，产出 dist/*.rpk
#   .\tools\deploy_quickapp.ps1              # rpk -> romfs 目录
#   wsl -d Ubuntu-22.04 bash /mnt/d/desktop/VelaRide_AI/tools/wsl_sync_board.sh
#   wsl -d Ubuntu-22.04 bash /mnt/d/desktop/VelaRide_AI/tools/wsl_build.sh
#   .\tools\flash.ps1 -Port COM5

param(
    [string]$Package = "com.velaride.ai"
)

$ErrorActionPreference = "Stop"

$Root    = "D:/desktop/VelaRide_AI"
$DistDir = "$Root/vela-quickapp/dist"
$AppDir  = "$Root/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/src/etc/data/app/$Package"

$rpk = Get-ChildItem "$DistDir/*.rpk" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $rpk) { Write-Error "找不到 rpk，请先在 vela-quickapp 下执行 npm run build" }

Write-Host "=== 源包 ===" -ForegroundColor Cyan
Write-Host "$($rpk.Name)  $([math]::Round($rpk.Length/1KB,1)) KB  $($rpk.LastWriteTime)"

# 清空旧内容再解包，避免残留上一版的页面文件
if (Test-Path $AppDir) { Remove-Item $AppDir -Recurse -Force }
New-Item -ItemType Directory -Path $AppDir -Force | Out-Null

Write-Host "=== 解包到 romfs ===" -ForegroundColor Cyan
# rpk 本质是 zip，但 Expand-Archive 只认 .zip 扩展名，直接用 .NET 解
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory($rpk.FullName, $AppDir)

Get-ChildItem $AppDir | ForEach-Object {
    $mark = if ($_.PSIsContainer) { "/" } else { "" }
    Write-Host "  $($_.Name)$mark"
}

Write-Host "=== 完成 ===" -ForegroundColor Green
Write-Host "接着执行："
Write-Host "  wsl -d Ubuntu-22.04 bash /mnt/d/desktop/VelaRide_AI/tools/wsl_sync_board.sh"
Write-Host "  wsl -d Ubuntu-22.04 bash /mnt/d/desktop/VelaRide_AI/tools/wsl_build.sh"
Write-Host "  .\tools\flash.ps1 -Port COM5"
