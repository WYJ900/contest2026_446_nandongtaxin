#!/usr/bin/env bash
# 拉取思澈官方的黄山派示例（含表盘 UI）到 WSL 侧
#
# lckfb-hspi-ulp_example 是唯一针对本板（390×450 屏）的官方 UI 示例，
# 屏幕尺寸、EPIC 加速、LCD 驱动参数都是对的，不用猜。
# 注意：它基于 SiFli-SDK（RT-Thread 风格）而非 openvela/NuttX，
# 不能直接编译进本工程，只作 UI 实现思路参考。
set -eu

DEST=/home/wyj/sifli_hspi

if [ -d "$DEST/.git" ] && git -C "$DEST" rev-parse HEAD >/dev/null 2>&1; then
  echo "已存在：$(git -C "$DEST" log --oneline -1)"
else
  rm -rf "$DEST"
  echo "=== 克隆 lckfb-hspi-ulp_example ==="
  git clone --depth 1 https://github.com/OpenSiFli/lckfb-hspi-ulp_example.git "$DEST"
fi

echo
echo "=== 顶层 ==="
ls "$DEST"

echo
echo "=== 表盘目录 ==="
find "$DEST" -type d -iname 'watch*' | head -5

echo
echo "=== lvgl 子目录 ==="
ls "$DEST/lvgl" 2>/dev/null
