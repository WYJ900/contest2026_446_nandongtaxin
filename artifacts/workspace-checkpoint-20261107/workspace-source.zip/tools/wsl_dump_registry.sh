#!/usr/bin/env bash
# 打印 feature 注册表内容，排查 feature 注册不上的问题
GEN=/home/wyj/velaride_ai/cmake_out/lckfb_huangshan_pi/jidl_generated

echo "=== 目录内容 ==="
ls -la "$GEN"

for f in features_registry_list.h cfeatures_registry_list.h features_registry_table.h; do
  echo
  echo "=== $f ==="
  if [ -f "$GEN/$f" ]; then
    cat "$GEN/$f"
  else
    echo "  不存在"
  fi
done
