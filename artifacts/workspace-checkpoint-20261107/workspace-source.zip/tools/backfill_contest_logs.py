#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# Backfill contest AI Coding logs from ~/.claude/projects/ transcripts.
# Replicates snapshot_core.py exactly (schema, seq, redact, manifest) but:
#   - only processes one workspace dir's transcripts
#   - writes to --out (staging) for preview before export
#   - supports --include SID[,SID...], --drop-missing-mimo (skip sessions with 0 mimo)
import json, os, re, argparse
from datetime import datetime, timezone
from pathlib import Path

VERSION = "1.3.0"
SCHEMA_VERSION = "1.0"
DEFAULT_REDACT_RULES = [
    (re.compile(r"sk-[A-Za-z0-9_-]{20,}"), "sk-***REDACTED***"),
    (re.compile(r"ghp_[A-Za-z0-9]{36}"), "ghp_***REDACTED***"),
    (re.compile(r"Bearer\s+[A-Za-z0-9._\-+/=]+"), "Bearer ***REDACTED***"),
]
SKIP_BLOCK_TYPES = {"image"}


def iso_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"


def load_transcript(p):
    if not p.exists():
        return None
    try:
        out = []
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return out
    except Exception:
        return None


def expand_claude_event(raw, fallback_ts):
    out = []
    top_type = raw.get("type")
    ts = raw.get("timestamp") or fallback_ts
    if top_type in ("progress", "file-history-snapshot", "file-history-delta", "queue-operation",
                    "permission-mode", "agent-name", "summary", "attachment", "mode",
                    "last-prompt", "ai-title", "atis-latch", "system"):
        return out
    msg = raw.get("message") or {}
    role = (msg.get("role") or top_type or "system").lower()
    content = msg.get("content")
    model = msg.get("model")
    usage = msg.get("usage") or {}
    common = {"ts": ts}
    if model:
        common["model"] = model
    ti = usage.get("input_tokens")
    to = usage.get("output_tokens")
    if isinstance(ti, int):
        common["tokens_in"] = ti
    if isinstance(to, int):
        common["tokens_out"] = to
    if isinstance(content, str):
        if content:
            out.append({**common, "role": role, "text": content})
        return out
    if not isinstance(content, list):
        return out
    for block in content:
        if not isinstance(block, dict):
            continue
        bt = block.get("type")
        if bt in SKIP_BLOCK_TYPES:
            continue
        if bt == "text":
            t = block.get("text", "")
            if t:
                out.append({**common, "role": role, "text": t})
        elif bt == "thinking":
            th = block.get("thinking") or block.get("text") or ""
            if th:
                out.append({**common, "role": role, "thinking": th})
        elif bt == "tool_use":
            out.append({**common, "role": "tool", "tool_name": block.get("name", "unknown"),
                        "tool_call_id": block.get("id", f"call_{len(out)}"),
                        "input": block.get("input"), "output": None})
        elif bt == "tool_result":
            out.append({**common, "role": "tool", "tool_name": "<result>",
                        "tool_call_id": block.get("tool_use_id", f"call_{len(out)}"),
                        "input": None, "output": block.get("content"),
                        "is_error": bool(block.get("is_error"))})
        else:
            out.append({**common, "role": role,
                        "text": f"[unsupported block type: {bt}]",
                        "metadata": {"dropped": True, "original_type": bt}})
    return out


def redact_value(v, rules, counter):
    if isinstance(v, str):
        o = v
        for pat, rep in rules:
            o, n = pat.subn(rep, o)
            counter[0] += n
        return o
    if isinstance(v, list):
        return [redact_value(x, rules, counter) for x in v]
    if isinstance(v, dict):
        return {k: redact_value(x, rules, counter) for k, x in v.items()}
    return v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--projects", required=True)
    ap.add_argument("--workspace", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--include", default="")
    ap.add_argument("--drop-missing-mimo", action="store_true")
    args = ap.parse_args()

    ws = str(Path(args.workspace).resolve()).lower()
    proj = Path(args.projects)
    sid_filter = set(s for s in args.include.split(",") if s)

    transcripts = sorted(proj.glob("*.jsonl"))
    selected = []
    for t in transcripts:
        raw = load_transcript(t)
        if raw is None:
            continue
        cwds = [e.get("cwd") for e in raw if e.get("cwd")]
        if not cwds:
            continue
        if not all(str(c).lower().startswith(ws) for c in cwds):
            continue
        evs = []
        for r in raw:
            evs.extend(expand_claude_event(r, fallback_ts=iso_now()))
        if not evs:
            continue
        assistant = [e for e in evs if e.get("role") == "assistant"]
        if not assistant:
            continue
        mimo = sum(1 for e in assistant if str(e.get("model", "")).startswith("mimo"))
        tot = len(assistant)
        selected.append({"sid": t.stem, "raw": raw, "evs": evs, "total": tot,
                         "mimo": mimo, "pct": mimo * 100 // tot if tot else 0})
    print(f"[scan] {len(selected)} session(s) inside workspace")
    if args.drop_missing_mimo:
        before = len(selected)
        selected = [s for s in selected if s["mimo"] > 0]
        print(f"[filter] dropped {before - len(selected)} session(s) with 0 mimo; kept {len(selected)}")
    if sid_filter:
        selected = [s for s in selected if s["sid"] in sid_filter]
        print(f"[filter] include set -> {len(selected)} session(s)")

    team_id = os.environ.get("TEAM_ID", "")
    gl = os.environ.get("GITHUB_LOGIN", "")
    rules = DEFAULT_REDACT_RULES
    out_root = Path(args.out)
    member_dir = out_root / gl
    member_dir.mkdir(parents=True, exist_ok=True)
    man_path = member_dir / "manifest.json"
    manifest = {"schema_version": SCHEMA_VERSION, "team_id": team_id, "github_login": gl,
                "generator": f"claude-code-collector@{VERSION}", "updated_at": iso_now(), "sessions": []}
    if man_path.exists():
        try:
            manifest = json.loads(man_path.read_text(encoding="utf-8"))
        except Exception:
            pass

    total_events = 0
    for s in selected:
        sid = s["sid"]
        evs = s["evs"]
        lines = []
        seq = 0
        for ev in evs:
            counter = [0]
            red = redact_value(ev, rules, counter)
            out = {"schema_version": SCHEMA_VERSION, "session_id": sid, "team_id": team_id,
                   "github_login": gl, "tool": "claude-code", "seq": seq, **red}
            if counter[0] > 0:
                out["redacted_count"] = counter[0]
            lines.append(json.dumps(out, ensure_ascii=False))
            seq += 1
        if not lines:
            continue
        date_str = (evs[0].get("ts") or iso_now())[:10]
        rel = f"{gl}/{date_str}/claude-code__{sid}.jsonl"
        jp = member_dir / rel
        jp.parent.mkdir(parents=True, exist_ok=True)
        with jp.open("w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        entry = {"session_id": sid, "tool": "claude-code",
                 "started_at": (evs[0].get("ts") or iso_now()),
                 "last_event_at": iso_now(), "event_count": len(evs),
                 "raw_event_count": len(s["raw"]), "file_path": f"logs/{rel}",
                 "collection_mode": "backfill", "health": "ok"}
        last_asst = next((e for e in reversed(s["raw"]) if (e.get("message") or {}).get("model")), None)
        if last_asst:
            entry["model"] = last_asst.get("message", {}).get("model")
        entry["mimo_events"] = s["mimo"]
        entry["assistant_events"] = s["total"]
        existing = next((x for x in manifest["sessions"] if x.get("session_id") == sid), None)
        if existing:
            existing.update(entry)
        else:
            manifest["sessions"].append(entry)
        total_events += len(evs)
        print(f"  [wrote] {sid[:8]}  events={len(evs)}  mimo={s['mimo']}/{s['total']} ({s['pct']}%) -> {rel}")
    with man_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"[done] {len(selected)} session(s), {total_events} events -> {member_dir}")


if __name__ == "__main__":
    main()
