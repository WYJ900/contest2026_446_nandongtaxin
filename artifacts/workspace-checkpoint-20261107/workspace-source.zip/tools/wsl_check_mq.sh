#!/usr/bin/env bash
# 检查消息队列相关配置，排查 velaclaw bridge 线程 mq_open 失败
CFG=/home/wyj/velaride_ai/cmake_out/lckfb_huangshan_pi/.config
REF=/home/wyj/velaride_ai/../velaride_ai/packages/ai_agent/defconfigs

echo "=== 本板 mqueue 配置 ==="
grep -E '^CONFIG_(MQ_|FS_MQUEUE|PREALLOC_MQ|DISABLE_MQUEUE)' "$CFG" || echo "  （无匹配）"

echo
echo "=== 参考板 gemini-s1 的 mqueue 配置 ==="
grep -E '^CONFIG_(MQ_|FS_MQUEUE|PREALLOC_MQ|DISABLE_MQUEUE)' \
  /home/wyj/velaride_ai/packages/ai_agent/defconfigs/gemini-s1/gemini-s1_defconfig \
  2>/dev/null || echo "  （无匹配 / 文件不存在）"

echo
echo "=== 参考板 goldfish 的 mqueue 配置 ==="
grep -E '^CONFIG_(MQ_|FS_MQUEUE|PREALLOC_MQ|DISABLE_MQUEUE)' \
  /home/wyj/velaride_ai/packages/ai_agent/defconfigs/goldfish-arm64-v8a-ap/goldfish-arm64-v8a-ap_defconfig \
  2>/dev/null || echo "  （无匹配 / 文件不存在）"

echo
echo "=== 参考板的 ai_agent 相关全部配置（gemini-s1）==="
grep -E '^CONFIG_(AI_AGENT|EXAMPLES_AI_AGENT|VELACLAW)' \
  /home/wyj/velaride_ai/packages/ai_agent/defconfigs/gemini-s1/gemini-s1_defconfig 2>/dev/null

echo
echo "=== 本板的 ai_agent 相关配置 ==="
grep -E '^CONFIG_(AI_AGENT|EXAMPLES_AI_AGENT|VELACLAW)' "$CFG"
