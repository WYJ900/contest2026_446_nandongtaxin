﻿"""Workspace entry point; the implementation is maintained in the team repository."""
from pathlib import Path
import runpy

if __name__ == '__main__':
    runpy.run_path(str(Path(__file__).resolve().parents[1] / 'my-contest-repo/scripts/boot_check.py'), run_name='__main__')
