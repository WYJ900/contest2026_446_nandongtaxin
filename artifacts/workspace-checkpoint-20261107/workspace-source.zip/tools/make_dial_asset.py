#!/usr/bin/env python3
"""Build the embedded VelaRide dial asset from SiFli-SDK artwork.

The source PNG is Apache-2.0 artwork from SiFli-SDK watch_v9.  This tool
performs deterministic resize/compositing and writes native little-endian
RGB565 data for the SF32LB52/LVGL display path.
"""

from pathlib import Path

from PIL import Image, ImageChops, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "backup" / "sifli_ui_preview" / "dial_bg.png"
PREVIEW = ROOT / "apps" / "examples" / "velaride" / "velaride_dial_390.png"
OUTPUT = ROOT / "apps" / "examples" / "velaride" / "velaride_dial_rgb565.bin"
INCLUDE = ROOT / "apps" / "examples" / "velaride" / "velaride_dial_rgb565.inc"

SIZE = 390
BACKGROUND = (0x11, 0x18, 0x27, 0xFF)


def main() -> None:
    source = Image.open(SOURCE).convert("RGBA")
    dial = source.resize((SIZE, SIZE), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", dial.size, BACKGROUND)

    scale = 4
    mask_large = Image.new("L", (SIZE * scale, SIZE * scale), 0)
    ImageDraw.Draw(mask_large).ellipse(
        (0, 0, SIZE * scale - 1, SIZE * scale - 1), fill=255
    )
    circle_mask = mask_large.resize((SIZE, SIZE), Image.Resampling.LANCZOS)
    circle_mask = ImageChops.multiply(dial.getchannel("A"), circle_mask)
    canvas.paste(dial, (0, 0), circle_mask)
    rgb = canvas.convert("RGB")
    rgb.save(PREVIEW)

    data = bytearray()
    for red, green, blue in rgb.getdata():
        value = ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3)
        data.append(value & 0xFF)
        data.append(value >> 8)

    OUTPUT.write_bytes(data)
    with INCLUDE.open("w", encoding="ascii", newline="\n") as include:
        include.write(
            "/* Deterministically resized and circle-masked by "
            "tools/make_dial_asset.py from\n"
            " * SiFli-SDK watch_v9 img_dial_bg.png.\n"
            " * SPDX-FileCopyrightText: 2026 SiFli Technologies(Nanjing) "
            "Co., Ltd\n"
            " * SPDX-License-Identifier: Apache-2.0\n"
            " */\n\n"
            "static const unsigned char velaride_dial_rgb565[] = {\n"
        )
        for offset in range(0, len(data), 16):
            values = ", ".join(f"0x{byte:02x}" for byte in data[offset:offset + 16])
            include.write(f"  {values},\n")
        include.write("};\n")
        include.write(
            f"static const unsigned int velaride_dial_rgb565_len = {len(data)};\n"
        )
    print(f"preview={PREVIEW} size={PREVIEW.stat().st_size}")
    print(f"rgb565={OUTPUT} size={len(data)}")
    print(f"include={INCLUDE} size={INCLUDE.stat().st_size}")


if __name__ == "__main__":
    main()
