"""Preserve local-only build tools and APK alongside the existing GPS archives."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "my-contest-repo/artifacts/checkpoint-before-safety-20261103"
DEST.mkdir(parents=True, exist_ok=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

files = [ROOT / "AGENTS.md", ROOT / "PROJECT_PLAN.md"]
for folder in ("tools", "vela-quickapp/src", "project-docs"):
    files.extend(p for p in (ROOT / folder).rglob("*")
                 if p.is_file() and p.suffix in (".py", ".sh", ".ps1", ".mjs", ".js", ".md", ".json", ".ux", ".h", ".c")
                 and "__pycache__" not in p.parts)
files.extend(ROOT / "vela-quickapp" / p for p in ("package.json", "package-lock.json"))
with zipfile.ZipFile(DEST / "workspace-tools-and-quickapp.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(files)):
        archive.write(path, path.relative_to(ROOT).as_posix())
shutil.copy2(ROOT / "exports/mobile/VelaRide-0.1.4-debug.apk", DEST)
manifest = {
    "date": "2026-11-03",
    "purpose": "Local Git checkpoint before safety feature development",
    "installed_candidate_per_handoff": "9041c538529b46f3419c06f46bf70cfdd2570c0d20a58f704b31f9b147f7c0ef",
    "firmware_config_source_and_evidence": [
        "artifacts/ride-gps-stage-20261101/",
        "artifacts/phone-gps-ui-stage-20261101/",
        "artifacts/rc17-baseline-20261026/",
        "docs/validation-ride-gps-20261101/",
        "docs/HANDOFF_RIDE_GPS_20261101.md",
    ],
    "real_new_ride_gps_acceptance": "PENDING user test; no hardware interaction in this checkpoint",
    "reproducibility_limit": "Canonical application and accepted WSL build tree differ. Existing stage app archive, config, patches and baseline overlay are preserved; this is not a verified clean full-source rebuild.",
    "workspace_sources": {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(set(files))},
    "files": {p.name: digest(p) for p in DEST.iterdir() if p.is_file() and p.name != "manifest.json"},
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(f"Archived {len(set(files))} workspace source/tool files and Android 0.1.4 APK")
