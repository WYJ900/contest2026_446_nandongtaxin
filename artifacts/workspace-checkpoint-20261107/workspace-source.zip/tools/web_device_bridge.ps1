# VelaRide Web 网关的短连接串口桥接。
# 每次操作打开 COM、显式保持 DTR/RTS 为低、执行后立即关闭，避免浏览器
# Web Serial 长期独占 CH340 或意外改变复位线。

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('time_sync','ride_status','phone_data','review_upload')]
    [string]$Action,
    [string]$Port = 'COM5',
    [long]$Epoch = 0,
    [double]$Speed = 0,
    [double]$Distance = 0,
    [string]$ReviewBase64 = ''
)

$ErrorActionPreference = 'Stop'
$sp = New-Object System.IO.Ports.SerialPort($Port, 1000000, 'None', 8, 'One')
$sp.ReadTimeout = 300
$sp.WriteTimeout = 1000
$sp.DtrEnable = $false
$sp.RtsEnable = $false

function Invoke-DeviceCommand {
    param([string]$Command, [int]$WaitMs = 900)

    $sp.Write("$Command`r`n")
    $buf = New-Object System.Text.StringBuilder
    $deadline = (Get-Date).AddMilliseconds($WaitMs)
    while ((Get-Date) -lt $deadline) {
        if ($sp.BytesToRead -gt 0) {
            [void]$buf.Append($sp.ReadExisting())
            $deadline = (Get-Date).AddMilliseconds(350)
        }
        Start-Sleep -Milliseconds 25
    }

    return ($buf.ToString() -replace "`e\[[0-9;]*[A-Za-z]", '')
}

try {
    $sp.Open()
    Start-Sleep -Milliseconds 150
    if ($sp.BytesToRead -gt 0) { [void]$sp.ReadExisting() }

    $output = New-Object System.Text.StringBuilder
    switch ($Action) {
        'time_sync' {
            if ($Epoch -lt 1704067200) { throw 'invalid epoch' }
            [void]$output.Append((Invoke-DeviceCommand "velaride time-set $Epoch"))
        }
        'ride_status' {
            [void]$output.Append((Invoke-DeviceCommand 'velaride ride-status'))
            [void]$output.Append((Invoke-DeviceCommand 'velaride persist-read'))
        }
        'phone_data' {
            if ($Speed -lt 0 -or $Distance -lt 0) { throw 'invalid phone data' }
            $speedText = $Speed.ToString('0.0', [Globalization.CultureInfo]::InvariantCulture)
            $distanceText = $Distance.ToString('0.00', [Globalization.CultureInfo]::InvariantCulture)
            [void]$output.Append((Invoke-DeviceCommand "velaride phone-data $speedText $distanceText"))
        }
        'review_upload' {
            if ([string]::IsNullOrWhiteSpace($ReviewBase64)) { throw 'empty review' }
            $bytes = [Convert]::FromBase64String($ReviewBase64)
            if ($bytes.Length -gt 260) { throw 'review too long' }
            $hex = -join ($bytes | ForEach-Object { $_.ToString('x2') })
            [void]$output.Append((Invoke-DeviceCommand 'velaride review-begin' 500))
            for ($i = 0; $i -lt $hex.Length; $i += 32) {
                $length = [Math]::Min(32, $hex.Length - $i)
                $part = $hex.Substring($i, $length)
                [void]$output.Append((Invoke-DeviceCommand "velaride review-part $part" 500))
            }
            [void]$output.Append((Invoke-DeviceCommand 'velaride review-end' 1200))
            [void]$output.Append((Invoke-DeviceCommand 'velaride review-read' 800))
        }
    }

    [Console]::OutputEncoding = [Text.Encoding]::UTF8
    Write-Output $output.ToString()
}
finally {
    if ($sp.IsOpen) { $sp.Close() }
}
