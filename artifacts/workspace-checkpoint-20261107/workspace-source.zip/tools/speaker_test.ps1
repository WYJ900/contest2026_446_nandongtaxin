﻿# Run the Huangshan Pi speaker diagnostic without resetting the board.
# Requires the firmware containing the speaker_test NSH command.
param(
    [string]$Port = "COM5",
    [ValidateRange(1, 5)][int]$Repeat = 1,
    [ValidateRange(-24, 6)][int]$GainDb = 0,
    [ValidateSet("pcm", "pcm24", "internal", "music", "music24", "musicclean", "musicsteady", "musicusb", "silence", "silence24", "pa-only")][string]$Mode = "pcm"
)

$ErrorActionPreference = "Stop"
$Probe = Join-Path $PSScriptRoot "serial_probe.py"
$WaitSeconds = switch ($Mode) {
    "music" { [Math]::Min(45, 17 * $Repeat + 4) }
    "music24" { [Math]::Min(45, 17 * $Repeat + 4) }
    "musicclean" { [Math]::Min(45, 18 * $Repeat + 4) }
    "musicsteady" { [Math]::Min(45, 18 * $Repeat + 4) }
    "musicusb" { [Math]::Min(45, 18 * $Repeat + 4) }
    "silence" { 6 * $Repeat + 4 }
    "silence24" { 6 * $Repeat + 4 }
    "pa-only" { 8 }
    default { 4 * $Repeat + 4 }
}
& py -3 $Probe --port $Port --command "speaker_test $Repeat $GainDb $Mode" --wait $WaitSeconds
if ($LASTEXITCODE -ne 0) {
    throw "Serial speaker test failed."
}
