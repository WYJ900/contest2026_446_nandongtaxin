"""Upload a local bounded PCM WAV, verify its readback, and optionally play once."""
import argparse
import codecs
import json
from pathlib import Path
import re
import time
import wave

import serial

from mic_capture import BoardRebootError, checksum, decode_dump


class Console:
    def __init__(self, port):
        self.port = port
        self.decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
        self.pending = ''

    def receive(self, pattern, timeout=4):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if 'SFBL' in self.pending or 'AI Agent - Vela AI Agent starting' in self.pending:
                raise BoardRebootError('Board rebooted during upload/playback.')
            if 'Unknown command:' in self.pending or 'command not found' in self.pending:
                raise RuntimeError('The console did not accept the command.')
            match = re.search(pattern, self.pending)
            if match:
                response = self.pending[:match.end()]
                self.pending = self.pending[match.end():]
                return match, response
            data = self.port.read(self.port.in_waiting or 1)
            if data:
                self.pending += self.decoder.decode(data)
            if len(self.pending) > 700000:
                raise RuntimeError('Oversized serial response.')
        raise TimeoutError('Board response timed out; no audio content was logged.')

    def command(self, command, pattern, timeout=4):
        self.port.write((command + '\r\n').encode())
        return self.receive(pattern, timeout)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('wav', type=Path)
    parser.add_argument('--port', default='COM5')
    parser.add_argument('--skip-ms', type=int, default=0)
    parser.add_argument('--playback', action='store_true')
    parser.add_argument('--gain', type=int, choices=range(-24, 7), default=6)
    parser.add_argument('--log', type=Path, required=True)
    args = parser.parse_args()
    with wave.open(str(args.wav), 'rb') as source:
        if (source.getnchannels(), source.getsampwidth(), source.getframerate(), source.getcomptype()) != (1, 2, 16000, 'NONE'):
            parser.error('Input must be mono, 16-bit PCM, 16000 Hz.')
        if not 0 <= args.skip_ms * 16 < source.getnframes():
            parser.error('--skip-ms is outside the recording.')
        source.setpos(args.skip_ms * 16)
        pcm = source.readframes(source.getnframes() - source.tell())
    if not 0 < len(pcm) <= 160000 or len(pcm) % 2:
        parser.error('Upload must contain no more than five seconds of complete PCM samples.')
    digest = checksum(pcm)
    port = serial.Serial(port=None, baudrate=1000000, timeout=0.1, write_timeout=1)
    port.dtr = False
    port.rts = False
    port.port = args.port
    radio_owned = False
    rebooted = False
    console = Console(port)
    report = {'input': str(args.wav), 'skip_ms': args.skip_ms,
              'bytes': len(pcm), 'checksum': f'{digest:08x}'}
    args.log.parent.mkdir(parents=True, exist_ok=True)
    try:
        port.open()
        status, _ = console.command('velaride_ble radio-status',
                                    r'ready=(\d+) connected=(\d+) adv_paused=(\d+)')
        ready, connected, paused = map(int, status.groups())
        if not ready or connected:
            raise RuntimeError('Upload requires ready, disconnected BLE.')
        if not paused:
            result, _ = console.command('velaride_ble adv-off', r'advertising pause ret=(-?\d+)')
            if int(result.group(1)) != 0:
                raise RuntimeError('Could not pause advertising.')
            radio_owned = True
        result, _ = console.command(f'mic_test load {len(pcm)} {digest:08x}', r'MIC_LOAD ready bytes=(\d+)')
        if int(result.group(1)) != len(pcm):
            raise RuntimeError('Upload length was not accepted.')
        started = time.monotonic()
        for offset in range(0, len(pcm), 64):
            block = pcm[offset:offset + 64]
            port.write(block.hex().encode() + b'\n')
            result, _ = console.receive(r'MIC_LOAD offset=(\d+)')
            if int(result.group(1)) != offset + len(block):
                raise RuntimeError('Upload acknowledgement offset mismatch.')
            if (offset + len(block)) % 32000 == 0:
                print(f'Uploaded {offset + len(block)}/{len(pcm)} bytes.', flush=True)
        result, _ = console.receive(r'mic_test: done result=(-?\d+)', 5)
        if int(result.group(1)) != 0:
            raise RuntimeError('Board rejected the upload checksum or file write.')
        report['upload_seconds'] = round(time.monotonic() - started, 3)
        _, raw_dump = console.command('mic_test dump', r'MIC_END', 25)
        if decode_dump(raw_dump) != pcm:
            raise RuntimeError('PCM readback does not match the uploaded file.')
        report['readback_verified'] = True
        print('Upload and complete PCM readback verified.', flush=True)
        if args.playback:
            print('Playing uploaded voice once on board speaker.', flush=True)
            result, playback_log = console.command(
                f'speaker_test 1 {args.gain} mic',
                r'speaker_test: done, amplifier off, result=(-?\d+)', 10)
            args.log.with_suffix('.playback.log').write_text(playback_log, encoding='utf-8')
            report['playback_result'] = int(result.group(1))
            if report['playback_result'] != 0:
                raise RuntimeError('Board reported a playback failure.')
            print('Playback completed; amplifier off.', flush=True)
    except BoardRebootError:
        rebooted = True
        raise
    finally:
        if port.is_open:
            if radio_owned and not rebooted:
                try:
                    result, _ = console.command('velaride_ble adv-on', r'advertising restart ret=(-?\d+)')
                    report['advertising_restore_result'] = int(result.group(1))
                    print('BLE advertising restore result: ' + result.group(1), flush=True)
                except Exception as error:
                    print('Could not restore advertising: ' + str(error), flush=True)
            port.close()
        args.log.write_text(json.dumps(report, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
