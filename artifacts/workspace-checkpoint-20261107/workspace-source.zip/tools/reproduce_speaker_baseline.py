"""Reproduce the archived binary in the isolated archive-check tree (WSL only).

The original incremental image contains two different compilation times.
SOURCE_DATE_EPOCH fixes compiler date macros; a macro prefix map fixes __FILE__.
This writes only the isolated rebuild tree and diagnostic evidence, never flash.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile


ROOT = Path('/mnt/d/desktop/VelaRide_AI')
SAVE = ROOT / 'backup/expansion-20261027'
TREE = Path('/home/wyj/velaride_speaker_archive_check_20261027')
SOURCE = TREE / 'source'
OUT = TREE / 'output'
ORIGINAL = '/home/wyj/velaride_speaker_stage'
GCC = '/opt/arm-gnu-toolchain/bin/arm-none-eabi-gcc'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def environment(hour, minute, second):
    env = os.environ.copy()
    env['PATH'] = '/opt/arm-gnu-toolchain/bin:' + str(Path.home() / '.local/bin') + ':' + env['PATH']
    env['SOURCE_DATE_EPOCH'] = str(int(datetime(2026, 10, 27, hour, minute, second, tzinfo=timezone.utc).timestamp()))
    return env


def command(args, log, env):
    with (SAVE / log).open('w', encoding='utf-8') as stream:
        subprocess.run(args, cwd=SOURCE / 'nuttx', env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)


def main():
    baseline = SAVE / 'speaker-source-snapshot/nuttx.bin'
    assert sha(baseline) == '23ea7b74e6f6aa4bbe9c2e9e925b034eed1ef1cf5a37fa255f2f105222068941'
    env = environment(13, 9, 3)
    probe = subprocess.check_output([GCC, '-E', '-P', '-x', 'c', '-'],
                                   input='__DATE__ " " __TIME__\n', text=True, env=env)
    assert probe.strip() == '"Oct 27 2026" " " "13:09:03"', probe
    # NuttX already strips its own and apps' paths. A whole-tree mapping would
    # override those maps and introduce extra strings. Only vendor driver paths
    # are absolute in the original image (8 strings, 24 extra bytes each).
    driver_path = '/vendor/sifli/boards/sf32lb52/drivers'
    flags = '-Wno-cpp -Wno-deprecated-declarations ' + f'-fmacro-prefix-map={SOURCE}{driver_path}={ORIGINAL}{driver_path}'
    command(['cmake', '-B', str(OUT), '-S', str(SOURCE / 'nuttx'), '-GNinja',
             f'-DBOARD_CONFIG={SOURCE}/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh',
             '-DEXTRA_FLAGS=' + flags], '10-reproduce-configure.log', env)
    # JIDL generation has nondeterministic declaration ordering. Preserve the
    # exact generated C++/headers used by the accepted image as build inputs.
    generated = SAVE / 'generated-interfaces.tar.gz'
    generated_manifest = json.loads((SAVE / 'generated-interfaces-manifest.json').read_text())
    assert sha(generated) == generated_manifest['sha256']
    generated_root = (OUT / 'jidl_generated').resolve()
    restored = set()
    with tarfile.open(generated, 'r:gz') as archive:
        for member in archive:
            target = (generated_root / member.name).resolve()
            if not member.isfile() or not target.is_relative_to(generated_root):
                raise RuntimeError('Unexpected generated source archive entry')
            payload = archive.extractfile(member).read()
            assert hashlib.sha256(payload).hexdigest() == generated_manifest['files'][member.name]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
            restored.add(member.name)
    assert restored == set(generated_manifest['files'])
    command(['cmake', '--build', str(OUT), '--', '-j8'], '10-reproduce-build.log', env)
    print('Full build with baseline date and source-path mapping completed', flush=True)
    # The accepted incremental image compiled agent_main 32 seconds after uname.
    os.utime(SOURCE / 'packages/ai_agent/src/agent_main.c', None)
    command(['cmake', '--build', str(OUT), '--', '-j8'], '10-reproduce-agent-time.log', environment(13, 9, 35))
    image = OUT / 'nuttx.bin'
    config_equal = (OUT / '.config').read_bytes() == (SAVE / 'speaker-source-snapshot/.config').read_bytes()
    report = {'baseline_sha256': sha(baseline), 'rebuilt_sha256': sha(image),
              'binary_identical': image.read_bytes() == baseline.read_bytes(),
              'config_identical': config_equal, 'bytes': image.stat().st_size,
              'compiler': subprocess.check_output([GCC, '--version'], text=True).splitlines()[0],
              'source_archive_sha256': json.loads((SAVE / 'speaker-source-snapshot/manifest.json').read_text())['files']['source.tar.gz']['sha256'],
              'generated_interfaces_sha256': sha(generated),
              'macro_prefix_map': {str(SOURCE) + driver_path: ORIGINAL + driver_path},
              'build_epoch': env['SOURCE_DATE_EPOCH'], 'agent_epoch': environment(13, 9, 35)['SOURCE_DATE_EPOCH'],
              'scope': 'Local archive rebuild; no flash; toolchain remains an external dependency.'}
    (SAVE / '10-reproducibility.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    shutil.copy2(image, SAVE / 'archive-reproduced.bin')
    print(json.dumps(report, indent=2), flush=True)
    if not (report['binary_identical'] and config_equal):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
