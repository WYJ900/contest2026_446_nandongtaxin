#!/usr/bin/env bash
# 安装 ARM GNU 工具链 13.x（Linux x86_64）到 WSL
#
# 原因：Ubuntu 22.04 apt 只提供 arm-none-eabi-gcc 10.3，不支持 libcxx 依赖的
# __builtin_bit_cast / __is_nothrow_assignable 等内建，编译必定失败。
# 项目自带的 Windows 预编译工具链是 GCC 13.4.0，这里装版本对齐的 Linux 版。
set -eu

TC_DIR=/opt/arm-gnu-toolchain
TC_VER=13.3.rel1
TARBALL="arm-gnu-toolchain-${TC_VER}-x86_64-arm-none-eabi.tar.xz"
URL="https://developer.arm.com/-/media/Files/downloads/gnu/${TC_VER}/binrel/${TARBALL}"

if [ -x "$TC_DIR/bin/arm-none-eabi-gcc" ]; then
  echo "工具链已存在：$("$TC_DIR/bin/arm-none-eabi-gcc" --version | head -1)"
  exit 0
fi

cd /tmp
if [ ! -f "$TARBALL" ]; then
  echo "=== 下载 ARM GNU Toolchain $TC_VER ==="
  wget -q --show-progress "$URL" -O "$TARBALL"
fi

echo "=== 解压到 $TC_DIR ==="
sudo mkdir -p "$TC_DIR"
sudo tar -xf "$TARBALL" -C "$TC_DIR" --strip-components=1

echo "=== 验证 ==="
"$TC_DIR/bin/arm-none-eabi-gcc" --version | head -1
