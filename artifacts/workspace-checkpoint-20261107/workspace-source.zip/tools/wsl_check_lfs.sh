#!/usr/bin/env bash
# 检查并同步 vendor 预编译库（Git LFS）
#
# vendor/sifli/boards/sf32lb52/libs/nsh_cmake/ 下的 .a 是走 Git LFS 的预编译库。
# 若 LFS 未拉取，文件只是 134 字节的指针文本，链接期报
#   "file format not recognized; treating as linker script"
# 这个报错完全看不出是 LFS 问题，所以单独检查。
set -eu

SRC=/mnt/d/desktop/VelaRide_AI
DEST=/home/wyj/velaride_ai
LIBDIR=vendor/sifli/boards/sf32lb52/libs

echo "=== 检查 LFS 指针文件 ==="
pointers=0
for f in "$SRC/$LIBDIR/nsh_cmake"/*.a; do
  [ -f "$f" ] || continue
  if head -c 40 "$f" 2>/dev/null | grep -q 'git-lfs'; then
    echo "    未拉取: $(basename "$f") ($(stat -c%s "$f") bytes)"
    pointers=$((pointers + 1))
  fi
done

if [ "$pointers" -gt 0 ]; then
  echo
  echo "有 $pointers 个 LFS 文件未拉取，请在 Windows 侧执行：" >&2
  echo "    cd D:/desktop/VelaRide_AI/$LIBDIR && git lfs pull" >&2
  exit 1
fi
echo "    全部已拉取"

echo "=== 同步预编译库到 WSL ==="
mkdir -p "$DEST/$LIBDIR"
rsync -a --exclude='.git' "$SRC/$LIBDIR/" "$DEST/$LIBDIR/"
ls -la "$DEST/$LIBDIR/nsh_cmake"/*.a | awk '{printf "    %-28s %s\n", $NF, $5}' \
  | sed "s#$DEST/$LIBDIR/nsh_cmake/##"
