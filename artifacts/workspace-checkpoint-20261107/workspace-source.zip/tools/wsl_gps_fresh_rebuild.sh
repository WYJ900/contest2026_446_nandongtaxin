#!/bin/bash
# Copy the accepted GPS tree unchanged and rebuild from scratch; compare to 9041c538.
set -u
export PATH=/opt/arm-gnu-toolchain/bin:/home/wyj/.local/bin:/usr/local/bin:/usr/bin:/bin
BASE=/home/wyj/velaride_ride_gps_stage
DST=/home/wyj/velaride_gps_fresh_rebuild
OUT=$DST/cmake_out/lckfb_huangshan_pi
rm -rf "$DST"; mkdir -p "$DST"
rsync -a --exclude=/cmake_out "$BASE/" "$DST/"
cd "$DST/nuttx"
cmake -B "$OUT" -S "$DST/nuttx" -GNinja \
  -DBOARD_CONFIG="$DST/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh" \
  '-DEXTRA_FLAGS=-Wno-cpp -Wno-deprecated-declarations' > /tmp/gps_fresh_configure.log 2>&1
cmake --build "$OUT" -- -j8 > /tmp/gps_fresh_build.log 2>&1 || { tail -30 /tmp/gps_fresh_build.log; exit 1; }
cmp "$BASE/cmake_out/lckfb_huangshan_pi/.config" "$OUT/.config" && echo CONFIG-SAME
sha256sum "$BASE/cmake_out/lckfb_huangshan_pi/nuttx.bin" "$OUT/nuttx.bin"
cp "$OUT/nuttx.bin" /mnt/d/desktop/VelaRide_AI/backup/bisect-20261105/gps-fresh-rebuild.bin
