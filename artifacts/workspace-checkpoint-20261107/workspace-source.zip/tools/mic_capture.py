"""Capture the board microphone locally and verify the serial PCM transfer."""
import argparse
import array
import codecs
import json
import math
from pathlib import Path
import re
import sys
import time
import wave

import serial


class BoardRebootError(RuntimeError):
    pass


def exchange(port, decoder, command, pattern, timeout):
    port.write((command + '\r\n').encode())
    received = ''
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        data = port.read(port.in_waiting or 1)
        if not data:
            continue
        received += decoder.decode(data)
        if 'SFBL' in received or 'AI Agent - Vela AI Agent starting' in received:
            raise BoardRebootError('The board rebooted during capture.')
        if 'Unknown command:' in received or 'command not found' in received:
            raise RuntimeError('Microphone command is unavailable.')
        match = re.search(pattern, received)
        if match:
            return match, received
        if len(received) > 700000:
            raise RuntimeError('Unexpectedly large serial response.')
    raise TimeoutError(f'No completion for {command!r}')


def checksum(data):
    value = 2166136261
    for byte in data:
        value = ((value ^ byte) * 16777619) & 0xffffffff
    return value


def decode_dump(text):
    header = re.search(r'MIC_BEGIN bytes=(\d+) rate=16000 bits=16 checksum=([0-9a-fA-F]{8})', text)
    if not header:
        raise ValueError('Missing microphone transfer header.')
    expected = int(header.group(1))
    if not 0 < expected <= 160000 or expected % 2:
        raise ValueError('Invalid PCM length.')
    output = bytearray()
    for match in re.finditer(r'^MICDATA ([0-9a-fA-F]{8}) ([0-9a-fA-F]+)\r?$', text, re.M):
        offset = int(match.group(1), 16)
        block = bytes.fromhex(match.group(2))
        if offset != len(output) or not 0 < len(block) <= 64:
            raise ValueError('Missing, duplicate or out-of-order PCM data.')
        output.extend(block)
    if len(output) != expected or 'MIC_END' not in text:
        raise ValueError('Incomplete PCM transfer.')
    if checksum(output) != int(header.group(2), 16):
        raise ValueError('PCM checksum mismatch.')
    return bytes(output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', default='COM5')
    parser.add_argument('--seconds', type=int, choices=range(1, 6), default=3)
    parser.add_argument('--countdown', type=int, choices=range(0, 31), default=5)
    parser.add_argument('--keep-radio', action='store_true',
                        help='Leave legacy BLE unchanged; do not require radio-control commands.')
    parser.add_argument('--playback', action='store_true',
                        help='Play the captured voice once on the board, then turn the amplifier off.')
    parser.add_argument('--cue', action='store_true', help='Use short Windows PC beeps to mark recording start/end.')
    parser.add_argument('--gain', type=int, choices=range(-24, 7), default=6)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    port = serial.Serial(port=None, baudrate=1000000, timeout=0.1, write_timeout=1)
    port.dtr = False
    port.rts = False
    port.port = args.port
    decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
    radio_owned = False
    rebooted = False
    try:
        port.open()
        if not args.keep_radio:
            status, _ = exchange(port, decoder, 'velaride_ble radio-status',
                                 r'ready=(\d+) connected=(\d+) adv_paused=(\d+)', 4)
            ready, connected, paused = map(int, status.groups())
            if not ready or connected:
                raise RuntimeError('Microphone test requires a ready, disconnected BLE adapter.')
            if not paused:
                result, _ = exchange(port, decoder, 'velaride_ble adv-off',
                                     r'advertising pause ret=(-?\d+)', 4)
                if int(result.group(1)) != 0:
                    raise RuntimeError('Could not pause BLE advertising.')
                radio_owned = True
        print(f'Recording board microphone in {args.countdown} seconds, duration {args.seconds}s.', flush=True)
        time.sleep(args.countdown)
        if args.cue:
            import winsound
            winsound.Beep(880, 150)
        result, record_log = exchange(port, decoder, f'mic_test {args.seconds}',
                                      r'mic_test: done result=(-?\d+)', args.seconds + 7)
        if args.cue:
            winsound.Beep(660, 150)
        if int(result.group(1)) != 0:
            raise RuntimeError('Capture failed: ' + record_log[-1500:])
        timing = re.search(r'MIC_DMA remaining=0 elapsed=(\d+)', record_log)
        if not timing:
            raise RuntimeError('Capture did not report a complete DMA transfer.')
        elapsed_ms = int(timing.group(1))
        warmup = re.search(r'MIC_RECORD[^\r\n]*warmup_ms=(\d+)', record_log)
        warmup_ms = int(warmup.group(1)) if warmup else 0
        observed_rate = (args.seconds * 1000 + warmup_ms) * 16000 / max(1, elapsed_ms)
        if not 15200 <= observed_rate <= 16800:
            raise RuntimeError(f'Unexpected microphone DMA rate: {observed_rate:.1f} samples/s')
        for attempt in range(2):
            _, dump = exchange(port, decoder, 'mic_test dump', r'MIC_END', 25)
            try:
                pcm = decode_dump(dump)
                if len(pcm) != args.seconds * 16000 * 2:
                    raise ValueError('PCM length differs from the requested capture duration.')
                break
            except ValueError:
                if attempt == 1:
                    raise
        values = array.array('h')
        values.frombytes(pcm)
        if sys.byteorder != 'little':
            values.byteswap()
        metadata = {
            'seconds': len(values) / 16000,
            'sample_rate': 16000,
            'bits': 16,
            'channels': 1,
            'capture_elapsed_ms': elapsed_ms,
            'warmup_ms': warmup_ms,
            'observed_sample_rate': round(observed_rate, 2),
            'min': min(values),
            'max': max(values),
            'rms': round(math.sqrt(sum(v * v for v in values) / len(values)), 3),
            'mean': round(sum(values) / len(values), 3),
            'zero_samples': sum(v == 0 for v in values),
            'clipped_samples': sum(v in (-32768, 32767) for v in values),
            'checksum': f'{checksum(pcm):08x}',
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(args.output), 'wb') as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(16000)
            output.writeframes(pcm)
        args.output.with_suffix('.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        print(json.dumps(metadata), flush=True)
        print(f'Saved verified microphone recording: {args.output}', flush=True)
        if args.playback:
            print('Playing captured voice once on the board speaker.', flush=True)
            result, playback_log = exchange(
                port, decoder, f'speaker_test 1 {args.gain} mic',
                r'speaker_test: done, amplifier off, result=(-?\d+)', 10)
            args.output.with_suffix('.playback.log').write_text(playback_log, encoding='utf-8')
            metadata['playback_result'] = int(result.group(1))
            args.output.with_suffix('.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
            if metadata['playback_result'] != 0:
                raise RuntimeError('Board voice playback failed: ' + playback_log[-1500:])
            print('Board voice playback completed, amplifier off.', flush=True)
    except BoardRebootError:
        rebooted = True
        raise
    finally:
        if port.is_open:
            if radio_owned and not rebooted:
                try:
                    result, _ = exchange(port, decoder, 'velaride_ble adv-on',
                                         r'advertising restart ret=(-?\d+)', 4)
                    print('BLE advertising restore result: ' + result.group(1), flush=True)
                except Exception as error:
                    print('Could not restore BLE advertising: ' + str(error), flush=True)
            port.close()


if __name__ == '__main__':
    main()
