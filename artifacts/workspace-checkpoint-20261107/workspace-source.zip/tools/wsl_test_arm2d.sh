#!/usr/bin/env bash
# Arm-2D 在本板工具链下的可行性预检：单独编一个核心源文件，看能不能过
#
# 目的是在投入完整构建集成之前，先确认三件事：
#   1. arm_2d.h 能否被 arm-none-eabi-gcc 13 正常解析
#   2. M33（armv8-m.main，无 MVE）下是否有缺失的 CMSIS 依赖
#   3. 是否强依赖 Helium/MVE 内建
set -u

SRC=/home/wyj/arm2d
OUT=/tmp/arm2d_probe
GCC=/opt/arm-gnu-toolchain/bin/arm-none-eabi-gcc

rm -rf "$OUT" && mkdir -p "$OUT/cfg"

# Arm-2D 要求项目提供 arm_2d_cfg.h，先用官方模板
cp "$SRC/Library/Include/template/arm_2d_cfg.h" "$OUT/cfg/"

# 本板 CPU 参数：Cortex-M33 + FPU（fpv5-sp-d16），无 MVE
# Arm-2D 用了匿名结构体成员（implement_ex 宏），GCC 需要 -fms-extensions，
# 否则会刷出成百上千条 "declaration does not declare anything" 警告
FLAGS="-mcpu=cortex-m33 -mthumb -mfpu=fpv5-sp-d16 -mfloat-abi=hard -Os -c"
FLAGS="$FLAGS -fms-extensions -Wno-unused-parameter"
# Arm-2D 依赖 CMSIS：Core（cmsis_compiler.h）+ DSP（arm_math.h）
# sifli 自带一份和芯片配套的 CMSIS，优先用它；DSP 头取自项目里的 CMSIS_5
CMSIS_SIFLI=/home/wyj/velaride_ai/vendor/sifli/chips/external/CMSIS/Include
CMSIS_CORE=/home/wyj/velaride_ai/apps/mlearning/cmsis/CMSIS_5/CMSIS/Core/Include
CMSIS_DSP=/home/wyj/velaride_ai/apps/mlearning/cmsis/CMSIS_5/CMSIS/DSP/Include
INC="-I$SRC/Library/Include -I$SRC/Helper/Include -I$OUT/cfg"
INC="$INC -I$CMSIS_SIFLI -I$CMSIS_CORE -I$CMSIS_DSP"

# 找一个不带 helium 后缀的核心文件来试
TARGET="$SRC/Library/Source/arm_2d.c"

echo "=== 试编译 $(basename "$TARGET") ==="
echo "flags: $FLAGS"
echo

"$GCC" $FLAGS $INC "$TARGET" -o "$OUT/arm_2d.o" 2>&1 | head -30
rc=${PIPESTATUS[0]}

echo
if [ "$rc" -eq 0 ]; then
  echo "✅ 编译通过，Arm-2D 可用于本板"
  ls -la "$OUT/arm_2d.o"
else
  echo "❌ 编译失败（exit=$rc），上面是前 30 行错误"
fi
