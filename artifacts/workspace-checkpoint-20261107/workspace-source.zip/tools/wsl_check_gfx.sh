#!/usr/bin/env bash
# 检查图形性能相关配置，用于评估流畅度优化空间
CFG=/home/wyj/velaride_ai/cmake_out/lckfb_huangshan_pi/.config

show() {
  echo "=== $1 ==="
  shift
  grep -E "$1" "$CFG" || echo "  （无匹配）"
  echo
}

show "渲染后端与汇编优化"        '^CONFIG_LV_USE_DRAW|^CONFIG_LV_DRAW_SW_ASM|^CONFIG_LV_USE_ARM2D|^CONFIG_LV_USE_NATIVE_HELIUM'
show "绘制缓冲对齐 / 绘制单元"    '^CONFIG_LV_DRAW_BUF|^CONFIG_LV_DRAW_SW_DRAW_UNIT|^CONFIG_LV_DRAW_SW_LAYER'
show "缓存"                      '^CONFIG_LV_DRAW_SW_.*CACHE|^CONFIG_LV_CACHE|^CONFIG_LV_IMAGE_CACHE|^CONFIG_LV_FONT_CACHE'
show "刷新与显示"                '^CONFIG_LV_DEF_REFR|^CONFIG_LV_DISP|^CONFIG_LV_USE_NUTTX'
show "内存"                      '^CONFIG_LV_MEM|^CONFIG_LV_USE_STDLIB'
show "LCD / 屏幕驱动"            '^CONFIG_LCD|^CONFIG_SIFLI_LCD|^CONFIG_BSP_USING_LCDC|^CONFIG_VIDEO_FB'
show "图形加速器"                '^CONFIG_BSP_USING_EPIC|^CONFIG_RT_USING_EPIC|EPIC'
