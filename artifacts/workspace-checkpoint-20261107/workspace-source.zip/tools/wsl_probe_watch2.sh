#!/usr/bin/env bash
# 深入探查思澈表盘示例：gui_apps 实现与动画手法
W=/home/wyj/sifli_hspi/lvgl/watch

echo "=== README ==="
cat "$W/README.md"

echo
echo "=== gui_apps 内容 ==="
ls -la "$W/src/gui_apps/"

echo
echo "=== 所有非字体的 .c（真正的 UI 代码）==="
find "$W/src" -name '*.c' | grep -v '/fonts/' | grep -v '/images/'

echo
echo "=== 用到的 LVGL 动画 API ==="
find "$W/src" -name '*.c' -o -name '*.h' | grep -v '/fonts/' | \
  xargs grep -ho 'lv_anim[a-z_]*\|lv_obj_set_style_transform[a-z_]*' 2>/dev/null | sort -u | head -20

echo
echo "=== 是否用 EPIC ==="
find "$W" -type f \( -name '*.c' -o -name '*.h' -o -name '*.conf' -o -name 'Kconfig*' \) \
  | xargs grep -l 'EPIC' 2>/dev/null | head -5
