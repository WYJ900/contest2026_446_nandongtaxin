"""Verify the complete F: backup, then add non-destructive watch directories."""
from datetime import datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import uuid

ROOT=Path(__file__).resolve().parents[1]
backup=Path((ROOT/'backup/install-features-20261104/tf-backup-path.txt').read_text(encoding='utf-8-sig').strip())
card=Path('F:/')
original=backup/'CARD_ROOT'
info=json.loads((backup/'CARD_INFO.json').read_text(encoding='utf-8-sig'))
assert backup.resolve().is_relative_to(Path('D:/desktop/AL').resolve())

def current_volume():
    command="Get-Volume -DriveLetter F | Select-Object UniqueId,FileSystem,AllocationUnitSize,Size | ConvertTo-Json -Compress"
    result=subprocess.run(['powershell.exe','-NoProfile','-Command',command],check=True,capture_output=True)
    return json.loads(result.stdout.decode('utf-8-sig'))

volume=current_volume()
assert volume['UniqueId']==info['VolumeId'], 'F: volume changed; refusing card writes'
assert volume['FileSystem']=='FAT32' and volume['AllocationUnitSize']==32768

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): digest.update(block)
    return digest.hexdigest()

files=sorted(p for p in card.rglob('*') if p.is_file())
source_names={p.relative_to(card).as_posix() for p in files}
backup_names={p.relative_to(original).as_posix() for p in original.rglob('*') if p.is_file()}
assert source_names==backup_names, 'Backup file list differs from source'
items=[]
for source in files:
    name=source.relative_to(card).as_posix()
    copy=original/name
    source_hash=sha(source)
    assert source.stat().st_size==copy.stat().st_size and source_hash==sha(copy), name
    items.append({'path':name,'bytes':source.stat().st_size,'sha256':source_hash})
manifest={'verified_at':datetime.now().astimezone().isoformat(),'source':'F:/','backup':str(original),
          'files':items,'file_count':len(items),'total_bytes':sum(item['bytes'] for item in items),
          'all_source_files_including_hidden_verified':True}
(backup/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(backup/'SHA256SUMS.txt').write_text(''.join(item['sha256']+'  '+item['path']+'\n' for item in items),encoding='utf-8',newline='\n')
print(f"PASS: backed up and SHA-256 verified {len(items)} files / {manifest['total_bytes']} bytes",flush=True)

# Only now write to the explicitly identified removable volume. No format,
# partition change or deletion of original files is performed.
assert current_volume()['UniqueId']==info['VolumeId']
memos=card/'MEMOS'
memos.mkdir(exist_ok=True)
assert memos.is_dir()
probe=card/(uuid.uuid4().hex[:8].upper()+'.TMP')
assert probe.resolve().parent==card.resolve()
data=os.urandom(512*1024)
try:
    with probe.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())
    assert sha(probe)==hashlib.sha256(data).hexdigest(), 'Card write/readback failed'
finally:
    if probe.exists(): probe.unlink()

ready='''VelaRide TF card / 手表 TF 卡准备完成

文件系统：FAT32；簇大小：32 KB；分区：MBR。
MEMOS 目录供手表保存 3 秒板载录音，插卡后由手表挂载到 /data/tf。
在手表暂停骑行 → 控制页 → 语音标记 → 点击录制。
手机 App 0.2.0 可同步、校验、试听并关联实际骑行记录。

原来的全部图片和音乐已备份且逐文件 SHA-256 校验，同时保留在卡上。
这些旧素材不会被当前手表固件自动播放。
录音、App 同步和 TF 实物掉电行为仍需插卡后验证。
'''
with (card/'READY.TXT').open('w',encoding='utf-8-sig',newline='\r\n') as stream:
    stream.write(ready);stream.flush();os.fsync(stream.fileno())

for item in items:
    assert sha(card/item['path'])==item['sha256'], 'Original file changed: '+item['path']
result={'prepared_at':datetime.now().astimezone().isoformat(),'source_volume':info['VolumeId'],
        'backup':str(backup),'original_files_verified':len(items),'original_bytes':manifest['total_bytes'],
        'original_files_preserved_on_card':True,'format_performed':False,'partition_changes':False,
        'file_system':'FAT32','cluster_bytes':32768,'added':['MEMOS/','READY.TXT'],
        'card_write_readback_bytes':len(data),'card_write_readback_passed':True,
        'hardware_watch_mount_and_recording':'pending insertion'}
(backup/'PREPARATION_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(backup/'先读_备份与插卡说明.txt').write_text('原卡全部文件在 CARD_ROOT 文件夹。SHA256_MANIFEST.json 为逐文件校验清单。\n'
    '未格式化、未清空原卡；F: 新增 MEMOS 录音目录与 READY.TXT 使用说明。\n'
    '请安全弹出 F: 后插入手表；再检查挂载和真实录音。\n',encoding='utf-8-sig')
print(json.dumps(result,ensure_ascii=False,indent=2))
