"""Keep a serial connection open for repeatable speaker listening tests."""
import argparse
import codecs
import re
from pathlib import Path
import time

import serial


class BoardRebootError(RuntimeError):
    pass


def console_command(port, decoder, log, command, pattern, timeout=4):
    log.write(f'\nHOST COMMAND: {command}\n')
    port.write((command + '\r\n').encode())
    received = ''
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        chunk = port.read(port.in_waiting or 1)
        if not chunk:
            continue
        decoded = decoder.decode(chunk)
        log.write(decoded)
        received = (received + decoded)[-24000:]
        if 'SFBL' in received or 'AI Agent - Vela AI Agent starting' in received:
            raise BoardRebootError('Board rebooted; see the serial log.')
        if 'Unknown command:' in received or 'command not found' in received:
            raise RuntimeError('Command was not accepted by the console.')
        match = re.search(pattern, received)
        if match:
            return match
    raise RuntimeError(f'No expected response to {command!r}; see the serial log.')


parser = argparse.ArgumentParser()
parser.add_argument('--port', default='COM5')
parser.add_argument('--gain', type=int, choices=range(-24, 7), default=6)
parser.add_argument('--mode', choices=('music24', 'musicclean', 'musicsteady', 'musicusb', 'mic'), default='musicusb')
parser.add_argument('--log', type=Path, required=True)
parser.add_argument('--stop-file', type=Path, required=True)
parser.add_argument('--restore-advertising', action='store_true')
parser.add_argument('--quiet-radio', action=argparse.BooleanOptionalAction, default=True)
parser.add_argument('--loops', type=int, default=1, help='default: one group; explicit 0 repeats until the stop file appears')
args = parser.parse_args()
if args.loops < 0:
    parser.error('--loops must be nonnegative')
if args.stop_file.exists():
    parser.error('Stop file already exists; use a fresh stop-file path.')
args.log.parent.mkdir(parents=True, exist_ok=True)
port = serial.Serial(port=None, baudrate=1000000, timeout=0.1, write_timeout=1)
port.dtr = False
port.rts = False
port.port = args.port
decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
lap = 0
board_rebooted = False
radio_owned = False
try:
    port.open()
    with args.log.open('w', encoding='utf-8', buffering=1) as log:
        # Drain old console output before watching a new playback command.
        deadline = time.monotonic() + 0.3
        while time.monotonic() < deadline:
            chunk = port.read(port.in_waiting or 1)
            if chunk:
                log.write(decoder.decode(chunk))
        if args.quiet_radio:
            status = console_command(
                port, decoder, log, 'velaride_ble radio-status',
                r'VELARIDE_BLE: ready=(\d+) connected=(\d+) adv_paused=(\d+)')
            ready, connected, paused = map(int, status.groups())
            if not ready or connected:
                raise RuntimeError('Quiet playback requires a ready, disconnected BLE adapter.')
            if not paused:
                result = console_command(
                    port, decoder, log, 'velaride_ble adv-off',
                    r'VELARIDE_BLE: advertising pause ret=(-?\d+)')
                if int(result.group(1)) != 0:
                    raise RuntimeError('BLE advertising could not be paused.')
                radio_owned = True
            print('Quiet-radio playback enabled.', flush=True)
        while not args.stop_file.exists() and (args.loops == 0 or lap < args.loops):
            lap += 1
            command = f'speaker_test 1 {args.gain} {args.mode}'
            log.write(f'\nHOST LAP {lap}: {command}\n')
            print(f'Playing lap {lap}, {args.mode}, {args.gain:+d} dB', flush=True)
            result = console_command(
                port, decoder, log, command,
                r'speaker_test: done, amplifier off, result=(-?\d+)', timeout=30)
            if int(result.group(1)) != 0:
                raise RuntimeError('Playback reported an error; see the serial log.')
            print(f'Lap {lap} completed normally.', flush=True)
            # NS4150B shutdown is specified at about 80 ms. Allow the
            # amplifier to finish shutting down before another startup.
            time.sleep(0.2)
        print('Playback finished and amplifier is off.', flush=True)
except BoardRebootError:
    board_rebooted = True
    raise
finally:
    if port.is_open:
        if (args.restore_advertising or radio_owned) and not board_rebooted:
            with args.log.open('a', encoding='utf-8') as log:
                log.write('\nHOST: restoring BLE advertising\n')
                try:
                    result = console_command(
                        port, decoder, log, 'velaride_ble adv-on',
                        r'VELARIDE_BLE: advertising restart ret=(-?\d+)')
                    print('BLE advertising restore result: ' + result.group(1), flush=True)
                except Exception as error:
                    print('BLE advertising restore failed: ' + str(error), flush=True)
        port.close()
