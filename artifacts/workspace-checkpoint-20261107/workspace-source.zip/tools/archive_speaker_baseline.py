"""Archive the current WSL source tree without claiming a reproducible rebuild.

Run in WSL. Git metadata and cmake_out are excluded; exact config/firmware,
build metadata and source inventory are saved separately. Existing output is
never overwritten. External symlinks are listed, not silently dereferenced.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile


def stream_sha(stream):
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(chunk)
    return digest.hexdigest()


def sha(path):
    with path.open('rb') as stream:
        return stream_sha(stream)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    output = args.output.resolve()
    if output.is_relative_to(source):
        parser.error('Archive destination must be outside the source tree')
    output.mkdir(parents=True, exist_ok=False)
    build = source / 'cmake_out/lckfb_huangshan_pi'
    expected = '23ea7b74e6f6aa4bbe9c2e9e925b034eed1ef1cf5a37fa255f2f105222068941'
    if sha(build / 'nuttx.bin') != expected:
        raise RuntimeError('Source tree does not contain the expected speaker-stage binary')
    for name in ('nuttx.bin', 'nuttx', '.config', 'CMakeCache.txt', 'build.ninja'):
        shutil.copy2(build / name, output / name)

    inventory = {}
    external = []
    git_heads = {}
    for directory, folders, files in os.walk(source, followlinks=False):
        base = Path(directory)
        if '.git' in folders or '.git' in files:
            proc = subprocess.run(['git', '-C', str(base), 'rev-parse', 'HEAD'],
                                  capture_output=True, text=True)
            git_heads[str(base.relative_to(source))] = proc.stdout.strip() if proc.returncode == 0 else None
        folders[:] = sorted(name for name in folders if name != '.git'
                            and not (base == source and name == 'cmake_out'))
        for name in sorted(folders + [f for f in files if f != '.git']):
            path = base / name
            relative = path.relative_to(source).as_posix()
            if path.is_symlink():
                target = os.readlink(path)
                resolved = path.resolve()
                outside = not resolved.is_relative_to(source)
                inventory[relative] = {'kind': 'symlink', 'target': target,
                                       'exists': path.exists(), 'outside_source': outside}
                if outside:
                    external.append({'path': relative, 'target': target, 'resolved': str(resolved),
                                     'exists': path.exists()})
            elif path.is_file():
                inventory[relative] = {'kind': 'file', 'bytes': path.stat().st_size, 'sha256': sha(path)}
        if len(inventory) and len(inventory) % 10000 < 10:
            print(f'Inventory: {len(inventory)} entries', flush=True)

    (output / 'source-inventory.json').write_text(json.dumps(inventory, indent=2), encoding='utf-8')
    archive = output / 'source.tar.gz'
    print(f'Archiving {len(inventory)} entries', flush=True)
    with tarfile.open(archive, 'w:gz', compresslevel=1, dereference=False) as tar:
        for relative in sorted(inventory):
            tar.add(source / relative, arcname='source/' + relative, recursive=False)
    # Verify payload hashes from the archive itself, including symlink targets.
    verified = 0
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            relative = member.name.removeprefix('source/')
            record = inventory[relative]
            if member.issym():
                if member.linkname != record['target']:
                    raise RuntimeError(f'Symlink mismatch: {relative}')
            elif member.isfile() or member.islnk():
                with tar.extractfile(member) as stream:
                    if stream_sha(stream) != record['sha256']:
                        raise RuntimeError(f'Archived file mismatch: {relative}')
            else:
                raise RuntimeError(f'Unexpected archive member: {relative}')
            verified += 1
    if verified != len(inventory):
        raise RuntimeError('Archive inventory incomplete')
    manifest = {
        'created_at': datetime.now(timezone.utc).isoformat(), 'source': str(source),
        'status': 'Verified archive of current source tree; clean rebuild not yet verified',
        'firmware_sha256': expected, 'source_entries': len(inventory),
        'source_bytes': sum(r.get('bytes', 0) for r in inventory.values()),
        'archive_payloads_verified': verified, 'git_heads': git_heads,
        'exclusions': ['.git metadata', 'cmake_out (selected build files saved separately)'],
        'external_symlinks': external,
        'limitations': ['Toolchain and host packages are external and not archived.',
                        'External symlink targets are not included.',
                        'This archive is not evidence of a clean or bit-identical rebuild.',
                        'Hardware acceptance is recorded separately in expansion-20261027.'],
        'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                  for p in sorted(output.iterdir()) if p.is_file()}}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps({'archive': str(archive), 'entries': verified,
                      'external_symlinks': len(external), 'archive_bytes': archive.stat().st_size}), flush=True)


if __name__ == '__main__':
    main()
