#!/usr/bin/env bash
# 探查思澈官方黄山派表盘示例的结构，评估可借鉴部分
W=/home/wyj/sifli_hspi/lvgl/watch

echo "=== watch 目录树（前两层）==="
find "$W" -maxdepth 2 | head -30

echo
echo "=== 源文件 ==="
find "$W" -name '*.c' -o -name '*.h' | head -20

echo
echo "=== 图片/字体资源 ==="
find "$W" \( -name '*.png' -o -name '*.bin' -o -name '*.ttf' \) | head -10

echo
echo "=== README ==="
find "$W" -iname 'README*' -exec head -30 {} \;

echo
echo "=== 是否用到 EPIC / 硬件加速 ==="
grep -rl 'EPIC\|epic' "$W" 2>/dev/null | head -5

echo
echo "=== 用到的 LVGL 动画 API ==="
grep -rho 'lv_anim_[a-z_]*' "$W" 2>/dev/null | sort -u | head -15
