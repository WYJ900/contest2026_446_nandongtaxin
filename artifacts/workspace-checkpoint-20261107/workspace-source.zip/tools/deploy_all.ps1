﻿# 快应用一键部署：打包 → 进 romfs → 同步 WSL → 编译固件 → 烧录
#
# 改完 vela-quickapp/src 下的 .ux 后跑这一条就行，全程约 3 分钟。
#
# 用法：
#   .\tools\deploy_all.ps1                    # 完整流程
#   .\tools\deploy_all.ps1 -SkipFlash         # 只编译不烧录
#   .\tools\deploy_all.ps1 -Port COM5         # 指定串口
#
# 注意：烧录前需在串口工具（EK-OmniProbe 等）里断开 COM5，端口是独占的。

param(
    [string]$Port = "COM5",
    [switch]$SkipFlash,
    [switch]$Reset          # 烧录后 RTS 复位并打印启动日志
)

$ErrorActionPreference = "Stop"
$Root = "D:\desktop\VelaRide_AI"
$WslRoot = "/mnt/d/desktop/VelaRide_AI"
$sw = [System.Diagnostics.Stopwatch]::StartNew()

function Step($n, $msg) {
    Write-Host ""
    Write-Host "[$n/5] $msg" -ForegroundColor Cyan
}

# 1. 打包：必须用 aiot-toolkit，hap-toolkit 产出的模块格式 vapp 加载不了
Step 1 "打包快应用（aiot build）"
Push-Location "$Root\vela-quickapp"
try {
    $out = & npx aiot build 2>&1
    $ok = $out | Select-String -Pattern "build success" -Quiet
    if (-not $ok) {
        $out | Select-Object -Last 15 | ForEach-Object { Write-Host $_ }
        throw "打包失败"
    }
    $out | Select-String -Pattern "generate files|build success" | ForEach-Object { Write-Host "  $_" }
}
finally { Pop-Location }

# 2. 解包进 romfs（设备 /etc 是只读 romfs，应用必须随固件烧录）
Step 2 "部署到 romfs"
& "$Root\tools\deploy_quickapp.ps1" | Select-String -Pattern "源包|app.js|完成" | ForEach-Object { Write-Host "  $_" }

# 3. 同步到 WSL —— 编译在 WSL 侧进行，不同步就会编出旧固件
Step 3 "同步板级目录到 WSL"
$sync = & wsl.exe -d Ubuntu-22.04 -- bash -c "bash $WslRoot/tools/wsl_sync_board.sh" 2>&1
$sync | Select-String -Pattern "vapp hap|com\." | ForEach-Object { Write-Host "  $_" }

# 4. 编译固件
Step 4 "编译固件"
$build = & wsl.exe -d Ubuntu-22.04 -- bash -c "bash $WslRoot/tools/wsl_build.sh 2>&1 | tail -20"
$failed = $build | Select-String -Pattern "FAILED|Error:"
if ($failed) {
    $build | Select-Object -Last 20 | ForEach-Object { Write-Host $_ }
    throw "编译失败"
}
$build | Select-String -Pattern "real|nuttx.bin" | ForEach-Object { Write-Host "  $_" }

# 5. 烧录
if ($SkipFlash) {
    Step 5 "跳过烧录（-SkipFlash）"
} else {
    Step 5 "烧录到 $Port"
    & "$Root\tools\flash.ps1" -Port $Port | Select-String -Pattern "固件大小|烧录完成" | ForEach-Object { Write-Host "  $_" }

    if ($Reset) {
        Write-Host ""
        Write-Host "=== 复位并捕获启动日志 ===" -ForegroundColor Cyan
        Start-Sleep -Seconds 2
        & "$Root\tools\reset.ps1" -Port $Port -Capture 15
    }
}

$sw.Stop()
Write-Host ""
Write-Host "完成，耗时 $([math]::Round($sw.Elapsed.TotalSeconds,1)) 秒" -ForegroundColor Green
