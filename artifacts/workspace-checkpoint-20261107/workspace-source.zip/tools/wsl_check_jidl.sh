#!/usr/bin/env bash
# 检查 jidl 生成产物是否完整
#
# jidl_gen_cpp 遇到 CRLF 会词法失败但仍返回退出码 0，留下 0 字节头文件，
# 最终表现是 feature 注册不上（运行时报 can not find feature: xxx）。
GEN=/home/wyj/velaride_ai/cmake_out/lckfb_huangshan_pi/jidl_generated/jidl
SRC=/home/wyj/velaride_ai/apps/frameworks/runtimes/feature/modules/jidl

echo "=== 源 .jidl 文件（行尾格式）==="
for f in "$SRC"/*.jidl; do
  [ -f "$f" ] || continue
  if grep -qU $'\r' "$f" 2>/dev/null; then
    printf '  %-24s CRLF ⚠\n' "$(basename "$f")"
  else
    printf '  %-24s LF\n' "$(basename "$f")"
  fi
done

echo
echo "=== 生成产物（0 字节 = 生成失败）==="
empty=0
for f in "$GEN"/*.h; do
  [ -f "$f" ] || continue
  sz=$(stat -c%s "$f")
  if [ "$sz" -eq 0 ]; then
    printf '  %-28s 0 字节 ⚠\n' "$(basename "$f")"
    empty=$((empty + 1))
  else
    printf '  %-28s %s\n' "$(basename "$f")" "$sz"
  fi
done
echo "  —— 空文件 $empty 个"

echo
echo "=== router / velaclaw 是否在注册表里 ==="
for n in router velaclaw app file; do
  if grep -qi "$n" "$GEN/../features_registry_list.h" 2>/dev/null; then
    printf '  %-10s 在注册表\n' "$n"
  else
    printf '  %-10s 不在注册表 ⚠\n' "$n"
  fi
done
