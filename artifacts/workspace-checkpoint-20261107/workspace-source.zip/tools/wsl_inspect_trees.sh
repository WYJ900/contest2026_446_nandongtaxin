#!/bin/bash
cd /home/wyj
for t in velaride_ride_gps_stage velaride_safety_stage; do
  echo "== $t"; ls "$t"
  find "$t/cmake_out" -maxdepth 3 -name nuttx.bin -exec sha256sum {} \; 2>/dev/null
done
echo "== non-app diff (names only)"
diff -rq --exclude=cmake_out --exclude=.git --exclude=velaride velaride_ride_gps_stage velaride_safety_stage 2>/dev/null | head -30
