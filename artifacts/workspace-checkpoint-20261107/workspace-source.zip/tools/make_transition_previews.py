#!/usr/bin/env python3
"""Generate low-cost RGB565 transition previews for all VelaRide scenes."""

from math import cos, pi, sin
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "apps" / "examples" / "velaride"
PREVIEW_DIR = OUT_DIR / "transition_previews"
INCLUDE = OUT_DIR / "velaride_transition_previews.inc"
W, H = 390, 450

COLORS = [
    0x071827, 0x111827, 0x111827, 0x000000,
    0x08271C, 0x2B190B, 0x21102F,
]


def rgb(color: int) -> tuple[int, int, int]:
    return ((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF)


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    name = "arialbd.ttf" if bold else "arial.ttf"
    path = Path(r"C:\Windows\Fonts") / name
    return ImageFont.truetype(str(path), size)


def centered(draw: ImageDraw.ImageDraw, y: int, text: str, fill, size: int,
             bold: bool = False) -> None:
    fnt = font(size, bold)
    box = draw.textbbox((0, 0), text, font=fnt)
    draw.text(((W - (box[2] - box[0])) / 2, y), text, font=fnt, fill=fill)


def hand(draw: ImageDraw.ImageDraw, angle: float, length: int, fill, width: int) -> None:
    cx, cy = W // 2, H // 2
    rad = angle * pi / 180
    end = (cx + sin(rad) * length, cy - cos(rad) * length)
    draw.line((cx, cy, *end), fill=fill, width=width)


def digital() -> Image.Image:
    image = Image.new("RGB", (W, H), rgb(COLORS[0]))
    draw = ImageDraw.Draw(image)
    centered(draw, 75, "VELARIDE", (56, 189, 248), 20, True)
    centered(draw, 126, "10:09", "white", 52, True)
    centered(draw, 205, "RIDE SAFETY", (100, 116, 139), 16)
    centered(draw, 265, "12.5 km     45 min     180 kcal", (203, 213, 225), 15)
    centered(draw, 365, "swipe left / up", (71, 85, 105), 15)
    return image


def simple() -> Image.Image:
    image = Image.new("RGB", (W, H), rgb(COLORS[1]))
    draw = ImageDraw.Draw(image)
    centered(draw, 45, "SIMPLE", (148, 163, 184), 16)
    cx, cy = W // 2, H // 2
    draw.ellipse((cx - 152, cy - 152, cx + 152, cy + 152),
                 outline="white", width=2)
    for i in range(12):
        angle = i * 30 * pi / 180
        x = cx + sin(angle) * 142
        y = cy - cos(angle) * 142
        radius = 4 if i % 3 == 0 else 2
        draw.ellipse((x - radius, y - radius, x + radius, y + radius),
                     fill="white" if i % 3 == 0 else (100, 116, 139))
    hand(draw, 305, 82, (226, 232, 240), 8)
    hand(draw, 54, 118, (56, 189, 248), 5)
    hand(draw, 210, 132, (244, 63, 94), 2)
    centered(draw, 375, "SiFli simple style", (100, 116, 139), 15)
    return image


def dial() -> Image.Image:
    image = Image.new("RGB", (W, H), rgb(COLORS[2]))
    dial_image = Image.open(OUT_DIR / "velaride_dial_390.png").convert("RGB")
    image.paste(dial_image, (0, 30))
    draw = ImageDraw.Draw(image)
    hand(draw, 305, 82, (17, 24, 39), 8)
    hand(draw, 54, 118, (3, 105, 161), 5)
    hand(draw, 210, 132, (244, 63, 94), 2)
    centered(draw, 405, "SiFli dial / VelaRide", (254, 243, 199), 15)
    return image


def numeral() -> Image.Image:
    image = Image.new("RGB", (W, H), "black")
    draw = ImageDraw.Draw(image)
    cx, cy = W // 2, H // 2
    for i in range(60):
        angle = i * 6 * pi / 180
        r1 = 169 if i % 5 == 0 else 174
        r2 = 181
        draw.line((cx + sin(angle) * r1, cy - cos(angle) * r1,
                   cx + sin(angle) * r2, cy - cos(angle) * r2),
                  fill=(156, 163, 175) if i % 5 == 0 else (75, 85, 99),
                  width=4 if i % 5 == 0 else 2)
    for i, text in enumerate(["12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"]):
        angle = i * 30 * pi / 180
        x = cx + sin(angle) * 132
        y = cy - cos(angle) * 132
        fnt = font(48)
        box = draw.textbbox((0, 0), text, font=fnt)
        draw.text((x - (box[2] - box[0]) / 2, y - (box[3] - box[1]) / 2),
                  text, font=fnt, fill="white")
    hand(draw, 305, 82, "white", 12)
    hand(draw, 54, 118, "white", 9)
    hand(draw, 210, 150, (255, 159, 10), 3)
    return image


def feature(scene: int) -> Image.Image:
    image = Image.new("RGB", (W, H), rgb(COLORS[scene]))
    draw = ImageDraw.Draw(image)
    if scene == 4:
        centered(draw, 65, "RIDING", (74, 222, 128), 20, True)
        centered(draw, 125, "00:00:00", "white", 46, True)
        centered(draw, 225, "18.6 km/h        4.2 km", (203, 213, 225), 19)
        centered(draw, 365, "swipe down to watchface", (100, 116, 139), 15)
    elif scene == 5:
        centered(draw, 65, "!", (251, 191, 36), 50, True)
        centered(draw, 155, "SAFETY", (251, 191, 36), 20, True)
        centered(draw, 225, "Take a 5 min break", (254, 243, 199), 24)
        centered(draw, 300, "riding 40 min", (148, 163, 184), 16)
    else:
        centered(draw, 70, "AI REVIEW", (192, 132, 252), 20, True)
        centered(draw, 155, "Steady pace this session.", (226, 232, 240), 19)
        centered(draw, 190, "Rest every 40 minutes.", (226, 232, 240), 19)
        centered(draw, 350, "swipe down to return", (100, 116, 139), 15)
    return image


def main() -> None:
    PREVIEW_DIR.mkdir(exist_ok=True)
    scenes = [digital(), simple(), dial(), numeral(), feature(4), feature(5), feature(6)]
    data = bytearray()
    for index, image in enumerate(scenes):
        image.save(PREVIEW_DIR / f"scene_{index}.png")
        for red, green, blue in image.getdata():
            value = ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3)
            data.extend((value & 0xFF, value >> 8))

    with INCLUDE.open("w", encoding="ascii", newline="\n") as output:
        output.write("/* Generated by tools/make_transition_previews.py. */\n\n")
        output.write("static const unsigned char velaride_transition_previews[] = {\n")
        for offset in range(0, len(data), 16):
            values = ", ".join(f"0x{byte:02x}" for byte in data[offset:offset + 16])
            output.write(f"  {values},\n")
        output.write("};\n")
        output.write(f"static const unsigned int velaride_transition_previews_len = {len(data)};\n")

    print(f"scenes={len(scenes)} raw_bytes={len(data)} include={INCLUDE.stat().st_size}")


if __name__ == "__main__":
    main()
