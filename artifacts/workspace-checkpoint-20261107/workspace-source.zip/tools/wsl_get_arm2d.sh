#!/usr/bin/env bash
# 在 WSL 侧拉取 Arm-2D 到 ext4（编译也在 WSL，避免跨 9p 的慢速与句柄占用）
#
# Arm-2D 是 LVGL 的 LV_USE_DRAW_ARM2D_SYNC 后端所需的库。
# external/Arm-2D/ 在本仓库里只有一个 .gitignore 占位（repo manifest 没管它），
# 所以要自己拉。Kconfig 要求："Must deploy arm-2d library to your project
# and add include PATH for arm_2d.h"
set -eu

DEST=/home/wyj/arm2d

if [ -d "$DEST/.git" ] && git -C "$DEST" rev-parse HEAD >/dev/null 2>&1; then
  echo "已存在且完整：$(git -C "$DEST" log --oneline -1)"
else
  rm -rf "$DEST"
  echo "=== 克隆 Arm-2D ==="
  git clone --depth 1 https://github.com/ARM-software/Arm-2D.git "$DEST"
fi

echo
echo "=== 顶层结构 ==="
ls "$DEST"

echo
echo "=== arm_2d.h 位置 ==="
find "$DEST" -name 'arm_2d.h' | head -3

echo
echo "=== 源文件数 ==="
find "$DEST" -name '*.c' | wc -l
