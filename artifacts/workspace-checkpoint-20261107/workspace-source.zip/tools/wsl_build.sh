#!/usr/bin/env bash
# WSL 侧固件编译脚本（在 ext4 原生路径上编译，避免 9p 文件系统 I/O 瓶颈）
#
# 用法：
#   bash wsl_build.sh            # 增量编译
#   bash wsl_build.sh clean      # 清理后重新配置编译
set -eu

ROOT=/home/wyj/velaride_ai
# 用绝对路径：相对路径会被 CMake 当成相对 nuttx/ 解析而找不到
BOARD_CONFIG="$ROOT/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh"
OUT="$ROOT/cmake_out/lckfb_huangshan_pi"
JOBS=$(nproc)

# kconfiglib 的 olddefconfig 等脚本装在 ~/.local/bin，非登录 shell 的 PATH 里没有
export PATH="$HOME/.local/bin:$PATH"

# 必须用 GCC 13：apt 自带的 10.3 不支持 libcxx 依赖的 __builtin_bit_cast
# 等内建，编译会在 libcxx 头文件里大量报错
TOOLCHAIN=/opt/arm-gnu-toolchain/bin
if [ ! -x "$TOOLCHAIN/arm-none-eabi-gcc" ]; then
  echo "缺少 GCC 13 工具链，请先执行：bash wsl_toolchain.sh" >&2
  exit 1
fi
export PATH="$TOOLCHAIN:$PATH"

cd "$ROOT"

if [ "${1:-}" = "clean" ]; then
  echo "=== 清理旧构建产物 ==="
  rm -rf "$OUT"
fi

# 缺少 ninja 文件或活动配置更新时重新配置，避免沿用旧的 config.h。
# 板级 defconfig 存在依赖缺口：CONFIG_UTILS_CURL=y，而 curl 的 Kconfig 声明
# depends on CRYPTO_MBEDTLS，但后者 default n 且无人 select，结果 curl 参与编译
# 却找不到 mbedtls/des.h。在 cmake 配置前补进 defconfig，让 kconfig 自行解析依赖。
if ! grep -q '^CONFIG_CRYPTO_MBEDTLS=y' "$BOARD_CONFIG/defconfig"; then
  echo "=== 补齐 CONFIG_CRYPTO_MBEDTLS（curl 的未满足依赖）==="
  echo 'CONFIG_CRYPTO_MBEDTLS=y' >> "$BOARD_CONFIG/defconfig"
fi

# 快应用运行时必需：vapp 启动时 ImageCacheManager 初始化会让 curl 建 socketpair
# （bind → listen → connect → accept 走 TCP loopback），NuttX 的 accept() 依赖
# backlog 支持，没有它就永久阻塞在 accept4，JS 引擎根本起不来 → 屏幕全黑，
# 且日志里看不到任何 [FEATURE]/[AIOTJS] 输出。板级 defconfig 漏了这项。
if ! grep -q '^CONFIG_NET_TCPBACKLOG=y' "$BOARD_CONFIG/defconfig"; then
  echo "=== 启用 CONFIG_NET_TCPBACKLOG（vapp 的未满足依赖）==="
  echo 'CONFIG_NET_TCPBACKLOG=y' >> "$BOARD_CONFIG/defconfig"
fi

# LVGL 的 POSIX 文件系统驱动：不开的话快应用里所有图片都读不了，报
#   lv_fs_open: Can't open file (/etc/data/app/xxx.png): unknown driver letter
# LETTER=47 是 '/' 的 ASCII，这样 /etc/... 这种绝对路径能直接当盘符路径识别。
# 取值抄自两块已跑通快应用的参考板：
#   packages/ai_agent/defconfigs/{goldfish-arm64-v8a-ap,gemini-s1}/*_defconfig
if ! grep -q '^CONFIG_LV_USE_FS_POSIX=y' "$BOARD_CONFIG/defconfig"; then
  echo "=== 启用 LVGL POSIX 文件系统（快应用图片加载）==="
  {
    echo 'CONFIG_LV_USE_FS_POSIX=y'
    echo 'CONFIG_LV_FS_POSIX_LETTER=47'
    echo 'CONFIG_LV_FS_POSIX_PATH="/"'
  } >> "$BOARD_CONFIG/defconfig"
fi

# 图形性能调优。板级 defconfig 的默认值明显偏保守，下面取值对齐两块参考板
# （gemini-s1 / goldfish-arm64-v8a-ap，都是跑通快应用的官方配置）：
#   LV_DEF_REFR_PERIOD   33 → 16   刷新周期，33ms 把帧率锁在 ~30fps，16ms 才够 60fps
#   LV_CACHE_DEF_SIZE     0 → 1MB  图像/数据缓存，为 0 时每帧都要重新解码
# 注 1：参考板的 LV_DRAW_SW_ASM_NEON 不能抄，NEON 是 Cortex-A 专用；本板是
#   Cortex-M33（armv8-m.main），既无 NEON 也无 MVE/Helium（那要 M55/M85），
#   所以 LVGL 没有可用的汇编后端，只能靠这些参数和缓存优化。
# 注 2：两个缓冲对齐值（LV_DRAW_BUF_ALIGN / STRIDE_ALIGN）保持原样不动，试过都会崩：
#   · LCD 驱动给出的 framebuffer 地址不固定，随之前的内存分配漂移
#     （改 MQ_MAXMSGSIZE 就从 0x60055b30 变成了 0x60075b38，前者 16 字节对齐、
#     后者只有 8 字节对齐），设 16/64 都会随机断言
#     `buf1 == lv_draw_buf_align(buf1, cf)  buf1 is not aligned`
#   · stride 也有上限：屏幕 390×450 RGB565，stride = 390×2 = 780 = 2²×3×5×13，
#     不能被 8/16 整除。设 16 会把 stride 上取整到 784，784×450 = 352800
#     超过 framebuffer 的 351000 字节，断言
#     `stride * h <= buf_size  FULL mode requires screen sized buffer(s)`
#   对齐带来的收益远小于刷新周期，不值得为它冒随机崩溃的风险。
if ! grep -q '^CONFIG_LV_DEF_REFR_PERIOD=16' "$BOARD_CONFIG/defconfig"; then
  echo "=== 图形性能调优（刷新周期 / 缓存）==="
  sed -i '/^CONFIG_LV_DEF_REFR_PERIOD=/d;
          /^CONFIG_LV_CACHE_DEF_SIZE=/d' "$BOARD_CONFIG/defconfig"
  {
    echo 'CONFIG_LV_DEF_REFR_PERIOD=16'
    echo 'CONFIG_LV_CACHE_DEF_SIZE=1048576'
  } >> "$BOARD_CONFIG/defconfig"
fi

# 圆角抗锯齿缓存。默认只缓存 4 个圆，而本项目 UI 里有 6 种不同的 border-radius
# 半径（12/3/10/4/20/16px，共 18 处），缓存不够就会反复重算 1/4 圆周的抗锯齿数据。
# 每个圆占 radius*4 字节，即使按最大 20px 算，16 个也只多几百字节。
# 注：没配阴影缓存（LV_DRAW_SW_SHADOW_CACHE_SIZE）——本项目 CSS 里没用 box-shadow，
# 配了纯属浪费内存。
if ! grep -q '^CONFIG_LV_DRAW_SW_CIRCLE_CACHE_SIZE=16' "$BOARD_CONFIG/defconfig"; then
  echo "=== 放大圆角抗锯齿缓存（UI 有 6 种圆角半径）==="
  sed -i '/^CONFIG_LV_DRAW_SW_CIRCLE_CACHE_SIZE=/d' "$BOARD_CONFIG/defconfig"
  echo 'CONFIG_LV_DRAW_SW_CIRCLE_CACHE_SIZE=16' >> "$BOARD_CONFIG/defconfig"
fi

# velaclaw / ai_agent 必需：bridge 线程 mq_open 的消息体远大于默认的 32 字节，
# 会在 nxmq_alloc_msgq 直接断言崩溃（断言是 attr->mq_msgsize <= MQ_MAX_BYTES，
# 而 MQ_MAX_BYTES 就是 CONFIG_MQ_MAXMSGSIZE）：
#   Assertion failed at /sched/mqueue/mq_msgqalloc.c:76 task: vapp
#   nxmq_alloc_msgq → file_mq_vopen → mq_open → bridge_recv_thread
# 4096 不是随便取的：velaclaw 源码里硬编码了这个尺寸，必须 ≥ 它
#   packages/ai_agent/src/quickapp/velaclaw_quickapp_bridge.c:44
#   packages/ai_agent/src/agent_main.c:218
#     #define VELACLAW_MQ_MSG_SIZE  4096
# goldfish 参考板用的也正是 4096（gemini-s1 的 1024 不够，别抄）。
if ! grep -q '^CONFIG_MQ_MAXMSGSIZE=4096' "$BOARD_CONFIG/defconfig"; then
  echo "=== 放大 CONFIG_MQ_MAXMSGSIZE 到 4096（velaclaw 硬编码要求）==="
  sed -i '/^CONFIG_MQ_MAXMSGSIZE=/d' "$BOARD_CONFIG/defconfig"
  echo 'CONFIG_MQ_MAXMSGSIZE=4096' >> "$BOARD_CONFIG/defconfig"
fi

if [ ! -f "$OUT/build.ninja" ] ||
   [ "$OUT/.config" -nt "$OUT/include/nuttx/config.h" ]; then
  echo "=== CMake 配置 ==="
  # NuttX's CMake menuconfig target invalidates this generated header.
  # Do the same for command-line .config edits, otherwise an incremental
  # build can silently keep the previous graphics/backend configuration.
  if [ -f "$OUT/build.ninja" ]; then
    rm -f "$OUT/include/nuttx/config.h"
  fi
  cmake -B "$OUT" -S nuttx -GNinja \
    -DBOARD_CONFIG="$BOARD_CONFIG" \
    -DEXTRA_FLAGS="-Wno-cpp -Wno-deprecated-declarations"
fi

echo "=== 编译（-j$JOBS）==="
time cmake --build "$OUT" -- -j"$JOBS"

echo "=== 产物 ==="
ls -lh "$OUT"/nuttx.bin "$OUT"/nuttx 2>/dev/null || true

# 黄山派配置分区的 Flash 绝对地址为 0x129a0000，应用镜像从
# 0x12010000 开始，因此 nuttx.bin 的最大长度只能是 0x990000。
# 日常 sftool 只写镜像实际长度；一旦超过这个上限就会覆盖骑行记录。
CONFIG_PARTITION_OFFSET=$((0x990000))
if [ -f "$OUT/nuttx.bin" ]; then
  FW_SIZE=$(stat -c %s "$OUT/nuttx.bin")
  if [ "$FW_SIZE" -ge "$CONFIG_PARTITION_OFFSET" ]; then
    echo "ERROR: nuttx.bin=$FW_SIZE bytes overlaps config partition at 0x129a0000" >&2
    exit 1
  fi
  echo "=== Flash 安全边界 ==="
  echo "固件 $FW_SIZE B，配置区偏移 $CONFIG_PARTITION_OFFSET B，余量 $((CONFIG_PARTITION_OFFSET - FW_SIZE)) B"
fi
