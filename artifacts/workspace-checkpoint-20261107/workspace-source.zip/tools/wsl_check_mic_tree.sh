#!/usr/bin/env bash
set -euo pipefail
B=/home/wyj/velaride_rc17_baseline/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/src
S=/home/wyj/velaride_microphone_stage/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/src
sha256sum "$S/mic_test.c" "$S/audio_test.h" "$S/audio_test_lock.c" | cut -c1-16
diff "$B/CMakeLists.txt" "$S/CMakeLists.txt" || true
grep -n touch_probe "$S/CMakeLists.txt" || echo "touch_probe not registered"
grep -n "^CONFIG_INPUT_FT6146\|^CONFIG_EXAMPLES_VELARIDE=" /home/wyj/velaride_microphone_stage/cmake_out/lckfb_huangshan_pi/.config
