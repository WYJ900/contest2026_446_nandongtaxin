﻿param([string[]]$Only = @())
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$voiceOutput = Join-Path (Split-Path $PSScriptRoot -Parent) 'build/stages/sound/assets'
New-Item -ItemType Directory -Force $voiceOutput | Out-Null
$voiceSynth = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $voiceSynth.SelectVoice('Microsoft Huihui Desktop')
    $voiceSynth.Rate = 1
    $voiceSynth.Volume = 100
    $voiceFormat = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(16000,
        [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,
        [System.Speech.AudioFormat.AudioChannel]::Mono)
    $voicePrompts = [ordered]@{
        ride_mode = '进入骑行模式'
        three = '三'
        two = '二'
        one = '一'
        go = '开始'
        alarm_mode = '闹钟'
        countdown_mode = '倒计时'
        stopwatch_mode = '秒表'
    }
    foreach ($voiceName in $voicePrompts.Keys) {
        if ($Only.Count -gt 0 -and $voiceName -notin $Only) { continue }
        $voiceSynth.SetOutputToWaveFile((Join-Path $voiceOutput ($voiceName + '.wav')), $voiceFormat)
        $voiceSynth.Speak($voicePrompts[$voiceName])
        $voiceSynth.SetOutputToNull()
    }
    $voicePrompts | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $voiceOutput 'prompts.json')
} finally { $voiceSynth.Dispose() }
