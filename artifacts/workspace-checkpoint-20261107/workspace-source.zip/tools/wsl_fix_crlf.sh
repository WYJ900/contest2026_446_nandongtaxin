#!/usr/bin/env bash
# 批量修复 Windows 检出带来的 CRLF 行尾
#
# 影响面比想象的大：
# - 带 shebang 的 perl/python/shell 脚本：内核解析 shebang 时把 \r 当成解释器名
#   的一部分，报 "perl\r: No such file or directory"；
# - .jidl 接口定义文件：jidl_gen_cpp 词法分析在 \r 上失败，但退出码仍是 0，
#   于是 ninja 认为生成成功，留下 0 字节头文件，最终在编译期报大量
#   "xxx has not been declared"，很难反查到根因。
set -eu

DEST=/home/wyj/velaride_ai

echo "=== 修复 CRLF ==="
fixed=0
while IFS= read -r f; do
  if grep -qU $'\r' "$f" 2>/dev/null; then
    sed -i 's/\r$//' "$f"
    fixed=$((fixed + 1))
  fi
done < <(find "$DEST/apps" "$DEST/external" "$DEST/nuttx" "$DEST/frameworks" \
              "$DEST/packages" "$DEST/vendor" \
           -type f \( -name '*.jidl' -o -name '*.pl' -o -name '*.py' \
                      -o -name '*.sh' -o -name '*.cmake' \) 2>/dev/null)
echo "    修复 $fixed 个文件"

echo "=== 验证 jidl 可解析 ==="
cd "$DEST/apps/frameworks/runtimes/feature/modules"
# jidl_gen_cpp 不会自建输出目录，必须先建好
rm -rf /tmp/jidlcheck && mkdir -p /tmp/jidlcheck
if "$DEST/prebuilts/tools/rust/bin/jidl/jidl_gen_cpp" jidl/cipher.jidl \
     --out-dir /tmp/jidlcheck --header c.h --source c.cpp 2>/dev/null \
   && [ -s /tmp/jidlcheck/c.h ]; then
  echo "    OK（生成 $(wc -l < /tmp/jidlcheck/c.h) 行）"
  rm -rf /tmp/jidlcheck
else
  echo "    仍然失败" >&2
  exit 1
fi
