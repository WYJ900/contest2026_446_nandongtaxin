#!/usr/bin/env bash
# Re-resolve a display configuration change before rebuilding the test image.
set -euo pipefail
project_root=/home/wyj/velaride_ai
output_dir="$project_root/cmake_out/lckfb_huangshan_pi"
export PATH="/opt/arm-gnu-toolchain/bin:/home/wyj/.local/bin:$PATH"
export KCONFIG_CONFIG="$output_dir/.config"
export APPSDIR="$project_root/apps"
export APPSBINDIR="$output_dir/apps"
export BINDIR="$output_dir"
export EXTERNALDIR=dummy
export DRIVERS_PLATFORM_DIR=dummy
cd "$project_root/nuttx"
olddefconfig
# CMake's menuconfig target also invalidates this generated header.
rm -f "$output_dir/include/nuttx/config.h"
cmake -S "$project_root/nuttx" -B "$output_dir" -GNinja
bash /mnt/d/desktop/VelaRide_AI/tools/wsl_build.sh
