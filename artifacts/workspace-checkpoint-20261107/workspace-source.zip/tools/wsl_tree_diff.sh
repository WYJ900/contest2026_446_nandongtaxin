#!/bin/bash
cd /home/wyj
for t in velaride_product_features; do
 echo "== safety_stage vs $t (non-app)"
 diff -rq --exclude=cmake_out --exclude=.git --exclude=velaride --exclude='*.orig' velaride_safety_stage $t 2>/dev/null | head -40
done
