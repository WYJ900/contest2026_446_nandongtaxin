#!/usr/bin/env bash
# 一键初始化 WSL 编译环境（幂等，可重复执行）
#
# 把 Windows 侧源码搬到 WSL 原生 ext4 并修好所有 Windows 检出遗留问题。
# 各步骤的具体原因见对应子脚本注释，以及 docs/BUILD_FLASH.md。
set -eu

TOOLS=$(cd "$(dirname "$0")" && pwd)

step() {
  echo
  echo "############################################################"
  echo "# $1"
  echo "############################################################"
}

step "1/7 安装 GCC 13 工具链"
bash "$TOOLS/wsl_toolchain.sh"

step "2/7 同步核心目录（nuttx/apps/vendor/build/packages/frameworks）"
bash "$TOOLS/wsl_sync.sh"

step "3/7 同步 external 下实际用到的第三方库"
bash "$TOOLS/wsl_sync_external.sh"

step "4/7 修复符号链接并补齐 external 根构建文件"
bash "$TOOLS/wsl_fixlinks.sh"

step "5/7 补齐 prebuilts 工具（jidl_gen_cpp）"
bash "$TOOLS/wsl_fix_env.sh"

step "6/7 修复 CRLF 行尾"
bash "$TOOLS/wsl_fix_crlf.sh"

step "7/7 检查并同步 LFS 预编译库"
bash "$TOOLS/wsl_check_lfs.sh"

echo
echo "############################################################"
echo "# 初始化完成，接下来执行编译："
echo "#   bash $TOOLS/wsl_build.sh"
echo "############################################################"
