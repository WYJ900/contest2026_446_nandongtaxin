#!/usr/bin/env bash
# 探查 Arm-2D 的构建要求：核心源文件、include 路径、配置头
SRC=/home/wyj/arm2d

echo "=== Library 结构 ==="
find "$SRC/Library" -maxdepth 2 -type d

echo
echo "=== 核心 .c（Library/Source）==="
ls "$SRC/Library/Source"/*.c 2>/dev/null | xargs -r -n1 basename

echo
echo "=== Helper 里的 .c ==="
find "$SRC/Helper" -name '*.c' | head -15

echo
echo "=== 配置头模板 ==="
find "$SRC" -name 'arm_2d_cfg.h' -o -name 'arm_2d_user_cfg*' | head -5

echo
echo "=== 是否有 arm_2d_helper_swap_rgb16（LVGL 适配层要用）==="
grep -rl 'arm_2d_helper_swap_rgb16' "$SRC/Helper" "$SRC/Library" 2>/dev/null | head -3

echo
echo "=== CMSIS 依赖（M33 需要 core_cm33.h 之类）==="
grep -rn '#include "cmsis_compiler.h"\|#include "arm_compat.h"\|core_cm' "$SRC/Library/Include/arm_2d.h" 2>/dev/null | head -5
grep -rn 'cmsis' "$SRC/CMakeLists.txt" 2>/dev/null | head -5
