"""Freeze the accepted pre-audio firmware and its reconstructed source overlay."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'my-contest-repo/artifacts/rc17-baseline-20261026'
OUT.mkdir(parents=True, exist_ok=True)
if (OUT / 'manifest.json').exists():
    raise SystemExit('This baseline is already frozen; do not overwrite it. Use a new destination for a new baseline.')


def sha(data):
    return hashlib.sha256(data).hexdigest()


firmware = (ROOT / 'backup/speaker-20261020/rc17-before-speaker.bin').read_bytes()
assert sha(firmware) == 'b04d766146ac6c9b9dda8c7a9e276afdf7e007d5f49b8dba4adfcb7a51c1d81d'
(OUT / 'firmware.bin').write_bytes(firmware)
config = (ROOT / 'build/migrate/out/mig75_rc17.config').read_bytes()
(OUT / 'config').write_bytes(config)

app = {}
with tarfile.open(ROOT / 'backup/restore-20261026/original-u7-app-sources.tar.gz') as original:
    for member in original.getmembers():
        if member.isfile():
            assert member.name.startswith('velaride/') and '..' not in Path(member.name).parts
            app[member.name] = original.extractfile(member).read()
app['velaride/velaride_shell.c'] = (ROOT / 'backup/restore-20261026/reconstructed-rc17-shell.c').read_bytes()


def connection_block(text):
    start = text.index('  if (g_sport.info == VELARIDE_INFO_CONNECTION)', text.index('static void update_info(void)\n{'))
    end = text.index('  else if (g_sport.info == VELARIDE_INFO_DEVICE)', start)
    return start, end


old_ui = app['velaride/velaride_sport_ui.c'].decode('utf-8').replace('\r\n', '\n')
new_ui = (ROOT / 'build/migrate/velaride/velaride_sport_ui.c').read_text(encoding='utf-8')
a, b = connection_block(old_ui)
c, d = connection_block(new_ui)
app['velaride/velaride_sport_ui.c'] = (new_ui[:c] + old_ui[a:b] + new_ui[d:]).encode('utf-8')
assert b'huangshan_touch_retry' not in app['velaride/velaride_shell.c']
assert b'phone_clear' not in app['velaride/velaride_ble.c']
assert b'g_adv_paused' not in app['velaride/velaride_ble.c']

ap_path = 'boards/sf32lb52/lckfb_huangshan_pi/src/sifli_ap.c'
ap = (ROOT / 'build/migrate/vendor_sifli' / ap_path).read_text(encoding='utf-8')
ap = ap.replace('#include <nuttx/mutex.h>\n', '')
a = ap.index('#ifdef CONFIG_INPUT_FT6146\nstatic mutex_t g_touch_init_lock')
b = ap.index('\n#endif\n', a) + len('\n#endif\n')
ap = ap[:a] + ap[b:]
assert ap.count('      ret = huangshan_touch_retry();') == 1
ap = ap.replace('      ret = huangshan_touch_retry();',
                '      ret = ft6146_touch_initialize(g_pending_touch_i2c,\n'
                '                                    GET_PIN_2(hwp_gpio1,\n'
                '                                              CONFIG_TOUCH_IRQ_PIN));')
assert 'huangshan_touch_retry' not in ap and 'g_touch_ready' not in ap
overrides = {
    ap_path: ap.encode('utf-8'),
    'boards/sf32lb52/lckfb_huangshan_pi/src/CMakeLists.txt':
        (ROOT / 'backup/speaker-20261020/board-CMakeLists.txt').read_bytes(),
}
assert b'speaker_test' not in overrides['boards/sf32lb52/lckfb_huangshan_pi/src/CMakeLists.txt']

manifest = {
    'status': 'Firmware accepted on hardware; reconstructed source overlay over preserved U7 base',
    'firmware_sha256': sha(firmware), 'config_sha256': sha(config),
    'user_confirmation': 'rc17: original smoothness, raise-to-wake, menus, control center, settings and ride navigation restored',
    'observed_slide_hz': 51.6, 'observed_slide_count': 11, 'observed_raise_count': 1,
    'source_base': '/home/wyj/velaride_ai (preserved U7 source tree; omit its unreferenced touch_probe.c)',
    'source_overlay_rebuild_verified': False,
    'repositories': {}, 'source_files': {}, 'deleted_files': [],
}
with zipfile.ZipFile(OUT / 'source-overlay.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name, rel in [('vendor_sifli', 'build/migrate/vendor_sifli'), ('lvgl', 'build/migrate/lvgl')]:
        repo = ROOT / rel
        manifest['repositories'][name] = subprocess.check_output(
            ['git', '-C', str(repo), 'rev-parse', 'HEAD']).decode().strip()
        deleted = subprocess.check_output(['git', '-C', str(repo), 'diff', 'HEAD', '--name-only', '--diff-filter=D', '-z']).split(b'\0')
        manifest['deleted_files'].extend(f'{name}/{p.decode("utf-8")}' for p in deleted if p)
        names = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '-z']).split(b'\0')
        for raw in names:
            if not raw: continue
            local = raw.decode('utf-8')
            path = repo / local
            if not path.is_file(): continue
            content = overrides.get(local, path.read_bytes()) if name == 'vendor_sifli' else path.read_bytes()
            archive_name = f'{name}/{local}'
            z.writestr(archive_name, content)
            manifest['source_files'][archive_name] = sha(content)
    for name, content in app.items():
        z.writestr(name, content)
        manifest['source_files'][name] = sha(content)
    z.writestr('accepted.config', config)
manifest['source_overlay_sha256'] = sha((OUT / 'source-overlay.zip').read_bytes())
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print('Frozen firmware and source overlay:', OUT)
print('Source files:', len(manifest['source_files']))
print('Overlay bytes:', (OUT / 'source-overlay.zip').stat().st_size)
print('Note: overlay is explicitly marked as not yet rebuild-verified.')
