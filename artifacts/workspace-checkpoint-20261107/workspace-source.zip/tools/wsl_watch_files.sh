#!/usr/bin/env bash
# 列出思澈表盘示例里真正的 UI 代码（排除字体/图片资源）
W=/home/wyj/sifli_hspi/lvgl/watch/src

echo "=== gui_apps 结构 ==="
find "$W/gui_apps" -maxdepth 2 2>/dev/null | head -40

echo
echo "=== 非资源类 .c 文件 ==="
find "$W" -name '*.c' 2>/dev/null | grep -vE '/(fonts|images)/' | head -25

echo
echo "=== 文件总数统计 ==="
printf '  全部 .c : %s\n' "$(find "$W" -name '*.c' | wc -l)"
printf '  UI 代码 : %s\n' "$(find "$W" -name '*.c' | grep -vE '/(fonts|images)/' | wc -l)"
