#!/usr/bin/env bash
# 修复 Windows 检出导致的符号链接退化，并补齐 external/ 根构建文件
#
# 仓库里 apps/{external,packages,frameworks,vendor,tests} 都是指向上层目录的符号
# 链接，但 Windows 无符号链接权限时 git 会把它们存成内容为目标路径的普通文本文件。
# rsync 照搬后 CMake 的 EXISTS 判断失败，对应子目录整个不会被纳入构建。
set -eu

SRC=/mnt/d/desktop/VelaRide_AI
DEST=/home/wyj/velaride_ai

# external/ 根目录的构建文件（CMakeLists.txt / Kconfig / Make.defs 等）
# 是 add_subdirectory(external) 的入口，之前只同步了子库导致缺失
echo "=== 同步 external/ 根构建文件 ==="
rsync -a --exclude='.git' -f'+ /*.*' -f'- /*/' "$SRC/external/" "$DEST/external/"
ls "$DEST/external/" | grep -viE '^(libpng|freetype|rapidjson|yoga|curl|harfbuzz)$' | sed 's/^/    /'

echo "=== 修复 apps 下的符号链接 ==="
cd "$DEST/apps"
for name in external packages frameworks vendor tests; do
  target=$(tr -d '\r\n' < "$name" 2>/dev/null || true)
  if [ -f "$name" ] && [ -n "$target" ]; then
    rm -f "$name"
    ln -sfn "${target%/}" "$name"
    printf '    %-12s -> %s\n' "$name" "$(readlink "$name")"
  else
    printf '    %-12s 跳过（已是目录或不存在）\n' "$name"
  fi
done

echo "=== 验证链接可解析 ==="
for name in external packages frameworks vendor tests; do
  if [ -f "$DEST/apps/$name/CMakeLists.txt" ]; then
    printf '    %-12s OK\n' "$name"
  else
    printf '    %-12s 无 CMakeLists.txt\n' "$name"
  fi
done
