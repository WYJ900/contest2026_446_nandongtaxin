#!/usr/bin/env bash
# 同步 external/ 下本次构建实际需要的库，并修复 apps/external 符号链接
#
# 背景：
# 1. apps/external 在仓库里是指向 ../external/ 的符号链接，但在 Windows 检出时
#    退化成了普通文本文件，rsync 照搬过来不是目录，编译时报 "Not a directory"。
# 2. external/ 下有上百个第三方库，本次板级配置只用到少数几个，全量同步纯属浪费。
set -eu

SRC=/mnt/d/desktop/VelaRide_AI
DEST=/home/wyj/velaride_ai

# 依据 defconfig 里的 CONFIG_LIB_PNG / LIB_FREETYPE / LIB_RAPIDJSON /
# LIB_YOGA / UTILS_CURL 等选项挑选；harfbuzz 是 freetype 的关联依赖
# protobuf-c 由 CONFIG_PROTOBUF_C=y 启用，快应用 feature 框架的 IDL 层依赖它；
# zblue 由黄山派 BLE Peripheral/GATT Server 配置启用。
LIBS="libpng freetype rapidjson yoga curl harfbuzz protobuf-c zblue"

mkdir -p "$DEST/external"
for lib in $LIBS; do
  if [ ! -d "$SRC/external/$lib" ]; then
    echo "!! 源侧缺少 external/$lib，跳过"
    continue
  fi
  echo "=== syncing external/$lib ==="
  rsync -a --exclude='.git' "$SRC/external/$lib/" "$DEST/external/$lib/"
  printf '    %s files\n' "$(find "$DEST/external/$lib" -type f | wc -l)"
done

# 用真正的符号链接替换 Windows 检出时退化成的文本文件
if [ ! -L "$DEST/apps/external" ]; then
  rm -f "$DEST/apps/external"
  ln -sfn ../external "$DEST/apps/external"
fi
echo "=== apps/external -> $(readlink "$DEST/apps/external") ==="

# 同步会带回 Windows 的 CRLF 行尾，必须紧接着修，否则构建期要执行的脚本
# （如 curl 的 gen.pl）shebang 会变成 "perl\r" 而报 not found
echo "=== 修复本次同步内容的 CRLF ==="
fixed=0
for lib in $LIBS; do
  [ -d "$DEST/external/$lib" ] || continue
  while IFS= read -r f; do
    if head -c 2 "$f" 2>/dev/null | grep -q '#!' && grep -qU $'\r' "$f" 2>/dev/null; then
      sed -i 's/\r$//' "$f"
      fixed=$((fixed + 1))
    fi
  done < <(find "$DEST/external/$lib" -type f \
             \( -name '*.pl' -o -name '*.py' -o -name '*.sh' \) 2>/dev/null)
done
echo "    修复 $fixed 个脚本"
