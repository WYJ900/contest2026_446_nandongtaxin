﻿# 抓串口里的 LCD_FLUSH 送屏调用日志
#
# 驱动每满一个窗口往串口打一行（sf32lb_lcd.c 的
# SF32LB_LCD_FLUSH_WINDOW）。局部刷新时一次显示刷新可能包含多个 putarea，
# 所以这里统计的是调用率，不是真正的显示 FPS。
# 屏幕静止时不刷新、不出日志，所以跑这个脚本期间要在表上持续滑动。
#
# 用法：
#   .\tools\fps.ps1                  # 抓 20 秒
#   .\tools\fps.ps1 -Seconds 30      # 抓 30 秒
#   .\tools\fps.ps1 -All             # 连其他日志一起打（排障用）
#
# 注意：COM5 独占，运行前需在 EK-OmniProbe 等串口工具里断开连接。

param(
    [int]$Seconds = 20,
    [string]$Port = "COM5",
    [int]$Baud = 1000000,
    [switch]$All          # 打印全部串口输出，不只过滤 LCD_FLUSH
)

$ErrorActionPreference = "Stop"

$sp = New-Object System.IO.Ports.SerialPort($Port, $Baud, 'None', 8, 'One')
$sp.ReadTimeout = 500
# 黄山派用 CH340，拉高 DTR/RTS 会触发复位，必须关掉
$sp.DtrEnable = $false
$sp.RtsEnable = $false

$samples = New-Object System.Collections.Generic.List[double]
$gestureSamples = New-Object System.Collections.Generic.List[string]
$touchSamples = New-Object System.Collections.Generic.List[string]

try {
    $sp.Open()
    Start-Sleep -Milliseconds 200
    if ($sp.BytesToRead -gt 0) { [void]$sp.ReadExisting() }

    Write-Host ""
    Write-Host "抓 $Seconds 秒 —— 现在开始在表上持续上下滑动卡片" -ForegroundColor Cyan
    Write-Host "（屏幕静止时不刷新，不会有送屏日志）" -ForegroundColor DarkGray
    Write-Host ""

    $deadline = (Get-Date).AddSeconds($Seconds)
    $buf = ""

    while ((Get-Date) -lt $deadline) {
        if ($sp.BytesToRead -gt 0) {
            $buf += $sp.ReadExisting()
            # 按行切，最后一段可能不完整，留到下一轮
            $lines = $buf -split "`r?`n"
            $buf = $lines[-1]

            foreach ($line in $lines[0..($lines.Count - 2)]) {
                if ($line -match 'LCD_(?:FLUSH|FPS):\s*([\d.]+)\s*(?:calls/s|fps)\s+flush_avg=(\d+)ms') {
                    $rate = [double]$Matches[1]
                    $samples.Add($rate)
                    Write-Host ("  {0,6:N1} calls/s   flush_avg={1,3}ms" -f $rate, $Matches[2]) -ForegroundColor Green
                }
                elseif ($line -match 'VELARIDE_(?:MENU_)?PERF:') {
                    $gestureSamples.Add($line.Trim())
                    Write-Host "  $($line.Trim())" -ForegroundColor Yellow
                }
                elseif ($line -match 'VELARIDE_(?:TOUCH|NAV|TP|UV):') {
                    $touchSamples.Add($line.Trim())
                    Write-Host "  $($line.Trim())" -ForegroundColor Cyan
                }
                elseif ($All -and $line.Trim()) {
                    Write-Host "  $line" -ForegroundColor DarkGray
                }
            }
        }
        Start-Sleep -Milliseconds 50
    }
}
finally {
    if ($sp.IsOpen) { $sp.Close() }
    $sp.Dispose()
}

Write-Host ""
if ($samples.Count -eq 0) {
    Write-Host "未抓到可选的同步 LCD 送屏日志；异步 DMA 正常命中时这是预期结果。" -ForegroundColor DarkGray
}
else {
    $avg = ($samples | Measure-Object -Average).Average
    $min = ($samples | Measure-Object -Minimum).Minimum
    $max = ($samples | Measure-Object -Maximum).Maximum
    Write-Host "=== $($samples.Count) 个采样窗口 ===" -ForegroundColor Cyan
    Write-Host ("  平均 {0:N1} calls/s    最低 {1:N1}    最高 {2:N1}" -f $avg, $min, $max)
}

if ($gestureSamples.Count -eq 0) {
    if ($touchSamples.Count -eq 0) {
        Write-Host "未抓到已完成手势的性能行；可能未在窗口内完成滑动。" -ForegroundColor Yellow
    }
    else {
        Write-Host "已抓到触摸/导航事件，但未形成至少两帧的有效刷新。" -ForegroundColor Yellow
    }
}
else {
    Write-Host "抓到 $($gestureSamples.Count) 次有效滑动的端到端性能日志。" -ForegroundColor Cyan
}
