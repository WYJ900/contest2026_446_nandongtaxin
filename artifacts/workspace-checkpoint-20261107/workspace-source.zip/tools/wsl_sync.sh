#!/usr/bin/env bash
# WSL 侧最小化同步脚本
# 只同步固件编译真正需要的目录，跳过 external/ 等无关的海量第三方库
set -u

SRC=/mnt/d/desktop/VelaRide_AI
DEST=/home/wyj/velaride_ai

rm -rf "$DEST"
mkdir -p "$DEST"

# compile_commands.json 分析结果：本次板级编译只引用 nuttx/apps/vendor
# build 提供 envsetup.sh；packages/frameworks 供后续快应用与 AI Agent 使用
for d in nuttx apps vendor build packages frameworks; do
  echo "=== syncing $d ==="
  rsync -a --exclude='.git' "$SRC/$d/" "$DEST/$d/"
  printf '    %s files\n' "$(find "$DEST/$d" -type f | wc -l)"
done

echo "=== 完成，总大小 ==="
du -sh "$DEST"
