#!/usr/bin/env bash
# 看思澈转场动画的核心实现——它是怎么做到丝滑的
F=/home/wyj/sifli_hspi/lvgl/watch/src/gui_apps/utils/custom_trans_anim.c

echo "=== include 与依赖 ==="
grep -n '#include' "$F"

echo
echo "=== EPIC 相关代码 ==="
grep -n -B3 -A8 'EPIC' "$F" | head -40
