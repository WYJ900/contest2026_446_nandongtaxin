"""Create a local review bundle from an explicit allowlist; no recordings or keys."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'exports/handoff-20261026'
OUT.mkdir(parents=True, exist_ok=True)
DOC = ROOT / 'my-contest-repo/docs/HANDOFF_REGRESSION_20261026.md'
selected = {DOC}


def add(relative):
    path = ROOT / relative
    if not path.is_file():
        raise FileNotFoundError(relative)
    assert path.resolve().is_relative_to(ROOT.resolve())
    selected.add(path)


# All direct local references in the handoff remain valid in the mirrored ZIP.
for target in re.findall(r'\]\(([^)]+)\)', DOC.read_text(encoding='utf-8')):
    if target.startswith(('https://', 'http://', '#')):
        continue
    path = (DOC.parent / target.split('#', 1)[0]).resolve()
    assert path.is_relative_to(ROOT.resolve()) and path.is_file(), target
    selected.add(path)

for path in (ROOT / 'backup/restore-20261026/handoff-diffs').rglob('*'):
    if path.is_file(): selected.add(path)

for relative in [
    'AGENTS.md', 'my-contest-repo/AGENTS.md',
    'my-contest-repo/docs/CURRENT_STATE.md',
    'my-contest-repo/docs/HANDOFF_UI_20261011.md',
    'my-contest-repo/docs/HANDOFF_DISPLAY_MIGRATION_20261017.md',
    'my-contest-repo/docs/HANDOFF_DISPLAY_20261017_EVENING.md',
    'my-contest-repo/docs/HANDOFF_EPIC_20261017.md',
    'my-contest-repo/artifacts/velaride-ui-u7-20261011.bin',
    'my-contest-repo/artifacts/rc17-baseline-20261026/firmware.bin',
    'my-contest-repo/artifacts/rc17-baseline-20261026/config',
    'my-contest-repo/artifacts/rc17-baseline-20261026/manifest.json',
    'backup/restore-20261026/reconstructed-rc17.bin',
    'backup/restore-20261026/reconstructed-rc17.config',
    'backup/restore-20261026/rc17-microphone-only.bin',
    'backup/restore-20261026/rc17-microphone-only.config',
    'backup/restore-20261026/rc17-touch-recovery-probe.bin',
    'backup/restore-20261026/handoff-final-state.json',
    'backup/restore-20261026/handoff-firmware-index.json',
    'backup/restore-20261026/hardware-diagnosis-current.json',
    'backup/restore-20261026/microphone-stage-scope.json',
    'backup/restore-20261026/source-preservation.json',
    'backup/restore-20261026/vendor-working.patch',
    'backup/restore-20261026/lvgl-working.patch',
    'backup/restore-20261026/touch_probe.c',
    'backup/restore-20261026/build_touch_probe.sh',
    'backup/restore-20261026/build_touch_probe_rc17.sh',
    'backup/restore-20261026/check_original_ui.sh',
    'backup/restore-20261026/original-u7-board-CMakeLists.txt',
    'backup/restore-20261026/original-u7-sifli_ap.c',
    'backup/restore-20261026/rc17-accepted-interaction.log',
    'backup/restore-20261026/rc17-base-status.log',
    'backup/restore-20261026/rc17-legacy-ble-check.json',
    'backup/restore-20261026/original-rc17-state.log',
    'backup/restore-20261026/original-u7-ready.log',
    'backup/restore-20261026/microphone-stage-preflight.log',
    'backup/restore-20261026/rollback-mic-state.log',
    'backup/restore-20261026/independent-touch-probe.log',
    'backup/restore-20261026/probe-screen-disconnected.log',
    'backup/restore-20261026/probe-cable-only.log',
    'backup/restore-20261026/probe-screen-reconnected.log',
    'backup/restore-20261026/rc17-reset-order-probe.log',
    'backup/restore-20261026/idle-amp-and-touch-lines.log',
    'backup/restore-20261026/rc17-gpio-state.log',
    'backup/restore-20261026/rc17-pinmux-state.log',
    'backup/restore-20261026/rc17-i2c-routing.log',
    'backup/restore-20261026/handoff-restore-rc17.log',
    'backup/speaker-20261025/mic-v14-boot.log',
    'backup/speaker-20261025/speaker_test.accepted-v13.c',
    'backup/speaker-20261025/accepted-usb-profile.json',
    'backup/speaker-20261025/accepted-v13-validation.json',
    'backup/speaker-20261025/known-voice-upload-v16.json',
    'backup/speaker-20261025/known-voice-upload-v16.playback.log',
    'build/migrate/velaride/velaride_shell.c',
    'build/migrate/velaride/velaride_sport_ui.c',
    'build/migrate/velaride/velaride_ble.c',
    'build/migrate/velaride/velaride_ride_session.c',
    'build/migrate/vendor_sifli/boards/sf32lb52/lckfb_huangshan_pi/src/sifli_ap.c',
    'build/migrate/vendor_sifli/boards/sf32lb52/lckfb_huangshan_pi/src/CMakeLists.txt',
    'build/migrate/vendor_sifli/boards/sf32lb52/lckfb_huangshan_pi/src/mic_test.c',
    'build/migrate/vendor_sifli/boards/sf32lb52/lckfb_huangshan_pi/src/speaker_test.c',
    'build/migrate/vendor_sifli/boards/sf32lb52/lckfb_huangshan_pi/src/voice_test_dsp.h',
    'build/migrate/vendor_sifli/boards/sf32lb52/lckfb_huangshan_pi/src/audio_test.h',
    'build/stages/microphone-only/mic_test.c',
    'build/stages/microphone-only/audio_test_lock.c',
    'build/stages/microphone-only/audio_test.h',
    'tools/serial_probe.py', 'tools/mic_capture.py', 'tools/voice_upload.py',
    'tools/freeze_rc17_baseline.py', 'tools/prepare_frozen_rc17.sh',
    'tools/build_microphone_stage.sh', 'tools/phone_ble_check.py',
    'my-contest-repo/mobile/android/README.md',
    'my-contest-repo/mobile/android/build.ps1',
    'my-contest-repo/mobile/android/tests/WireCodecTest.java',
    'exports/mobile/VelaRide-0.1.0-debug.apk',
]:
    add(relative)

for path in (ROOT / 'my-contest-repo/mobile/android/app/src/main').rglob('*'):
    if path.is_file(): selected.add(path)

readme = '''# VelaRide 本地交接包（2026-10-26）

先读 [详细交接文档](my-contest-repo/docs/HANDOFF_REGRESSION_20261026.md)，
再读 [最终状态 JSON](backup/restore-20261026/handoff-final-state.json) 和
[代码差异索引](backup/restore-20261026/handoff-diffs/README.md)。

最近一次经校验写入的是原样高帧率 rc17。交互曾在完全重插屏幕端后恢复，
用户确认正常，但随后静置又黑屏，侧键不亮，读取时出现连续 SFBL。
基础功能尚未稳定修好，根因未确定；不要把本包当成已完成修复的发布版。

目录保留原工作区的相对布局。固件索引含所有原机留存版本，本包仅附原 U7、
原 rc17、纯重建 rc17、麦克风独立候选和 rc17 诊断版，供核验／受控对照。
不要只按文件名或目录名认版本；使用完整 SHA-256。

本包包含关键日志、8 份源码差异、相关源文件、原应用快照、配置和安装包。
它不是完整开发环境，不含原始人声、签名私钥、全部 SDK/工具链，也不包含
约 93 MB 的 `source-overlay.zip`。该覆盖层及保留的 U7 完整构建树仍在原机，
具体位置和依赖见主文档。固件／源码目录存在多轮历史状态，先审阅再运行脚本。

包内文件校验见 [CONTENTS_SHA256.json](CONTENTS_SHA256.json)。
没有代用户发送给任何人，没有执行 git commit 或 push。
'''

contents = {}
archive = OUT / 'VelaRide-handoff-20261026.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    z.writestr('README.md', readme)
    contents['README.md'] = {'bytes': len(readme.encode()), 'sha256': hashlib.sha256(readme.encode()).hexdigest()}
    for path in sorted(selected):
        name = path.relative_to(ROOT).as_posix()
        assert '..' not in Path(name).parts and not Path(name).is_absolute()
        assert not name.endswith(('.wav', '.pcm', '.keystore'))
        data = path.read_bytes()
        z.writestr(name, data)
        contents[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    z.writestr('CONTENTS_SHA256.json', json.dumps(contents, indent=2, ensure_ascii=False))

with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, info in contents.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == info['sha256'], name

(OUT / 'README.md').write_text(readme, encoding='utf-8')
(OUT / 'HANDOFF_REGRESSION_20261026.md').write_bytes(DOC.read_bytes())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(OUT / 'package-sha256.txt').write_text(digest + '  ' + archive.name + '\n', encoding='utf-8')
print('Handoff ZIP:', archive)
print('Files:', len(contents) + 1, 'Bytes:', archive.stat().st_size)
print('SHA256:', digest)
print('Verified: main-document local links exist; ZIP CRC and per-file SHA-256 match.')
