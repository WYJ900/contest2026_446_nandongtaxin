#!/usr/bin/env bash
# 检查网络相关 Kconfig，排查 vapp 卡在 curl socketpair 的问题
CFG=/home/wyj/velaride_ai/cmake_out/lckfb_huangshan_pi/.config

echo "=== TCPBACKLOG（listen/accept 需要）==="
grep -E 'TCPBACKLOG' "$CFG" || echo "  未设置"

echo "=== LOOPBACK ==="
grep -E 'LOOPBACK' "$CFG"

echo "=== TCP / socket 选项 ==="
grep -E '^CONFIG_NET_TCP|^CONFIG_NET_SOCKOPTS|^CONFIG_NET_IPv4|^CONFIG_NET_LOCAL' "$CFG"

echo "=== 缓冲与连接数 ==="
grep -E '^CONFIG_NET_TCP_CONNS|^CONFIG_NET_MAX_LISTENPORTS|^CONFIG_IOB' "$CFG"
