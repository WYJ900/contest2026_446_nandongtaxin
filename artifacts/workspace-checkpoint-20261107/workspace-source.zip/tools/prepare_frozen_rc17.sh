#!/usr/bin/env bash
set -euo pipefail
SRC=/home/wyj/velaride_ai
DST=/home/wyj/velaride_rc17_baseline
BASE=/mnt/d/desktop/VelaRide_AI/my-contest-repo/artifacts/rc17-baseline-20261026
SAVE=/mnt/d/desktop/VelaRide_AI/backup/restore-20261026
if [ ! -e "$DST/.source-reconstruction-done" ]; then
mkdir -p "$DST"
rsync -a --exclude=/cmake_out --exclude=touch_probe.c "$SRC/" "$DST/"
python3 - "$BASE" "$DST" <<'PY'
from pathlib import Path
import hashlib,json,sys,zipfile
base=Path(sys.argv[1]); dst=Path(sys.argv[2]).resolve()
assert dst==Path('/home/wyj/velaride_rc17_baseline')
m=json.loads((base/'manifest.json').read_text())
def target(name):
    prefix,rel=name.split('/',1)
    roots={'vendor_sifli':dst/'vendor/sifli','lvgl':dst/'apps/graphics/lvgl/lvgl','velaride':dst/'apps/examples/velaride'}
    assert all(p.resolve().is_relative_to(dst) for p in roots.values())
    result=(roots[prefix]/rel).resolve()
    assert result.is_relative_to(roots[prefix].resolve())
    return result
with zipfile.ZipFile(base/'source-overlay.zip') as z:
    for name,digest in m['source_files'].items():
        data=z.read(name); assert hashlib.sha256(data).hexdigest()==digest
        p=target(name); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
for name in m.get('deleted_files',[]):
    target(name).unlink(missing_ok=True)
# Match the migration's build integration; the diagnostic app stays excluded.
p=dst/'apps/graphics/lvgl/CMakeLists.txt'; s=p.read_text()
if 'target_link_libraries(lvgl PRIVATE sifli_hal)' not in s:
    anchor='  if(NOT CONFIG_LV_ASSERT_HANDLER_INCLUDE STREQUAL "")'
    assert s.count(anchor)==1
    s=s.replace(anchor,'  if(CONFIG_LV_USE_SIFLI_EPIC)\n    target_link_libraries(lvgl PRIVATE sifli_hal)\n  endif()\n\n'+anchor)
    p.write_text(s)
board=dst/'vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh/defconfig'
board.write_bytes((base/'config').read_bytes())
(dst/'.source-reconstruction-done').write_text(m['firmware_sha256']+'\n')
print('Independent RC17 source tree prepared and overlay checksums verified.')
PY
else
  echo 'Frozen RC17 source tree already prepared; leaving its sources unchanged.'
fi
export PATH=/opt/arm-gnu-toolchain/bin:$HOME/.local/bin:$PATH
OUT=$DST/cmake_out/lckfb_huangshan_pi
cd "$DST/nuttx"
cmake -B "$OUT" -S "$DST/nuttx" -GNinja \
  -DBOARD_CONFIG="$DST/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/configs/nsh" \
  '-DEXTRA_FLAGS=-Wno-cpp -Wno-deprecated-declarations' > "$SAVE/rc17-reconstruction-configure.log" 2>&1 ||
  { tail -30 "$SAVE/rc17-reconstruction-configure.log"; exit 1; }
cmake --build "$OUT" -- -j8 > "$SAVE/rc17-reconstruction-build.log" 2>&1 ||
  { tail -40 "$SAVE/rc17-reconstruction-build.log"; exit 1; }
test "$(stat -c %s "$OUT/nuttx.bin")" -lt $((0x990000))
cp "$OUT/nuttx.bin" "$SAVE/reconstructed-rc17.bin"
cp "$OUT/.config" "$SAVE/reconstructed-rc17.config"
sha256sum "$SAVE/reconstructed-rc17.bin"
