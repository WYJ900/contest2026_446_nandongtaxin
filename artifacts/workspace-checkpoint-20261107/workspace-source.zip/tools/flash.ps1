﻿# 烧录脚本（Windows 侧执行）
#
# 流程：WSL 里编译好的 nuttx.bin 拷回 Windows，再用 sftool.exe 通过 COM 口烧录。
# WSL2 默认拿不到 USB 串口，所以编译在 WSL、烧录在 Windows 是最省事的分工。
#
# 用法：
#   .\flash.ps1                 # 自动探测 COM 口
#   .\flash.ps1 -Port COM7      # 指定 COM 口

param(
    [string]$Port = "",
    [int]$Baud = 1000000,
    [switch]$Compat,
    [switch]$NoPostReset
)

$ErrorActionPreference = "Stop"

$ProjectRoot = "D:/desktop/VelaRide_AI"
$WslBin      = "\\wsl$\Ubuntu-22.04\home\wyj\velaride_ai\cmake_out\lckfb_huangshan_pi\nuttx.bin"
$LocalBin    = "$ProjectRoot/nuttx.bin"
$FlashAddr   = "0x12010000"

Write-Host "=== 从 WSL 取出固件 ===" -ForegroundColor Cyan
if (-not (Test-Path $WslBin)) {
    Write-Error "找不到固件 $WslBin`n请先在 WSL 中编译：wsl -d Ubuntu-22.04 bash /mnt/d/desktop/VelaRide_AI/tools/wsl_build.sh"
}
if ((Get-Item -LiteralPath $WslBin).Length -ge 0x990000) {
    throw 'Firmware overlaps the persistent config partition; refusing to flash.'
}
Copy-Item $WslBin $LocalBin -Force
$size = [math]::Round((Get-Item $LocalBin).Length / 1MB, 2)
Write-Host "固件大小：$size MB"

if ([string]::IsNullOrEmpty($Port)) {
    Write-Host "=== 探测串口 ===" -ForegroundColor Cyan
    $ports = [System.IO.Ports.SerialPort]::GetPortNames()
    if ($ports.Count -eq 0) { Write-Error "未检测到任何串口，请确认黄山派已通过 USB 连接" }
    Write-Host "可用串口：$($ports -join ', ')"
    $Port = $ports[-1]
    Write-Host "自动选择：$Port（如不正确请用 -Port 指定）"
}

Write-Host "=== 烧录到 $Port @ $FlashAddr ===" -ForegroundColor Cyan
$sftool = "$ProjectRoot/sftool.exe"
# 注意：不能用 $args 作变量名，它是 PowerShell 自动变量
$sfArgs = @("-c", "SF32LB52", "-p", $Port)
if ($Compat) {
    $sfArgs += "--compat"
} else {
    $sfArgs += @("-b", "$Baud", "--before", "default_reset", "--after", "soft_reset")
}
$sfArgs += @("write_flash", "$LocalBin@$FlashAddr")

Write-Host "sftool $($sfArgs -join ' ')" -ForegroundColor DarkGray
& $sftool @sfArgs

if ($LASTEXITCODE -ne 0) {
    Write-Host "烧录失败。可以加 -Compat 参数重试：.\flash.ps1 -Port $Port -Compat" -ForegroundColor Yellow
    exit 1
}
Write-Host "=== 烧录完成 ===" -ForegroundColor Green

# sftool 的 soft_reset 只复位 SoC，CO5300 AMOLED 偶发仍停留在黑屏状态。
# 再通过 CH340N 拉一次 RTS，让板级 LCD 上电和面板初始化完整重跑。
if (-not $NoPostReset) {
    Write-Host "=== 执行烧录后 RTS 完整复位（防止 AMOLED 黑屏）===" -ForegroundColor Cyan
    & "$ProjectRoot/tools/reset.ps1" -Port $Port -Baud $Baud -Capture 10
}

Write-Host "串口调试：使用 putty/串口工具连接 $Port，波特率 $Baud"
