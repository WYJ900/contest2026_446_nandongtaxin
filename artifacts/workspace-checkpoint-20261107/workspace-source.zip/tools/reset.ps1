﻿# 通过 CH340N 的 RTS 信号软复位黄山派，并捕获启动日志
#
# 硬件上这块板没有独立 RESET 键（复位复用在 Power Key/KEY1，需长按约 10 秒），
# RTS 复位更方便，也能绕开信号屏蔽而杀不掉的僵死进程。
#
# 用法：
#   .\tools\reset.ps1
#   .\tools\reset.ps1 -Then "velaclock &"    # 抢在 rcS 的 sleep 3 之前占用 LVGL
#
# 注意：COM5 独占，运行前需在串口工具里断开连接。

param(
    [string]$Port = "COM5",
    [int]$Baud = 1000000,
    [string]$Then = "",
    [int]$Capture = 10
)

$ErrorActionPreference = "Stop"

$sp = New-Object System.IO.Ports.SerialPort($Port, $Baud, 'None', 8, 'One')
$sp.ReadTimeout = 500
$sp.DtrEnable = $false
$sp.RtsEnable = $false

try {
    $sp.Open()

    Write-Host "=== RTS 复位 ===" -ForegroundColor Cyan
    $sp.RtsEnable = $true
    Start-Sleep -Milliseconds 300
    $sp.RtsEnable = $false

    if ($Then) {
        # rcS 里有 sleep 3，趁这个窗口抢占 LVGL（同时只能有一个 LVGL 实例）
        Write-Host "=== 等待 NSH 就绪 ===" -ForegroundColor Cyan
        $acc = New-Object System.Text.StringBuilder
        $deadline = (Get-Date).AddSeconds(8)
        $ready = $false
        while ((Get-Date) -lt $deadline) {
            if ($sp.BytesToRead -gt 0) {
                [void]$acc.Append($sp.ReadExisting())
                if ($acc.ToString() -match "nsh>") { $ready = $true; break }
            }
            Start-Sleep -Milliseconds 30
        }
        if (-not $ready) { Write-Host "未等到 nsh> 提示符" -ForegroundColor Yellow }

        Write-Host "=== 执行: $Then ===" -ForegroundColor Cyan
        $sp.WriteLine($Then)
    }

    Write-Host "=== 启动日志（$Capture 秒）===" -ForegroundColor Cyan
    $buf = New-Object System.Text.StringBuilder
    $deadline = (Get-Date).AddSeconds($Capture)
    while ((Get-Date) -lt $deadline) {
        if ($sp.BytesToRead -gt 0) { [void]$buf.Append($sp.ReadExisting()) }
        Start-Sleep -Milliseconds 100
    }
    Write-Host ($buf.ToString() -replace "`e\[K", "")
}
finally {
    if ($sp.IsOpen) { $sp.Close() }
}
