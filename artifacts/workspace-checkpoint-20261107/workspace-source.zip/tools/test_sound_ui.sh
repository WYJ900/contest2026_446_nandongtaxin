#!/usr/bin/env bash
set -euo pipefail
WORK=/mnt/d/desktop/VelaRide_AI
SAVE=$WORK/backup/sound-stage-20261027
OUT=/tmp/velaride-sound-ui-test
MODE=${1:-ON}
if [ "$MODE" = OFF ]; then
  OUT=/tmp/velaride-sound-ui-off-test
  SAVE=$SAVE/disabled
  mkdir -p "$SAVE"
fi
cmake -S "$WORK/my-contest-repo/tests/sport_ui" -B "$OUT" -GNinja \
  -DLVGL_SOURCE=/home/wyj/velaride_speaker_stage/apps/graphics/lvgl/lvgl \
  -DVELARIDE_COUNTDOWN=ON -DVELARIDE_ALARM=ON -DVELARIDE_SOUND="$MODE" -DCMAKE_BUILD_TYPE=Debug \
  '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' \
  '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined' > "$SAVE/06-ui-configure.log" 2>&1
cmake --build "$OUT" -- -j8 > "$SAVE/07-ui-build.log" 2>&1 ||
  { tail -60 "$SAVE/07-ui-build.log"; exit 1; }
mkdir -p "$SAVE/screens"
"$OUT/sport_ui_test" "$SAVE/screens" > "$SAVE/08-sport-ui.log" 2>&1 ||
  { tail -45 "$SAVE/08-sport-ui.log"; exit 1; }
"$OUT/shell_ui_test" "$SAVE/screens" > "$SAVE/09-shell-ui.log" 2>&1 ||
  { tail -45 "$SAVE/09-shell-ui.log"; exit 1; }
tail -2 "$SAVE/08-sport-ui.log"
tail -2 "$SAVE/09-shell-ui.log"
