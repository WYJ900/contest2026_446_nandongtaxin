#!/usr/bin/env python3
"""Build local prototype watch-face assets from user-provided references."""

from pathlib import Path

import cv2
import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r"D:\desktop\OIP.webp")
OUT_DIR = ROOT / "apps" / "examples" / "velaride"
PREVIEW = OUT_DIR / "velaride_mickey_390.png"
INCLUDE = OUT_DIR / "velaride_mickey_rgb565.inc"
SIZE = 390
BACKGROUND = (0x11, 0x18, 0x27)


def write_rgb565_include(rgb: Image.Image, output: Path, symbol: str) -> None:
    data = bytearray()
    for red, green, blue in rgb.getdata():
        value = ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3)
        data.extend((value & 0xFF, value >> 8))

    with output.open("w", encoding="ascii", newline="\n") as include:
        include.write(
            "/* Perspective-corrected from a user-provided local prototype "
            "reference.\n"
            " * Verify third-party artwork rights before public distribution.\n"
            " */\n\n"
            f"static const unsigned char {symbol}[] = {{\n"
        )
        for offset in range(0, len(data), 16):
            values = ", ".join(f"0x{byte:02x}" for byte in data[offset:offset + 16])
            include.write(f"  {values},\n")
        include.write("};\n")
        include.write(f"static const unsigned int {symbol}_len = {len(data)};\n")


def main() -> None:
    source = cv2.imread(str(SOURCE), cv2.IMREAD_COLOR)
    if source is None:
        raise SystemExit(f"cannot read {SOURCE}")

    # Corners of the illuminated watch face in the supplied 474x296 photo.
    # The tighter crop removes most of the photographed strap and crown.
    src = np.float32([[170, 10], [419, 60], [351, 276], [91, 207]])
    dst = np.float32([[0, 0], [SIZE - 1, 0], [SIZE - 1, SIZE - 1], [0, SIZE - 1]])
    matrix = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(source, matrix, (SIZE, SIZE),
                                 flags=cv2.INTER_LANCZOS4,
                                 borderMode=cv2.BORDER_CONSTANT,
                                 borderValue=BACKGROUND[::-1])

    rgb = Image.fromarray(cv2.cvtColor(warped, cv2.COLOR_BGR2RGB))
    rgb.save(PREVIEW)
    write_rgb565_include(rgb, INCLUDE, "velaride_mickey_rgb565")
    print(f"preview={PREVIEW} size={PREVIEW.stat().st_size}")
    print(f"include={INCLUDE} size={INCLUDE.stat().st_size}")


if __name__ == "__main__":
    main()
