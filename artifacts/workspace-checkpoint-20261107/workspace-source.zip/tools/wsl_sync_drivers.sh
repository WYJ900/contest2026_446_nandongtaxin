#!/usr/bin/env bash
# 同步板级 drivers/ 与 configs/ 到 WSL
#
# wsl_sync_board.sh 只同步 lckfb_huangshan_pi/src/（rcS + romfs 快应用），
# 不覆盖 sf32lb52/drivers/（LCD 驱动）和 configs/（defconfig）。
# 改了 LCD 驱动或板级配置后跑这个，否则编出来的固件还是旧的。
#
# 注意：改 defconfig 后必须 wsl_build.sh clean 全量重编，增量不会重新跑
# kconfig。改 drivers/ 下的 .c 增量即可。
set -eu

SRC=/mnt/d/desktop/VelaRide_AI/vendor/sifli/boards/sf32lb52
DST=/home/wyj/velaride_ai/vendor/sifli/boards/sf32lb52

echo "=== 同步 drivers/ ==="
rsync -a --exclude='.git' --exclude='*.bak' "$SRC/drivers/" "$DST/drivers/"

echo "=== 同步 configs/ ==="
rsync -a --exclude='.git' \
  "$SRC/lckfb_huangshan_pi/configs/" "$DST/lckfb_huangshan_pi/configs/"

# 源码走 C 预处理器，CRLF 会让部分工具链报错（.jidl 上踩过这个坑，
# 且失败时退出码是 0，很难发现）
echo "=== 修 CRLF ==="
find "$DST/drivers" "$DST/lckfb_huangshan_pi/configs" -type f \
  \( -name '*.c' -o -name '*.h' -o -name 'defconfig' -o -name 'Kconfig' \) \
  -exec sed -i 's/\r$//' {} +

echo "=== 关键配置项确认 ==="
grep -nE 'LV_NUTTX_VSYNC_TIMER_PERIOD|LV_NUTTX_LCD_DOUBLE_BUFFER|LV_NUTTX_LCD_SINGLE_BUFFER' \
  "$DST/lckfb_huangshan_pi/configs/nsh/defconfig" || echo "  （未找到，检查 defconfig）"

echo "=== LCD 驱动分片行数 ==="
grep -n 'SF32LB_LCD_CHUNK_ROWS\|SF32LB_LCD_FLUSH_WINDOW' \
  "$DST/drivers/lcd/sf32lb_lcd.c" | head -4
