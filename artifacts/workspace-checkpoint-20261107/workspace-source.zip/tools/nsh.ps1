﻿# 通过串口向 NSH 发送命令并回显输出
#
# 用法：
#   .\tools\nsh.ps1 -Cmd "date"
#   .\tools\nsh.ps1 -Cmd "ls /dev" -Wait 3000
#
# 注意：COM5 是独占的，运行前需在 EK-OmniProbe 里断开串口连接。

param(
    [Parameter(Mandatory=$true)][string[]]$Cmd,
    [string]$Port = "COM5",
    [int]$Baud = 1000000,
    [int]$Wait = 1500
)

$ErrorActionPreference = "Stop"

$sp = New-Object System.IO.Ports.SerialPort($Port, $Baud, 'None', 8, 'One')
$sp.ReadTimeout = 500
# 黄山派用 CH340，拉高 DTR/RTS 会触发复位，必须关掉
$sp.DtrEnable = $false
$sp.RtsEnable = $false

try {
    $sp.Open()
    # 清掉可能残留的旧数据
    Start-Sleep -Milliseconds 200
    if ($sp.BytesToRead -gt 0) { [void]$sp.ReadExisting() }

    foreach ($c in $Cmd) {
        Write-Host "nsh> $c" -ForegroundColor Cyan
        $sp.WriteLine($c)

        $buf = New-Object System.Text.StringBuilder
        $deadline = (Get-Date).AddMilliseconds($Wait)
        while ((Get-Date) -lt $deadline) {
            if ($sp.BytesToRead -gt 0) {
                [void]$buf.Append($sp.ReadExisting())
                # 收到数据后再多等一会，避免截断长输出
                $deadline = (Get-Date).AddMilliseconds(600)
            }
            Start-Sleep -Milliseconds 50
        }

        # 去掉 ANSI 清行符，让输出干净
        $out = $buf.ToString() -replace "`e\[K", ""
        Write-Host $out
    }
}
finally {
    if ($sp.IsOpen) { $sp.Close() }
}
