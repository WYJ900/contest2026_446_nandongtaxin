﻿"""Workspace entry point for the team's basic companion BLE check."""
from pathlib import Path
import runpy

if __name__ == '__main__':
    runpy.run_path(str(Path(__file__).resolve().parents[1] / 'my-contest-repo/scripts/companion_basic_check.py'), run_name='__main__')
