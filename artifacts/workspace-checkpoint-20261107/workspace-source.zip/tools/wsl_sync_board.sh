#!/usr/bin/env bash
# 同步板级 src/ 目录（启动脚本 rcS + romfs 内的快应用）到 WSL 并修 CRLF
#
# 编译在 WSL 侧进行，改了 Windows 侧的 rcS 或 etc/data/app/ 下的快应用后
# 必须跑这个，否则编出来的固件还是旧内容。
set -eu

SRC=/mnt/d/desktop/VelaRide_AI/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/src
DST=/home/wyj/velaride_ai/vendor/sifli/boards/sf32lb52/lckfb_huangshan_pi/src

echo "=== 同步板级 src/ ==="
rsync -a --exclude='.git' "$SRC/" "$DST/"

# rcS 会过 C 预处理器，CRLF 会让它出错；.json 也要干净
echo "=== 修 CRLF（rcS / json）==="
find "$DST/etc" -type f \( -name 'rcS' -o -name 'rc.sysinit' -o -name '*.json' \) \
  -exec sed -i 's/\r$//' {} +

echo "=== 同步后的 rcS ==="
cat "$DST/etc/init.d/rcS"

echo "=== romfs 内的快应用 ==="
ls "$DST/etc/data/app/"
