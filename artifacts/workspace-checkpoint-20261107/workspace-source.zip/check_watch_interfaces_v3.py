from inspect_watch_mesh import ROOT
import numpy as np,trimesh,json
from scipy.ndimage import binary_erosion
P=ROOT/'局部加厚V3_待复核'
old=trimesh.load_mesh(ROOT/'修复版_单件STL'/'外壳_修复.stl')
new=trimesh.load_mesh(P/'外壳_V3.stl')
def block(mesh,points,direction,limit):
 result=np.zeros(len(points),dtype=bool)
 for start in range(0,len(points),1500):
  a=points[start:start+1500];dirs=np.tile(direction,(len(a),1))
  hit,ri,fi=mesh.ray.intersects_location(a,dirs,multiple_hits=False)
  dist=np.linalg.norm(hit-a[ri],axis=1);result[start+ri[dist<limit]]=True
 return result
report={}
x=np.arange(-48.5,-13.4,.1);z=np.arange(-3.9,1.01,.1)
X,Z=np.meshgrid(x,z)
for name,start_y,direction,limit in [('front_slot',-6,[0,1,0],11),('rear_slot',48,[0,-1,0],12)]:
 points=np.c_[X.ravel(),np.full(X.size,start_y),Z.ravel()]
 ob=block(old,points,direction,limit);nb=block(new,points,direction,limit)
 clear=(~ob).reshape(X.shape);safe=binary_erosion(clear,iterations=2)
 newly=nb&~ob;safe_new=nb.reshape(X.shape)&safe
 d=dict(grid_pitch_mm=.1,original_clear_points=int((~ob).sum()),newly_blocked_points=int(newly.sum()),newly_blocked_away_from_boundary=int(safe_new.sum()))
 if newly.any():d['affected_bounds_xz']=np.c_[points[newly,0],points[newly,2]].min(0).tolist(),np.c_[points[newly,0],points[newly,2]].max(0).tolist()
 report[name]=d;print(name,d,flush=True)
# Both screw passages, in the region around the original holes.
for idx,(cy,cz) in enumerate([(7.485624,5.7),(37.5926,4.8)]):
 a=np.arange(-1.9,1.91,.1);Y,Z=np.meshgrid(a+cy,a+cz)
 points=np.c_[np.full(Y.size,-54),Y.ravel(),Z.ravel()]
 ob=block(old,points,[1,0,0],47);nb=block(new,points,[1,0,0],47)
 d=dict(original_clear_points=int((~ob).sum()),newly_blocked_points=int((nb&~ob).sum()))
 report[f'crossbar_screw_passage_{idx}']=d;print(d,flush=True)
(P/'interface_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
