from pathlib import Path
import numpy as np, trimesh, manifold3d as md
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from inspect_watch_mesh import ROOT
WORK=ROOT/'局部加厚工作记录'
def solid(name):
 m=trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{name}_修复.stl')
 return md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)))
main=solid('外壳');back=solid('底部外壳')
centers=[(-46.326612,32.785691),(-15.571870,32.785691),(-42.136924,2.476229),(-19.761558,2.476229)]
rings=[]
for x,y in centers:
 ring=(md.Manifold.cylinder(4.75,2.4,circular_segments=128)-md.Manifold.cylinder(4.85,1.6,circular_segments=128).translate([0,0,-.05])).translate([x,y,-3.6088265])
 print('boss',x,y,'main collision',(ring^main).volume(),flush=True)
 rings.append(ring)
newback=back
for r in rings:newback=newback+r
print('back add volume',newback.volume()-back.volume(),'overlap',(newback^main).volume(),flush=True)
fig,axs=plt.subplots(2,4,figsize=(16,7))
for ax,y in zip(axs.flat,[-2.5,-1,0,.5,40.8,42,43.5,44.1]):
 for p in main.rotate([90,0,0]).slice(y).to_polygons():
  p=np.asarray(p);p=np.vstack([p,p[0]]);ax.plot(p[:,0],-p[:,1],lw=.8)
 ax.set_title(f'XZ at Y={y}');ax.set_aspect('equal');ax.grid(alpha=.3)
fig.tight_layout();fig.savefig(WORK/'slot_XZ_sections.png',dpi=180)
