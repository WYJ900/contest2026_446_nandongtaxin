from inspect_watch_mesh import ROOT,stats
import numpy as np,trimesh,manifold3d as md,pymeshfix,pymeshlab as pm,json
OUT=ROOT/'局部加厚V2_待复核'
old=trimesh.load_mesh(ROOT/'修复版_单件STL'/'外壳_修复.stl')
cand=trimesh.load_mesh(OUT/'外壳_局部加厚V2.stl')
def s(m):return md.Manifold(md.Mesh64(np.asarray(m.vertices,dtype=np.float64),np.asarray(m.faces,dtype=np.uint64)))
def m(s):
 a=s.to_mesh64();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=False)
hull=s(old.convex_hull);base=s(old)
constrained=base+(s(cand)-hull)
nom=m(constrained)
print('raw components',len(constrained.decompose()),'volume',constrained.volume(),flush=True)
nom.export(OUT/'main_constrained_raw.stl')
r=trimesh.load_mesh(OUT/'main_constrained_raw.stl')
print('raw',stats(r),flush=True)
r.vertices=np.round(r.vertices,5);r.merge_vertices()
v,f=pymeshfix.clean_from_arrays(np.asarray(r.vertices,dtype=float),np.asarray(r.faces,dtype=np.int32),joincomp=False,remove_smallest_components=False)
r=trimesh.Trimesh(v,f,process=True);r.fix_normals(multibody=True)
path=OUT/'外壳_外侧加强V2.stl';r.export(path);r=trimesh.load_mesh(path)
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=r.vertices,face_matrix=r.faces));ms.compute_selection_by_self_intersections_per_face()
print('final',stats(r),'intersections',int(ms.current_mesh().face_selection_array().sum()),'euler',r.euler_number,flush=True)
print('source removed',(base-s(r)).volume(),'internal added',((s(r)-base)^hull).volume(),flush=True)
np.random.seed(19);p,_=trimesh.sample.sample_surface(r,16000);_,d,_=trimesh.proximity.closest_point(nom,p)
print('cleanup deviation',float(d.max()),p[d.argmax()],flush=True)
