import manifold3d
from inspect_watch_mesh import ROOT, stats
import trimesh, pymeshlab as pm, numpy as np
m = trimesh.load_mesh(ROOT / '外壳.stl')
for op in ['folded', 'tflip', 'tcollapse', 'manifold']:
    ms = pm.MeshSet(); ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices, face_matrix=m.faces))
    try:
        if op == 'folded': ms.meshing_remove_folded_faces()
        if op == 'tflip': ms.meshing_remove_t_vertices(method='Edge Flip', threshold=100000, repeat=True)
        if op == 'tcollapse': ms.meshing_remove_t_vertices(method='Edge Collapse', threshold=100000, repeat=True)
        if op == 'manifold':
            s = manifold3d.Manifold(manifold3d.Mesh(np.asarray(m.vertices, dtype=np.float32), np.asarray(m.faces, dtype=np.uint32))).simplify(0.00001).to_mesh()
            ms = pm.MeshSet(); ms.add_mesh(pm.Mesh(vertex_matrix=np.asarray(s.vert_properties[:, :3], dtype=float), face_matrix=np.asarray(s.tri_verts, dtype=np.int32)))
        out = trimesh.Trimesh(ms.current_mesh().vertex_matrix(), ms.current_mesh().face_matrix(), process=False)
        ms.compute_selection_by_self_intersections_per_face()
        print(op, stats(out), 'selfintersection', int(ms.current_mesh().face_selection_array().sum()), 'volume_delta', out.volume-m.volume, flush=True)
    except Exception as e: print(op, type(e).__name__, str(e), flush=True)
