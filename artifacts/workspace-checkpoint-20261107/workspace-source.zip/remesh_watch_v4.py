from inspect_watch_mesh import ROOT,stats
import trimesh,numpy as np,manifold3d as md,json,time
from PIL import Image,ImageDraw
from skimage.measure import marching_cubes
from scipy.ndimage import binary_closing,binary_opening,generate_binary_structure
import pymeshlab as pm
P=ROOT/'20261018_V4_工作记录'
m=trimesh.load_mesh(P/'main_trial.stl')
s=md.Manifold(md.Mesh64(m.vertices.astype('float64'),m.faces.astype('uint64')))
assert s.status()==md.Error.NoError
pitch=.06;origin=np.floor((m.bounds[0]-.3)/pitch)*pitch
shape=np.ceil((m.bounds[1]+.3-origin)/pitch).astype(int)+1
print('grid',shape.tolist(),int(np.prod(shape)),flush=True)
vol=np.zeros(shape[::-1],dtype=np.uint8)
for k in range(shape[2]):
 polygons=s.slice(origin[2]+k*pitch).to_polygons()
 polygons=sorted(polygons,key=lambda p:abs(np.cross(np.asarray(p),np.roll(p,-1,axis=0)).sum()),reverse=True)
 im=Image.new('1',(int(shape[0]),int(shape[1])));d=ImageDraw.Draw(im)
 for p in polygons:
  p=np.asarray(p);area=np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])
  xy=(p-origin[:2])/pitch
  d.polygon([tuple(x) for x in xy],fill=1 if area>0 else 0)
 vol[k]=np.asarray(im,dtype=np.uint8)
 if k%50==0:print('slice',k,flush=True)
structure=generate_binary_structure(3,1)
vol=binary_closing(vol,structure=structure)
vol=binary_opening(vol,structure=structure)
v,f,_,_=marching_cubes(vol,.5,spacing=(pitch,pitch,pitch),allow_degenerate=False)
m=trimesh.Trimesh(v[:,::-1]+origin,f[:,::-1],process=True);del vol
m=max(m.split(only_watertight=False),key=lambda q:abs(q.volume));m.fix_normals()
print('voxel',stats(m),flush=True)
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices,face_matrix=m.faces))
ms.meshing_decimation_quadric_edge_collapse(targetfacenum=250000,preservenormal=True,preservetopology=True,qualitythr=.3)
a=ms.current_mesh();m=trimesh.Trimesh(a.vertex_matrix(),a.face_matrix(),process=True);m.fix_normals()
m.export(P/'main_resampled.stl');m=trimesh.load_mesh(P/'main_resampled.stl')
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices,face_matrix=m.faces));ms.compute_selection_by_self_intersections_per_face()
print('final',stats(m),'SI',int(ms.current_mesh().face_selection_array().sum()),flush=True)
from audit_watch_v4 import audit
audit(P/'main_resampled.stl','V4_resampled')
