from inspect_watch_mesh import ROOT
from pathlib import Path
import json,shutil,hashlib,zipfile
import numpy as np,trimesh
from shapely.geometry import Polygon,LineString
SRC=ROOT/'局部加厚V3_待复核'
DEST=ROOT/'20261018_局部加厚V3_厂家复审';DEST.mkdir(exist_ok=True)
check=json.loads((SRC/'verification.json').read_text(encoding='utf-8'))
interface=json.loads((SRC/'interface_checks.json').read_text(encoding='utf-8'))
for p in check['parts']:
 assert p['components']==1 and p['stats']['watertight'] and p['self_intersections']==0
 assert p['stats']['boundary_edges']==p['stats']['nonmanifold_edges']==p['stats']['degenerate_faces']==0
assert all(c['after']<.001 for c in check['collisions'])
assert all(v['newly_blocked_points']==0 for v in interface.values())
files=[(SRC/'外壳_V3.stl','01_外壳_局部加厚V3.stl'),(SRC/'底部外壳_V3.stl','02_底部外壳_局部加厚V3.stl'),(SRC/'上横杆_V3.stl','03_上横杆_加厚V3.stl'),(ROOT/'下横杆.stl','04_下横杆_原版.stl'),(ROOT/'V0.2黄山派-按钮其一.stl','05_按钮其一_原版.stl'),(ROOT/'V0.2黄山派-按钮其二.stl','06_按钮其二_原版.stl')]
manifest=[]
for source,name in files:
 shutil.copy2(source,DEST/name);manifest.append(dict(file=name,sha256=hashlib.sha256((DEST/name).read_bytes()).hexdigest()))
main=trimesh.load_mesh(DEST/files[0][1]);back=trimesh.load_mesh(DEST/files[1][1]);bar=trimesh.load_mesh(DEST/files[2][1])
measure={}
sec=back.section(plane_origin=[0,0,0],plane_normal=[0,0,1]);loops=[Polygon(p[:,:2]) for p in sec.discrete]
boss=[]
for center in [(-46.326612,32.785691),(-15.571870,32.785691),(-42.136924,2.476229),(-19.761558,2.476229)]:
 near=[p for p in loops if np.linalg.norm(np.array(p.centroid.coords[0])-center)<.05]
 near=sorted(near,key=lambda p:p.area)
 assert len(near)==2
 wall=near[0].boundary.distance(near[1].boundary);assert wall>=1.1
 boss.append(dict(center_xy=center,wall_mm=wall))
measure['back_boss_walls']=boss
sec=bar.section(plane_origin=[-31,0,0],plane_normal=[1,0,0]);loops=sorted([Polygon(p[:,[1,2]]) for p in sec.discrete],key=lambda p:p.area)
wall=loops[0].boundary.distance(loops[1].boundary);assert wall>=1.0
measure['upper_bar_midsection_min_wall_mm']=wall
measure['upper_bar_thickness_before_after_mm']=[3.0,float(bar.extents[2])]
for label,y in [('front',-3.8),('rear',45.2)]:
 hit,_,_=main.ray.intersects_location(np.array([[-31,y,-8.]]),np.array([[0.,0.,1.]]),multiple_hits=True)
 z=np.sort(hit[:,2]);measure[label+'_reinforcement_center_z_intersections_mm']=z.tolist()
measure['note']='Thickness measurements are at named sections, not a guarantee of >=1 mm at every bevel/edge.'
print(json.dumps(measure,ensure_ascii=False,indent=2),flush=True)
complete=dict(mesh_checks=check,interface_sampling=interface,section_measurements=measure,manifest=manifest)
(DEST/'验证记录.json').write_text(json.dumps(complete,ensure_ascii=False,indent=2),encoding='utf-8')
text='''2026-10-18 黄山派 watch 表带版 局部加厚V3（供厂家重新审核）

本文件夹才是本次交付。不要使用“加厚候选”或V2工作目录里的中间文件。
原始文件和最初的网格修复版均保留，没有覆盖。

修改三件：
1. 主外壳：在长槽外侧、横杆螺孔周围增加局部实体；前后最外侧各增加约0.95 mm，下沿局部增加约0.74 mm。未整体缩放，主体仍位于原坐标。对新增材料扣除了现有底壳、按钮、横杆周围的避让空间。
2. 底部外壳：四个螺丝柱外径加到约4.8 mm，原孔径和柱高保留；底面周边薄缘补料。Z=0截面四个柱壁实测约1.13 mm。
3. 上横杆：总厚度从3.0 mm改为4.2 mm（上下各约0.6 mm）；宽度从约3.947 mm改为4.263 mm（两侧各约0.158 mm）。横杆长度、轴孔位置保留，轴孔截面使用原模型孔周顶点的投影包络重建，不缩小原孔道。中部截面最小壁厚约1.09 mm，上下孔壁约1.10–1.15 mm。
其余三件（下横杆、两个按钮）逐字节复制原文件。

已完成验证：
- 六件分别为一个连通封闭壳体，法线绕序一致。
- 重新读取STL后，开放边0、非流形边0、退化面0、MeshLab检测的自相交面0。
- 现有六件静态装配未发现明显新增干涉；上下壳约0.000028 mm³交集为与原件相当的数值级误差。
- 以0.1 mm网格抽样前后长槽直通通路及两组横杆螺孔通路，未发现原本通过而新版本被阻挡的采样点。
- 详细数据和SHA-256见“验证记录.json”。

验证边界：
上述是网格检查、静态干涉和指定截面/通路检查，不能保证真实表带接头、电路板、电池及插拔运动全部适配，也不能保证所有倒角/边缘任意位置均高于1 mm。新增外侧轮廓有可见变化。请让嘉立创对V3重新做薄壁审核，再确认打印；不能视作已通过平台审核或零风险生产。

上传时每个STL作为单独零件，两套则每款数量2。沿用9000HE白色时，价格需重新报价；尚未替换旧订单、接受风险或提交回复。
'''
(DEST/'先读说明.txt').write_text(text,encoding='utf-8-sig')
shutil.copy2(Path(__file__),DEST/'package_watch_wallfix_v3.py')
shutil.copy2(Path(__file__).parent/'watch_wallfix_simple_v3.py',DEST/'watch_wallfix_simple_v3.py')
shutil.copy2(Path(__file__).parent/'inspect_watch_mesh.py',DEST/'inspect_watch_mesh.py')
shutil.copy2(Path(__file__).parent/'check_watch_interfaces_v3.py',DEST/'check_watch_interfaces_v3.py')
# Archive after preview is written by a separate render step.
print('DEST',DEST,flush=True)
