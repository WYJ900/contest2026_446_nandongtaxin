"""Additive PA12 prototype; preserve originals, explicitly validate known assembly."""
import json
from pathlib import Path
import numpy as np, trimesh, manifold3d as md
from shapely.geometry import LineString
from inspect_watch_mesh import ROOT
WORK=ROOT/'局部加厚工作记录'
OUT=WORK/'加厚候选'
OUT.mkdir(exist_ok=True)
names=['外壳','底部外壳','上横杆','下横杆','V0.2黄山派-按钮其一','V0.2黄山派-按钮其二']
meshes=[trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{n}_修复.stl') for n in names]
def solid(m): return md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)))
def mesh(s):
 a=s.to_mesh();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
s=[solid(m) for m in meshes];main,back=s[:2]
centers=[(-46.326612,32.785691),(-15.571870,32.785691),(-42.136924,2.476229),(-19.761558,2.476229)]
back_new=back
for x,y in centers:
 ring=(md.Manifold.cylinder(4.75,2.4,circular_segments=128)-md.Manifold.cylinder(4.85,1.6,circular_segments=128).translate([0,0,-.05])).translate([x,y,-3.6088265])
 back_new=back_new+ring

def extrude_patch(m, mask, vector):
    p=m.submesh([np.flatnonzero(mask)],append=True,repair=False)
    v=p.vertices;f=p.faces;n=len(v)
    edges=p.edges; sorted_edges=np.sort(edges,axis=1)
    _,inv,counts=np.unique(sorted_edges,axis=0,return_inverse=True,return_counts=True)
    boundary=edges[counts[inv]==1]
    sides=np.vstack([np.c_[boundary[:,0],boundary[:,1],boundary[:,1]+n],np.c_[boundary[:,0],boundary[:,1]+n,boundary[:,0]+n]])
    inset=vector/np.linalg.norm(vector)*0.01
    closed=trimesh.Trimesh(np.vstack([v-inset,v+vector]),np.vstack([f[:,::-1],f+n,sides]),process=True)
    closed.fix_normals(multibody=True)
    out=solid(closed)
    assert out.status()==md.Error.NoError
    return out
m=meshes[0];c=m.triangles_center;n=m.face_normals
front_mask=(c[:,1]<-.8)&(n[:,1]<-.9)&(c[:,2]<1.7)
rear_mask=(c[:,1]>42.2)&(n[:,1]>.9)&(c[:,2]<1.7)
front=extrude_patch(m,front_mask,np.array([0,-1.0,0]))
rear=extrude_patch(m,rear_mask,np.array([0,1.0,0]))
# Retain clearance from the rear cover's unchanged outer envelope and new bosses.
back_guard=back_new.minkowski_sum(md.Manifold.cube([.3,.3,.3],center=True))
collars=(front+rear)-back_guard
main_new=(main+collars).simplify(0.00001)
new=[main_new,back_new]+s[2:]
for i,body in enumerate(new[:2]):
 assert body.status()==md.Error.NoError
 mesh(body).export(OUT/f'{names[i]}_局部加强_候选.stl')
 additions=body-s[i]
 mesh(additions).export(OUT/f'{names[i]}_新增材料.stl')
 print(names[i],'before',s[i].volume(),'after',body.volume(),'removed',(s[i]-body).volume(),'components',len(body.decompose()),flush=True)
for i in range(2):
 for j in range(len(new)):
  if i==j:continue
  before=(s[i]^s[j]).volume();after=(new[i]^new[j]).volume()
  print('collision',names[i],names[j],before,after,flush=True)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
fig=plt.figure(figsize=(13,7))
for k in range(2):
 ax=fig.add_subplot(1,2,k+1,projection='3d')
 base=meshes[k];add=mesh(new[k]-s[k])
 for obj,color in [(base,'#a0aebb'),(add,'#e6a13b')]:
  tri=obj.triangles
  coll=Poly3DCollection(tri,facecolors=color,linewidths=0,alpha=1,shade=True,lightsource=matplotlib.colors.LightSource(azdeg=225,altdeg=45))
  ax.add_collection3d(coll)
 lo=np.minimum(base.bounds[0],add.bounds[0]);hi=np.maximum(base.bounds[1],add.bounds[1]);center=(lo+hi)/2
 ax.set_xlim(center[0]-25,center[0]+25);ax.set_ylim(center[1]-27,center[1]+27);ax.set_zlim(-6,11)
 ax.set_box_aspect((50,54,17));ax.view_init(elev=30,azim=-65);ax.set_axis_off();ax.set_title(['Main shell: external lip reinforcement','Rear cover: screw-boss collars'][k])
fig.suptitle('Orange = added material; grey = original geometry')
fig.tight_layout();fig.savefig(WORK/'reinforcement_preview.png',dpi=150)
