from pathlib import Path
import json
import numpy as np,trimesh,pymeshlab as pm
from inspect_watch_mesh import ROOT,stats
WORK=ROOT/'局部加厚工作记录';OUT=WORK/'加厚候选'
results=[]
for name in ['外壳','底部外壳']:
 old=trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{name}_修复.stl')
 new=trimesh.load_mesh(OUT/f'{name}_局部加强_候选.stl')
 ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=new.vertices,face_matrix=new.faces));ms.compute_selection_by_self_intersections_per_face()
 result=dict(name=name,stats=stats(new),self_intersections=int(ms.current_mesh().face_selection_array().sum()),topology=ms.get_topological_measures())
 np.random.seed(17);points,fi=trimesh.sample.sample_surface(new,18000);normals=new.face_normals[fi]
 hit,ri,tf=new.ray.intersects_location(points-normals*.0001,-normals,multiple_hits=False)
 dist=np.linalg.norm(hit-points[ri],axis=1);opp=np.einsum('ij,ij->i',normals[ri],new.face_normals[tf])<-.5
 thin=opp&(dist<1)&(dist>.001)
 result['thin_samples']=int(thin.sum());result['thickness_quantiles']=np.quantile(dist[opp],[0,.01,.05,.1,.5]).tolist()
 np.savez(WORK/f'{name}_candidate_thickness.npz',points=points[ri],thickness=dist,opposing=opp,normals=normals[ri])
 results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
(WORK/'candidate_verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
plt.rcParams['font.sans-serif']=['Microsoft YaHei'];plt.rcParams['axes.unicode_minus']=False
fig=plt.figure(figsize=(14,7),facecolor='white')
for i,name in enumerate(['外壳','底部外壳']):
 old=trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{name}_修复.stl');new=trimesh.load_mesh(OUT/f'{name}_局部加强_候选.stl')
 ax=fig.add_subplot(1,2,i+1,projection='3d')
 distances=trimesh.proximity.closest_point(old,new.triangles_center)[1]
 colors=np.tile(matplotlib.colors.to_rgba('#b0bac3'),(len(new.faces),1));colors[distances>.015]=matplotlib.colors.to_rgba('#ed9c27')
 ax.add_collection3d(Poly3DCollection(new.triangles,facecolors=colors,linewidths=0,shade=True,lightsource=matplotlib.colors.LightSource(azdeg=220,altdeg=50)))
 mid=new.bounds.mean(0);ax.set_xlim(mid[0]-25,mid[0]+25);ax.set_ylim(mid[1]-27,mid[1]+27);ax.set_zlim(-6,11)
 ax.set_box_aspect((50,54,17));ax.view_init(elev=30,azim=-65);ax.set_axis_off()
 ax.set_title(['主外壳：长槽外侧局部凸出约 1 mm','底壳：四个螺丝柱外径增大，孔径保留'][i],fontsize=13)
fig.suptitle('外观评审草案｜橙色为新增外表面｜未上传、非定稿',fontsize=17)
fig.tight_layout();fig.savefig(WORK/'局部加厚方案预览.png',dpi=160)
