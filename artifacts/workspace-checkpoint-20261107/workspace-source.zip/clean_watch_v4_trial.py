from inspect_watch_mesh import ROOT,stats
from audit_watch_v4 import audit
import trimesh,numpy as np,pymeshlab as pm,pymeshfix,json
P=ROOT/'20261018_V4_工作记录'
m=trimesh.load_mesh(P/'main_trial.stl');m.merge_vertices(digits_vertex=5);m.update_faces(m.nondegenerate_faces());m.update_faces(m.unique_faces());m.remove_unreferenced_vertices()
parts=m.split(only_watertight=False);parts=sorted(parts,key=lambda x:x.area,reverse=True)
print('PARTS',[(len(x.faces),x.area,x.volume) for x in parts[:10]],flush=True)
m=parts[0]
fix=pymeshfix.MeshFix(m.vertices,m.faces);fix.repair(joincomp=False,remove_smallest_components=True)
m=trimesh.Trimesh(fix.points,fix.faces,process=True)
print('FIX',stats(m),flush=True)
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=m.vertices,face_matrix=m.faces))
# MeshFix addresses the isolated intersections. Avoid global remeshing of interfaces.
a=ms.current_mesh();m=trimesh.Trimesh(a.vertex_matrix(),a.face_matrix(),process=True);m.export(P/'main_clean.stl')
print('REMESH',stats(m),flush=True)
ms.compute_selection_by_self_intersections_per_face();print('SELF_INTERSECTIONS',int(ms.current_mesh().face_selection_array().sum()),flush=True)
audit(P/'main_clean.stl','V4_main_trial')
