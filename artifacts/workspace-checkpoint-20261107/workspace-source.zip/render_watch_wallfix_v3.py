from inspect_watch_mesh import ROOT
import numpy as np,trimesh,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
plt.rcParams['font.sans-serif']=['Microsoft YaHei'];plt.rcParams['axes.unicode_minus']=False
DEST=ROOT/'20261018_局部加厚V3_厂家复审'
parts=[('外壳','01_外壳_局部加厚V3.stl'),('底部外壳','02_底部外壳_局部加厚V3.stl'),('上横杆','03_上横杆_加厚V3.stl')]
fig=plt.figure(figsize=(18,7),facecolor='white')
labels=['主外壳：长槽与螺孔外侧局部加强','底壳：螺丝柱外径加大、底缘补料','上横杆：厚度 3.0 → 4.2 mm']
for i,(name,file) in enumerate(parts):
 old=trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{name}_修复.stl');new=trimesh.load_mesh(DEST/file)
 ax=fig.add_subplot(1,3,i+1,projection='3d')
 d=trimesh.proximity.closest_point(old,new.triangles_center)[1]
 colors=np.tile(matplotlib.colors.to_rgba('#b4bec7'),(len(new.faces),1));colors[d>.02]=matplotlib.colors.to_rgba('#e99a29')
 # Uniform matte coloring avoids treating triangulation as a surface texture.
 light=np.clip(new.face_normals@np.array([-.25,-.3,.5])+.8,.65,1)
 colors[:,:3]*=light[:,None]
 ax.add_collection3d(Poly3DCollection(new.triangles,facecolors=colors,linewidths=0))
 mid=new.bounds.mean(0)
 if i<2:
  ax.set_xlim(mid[0]-25,mid[0]+25);ax.set_ylim(mid[1]-27,mid[1]+27);ax.set_zlim(-6,11);ax.set_box_aspect((50,54,17));ax.view_init(elev=32,azim=-65)
 else:
  ax.set_xlim(mid[0]-20,mid[0]+20);ax.set_ylim(mid[1]-4,mid[1]+4);ax.set_zlim(mid[2]-4,mid[2]+4);ax.set_box_aspect((40,8,8));ax.view_init(elev=20,azim=-55)
 ax.set_axis_off();ax.set_title(labels[i],fontsize=13,y=.94)
fig.suptitle('2026-10-18 局部加厚 V3｜橙色为变化区域｜本地检查通过，待厂家复审',fontsize=18,y=.98)
fig.text(.5,.04,'保留原坐标；静态装配与指定通路检查通过。未验证真实表带、电路板、电池及打印收缩后的装配。',ha='center',fontsize=13)
fig.tight_layout(rect=[0,.08,1,.93]);fig.savefig(DEST/'修改位置预览.png',dpi=160)
with zipfile.ZipFile(ROOT/'20261018_局部加厚V3_厂家复审.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in DEST.iterdir():
  if p.is_file():z.write(p,p.name)
print(DEST,flush=True)
