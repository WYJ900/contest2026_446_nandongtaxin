from inspect_watch_mesh import ROOT,stats
import numpy as np,trimesh,manifold3d as md,pymeshlab as pm,pymeshfix,json
OUT=ROOT/'局部加厚V2_待复核';OUT.mkdir(exist_ok=True)
names=['外壳','底部外壳','上横杆','下横杆','V0.2黄山派-按钮其一','V0.2黄山派-按钮其二']
meshes=[trimesh.load_mesh(ROOT/'修复版_单件STL'/f'{n}_修复.stl') for n in names]
def s(m):return md.Manifold(md.Mesh64(np.asarray(m.vertices,dtype=np.float64),np.asarray(m.faces,dtype=np.uint64)))
def m(s):
 a=s.to_mesh64();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=False)
solids=[s(x) for x in meshes];main,back,bar=solids[:3]
back_new=back
for x,y in [(-46.326612,32.785691),(-15.571870,32.785691),(-42.136924,2.476229),(-19.761558,2.476229)]:
 ring=(md.Manifold.cylinder(4.75,2.4,circular_segments=128)-md.Manifold.cylinder(4.85,1.6,circular_segments=128).translate([0,0,-.05])).translate([x,y,-3.6088265])
 back_new=back_new+ring
z=-4.0632
back_new=back_new+back.slice(z).simplify(.005).extrude(z-meshes[1].bounds[0,2]).translate([0,0,meshes[1].bounds[0,2]])
lo,hi=meshes[2].bounds
box=md.Manifold.cube(hi-lo).translate(lo)
filled=s(meshes[2].convex_hull)
bar_new=(bar+filled.translate([0,0,.6])+filled.translate([0,0,-.6]))-(box-bar)
report=[]
for i,new in [(1,back_new),(2,bar_new)]:
 new=new.simplify(.001);path=OUT/f'{names[i]}_局部加厚V2.stl';m(new).export(path);re=trimesh.load_mesh(path)
 nominal=re.copy();re.vertices=np.round(re.vertices,5);re.merge_vertices()
 rv,rf=pymeshfix.clean_from_arrays(np.asarray(re.vertices,dtype=np.float64),np.asarray(re.faces,dtype=np.int32),joincomp=False,remove_smallest_components=False)
 re=trimesh.Trimesh(rv,rf,process=True);re.fix_normals(multibody=True);re.export(path);re=trimesh.load_mesh(path)
 ms=pm.MeshSet();ms.add_mesh(pm.Mesh(vertex_matrix=re.vertices,face_matrix=re.faces));ms.compute_selection_by_self_intersections_per_face()
 d=dict(file=path.name,stats=stats(re),euler=int(re.euler_number),self_intersections=int(ms.current_mesh().face_selection_array().sum()),collisions=[])
 np.random.seed(18);ps,_=trimesh.sample.sample_surface(re,10000);d['cleanup_max_deviation_mm']=float(trimesh.proximity.closest_point(nominal,ps)[1].max())
 for j,other in enumerate(solids):
  if j!=i:d['collisions'].append(dict(part=names[j],original_mm3=(solids[i]^other).volume(),modified_mm3=(s(re)^other).volume()))
 print(json.dumps(d,ensure_ascii=False),flush=True);report.append(d)
(OUT/'back_bar_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
