from inspect_watch_mesh import ROOT
import numpy as np,trimesh,manifold3d as md
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
plt.rcParams['font.sans-serif']=['Microsoft YaHei'];plt.rcParams['axes.unicode_minus']=False
P=ROOT/'20261018_V4_工作记录'
new=trimesh.load_mesh(P/'main_deliver.stl');old=trimesh.load_mesh(ROOT/'修复版_单件STL'/'外壳_修复.stl')
render=new
centers=render.triangles_center;dist=[]
for i in range(0,len(centers),1000):dist.extend(trimesh.proximity.closest_point(old,centers[i:i+1000])[1])
colors=np.tile(matplotlib.colors.to_rgba('#b4bec7'),(len(render.faces),1));colors[np.array(dist)>.12]=matplotlib.colors.to_rgba('#e99a29')
light=np.clip(render.face_normals@np.array([-.25,-.3,.5])+.8,.65,1);colors[:,:3]*=light[:,None]
fig=plt.figure(figsize=(15,7),facecolor='white')
for i,az in enumerate([-65,115]):
 ax=fig.add_subplot(1,2,i+1,projection='3d');ax.add_collection3d(Poly3DCollection(render.triangles,facecolors=colors,linewidths=0))
 mid=new.bounds.mean(0);ax.set_xlim(mid[0]-25,mid[0]+25);ax.set_ylim(mid[1]-27,mid[1]+27);ax.set_zlim(-6,11);ax.set_box_aspect((50,54,17));ax.view_init(elev=34,azim=az);ax.set_axis_off()
 ax.set_title(['主外壳正面','主外壳背面'][i],fontsize=14)
fig.suptitle('V4 复审版｜橙色为主要变化区域｜本地检查通过，待厂家审核',fontsize=18)
fig.tight_layout();fig.savefig(P/'V4修改预览.png',dpi=150)
